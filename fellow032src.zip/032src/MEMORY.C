/*==========================*/
/* Fellow 1997 Petter Schau */
/* Memory system            */
/*==========================*/
 
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "defs.h"
#include "fellow.h"
#include "inout.h"
#include "68000.h"
#include "draw.h"
#include "memorya.h"
#include "fhfile.h"
#include "graphem.h"
#include "floppy.h"
#include "copper.h"
#include "led.h"
#include "cianew.h"

int meminitfirsttime = TRUE;
ULO config_memory_fast_allocated = 0;

/* Configuration for rom */

ULO config_memory_nokick;
UBY config_memory_kickname[256];
UBY config_memory_kicknameloaded[256];
ULO config_memory_kicksize;
ULO config_memory_romversion;
char kickstart_idstring[80];

#ifdef AF_MODE
char config_memory_keyname[256];
#endif

/* Configuration for memory sizes */

ULO config_memory_chipsize,config_memory_bogosize;
ULO config_memory_fastsize;

ULO spritewritebuffer[128][2];
ULO spritewritenext;
ULO spritewritereal;
ULO screenmode;

/* Declare functions in this file */

ULO meminit(void);
void dumpioblock(void);
void hexdump(ULO wher);

/* Table of register read/write functions */

regreadfunc ioread[256] = {rdefault,rdmaconr,rvposr,rvhposr,
                           rdefault,rdefault,rdefault,rdefault,
                           rdefault,rdefault,rdefault,rdefault,
                           rserdatr,rdefault,rintenar,rintreqr,
                           rdefault,rdefault,rdefault,rdefault,
                           rdefault,rdefault,rdefault,rdefault,
                           rdefault,rdefault,rdefault,rdefault,
                           rdefault,rdefault,rdefault,rdefault,
                           rdefault,rdefault,rdefault,rdefault,
                           rdefault,rdefault,rdefault,rdefault,
                           rdefault,rdefault,rdefault,rdefault,
                           rdefault,rdefault,rdefault,rdefault,
                           rdefault,rdefault,rdefault,rdefault,
                           rdefault,rdefault,rdefault,rdefault,
                           rdefault,rdefault,rdefault,rdefault,
                           rdefault,rdefault,rid,rdefault,
                           rdefault,rdefault,rdefault,rdefault,
                           rcopjmp1,rcopjmp2,rdefault,rdefault,
                           rdefault,rdefault,rdefault,rdefault,
                           rdefault,rdefault,rdefault,rdefault,
                           rdefault,rdefault,rdefault,rdefault,
                           rdefault,rdefault,rdefault,rdefault,
                           rdefault,rdefault,rdefault,rdefault,
                           rdefault,rdefault,rdefault,rdefault,
                           rdefault,rdefault,rdefault,rdefault,
                           rdefault,rdefault,rdefault,rdefault,
                           rdefault,rdefault,rdefault,rdefault,
                           rdefault,rdefault,rdefault,rdefault,
                           rdefault,rdefault,rdefault,rdefault,
                           rdefault,rdefault,rdefault,rdefault,
                           rdefault,rdefault,rdefault,rdefault,
                           rdefault,rdefault,rdefault,rdefault,
                           rdefault,rdefault,rdefault,rdefault,
                           rdefault,rdefault,rdefault,rdefault,
                           rdefault,rdefault,rdefault,rdefault,
                           rdefault,rdefault,rdefault,rdefault,
                           rdefault,rdefault,rdefault,rdefault,
                           rdefault,rdefault,rdefault,rdefault,
                           rdefault,rdefault,rdefault,rdefault,
                           rdefault,rdefault,rdefault,rdefault,
                           rdefault,rdefault,rdefault,rdefault,
                           rdefault,rdefault,rdefault,rdefault,
                           rdefault,rdefault,rdefault,rdefault,
                           rdefault,rdefault,rdefault,rdefault,
                           rdefault,rdefault,rdefault,rdefault,
                           rdefault,rdefault,rdefault,rdefault,
                           rdefault,rdefault,rdefault,rdefault,
                           rdefault,rdefault,rdefault,rdefault,
                           rdefault,rdefault,rdefault,rdefault,
                           rdefault,rdefault,rdefault,rdefault,
                           rdefault,rdefault,rdefault,rdefault,
                           rdefault,rdefault,rdefault,rdefault,
                           rdefault,rdefault,rdefault,rdefault,
                           rdefault,rdefault,rdefault,rdefault,
                           rdefault,rdefault,rdefault,rdefault,
                           rdefault,rdefault,rdefault,rdefault,
                           rdefault,rdefault,rdefault,rdefault,
                           rdefault,rdefault,rdefault,rdefault,
                           rdefault,rdefault,rdefault,rdefault,
                           rdefault,rdefault,rdefault,rdefault,
                           rdefault,rdefault,rdefault,rdefault,
                           rdefault,rdefault,rdefault,rdefault,
                           rdefault,rdefault,rdefault,rdefault,
                           rdefault,rdefault,rdefault,rdefault};

regwritefunc iowrite[256]={wdefault,wdefault,wdefault,wdefault,
                           wdefault,wdefault,wdefault,wdefault,
                           wdefault,wdefault,wdefault,wdefault,
                           wdefault,wdefault,wdefault,wdefault,
                           wdefault,wdefault,wdefault,wdefault,
                           wdefault,wdefault,wvpos,wcopcon,
                           wdefault,wdefault,wdefault,wdefault,
                           wdefault,wdefault,wdefault,wdefault,
                           wbltcon0,wbltcon1,wbltafwm,wbltalwm,
                           wbltcpth,wbltcptl,wbltbpth,wbltbptl,
                           wbltapth,wbltaptl,wbltdpth,wbltdptl,
                           wbltsize,wdefault,wdefault,wdefault,
                           wbltcmod,wbltbmod,wbltamod,wbltdmod,
                           wdefault,wdefault,wdefault,wdefault,
                           wbltcdat,wbltbdat,wbltadat,wdefault,
                           wdefault,wdefault,wdefault,wdefault,
                           wcop1lch,wcop1lcl,wcop2lch,wcop2lcl,
                           wcopjmp1,wcopjmp2,wdefault,wdiwstrt,
                           wdiwstop,wddfstrt,wddfstop,wdmacon,
                           wdefault,wintena,wintreq,wadcon,
                           wdefault,wdefault,wdefault,wdefault,
                           wdefault,wdefault,wdefault,wdefault,
                           wdefault,wdefault,wdefault,wdefault,
                           wdefault,wdefault,wdefault,wdefault,
                           wdefault,wdefault,wdefault,wdefault,
                           wdefault,wdefault,wdefault,wdefault,
                           wdefault,wdefault,wdefault,wdefault,
                           wdefault,wdefault,wdefault,wdefault,
                           wbpl1pth,wbpl1ptl,wbpl2pth,wbpl2ptl,
                           wbpl3pth,wbpl3ptl,wbpl4pth,wbpl4ptl,
                           wbpl5pth,wbpl5ptl,wbpl6pth,wbpl6ptl,
                           wdefault,wdefault,wdefault,wdefault,
                           wbplcon0,wbplcon1,wbplcon2,wdefault,
                           wbpl1mod,wbpl2mod,wdefault,wdefault,
                           wdefault,wdefault,wdefault,wdefault,
                           wdefault,wdefault,wdefault,wdefault,
                           wspr0pth,wspr0ptl,wspr1pth,wspr1ptl,
                           wspr2pth,wspr2ptl,wspr3pth,wspr3ptl,
                           wspr4pth,wspr4ptl,wspr5pth,wspr5ptl,
                           wspr6pth,wspr6ptl,wspr7pth,wspr7ptl,
                           wsprxpos,wsprxctl,wsprxdata,wsprxdatb,
                           wsprxpos,wsprxctl,wsprxdata,wsprxdatb,
                           wsprxpos,wsprxctl,wsprxdata,wsprxdatb,
                           wsprxpos,wsprxctl,wsprxdata,wsprxdatb,
                           wsprxpos,wsprxctl,wsprxdata,wsprxdatb,
                           wsprxpos,wsprxctl,wsprxdata,wsprxdatb,
                           wsprxpos,wsprxctl,wsprxdata,wsprxdatb,
                           wsprxpos,wsprxctl,wsprxdata,wsprxdatb,
                           wcolor,wcolor,wcolor,wcolor,
                           wcolor,wcolor,wcolor,wcolor,
                           wcolor,wcolor,wcolor,wcolor,
                           wcolor,wcolor,wcolor,wcolor,
                           wcolor,wcolor,wcolor,wcolor,
                           wcolor,wcolor,wcolor,wcolor,
                           wcolor,wcolor,wcolor,wcolor,
                           wcolor,wcolor,wcolor,wcolor,
                           wdefault,wdefault,wdefault,wdefault,
                           wdefault,wdefault,wdefault,wdefault,
                           wdefault,wdefault,wdefault,wdefault,
                           wdefault,wdefault,wdefault,wdefault,
                           wdefault,wdefault,wdefault,wdefault,
                           wdefault,wdefault,wdefault,wdefault,
                           wdefault,wdefault,wdefault,wdefault,
                           wdefault,wdefault,wdefault,wdefault};

/* Different variables used by the decode routines to scroll bitplanes */

ULO evenscroll,evenhiscroll,oddscroll,oddhiscroll;

/* Variables that correspond to various registers */

ULO dmaconr,dmacon;
ULO intenar,intena,intreq;

/* Screen related registers */

ULO bpl1pt,bpl2pt,bpl3pt,bpl4pt,bpl5pt,bpl6pt;

ULO lof,xpos,ypos,diwxleft,diwxright,diwytop,diwybottom,ddfstrt,
    ddfstop,
    bplcon0,bplcon1,bplcon2,bpl1mod,bpl2mod,diwstrt,diwstop;

/* Helpers for the screen emulation */

ULO screenptr;

/* Global line specific data */

ULO DDFstartpos,DDFnumberofwords,DIWfirstvisiblepos,DIWlastvisiblepos;
ULO DIWfirstposonline,DIWlastposonline;

/* Copper registers */

ULO copcon,cop1lc,cop2lc;

/* Blitter registers */

ULO linenum,linecount,linelength,blitterdmawaiting,
    bltadatoff,bltbdatoff,bltadattmp,bltbdattmp,
    bltcdattmp;

/* Sprite registers */

ULO sprpt[8],sprx[8],spry[8],sprly[8],spratt[8];
ULO spritestate[8];
ULO sprite16col[8];
UWO sprdat[8][2];

/* Actual memory */

UBY cmem[CHIPMEM+32];
UBY bmem[BOGOMEM+32];
UBY kmem[KICKMEM+32];
UBY emem[65536];
UBY *fmem = NULL;
UBY dmem[4096];
ULO dmemcounter;
ULO wriorgadr;

/*=======================*/
/* Memory mapping tables */
/*=======================*/

readfunc memory_bank_readbyte[256];
readfunc memory_bank_readword[256];
readfunc memory_bank_readlong[256];
writefunc memory_bank_writebyte[256];
writefunc memory_bank_writeword[256];
writefunc memory_bank_writelong[256];
char *memory_bank_pointers[256];

/*==========================*/
/* Memory mapping functions */
/*==========================*/

void memory_bank_set(readfunc rb, readfunc rw, readfunc rl, writefunc wb,
		     writefunc ww, writefunc wl, char *basep, ULO bank,
		     ULO basebank) {
  if (bank < 256) {
    memory_bank_readbyte[bank] = rb;
    memory_bank_readword[bank] = rw;
    memory_bank_readlong[bank] = rl;
    memory_bank_writebyte[bank] = wb;
    memory_bank_writeword[bank] = ww;
    memory_bank_writelong[bank] = wl;
    if (basep != NULL) memory_bank_pointers[bank] = basep - (basebank*0x10000);
    else memory_bank_pointers[bank] = NULL;
  }
}

void memory_bank_clear(ULO bank) {
  memory_bank_set(readnotavailablebyte, readnotavailableword,
		  readnotavailablelong, writenotavailablebyte,
		  writenotavailableword, writenotavailablelong, NULL, bank, 0);
}

void memory_bank_clear_all(void) {
  ULO bank;
  for (bank = 0; bank < 256; bank++) memory_bank_clear(bank);
}

/*=======================*/
/* Expansion card config */
/*=======================*/

/* Used to be hardwired for fastmemory, but to obtain a configdev */
/* the hardfile must also be a fake expansion card */

#define EMEM_MAX_CARDS 4

/* Number of cards */

int emem_cards, emem_cards_finished;

/* Card init and map functiontable */

ememinitfunc emem_card_initfunc[EMEM_MAX_CARDS];
ememmapfunc emem_card_mapfunc[EMEM_MAX_CARDS];

/* Clear */

void memory_emem_clear(void) {
  int i;
  for (i = 0; i < 65536; i++) emem[i] = 0xff;
}

/* Add card to tables */

void memory_emem_add_card(ememinitfunc cardinit, ememmapfunc cardmap) {
  if (emem_cards < EMEM_MAX_CARDS) {
    emem_card_initfunc[emem_cards] = cardinit;
    emem_card_mapfunc[emem_cards] = cardmap;
    emem_cards++;
  }
  else addlog("Autoconfig card addition failed, too many cards\n");
}

/* Kill all cards */

void memory_emem_kill_cards(void) {
  emem_cards = emem_cards_finished = 0;
}

/* Reset card setup */

void memory_emem_reset_cards(void) {
  emem_cards_finished = 0;
  memory_emem_this_card_init();
}

/* Init this card */

void memory_emem_this_card_init(void) {
  memory_emem_clear();
  if (emem_cards_finished == emem_cards) memory_emem_clear();
  else emem_card_initfunc[emem_cards_finished]();
} 

/* Map this card */

void memory_emem_this_card_map(ULO mapping) {
  if (emem_cards_finished == emem_cards) memory_emem_clear();
  else emem_card_mapfunc[emem_cards_finished++](mapping);
} 

/* Set a byte in autoconfig space, for initfunc routines */

void set_emem(ULO address, ULO value) {
  address &= 0xffff;
  switch (address) {
    case 0:
    case 2:
    case 0x40:
    case 0x42:
      emem[address] = value & 0xf0;
      emem[address+2] = (value & 0xf)<<4;
      break;
    default:
      emem[address] = ~(value & 0xf0);
      emem[address+2] = ~((value & 0xf)<<4);
      break;
    }
}

/* Read stubs for autoconfig */

#pragma aux reademembyte parm [ecx] value [edx];
ULO reademembyte(ULO address) {
  return emem[address&0xffff];
}

#pragma aux readememword parm [ecx] value [edx];
ULO readememword(ULO address) {
  return 0xffff;
}

#pragma aux readememlong parm [ecx] value [edx];
ULO readememlong(ULO address) {
  return 0xffffffff;
}

/* Write stubs for autoconfig */

#pragma aux writeemembyte parm [ecx] [edx];
void writeemembyte(ULO address, ULO data) {
  static ULO mapping;
  push_eax();
  data &= 0xff;
  switch (wriorgadr & 0xffff) {
    case 0x30:
    case 0x32:
      data = 0;
    case 0x48:
      mapping = (mapping & 0xff) | ((data & 0xff)<<8);
      memory_emem_this_card_map(mapping);
      memory_emem_this_card_init();
      break;
    case 0x4a:
      mapping = (mapping & 0xff00) | (data & 0xff);
      break;
    case 0x4c:
      emem_cards_finished++;
      memory_emem_this_card_init();
      break;
    }
  pop_eax();
  restore_ecx();
}

#pragma aux writeememword parm [ecx] [edx];
void writeememword(ULO address, ULO data) {
  restore_ecx();
}

#pragma aux writeememlong parm [ecx] [edx];
void writeememlong(ULO address, ULO data) {
  restore_ecx();
}

/* End of autoconfig */
/*===================*/


/* Functions to set dmem */

void dmem_clear(void) {
  int i;
  for (i = 0; i < 4096; i++) dmem[i] = 0;
}

void dmem_setcounter(ULO c) {
  dmemcounter = c;
}

ULO dmem_getcounter(void) {
  return dmemcounter + 0xf40000;
}

void dsets(char *st) {
  strcpy(dmem+dmemcounter,st);
  dmemcounter += strlen(st)+1;
  if (dmemcounter & 0x1) dmemcounter++;
}

void dsetb(UBY data) {
  dmem[dmemcounter++] = data;
}

void dsetw(UWO data) {
  dmem[dmemcounter++] = (data&0xff00)>>8;
  dmem[dmemcounter++] = data&0xff;
}

void dsetl(ULO data) {
  dmem[dmemcounter++] = (data&0xff000000)>>24;
  dmem[dmemcounter++] = (data&0xff0000)>>16;
  dmem[dmemcounter++] = (data&0xff00)>>8;
  dmem[dmemcounter++] = data&0xff;
}

#pragma aux readdmembyte parm [ecx] value [edx];
ULO readdmembyte(ULO address){
  ULO tmpval = 0;

  push_ecx();
  if ((address&0xffffff) < 0xf41000) tmpval = dmem[address&0xfff];
  pop_ecx();
  return tmpval;
}

#pragma aux readdmemword parm [ecx] value [edx];
ULO readdmemword(ULO address){
  ULO tmpval = 0;

  push_ecx();
  if ((address&0xffffff) < 0xf41000)
    tmpval = (dmem[address&0xfff]<<8) | dmem[(address&0xfff)+1];
  pop_ecx();
  return tmpval;
}

#pragma aux readdmemlong parm [ecx] value [edx];
ULO readdmemlong(ULO address){
  ULO tmpval = 0;
  push_ecx();

  if ((address&0xffffff) < 0xf41000)
    tmpval = (dmem[address&0xfff]<<24) | (dmem[(address&0xfff)+1]<<16) | (dmem[(address&0xfff)+2]<<8) | dmem[(address&0xfff)+3];
  pop_ecx();
  return tmpval;
}

#pragma aux writedmemlong parm [ecx] [edx];
void writedmemlong(ULO address, ULO data){
  push_ad();
  if ((wriorgadr & 0xffffff) == 0xf40000) {
    switch (data>>16) {
      case 0x0001:    fhfile_do(data);
                      break;
      default:        break;
      }
    }
  pop_ad();
  restore_ecx();
}

/* Used by hardfile, assume AmigaDOS never gives us a faulty address... */

UBY *address_to_ptr(ULO address) {
  address &= 0xffffff;
  if (address < 0x200000) return &cmem[address];
  else if (address < 0xa00000) return fmem + (address - 0x200000);
  else if (address < 0xdc0000) return &bmem[address - 0xc00000];
  return &kmem[address - 0xf80000];
}

void memory_chip_clear(void) {
  int i;
  for (i = 0; i < config_memory_chipsize; i++) cmem[i] = 0;
}

void memory_chip_map(void) {
  ULO bank, lastbank;
  if (config_memory_chipsize > 0x200000) lastbank = 0x200000>>16;
  else lastbank = config_memory_chipsize>>16;
  for (bank = 0; bank < lastbank; bank++)
    memory_bank_set(readchipbyte, readchipword, readchiplong,
		    writechipbyte, writechipword, writechiplong,
		    cmem, bank, 0);
  for (bank = lastbank; bank < (0x200000>>16); bank++) memory_bank_clear(bank);
  memory_chip_clear();
}

/* Set up autoconfig values for fastmem card */

void memory_fastcard_init(void) {
  addlog("Fastcard init\n");
  if (config_memory_fastsize == 0x100000) set_emem(0,0xe5);
  else if (config_memory_fastsize == 0x200000) set_emem(0,0xe6);
  else if (config_memory_fastsize == 0x400000) set_emem(0,0xe7);
  else if (config_memory_fastsize == 0x800000) set_emem(0,0xe0);
  set_emem(8,128);
  set_emem(4,1);
  set_emem(0x10,2011>>8);
  set_emem(0x14,2011&0xf);
  set_emem(0x18,0);
  set_emem(0x1c,0);
  set_emem(0x20,0);
  set_emem(0x24,1);
  set_emem(0x28,0);
  set_emem(0x2c,0);
  set_emem(0x40,0);
}

/* Map fastcard, should really map it to the address amigados tells us */
/* but assume it is 0x200000 for now */

void memory_fastcard_map(ULO mapping) {
  ULO bank, lastbank, i;

  if (config_memory_fastsize > 0x800000) lastbank = 0xa00000>>16;
  else lastbank = (0x200000 + config_memory_fastsize)>>16;
  for (bank = 0x200000>>16; bank < lastbank; bank++)
    memory_bank_set(readfastbyte, readfastword, readfastlong,
		    writefastbyte, writefastword, writefastlong,
		    fmem, bank, 0x200000>>16);
  for (i = 0; i < config_memory_fastsize; i++) fmem[i] = 0;
}

/* Clear fastmem address space tables */

void memory_inittables_fast_clear(void) {
  ULO bank;

  for (bank = 0x200000>>16; bank < (0xa00000>>16); bank++)
    memory_bank_clear(bank);
}

/* Allocate fastmemory, and if successful, enter the fastcard in the */
/* autoconfig tables */

void memory_inittables_fast_first(void) {
  ULO origmem = config_memory_fastsize;
  char s[80];

  addlog ("Allocating fast memory and possibly inserting card in table\n");
  sprintf(s, "Fast size: %d Allocated=%d\n", config_memory_fastsize,
	  config_memory_fast_allocated);
  addlog(s);
  if (config_memory_fast_allocated != config_memory_fastsize) {
    addlog("Need to allocate\n");
    if (fmem != NULL) free(fmem);
    if (config_memory_fastsize == 0) {
      addlog("Fastsize is 0, no alloc\n");
      config_memory_fast_allocated = 0;
      memory_inittables_fast_clear();
      return;
    }
    addlog("Allocating\n");
    fmem = (UBY *) malloc(config_memory_fastsize);
    if (fmem == NULL) {
      addlog("Alloc failed\n");
      if (!meminitfirsttime) freeadfcache();
      fmem = (UBY *) malloc(config_memory_fastsize);
      if (fmem == NULL) {
        addlog("Disalloc of adf-cache, still bad\n");
        config_memory_fastsize >>= 1;
        while (config_memory_fastsize >= 0x100000 && fmem == NULL) {
          fmem = (UBY *) malloc(config_memory_fastsize);
          if (fmem == NULL) config_memory_fastsize >>= 1;
	}
      }
      if (!meminitfirsttime) {
        if (config_memory_fastsize < 0x100000 || fmem == NULL)
          config_memory_fastsize = 0;
        fgui_fastmemAllocFail(origmem>>20, config_memory_fastsize>>20);
        disk_initinmem();
        disk_reinsertImages();
        if (fmem == NULL) {           /* Something is very wrong */
          config_memory_fastsize = config_memory_fast_allocated = 0;
          memory_inittables_fast_clear();
          return;
	}
      }
    }
  }
  addlog("Ending fast-alloc\n");
  config_memory_fast_allocated = config_memory_fastsize;
  memory_inittables_fast_clear();
  if (config_memory_fastsize > 0)
    memory_emem_add_card(memory_fastcard_init, memory_fastcard_map);
}

void memory_bogo_map(void) {
  ULO bank, lastbank, i;

  if (config_memory_bogosize > 0x1c0000) lastbank = 0xdc0000>>16;
  else lastbank = (0xc00000 + config_memory_bogosize)>>16;
  for (bank = 0xc00000>>16; bank < lastbank; bank++)
    memory_bank_set(readbogobyte, readbogoword, readbogolong,
		    writebogobyte, writebogoword, writebogolong,
		    bmem, bank, 0xc00000>>16);
  for (i = 0; i < config_memory_bogosize; i++) bmem[i] = 0;
}

void memory_register_map(void) {
  ULO bank, lastbank;
  if (config_memory_bogosize > 0x1c0000) lastbank = 0xdc0000>>16;
  else lastbank = (0xc00000 + config_memory_bogosize)>>16;
  for (bank = lastbank; bank < 0xe00000>>16; bank++)
    memory_bank_set(readregisterbyte, readregisterword, readregisterlong,
		    writeregisterbyte, writeregisterword, writeregisterlong,
		    NULL, bank, 0);
}

/* Map autoconfig to 0xe80000 */
/* Will also setup the first card */

void memory_emem_map(void) {
  ULO bank = 0xe80000>>16;
  memory_bank_set(reademembyte, readememword, readememlong,
		  writeemembyte, writeememword, writeememlong,
		  emem, bank, bank);
}

void memory_dmem_map(void) {
  ULO bank = 0xf40000>>16;
  if (config_fhfile_enabled)
    memory_bank_set(readdmembyte, readdmemword, readdmemlong,
		    writenotavailablebyte, writenotavailableword,
		    writedmemlong, dmem, bank, bank);
}

void memory_rom_map(void) {
  ULO bank;

#ifdef AF_MODE
  for (bank = AF_MAP_ROM>>16; bank < ((AF_MAP_ROM + 0x80000)>>16); bank++)
    memory_bank_set(readkickbyteaf, readkickwordaf, readkicklongaf,
		    writenotavailablebyte, writenotavailableword,
		    writenotavailablelong, kmem, bank, AF_MAP_ROM>>16);
#endif

  for (bank = 0xf80000>>16; bank < (0x1000000>>16); bank++)
    memory_bank_set(readkickbyte, readkickword, readkicklong,
		    writenotavailablebyte, writenotavailableword,
		    writenotavailablelong, kmem, bank, 0xf80000>>16);
}

char *rom_identify( char *s ) {
  int i = 0;

  if( !strncmp( &kmem[0x88], "exec", 4 ) ) {
    strcpy( s, "Kickstart 1.1 [" );
    strncat( s, &kmem[0x88], strlen( &kmem[0x88] )  - 2 );
    strcat( s, "]" );
    config_memory_romversion = 0x101;
    return s;
  };
  if( !strncmp( &kmem[0x3b], "AMIGA ROM", 9 ) ) {
    strcpy( s, "Kickstart 1.3 [" );
    strncat( s, &kmem[0x18], strlen( &kmem[0x18] ) - 2 );
    strcat( s, "]" );
    if( kmem[0x1e] == '3' ) {
      s[12] = '2';
      config_memory_romversion = 0x102;
    }
    else config_memory_romversion = 0x103;
    return s;
  };
  if( !strncmp( &kmem[0x31], "AMIGA ROM", 9 ) ) {
    strcpy( s, "Kickstart 2.04 [" );
    strncat( s, &kmem[0x18], strlen( &kmem[0x18] )  - 2 );
    strcat( s, "]" );
    config_memory_romversion = 0x200;
    return s;
  };
  if( !strncmp( &kmem[0x35], "AMIGA ROM", 9 ) ) {
    strcpy( s, "Kickstart 2.0 [" );
    strncat( s, &kmem[0x18], strlen( &kmem[0x18] )  - 2 );
    strcat( s, "]" );
    config_memory_romversion = 0x200;
    return s;
  };
  if( !strncmp( &kmem[0x9c], "exec", 4 ) ) {
    strcpy( s, "Kickstart " );
    while( kmem[i+0x85] != ' ' ) { strncat( s, &kmem[i+0x85], 1 ); i++; };
    strcat( s, " [" );
    strncat( s, &kmem[0x9c], strlen( &kmem[0x9c] )  - 2 );
    strcat( s, "]" );
    config_memory_romversion = 0x300;
    return s;
  };
  if( !strncmp( &kmem[0x9b], "exec", 4 ) ) {
    strcpy( s, "Kickstart " );
    while( kmem[i+0x85] != ' ' ) { strncat( s, &kmem[i+0x85], 1 ); i++; };
    strcat( s, " [" );
    strncat( s, &kmem[0x9b], strlen( &kmem[0x9b] )  - 2 );
    strcat( s, "]" );
    config_memory_romversion = 0x301;
    return s;
  };
  strcpy( s, "Unknown Kickstart, assuming V2.0" );
  config_memory_romversion = 0x200;
  return s;
};


#ifdef AF_MODE

int memory_decode_af_rom(char *filename, char *keyfile) {
  char *keybuffer;
  int keysize, filesize = 0, keypos = 0, c;
  FILE *KF, *RF;

  /* Read key */
  
  if ((KF = fopen(keyfile, "rb")) != NULL) {
    fseek(KF, 0, SEEK_END);
    keysize = ftell(KF);
    keybuffer = malloc(keysize);
    fseek(KF, 0, SEEK_SET);
    fread(keybuffer, 1, keysize, KF);
    fclose(KF);
  }
  else return -1;
  if (!keybuffer) return -1;  

  /* Read file */

  if ((RF = fopen(filename, "rb")) != NULL) {
    for (c = 0; c < 11; c++) fgetc(RF);
    while (((c = fgetc(RF)) != EOF) && filesize < 524288) {
      if (keysize != 0) c ^= keybuffer[keypos++];
      if (keypos == keysize) keypos = 0;
      kmem[filesize++] = c;
    }
    while ((c = fgetc(RF)) != EOF) filesize++;
    fclose(RF);
    free(keybuffer);
    return filesize;
  }
  free(keybuffer);
  return -1;
}
  

/* Load Amiga Forever encrypted ROM-files */
/* Return TRUE if file was handled, that is both if the file is */
/* valid, or has wrong version */

int memory_loadrom_af2(FILE *F) {
  int version,i;
  char *temppath;

  if (fgetc(F) == 'A')
    if (fgetc(F) == 'M')
      if (fgetc(F) == 'I')
	if (fgetc(F) == 'R')
	  if (fgetc(F) == 'O')
	    if (fgetc(F) == 'M')
	      if (fgetc(F) == 'T')
		if (fgetc(F) == 'Y')
		  if (fgetc(F) == 'P')
		    if (fgetc(F) == 'E') {
		      if ((version = fgetc(F)) == '1') {
			int size;

			/* File has correct header */
			fclose(F);

			/* Test if keyfile exists */

			if ((F = fopen(config_memory_keyname, "rb")) == NULL) {
			  fgui_loadrom_keymissing(config_memory_keyname);
			  config_memory_nokick = TRUE;
			  config_memory_romversion = 0;
			  strcpy(config_memory_kicknameloaded, "__None__");
			  strcpy(config_memory_kickname, "__None__");
			  return TRUE;
			}
			else {
			  fclose(F);
			  
			  size = memory_decode_af_rom(config_memory_kickname,
						      config_memory_keyname);
			  if (size > 0) { /* File maybe OK */
			    if (size != 262144 && size != 524288) {
			      /* File decoded to a weird size */

			      config_memory_nokick = TRUE;
			      fgui_loadrom_wrongsize(config_memory_kickname,
						     size);
			      config_memory_romversion = 0;
			      strcpy(config_memory_kicknameloaded, "__None__");
			      strcpy(config_memory_kickname, "__None__");
			      return TRUE;
			    }

			    if (size == 262144)
			      for (i = 0; i < 262144; i++)
				kmem[i + 262144] = kmem[i];
          
			    config_memory_nokick = FALSE;
			    strcpy(config_memory_kicknameloaded,
				   config_memory_kickname);
			    rom_identify(kickstart_idstring);
			    return TRUE;
			  }
			}

			return TRUE;  /* Size less than zero, some error */
		      }
		      else {
			config_memory_nokick = TRUE;
			fgui_loadrom_af_wrong_version(version - '0');
			config_memory_romversion = 0;
			strcpy(config_memory_kicknameloaded, "__None__");
			strcpy(config_memory_kickname, "__None__");
			return TRUE;
		      }
		    }
  /* Here, header was not recognized */
  return FALSE;
}

#endif

/* config_memory_kickname is the file we want to load */
/* config_memory_kicknameloaded is the file we currently have in memory */
/* Initially kickname is set to kick.rom */

/* Could add some error messages */

void memory_loadrom(void) {
  FILE *F;
  ULO i;

  if (stricmp(config_memory_kickname,config_memory_kicknameloaded) != 0) {

    /* New file is different from previous */
    /* Must load file */

    config_memory_nokick = FALSE;            /* Initially Kickstart is OK */
    if ((F = fopen(config_memory_kickname,"rb")) == NULL)
      config_memory_nokick = TRUE;           /* Kickstart NOT OK */

    /* Either the file is open, or config_memory_nokick is TRUE */ 

    if (!config_memory_nokick) {

      /* File opened successfully */
      /* mem_loadrom_af2 will return TRUE if file was handled */
      /* Handled also means any error conditions */
      /* The result can be that no kickstart was loaded */

#ifdef AF_MODE
      if (memory_loadrom_af2(F)) return;
#endif

      /* Here file is not encypted, go on as normal */

      fseek(F,0,SEEK_END);                      /* Check size */
      config_memory_kicksize = ftell(F);
      fseek(F,0,SEEK_SET);

      if (config_memory_kicksize == 262144) {   /* Load 256k ROM */
        fread(kmem,1,262144,F);
        for (i=0; i < 262144; i++) kmem[i+262144] = kmem[i];
      }
      else if (config_memory_kicksize == 524288)/* Load 512k ROM */
        fread(kmem,1,524288,F);
      else {                                     /* Rom size is wrong */
        fgui_loadrom_wrongsize(config_memory_kickname, config_memory_kicksize);
        config_memory_nokick = TRUE;
      }
      fclose(F);
    }
    if (config_memory_nokick) config_memory_romversion = 0;
    else {
      strcpy(config_memory_kicknameloaded, config_memory_kickname);
      rom_identify(kickstart_idstring);
    }
  }
}

void memory_initreg(void) {
  ULO k,m;
  /* Initialize Screen Registers*/
  lof = 0x8000;       /* Always long frame, or maybe not...*/
  bpl1mod = 0;
  bpl2mod = 0;
  diwxleft = 0;
  diwxright = 0; 
  diwytop = 0;   
  diwybottom = 0;
  bpl1pt = 0;
  bpl2pt = 0;
  bpl3pt = 0;
  bpl4pt = 0;
  bpl5pt = 0;
  bpl6pt = 0;
  bplcon0 = 0;
  bplcon1 = 0;
  bplcon2 = 0;
  ddfstrt = 0;
  ddfstop = 0;
  diwstrt = 0;
  diwstop = 0;
  intena = 0;
  intreq = 0;
  
  /* Initialize the helpers for screenemulation */
  /* Assume no bitplanes on */

  screenptr = (ULO) framebuffer + 12832 + (scanlineadd*8);

  DDFstartpos = 0;
  DDFnumberofwords = 0;
  DIWfirstvisiblepos = 256;
  DIWlastvisiblepos = 256;
  DIWfirstposonline = 88;

  /* Initialize various registers*/
  dmaconr = 0;
  dmacon = 0;

  /* Zero the shadow color registers */
  for (k=0; k<64; k++) shadcol[k] = 0;
  spritewritenext = 0;
  spritewritereal = 0;
}

ULO vgareg2color[256];

void mem_initcolortranslation(void) {
  ULO k,r,g,b;
  /* Create color translation table */
  if (config_graphics_modebits[config_graphics_mode] == 8) {
    ULO rbt[16] = { 0,0,1,1,1,2,2,2,3,3,3,4,4,4,5,5};
    ULO gt[16] = { 0,0,1,1,1,2,2,3,3,3,4,4,5,5,6,6};
    /* Use 6 levels of red and blue, 7 levels of green */
    for (k=0; k<4096;k++) {
      colortab[k] = rbt[k & 0xf] + gt[(k & 0xf0)>>4]*6 + rbt[(k & 0xf00)>>8]*42;
      vgareg2color[colortab[k]] = k;
      colortab[k] = colortab[k]<<24 |colortab[k]<<16 |colortab[k]<<8 | colortab[k];
    }
    for (r = 0; r < 6; r++) 
      for (g = 0; g < 7; g++)
	for (b = 0; b < 6; b++)
	  set_VGAcolor(b+(g*6)+(r*42),b*11+b,g*10,r*11+r);

  }
  else if (config_graphics_modebits[config_graphics_mode] == 15) {
    for (k=0; k<4096;k++) {
      colortab[k] = ((k & 0xf)<<1) | ((k & 0xf0)<<2) | ((k & 0xf00)<<3);
      colortab[k] = colortab[k]<<16 | colortab[k];
    }
    powerledcolor = 0x7c007c00;
    drivemotorcolor = 0x03e003e0;
    hdledcolor = 0x73807380;
  }
  else {
    for (k=0; k<4096;k++) {
      colortab[k] = ((k & 0xf)<<1) | ((k & 0xf0)<<3) | ((k & 0xf00)<<4);
      colortab[k] = colortab[k]<<16 | colortab[k];
    }
    powerledcolor = 0xf800f800;
    drivemotorcolor = 0x07e007e0;
    hdledcolor = 0x0e700e700;
  }   
}

/* Must be called every time memory sizes change */

void memory_init(void) {
  char str[80];

  memory_initreg();

  /* Initialize the jumptables */
  /* There is some redundancy here, but just make sure there are no */
  /* NULL ptrs in the tables, clear it all to a default value */

  memory_emem_kill_cards();
  memory_bank_clear_all();
  memory_chip_map();
  memory_inittables_fast_first();
  cia_map();
  memory_bogo_map();
  memory_register_map();
  memory_emem_map();
  memory_rom_map();
  memory_loadrom();
  memory_dmem_map();
  meminitfirsttime = FALSE;
}

void memory_cleanup(void) {
  if (fmem != NULL) free(fmem);
}




