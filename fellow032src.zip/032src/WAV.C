/*===========================*/
/* Fellow 1997 Petter Schau  */
/* Dump sound output to file */
/*===========================*/

#include <stdio.h>
#include <stdlib.h>
#include "defs.h"
#include "fellow.h"
#include "sound.h"
#include "graphem.h"
#include "draw.h"

/* Write sound output to wav file */
/* Files named fwavX.wav X increasing number for each time */

FILE *WAVFILE;
int wav_serialno = 0;
int old_sound_config, old_sound_mode, old_skiprate;
add_sample_to_buffer_routine old_putinbuffer;

/* Write WAV header to F */
/* FILE *F     - output file, already open */
/* int seconds - seconds of sound in file */
/* int rate    - samplerate */
/* int stereo  - flag, TRUE if stereo */
/* int bits16  - flag, TRUE if 16 bit */

void wav_genHeader(FILE *F, int seconds, int rate, int stereo, int bits16) {
  int filelength = seconds*rate*(stereo+1)*(bits16 + 1) + 42;
  int bytespersecond = filelength/seconds;
  int bits = (bits16+1)*8;
  fputc('R', F); fputc('I', F); fputc('F', F); fputc('F', F);
  fwrite(&filelength, 4, 1, F);
  filelength -= 42;
  fputc('W', F); fputc('A', F); fputc('W', F); fputc('E', F);
  fputc('f', F); fputc('m', F); fputc('t', F); fputc(' ', F);
  fputc(0x01, F); fputc(0, F);          /* Wave-format PCM */
  fputc(stereo + 1, F); fputc(0, F);    /* Channels in file */
  fwrite(&rate, 4, 1, F);               /* Sample rate */
  fwrite(&bytespersecond, 4, 1, F);     /* Bytes per second */
  fputc(0, F); fputc(0, F);             /* Block align */
  fwrite(&bits, 4, 1, F);               /* Bits */
  fputc('d', F); fputc('a', F); fputc('t', F); fputc('a', F);
  fwrite(&filelength, 4, 1, F);
}  

ULO eaxsaved;
void save_eax(void);
#pragma aux save_eax="mov [eaxsaved],eax";
void restore_eax(void);
#pragma aux restore_eax="mov eax,[eaxsaved]";

void call_oldputinbuffer(int newsamples);
#pragma aux call_oldputinbuffer="call dword ptr [old_putinbuffer]"\
                                 parm [ebx];

#pragma aux wav_add_sample parm [ebx];
void wav_add_sample(ULO newsamples) {
  int i;
  save_eax();
  for (i = 0; i < newsamples; i++) {
    fwrite(&right[i], 2, 1, WAVFILE);
    fwrite(&left[i], 2, 1, WAVFILE);
  }
  call_oldputinbuffer(newsamples);
  restore_eax();
}

/* Returns TRUE if OK */

int wav_capture_start(int seconds, int play) {
  char filename[40];
  int error = FALSE;
  old_sound_config = config_sound;
  old_skiprate = frameskip;
  old_sound_mode = config_sound_mode;
  sprintf(filename,"FWAV%d.WAV",wav_serialno++);
  if ((WAVFILE = fopen(filename,"wb"))) { 
    wav_genHeader(WAVFILE, seconds, 45454, 1, 1);
    if (play) {
      config_sound = 1;
      config_sound_mode = 0;
      sound_initmode();
    }
    else {
      config_sound = 3;               /* Setup sound-emu, no play */
      sound_initmode();
      audio_handler = audio_frequency_handler_44100;
      initperiodtable(45454);
    }
    old_putinbuffer = audio_putinbuffer;
    audio_putinbuffer = wav_add_sample;
    frameskip = 0x7ffffff;
  }
  else error = TRUE;
  return error;
}

void wav_capture_stop(void) {
  fclose(WAVFILE);
  config_sound = old_sound_config;
  config_sound_mode = old_sound_mode;
  frameskip = old_skiprate;
  sound_initmode();
}
