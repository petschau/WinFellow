/* Defines, some must be set also in include\asm\defs.inc */

/*==========================================================================*/
/* Number of graphics-modes supported, this stuff should be scrapped with a */
/* complete modularization of the device-dependent part of the drawing      */
/*==========================================================================*/

#define NROFMODES 14

/*=====================================================================*/
/* Use graphics emulation in C, replaces USE_C some time in the future */
/*=====================================================================*/

/*#define GRAPHEM_C*/

/*================================================*/
/* Use graphics and drawing routines written in C */
/* Broken for the moment                          */
/*================================================*/

/*#define USE_C*/

/*=============================================*/
/* Enable logging of various Amiga events like */
/* Cpu history and irq/exception logging       */
/*=============================================*/

/*#define DEBUGBUILD*/

/* Don't try these */
/*#define TEST_EVENTS_SANITY*/
/*#define CPU_TRACE_TO_FILE*/

/*===================================*/
/* 68000 prefetch word emulation     */
/* Slower, but some programs need it */
/* Not compatible with PC_PTR        */
/*===================================*/

/*#define PREFETCH*/

/*==============================*/
/* Use direct memory PC-pointer */
/*==============================*/

#define PC_PTR

/*===============================================*/
/* Support licensed AI software on Amiga Forever */
/*===============================================*/

#define AF_MODE
#define AF_MAP_ROM 0xe00000

/*=============================*/
/* C versus Assembly selection */
/*=============================*/

/*==========================*/
/* Use sound emulation in C */
/* Somewhat buggy now       */
/*==========================*/

/*#define SOUND_C*/

/*======================================*/
/* Use Planar to chunky conversion in C */
/* Works                                */
/*======================================*/

/*#define PLANAR_C*/

/*==============================*/
/* Use framebuffer drawing in C */
/* Not updated for a while      */
/*==============================*/

/*#define DRAW_C*/

/*================================*/
/* The rest is not wise to change */
/*================================*/

/*#define TSC_PROFILING*/

/*===========================*/
/* Some global hardfile defs */
/*===========================*/

#define FHFILE_MAX_DEVICES 10

#define FHFILE_NONE 0
#define FHFILE_HDF 1
#define FHFILE_ADF 2


/* Maximum values for memory, don't change */

#define CHIPMEM 0x200000
#define FASTMEM 0x800000
#define BOGOMEM 0x1c0000
#define KICKMEM 0x080000

#define UBY unsigned char
#define UWO unsigned short int
#define ULO unsigned long
#define BYT signed char
#define WOR signed short int
#define LON signed long
#define FALSE 0
#define TRUE 1

typedef ULO amigaadress;
typedef ULO (*readfunc)();
typedef void (*writefunc)();
typedef ULO (*ciareadfunc)(ULO i);
typedef void (*ciawritefunc)(ULO i, ULO data);
typedef ULO (*regreadfunc)();
typedef void (*regwritefunc)();

/*------------------------------------*/
/* The decode routines have this type */
/*------------------------------------*/

typedef void (*decoderoutinetype)(ULO,ULO);

extern UBY configromname[];

void irq_off(void);
void irq_on(void);
#pragma aux irq_off="cli";
#pragma aux irq_on="sti";

typedef union {
          ULO *lptr;
          UWO *wptr;
          UBY *bptr;
          ULO lval;
          UWO wval[2];
          UBY bval[4];
          } ptunion;

#define LORES 1
#define HIRES 2

typedef void (*planar2chunkyroutine)(void);

typedef void (*add_sample_to_buffer_routine)(ULO amount);
typedef ULO (*setup_soundmode_routine)(void);
typedef void (*playbuffer_routine)(void);
typedef void (*sound_before_emu_routine)(void);
typedef void (*sound_after_emu_routine)(void);

typedef void (*draw_routine_ptr)(void);

typedef ULO (*eareadfunc)(ULO);
typedef void (*eawritefunc)(ULO,ULO);
typedef ULO (*eacalcfunc)(ULO);


typedef void (*audiostatefunc)(int);
typedef void (*audiofreqhandlerfunc)(void);

typedef void (*buseventfunc)(void);

void push_ad(void);
void pop_ad(void);
#pragma aux push_ad="pushad";
#pragma aux pop_ad="popad";

void push_eax(void);
void pop_eax(void);
#pragma aux push_eax="push eax";
#pragma aux pop_eax="pop eax";

extern ULO wriorgadr;
void restore_ecx(void);
#pragma aux restore_ecx="mov ecx,dword ptr [wriorgadr]";

void push_ecx(void);
void pop_ecx(void);
#pragma aux push_ecx="push ecx";
#pragma aux pop_ecx="pop ecx";


#ifdef TSC_PROFILING
extern __int64 total_tsc;
extern ULO total_tsctimes;
extern __int64 decodehi2_tsc;
extern ULO decodehi2_tsctimes;
#endif

#define CYCLESPERLINE    228
#define CYCLESPERFRAME 71364
#define LINESPERFRAME    313

typedef void (*ememinitfunc)(void);
typedef void (*ememmapfunc)(ULO);


