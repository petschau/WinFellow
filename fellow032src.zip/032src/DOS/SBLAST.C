/*================================*/
/* Fellow Emulator                */
/* Soundblaster specific routines */
/* Petter Schau 1996/1997         */
/*================================*/

#include <stdio.h>
#include <dos.h>
#include <stdlib.h>
#include <conio.h>
#include "defs.h"
#include "sound.h"
#include "memory.h"
#include "keyboard.h"
#include "draw.h"
#include "sblasta.h"            /* Symbols defined in sblasta.asm */
#include "inout.h"

char *auddmaptr;                /* pointer to dma buffer */
ULO config_sb_forceV1;          /* Force using soundblaster V1 code */
ULO stereo;                     /* Stereo sound flag (playing) */
ULO bits16;                     /* 16bit sound flag (playing) */
ULO actualrate;
ULO playbuffer,editbuffer;      /* Doublebuffered sound, 0 or 1 */
ULO sb_irqbufferfinished;       /* Flag set when irq occurs */
ULO sb_oldirqmask1;
ULO sb_oldirqmask2;
ULO sb_halted;
ULO sb_playcmd16;
ULO sb_playmode16;

ULO emuspeed;
ULO sbxpos,sbypos,sbframe;

int sbio;
int sbirq;
int sbdma8;
int sbdma16;
int dspmajor;
int dspminor;
void (__interrupt __far *sboldirqvector)();
ULO sbsamplerate;

ULO dmasize;
ULO dmaselector;
ULO dmaaddress;
ULO dmapage;
ULO dmaflataddr;

ULO sb_mode_setup(void);

/*============================================*/
/* Callbacks to add samples to the dma-buffer */
/*============================================*/

#ifdef SOUND_C

void sb_8bit_mono_put_in_buffer(ULO samples) {
  int i;

  for (i = 0; i < samples; i++)
    *(auddmaptr + i) = ((left[i] + right[i])>>8) + 0x80;
  auddmaptr += samples;
}

void sb_8bit_stereo_put_in_buffer(ULO samples) {
  int i;

  for (i = 0; i < samples; i++) {
    *(auddmaptr + i) = (left[i]>>8) + 0x80;
    *(auddmaptr + i + 1) = (right[i]>>8) + 0x80;
    }
  auddmaptr += samples*2;
}

void sb_16bit_mono_put_in_buffer(ULO samples) {
  int i;

  for (i = 0; i < samples; i++)
    *(((WOR *) auddmaptr) + i) = left[i] + right[i];
  auddmaptr += samples*2;
}

void sb_16bit_stereo_put_in_buffer(ULO samples) {
  int i;

  for (i = 0; i < samples; i++) {
    *(((WOR *) auddmaptr) + 2*i) = left[i];
    *(((WOR *) auddmaptr) + 2*i + 2) = right[i];
    }
  auddmaptr += samples*4;
}

#endif


/*===========*/
/* DMA setup */
/*===========*/


/*---------------*/
/* DMA-registers */
/*---------------*/

#define SINGLE_MASK_8           0xa
#define SINGLE_MASK_16          0xd4
#define CLEAR_BYTEPTR_8         0xc
#define CLEAR_BYTEPTR_16        0xd8
#define SET_MODE_8              0xb
#define SET_MODE_16             0xd6
#define SET_PAGENR_CH0          0x87
#define SET_PAGENR_CH1          0x83
#define SET_PAGENR_CH2          0x81
#define SET_PAGENR_CH3          0x82
#define SET_PAGENR_CH4          0x8f
#define SET_PAGENR_CH5          0x8b
#define SET_PAGENR_CH6          0x89
#define SET_PAGENR_CH7          0x8a

/*-----------*/
/* DMA-modes */
/*-----------*/

#define DMA_MODE_READ           0x8
#define DMA_MODE_AUTOINIT       0x10
#define DMA_MODE_SINGLE         0x40

/*=====================*/
/* Mask single channel */
/*=====================*/

static void dma_maskchannel(int ch) {
  if (ch < 4) outp(SINGLE_MASK_8, ch | 4);
  else outp(SINGLE_MASK_16, (ch & 3) | 4);
}

/*========================*/
/* Clear byte ptr         */
/* (any value will clear) */
/*========================*/

static void dma_clearbyteptr(int ch) {
  if (ch < 4) outp(CLEAR_BYTEPTR_8, 0);
  else outp(CLEAR_BYTEPTR_16, 0);
}

/*==============*/
/* Set dma-mode */
/*==============*/

static void dma_setmode(int ch) {
  if (ch < 4) outp(SET_MODE_8, ch | DMA_MODE_READ | DMA_MODE_SINGLE);
  else outp(SET_MODE_16, (ch & 3) | DMA_MODE_READ | DMA_MODE_SINGLE);
}

/*=================*/
/* Set page number */
/*=================*/

static void dma_setpagenr(int ch) {
  switch(ch) {
    case 0: outp(SET_PAGENR_CH0, dmapage);
            break;
    case 1: outp(SET_PAGENR_CH1, dmapage);
            break;
    case 2: outp(SET_PAGENR_CH2, dmapage);
            break;
    case 3: outp(SET_PAGENR_CH3, dmapage);
            break;
    case 4: outp(SET_PAGENR_CH4, dmapage);
            break;
    case 5: outp(SET_PAGENR_CH5, dmapage);
            break;
    case 6: outp(SET_PAGENR_CH6, dmapage);
            break;
    case 7: outp(SET_PAGENR_CH7, dmapage);
            break;
    }
}

/*=============*/
/* Set address */
/*=============*/

static void dma_setaddress(int ch) {
  UWO address=((((ch < 4) ? (dmaflataddr): (dmaflataddr>>1)) & 0xffff));

  if (ch < 4) {
    if (playbuffer == 1) address += 20000;
    outp(ch<<1, address & 0xFF);
    outp(ch<<1, address>>8);
    }
  else {
    if (playbuffer == 1) address += 10000;
    outp(0xc0 | ((ch & 3)<<2), address & 0xFF);
    outp(0xc0 | ((ch & 3)<<2), address>>8);
    }
}

/*============*/
/* Set length */
/*============*/

static void dma_setlength(int ch) {
  if (ch < 4) {
    outp((ch<<1) | 1,(dmasize - 1) & 0xff);
    outp((ch<<1) | 1,(dmasize - 1)>>8);
    }
  else {
    outp(0xc2 | ((ch & 3)<<2),(dmasize - 1) & 0xff);
    outp(0xc2 | ((ch & 3)<<2),(dmasize - 1)>>8);
    }
}

/*========================*/
/* Un-Mask single channel */
/*========================*/

static void dma_unmaskchannel(int ch) {
  if (ch < 4) outp(SINGLE_MASK_8, ch);
  else outp(SINGLE_MASK_16, ch & 3);
}

/*================================*/
/* One procedure to bind them all */
/*================================*/

static void dma_inittransfer(void) {
  if (bits16) {
    dma_maskchannel(sbdma16);
    dma_clearbyteptr(sbdma16);
    dma_setmode(sbdma16);
    dma_setpagenr(sbdma16);
    dma_setaddress(sbdma16);
    dma_setlength(sbdma16);
    dma_unmaskchannel(sbdma16);
    }
  else {
    dma_maskchannel(sbdma8);
    dma_clearbyteptr(sbdma8);
    dma_setmode(sbdma8);
    dma_setpagenr(sbdma8);
    dma_setaddress(sbdma8);
    dma_setlength(sbdma8);
    dma_unmaskchannel(sbdma8);
    }
}

/* END OF DMA-SPECIFIC CODE */
/*==========================*/

/*==================*/
/* SB SPECIFIC CODE */
/*==================*/

/*==============*/
/* SB Registers */
/*==============*/

#define SB_MIXER_REG            4
#define SB_MIXER_DATA           5
#define SB_DSP_RESET            6
#define SB_DSP_READ_DATA        0xa
#define SB_DSP_WRITE            0xc
#define SB_DSP_DATA_AVAILABLE   0xe
#define SB_DSP_IRQ_ACK_8        0xe
#define SB_DSP_IRQ_ACK_16       0xf

/*==============*/
/* DSP commands */
/*==============*/

#define DSP_SET_TIMECONSTANT    0x40
#define DSP_ENABLE_SPEAKER      0xd1
#define DSP_DISABLE_SPEAKER     0xd3
#define DSP_SET_DMA_BLOCK_SIZE  0x48
#define DSP_SINGLE_HI_DMA_DAC   0x91
#define DSP_DMA_DAC             0x14
#define DSP_VERSION             0xe1
#define DSP_HALT_8              0xd0
#define DSP_CONTINUE_8          0xd4

/*================*/
/* Mixer commands */
/*================*/

#define MIXER_OUTPUT_STEREO_SELECT      0xe

/*==================*/
/* Read DSP command */
/*==================*/

static ULO sb_cmdread(void) {
  while (!(inp(sbio + SB_DSP_DATA_AVAILABLE) & 0x80));
  return inp(sbio + SB_DSP_READ_DATA);
}

/*===================*/
/* Write DSP command */
/*===================*/
static void sb_cmdwrite(UBY val) {
  while ((inp(sbio + SB_DSP_WRITE) & 0x80));
  outp(sbio + SB_DSP_WRITE, val);
}

/*====================*/
/* Read Mixer command */
/*====================*/

static ULO sb_mixread(ULO reg) {
  outp(sbio + SB_MIXER_REG, reg);
  return inp(sbio + SB_MIXER_DATA);
}

/*=====================*/
/* Write Mixer command */
/*=====================*/

static void sb_mixwrite(ULO reg, ULO val) {
  outp(sbio + SB_MIXER_REG, reg);
  outp(sbio + SB_MIXER_DATA, val);
}

/*================*/
/* Speaker output */
/*================*/

static void sb_enable_speaker(void) {
  sb_cmdwrite(DSP_ENABLE_SPEAKER);        
}

static void sb_disable_speaker(void) {
  sb_cmdwrite(DSP_DISABLE_SPEAKER);        
}

/*============================*/
/* Play on SB 1.XX and SB 2.0 */
/*============================*/

static void sb_playV1(void) {
  sb_cmdwrite(DSP_DMA_DAC);                 /* Start lospeed dma */
  sb_cmdwrite((dmasize - 1) & 0xff);        /* dma size */
  sb_cmdwrite((dmasize - 1)>>8);
}

/*============================*/
/* Play on SB PRO and SB V2.0 */
/*============================*/

static void sb_playPRO(void) {
  if (stereo || (!stereo && actualrate > 23000)) {
    sb_cmdwrite(DSP_SET_DMA_BLOCK_SIZE);   
    sb_cmdwrite((dmasize - 1) & 0xff);
    sb_cmdwrite((dmasize - 1)>>8);
    sb_cmdwrite(DSP_SINGLE_HI_DMA_DAC);     
  }
  else sb_playV1();
}

/*================*/
/* Play on SB 16  */
/*================*/

static void sb_play16(void) {
  sb_cmdwrite(sb_playcmd16);  
  sb_cmdwrite(sb_playmode16);
  sb_cmdwrite((dmasize - 1) & 0xff);
  sb_cmdwrite((dmasize - 1)>>8);
}

/*========================*/
/* Start playing a buffer */
/*========================*/

static void sb_start_playing_buffer(void) {
  dma_inittransfer(); 
  if (dspmajor >= 4) sb_play16();
  else if (dspmajor >= 2) sb_playPRO();
  else sb_playV1();
}

/*=================================*/
/* Free DOS-memory used for buffer */
/*=================================*/

static void sb_freebuffer (void) {
  static union REGS reg;
  reg.x.eax = 0x0101;
  reg.x.edx = dmaselector;
  int386(0x31, &reg, &reg);
}

/*=====================================*/
/* Allocate DOS-memory used for buffer */
/*=====================================*/

static int sb_allocatebuffer(int size) {
  ULO addr;
  static union REGS reg;

  reg.x.eax = 0x0100;                        /* DPMI Mem. Allocation */
  reg.x.ebx = ((size*2) + 15)>>4;            /* # of paragraphs to alloc. */
  int386(0x31, &reg, &reg);            
  if (reg.x.cflag) return 1;                 /* error alloc. mem. */
  dmaselector = reg.x.edx;                   /* get the base selector */
  addr = (reg.x.eax & 0xFFFF)<<4;            /* get the real segment adress */
  if ((addr>>16) != ((addr + size - 1)>>16))
    addr = (addr + size) & 0xffff0000;
  dmaflataddr = addr;                        /* get the 20 bit real adress */
  dmapage = dmaflataddr>>16;
  return 0;
}

/*=============*/
/* Irq handler */
/*=============*/

/* NOTE: The performace calculation does not belong here */

void __interrupt __far sb_irqhandler() {
  emuspeed = ((frames - sbframe)*71364) + (ypos*228) + xpos;
  emuspeed = (emuspeed*10000)/356820;
  if (emuspeed > 10000) emuspeed = 10000;
  sb_irqbufferfinished = 1;
  if (bits16) inp(sbio + SB_DSP_IRQ_ACK_16);    /* Clear SB-irq source */
  else inp(sbio + SB_DSP_IRQ_ACK_8);
  if (sbirq > 7) outp(0xA0,0x20);               /* Clear PIC */
  outp(0x20,0x20);
}

/*===========*/
/* Reset DSP */
/*===========*/

static int sb_resetdsp(void) {
  outp(sbio + SB_DSP_RESET, 1);   /* write 1 to reset port */
  delay(100);
  outp(sbio + SB_DSP_RESET, 0);   /* write 0 to reset port */
  delay(100);
  return !(inp(sbio + SB_DSP_READ_DATA) == 0xaa); 
}

/*==============================================*/
/* Initialize the irq-vector and enable the irq */
/*==============================================*/

void sb_initirq(void) {
  lock_region((void near *)sb_irqhandler, 1024);
  lock_region(&emuspeed, sizeof(emuspeed));
  lock_region(&frames, sizeof(frames));
  lock_region(&sbframe, sizeof(sbframe));
  lock_region(&xpos, sizeof(xpos));
  lock_region(&ypos, sizeof(ypos));
  lock_region(&sb_irqbufferfinished, sizeof(sb_irqbufferfinished));
  lock_region(&bits16, sizeof(bits16));
  lock_region(&sbio, sizeof(sbio));
  if (sbirq < 8) {
    sboldirqvector = _dos_getvect(sbirq + 8);
    _dos_setvect(sbirq + 8, sb_irqhandler);
    sb_oldirqmask1 = inp(0x21) & (1<<sbirq);
    outp(0x21, (inp(0x21) & ~(1<<sbirq)));
    }
  else {
    sboldirqvector = _dos_getvect(sbirq + 0x68);
    _dos_setvect(sbirq + 0x68, sb_irqhandler);
    sb_oldirqmask2 = inp(0xa1) & (1<<(sbirq - 8));
    outp(0xa1, (inp(0xa1) & ~(1<<(sbirq - 8))));
    }
}

/*==========================================*/
/* Set old irq-vector, and set old irq-mask */
/*==========================================*/

void sb_restoreirq(void) {
  if (sbirq < 8) {
    if (sb_oldirqmask1) outp(0x21, (inp(0x21) | sb_oldirqmask1));
    _dos_setvect(sbirq + 8, sboldirqvector);
    }
  else {
    if (sb_oldirqmask2) outp(0xa1, (inp(0xa1) | sb_oldirqmask2));
    _dos_setvect(sbirq + 0x68, sboldirqvector);
    }
  unlock_region((void near *)sb_irqhandler, 1024);
  unlock_region(&emuspeed, sizeof(emuspeed));
  unlock_region(&frames, sizeof(frames));
  unlock_region(&sbframe, sizeof(sbframe));
  unlock_region(&xpos, sizeof(xpos));
  unlock_region(&ypos, sizeof(ypos));
  unlock_region(&sb_irqbufferfinished, sizeof(sb_irqbufferfinished));
  unlock_region(&bits16, sizeof(bits16));
  unlock_region(&sbio, sizeof(sbio));
}

/*=======================================================*/
/* Return value of 'tmp' setting, or -1 if it is missing */
/*=======================================================*/

static int sb_scan_blaster(char tmp, char *env) {
  char cpy[5];
  int i = 0, retval;

  while (*(env + i) != 0 && toupper(*(env + i)) != toupper(tmp)) i++;
  if (*(env+i) == 0) retval = -1;
  else {
    env += i + 1; i = 0;
    while ( *(env+i) != 0 && *(env+i) != ' ' ) {
      cpy[i] = *(env+i);
      i++;
      }
    cpy[i] = 0;
    retval = atoi(cpy);
    }
  return retval;
}

/*==========================*/
/* Return TRUE if all is OK */
/*==========================*/

static int sb_examine_blaster_var(void) {
  char *envvar;
  char trans[20], o[80];
  int retval;

  if ((envvar = getenv("BLASTER")) != NULL) {
    sbio = sb_scan_blaster('A', envvar);
    sbirq = sb_scan_blaster('I', envvar);
    sbdma8 = sb_scan_blaster('D', envvar);
    sbdma16 = sb_scan_blaster('H', envvar);
    sprintf(trans,"%d\n", sbio);
    sscanf(trans,"%X\n", &sbio);

    addlog("Result of BLASTER search:\n");
    sprintf(o,"sbio = %X\n", sbio);
    addlog(o);
    sprintf(o,"sbirq = %d\n", sbirq);
    addlog(o);
    sprintf(o,"sbdma8 = %d\n", sbdma8);
    addlog(o);
    sprintf(o,"sbdma16 = %d\n", sbdma16);
    addlog(o);

    if (sbio != -1 && sbirq != -1 && sbdma8 != -1) {
      if ((sbdma16 == -1) && (dspmajor >= 3)) {
        addlog("16-bit DMA missing from BLASTER, modified to SB V1.0\n");
        dspmajor = 1;
        }
      retval = TRUE;
      }
    else {
      addlog("Serious error in BLASTER variable, sound disabled.\n");
      retval = FALSE;
      }
    }
  else retval = FALSE;          /* No BLASTER envvar at all */
  return retval;
}

/*=========================*/
/* Clear the sound-buffers */
/*=========================*/

static void sb_clear_dmabuffer(void) {
  int i;

  if (config_soundcard_found && dmaflataddr)
    for (i = 0; i < 40000; i++) *((char *)(dmaflataddr + i)) = 0;
}

/*===================================*/
/* Test irq, switch buffers and play */
/*===================================*/

/* Why asm?  Some volatile problems.  Experiment with it sometime */

void sb_testirqflag(void);
#pragma aux sb_testirqflag=\
  "lab:   test    byte ptr [f12pressed],1",\
  "       jnz     lab2",\
  "       test    byte ptr [sb_irqbufferfinished],1", \
  "       jz      lab",\
  "lab2:";

static void sb_play(void) {
  ULO tmp;

  tmp = editbuffer;
  editbuffer = playbuffer;
  playbuffer = tmp;
  auddmaptr = (char *) dmaflataddr + ((editbuffer == 1) ? 20000 : 0);
  sb_start_playing_buffer();
  sb_irqbufferfinished = FALSE;
  sb_halted = FALSE;
}

void sb_test_and_play(void) {
  sb_testirqflag();
  if (!f12pressed) sb_play();
}

/*======================================*/
/* Called before emulation is started   */
/*======================================*/

void sb_before_emu(void) {
  sb_clear_dmabuffer();
  sb_resetdsp();
  sb_mode_setup();
  sb_play();
}

/*===================================*/
/* Called after emulation is stopped */
/*===================================*/

void sb_after_emu(void) {
  sb_disable_speaker();
}


/*==========================================================*/
/* Install various callbacks in the central sound-emulation */
/*==========================================================*/

static void sb_set_global_callbacks(void) {
  /* Install callback for playing a buffer */

  sound_playbuffer = sb_test_and_play;

  /* Install callbacks for before and after emulation setup */

  sound_before_emu = sb_before_emu;
  sound_after_emu = sb_after_emu;
}

/*=======================================================*/
/* Set up a sound-mode                                   */
/* 234 = 45454 stereo and mono (on SB16) and mono on pro */
/* 224 = 31300 stereo and mono (on SB16) and mono on pro */
/* 210 = 21739 stereo and mono (on SB16) and mono on any */
/* 192 = 15650 stereo and mono (on SB16) and mono on any */
/* 233 = 21739 stereo on SB pro                          */
/* 224 = 15650 stereo on SB pro                          */
/*                                                       */
/* Returns the frequency to use in the period-table      */
/*=======================================================*/

ULO sb_mode_setup(void) {
  sb_set_global_callbacks();
  auddmaptr = (char *) dmaflataddr;
  stereo = !(config_sound_mode & 4);
  bits16 = !(config_sound_mode & 8);
  editbuffer = 0;
  playbuffer = 1;
  switch (config_sound_mode) {
    case 0:
            sbsamplerate = 234;
            dmasize = 9109;
            sb_playcmd16 = 0xb0;
            sb_playmode16 = 0x30;
            break;
    case 1:
            sbsamplerate = 224;
            dmasize = 6260;
            sb_playcmd16 = 0xb0;
            sb_playmode16 = 0x30;
            break;
    case 2:
            sbsamplerate = 210;
            dmasize = 9109/2;
            sb_playcmd16 = 0xb0;
            sb_playmode16 = 0x30;
            break;
    case 3:
            sbsamplerate = 192;
            dmasize = 6260/2;
            sb_playcmd16 = 0xb0;
            sb_playmode16 = 0x30;
            break;
    case 4:
            sbsamplerate = 234;
            dmasize = 9109/2;
            sb_playcmd16 = 0xb0;
            sb_playmode16 = 0x10;
            break;
    case 5:
            sbsamplerate = 224;
            dmasize = 6260/2;
            sb_playcmd16 = 0xb0;
            sb_playmode16 = 0x10;
            break;
    case 6:
            sbsamplerate = 210;
            dmasize = 9109/4;
            sb_playcmd16 = 0xb0;
            sb_playmode16 = 0x10;
            break;
    case 7:
            sbsamplerate = 192;
            dmasize = 6260/4;
            sb_playcmd16 = 0xb0;
            sb_playmode16 = 0x10;
            break;
    case 8:
            sbsamplerate = 234;
            dmasize = 9109;
            sb_playcmd16 = 0xc0;
            sb_playmode16 = 0x20;
            break;
    case 9:
            sbsamplerate = 224;
            dmasize = 6260;
            sb_playcmd16 = 0xc0;
            sb_playmode16 = 0x20;
            break;
    case 10:
            if (dspmajor == 4) sbsamplerate = 210;
            else sbsamplerate = 233;
            dmasize = 9109/2;
            sb_playcmd16 = 0xc0;
            sb_playmode16 = 0x20;
            break;
    case 11:
            if (dspmajor == 4) sbsamplerate = 192;
            else sbsamplerate = 224;
            dmasize = 6260/2;
            sb_playcmd16 = 0xc0;
            sb_playmode16 = 0x20;
            break;
    case 12:
            sbsamplerate = 234;
            dmasize = 9109/2;
            sb_playcmd16 = 0xc0;
            sb_playmode16 = 0;
            break;
    case 13:
            sbsamplerate = 224;
            dmasize = 3130;
            sb_playcmd16 = 0xc0;
            sb_playmode16 = 0;
            break;
    case 14:
            sbsamplerate = 210;
            dmasize = 9109/4;
            sb_playcmd16 = 0xc0;
            sb_playmode16 = 0;
            break;
    case 15:
            sbsamplerate = 192;
            dmasize = 3130/2;
            sb_playcmd16 = 0xc0;
            sb_playmode16 = 0;
            break;
    }
  sb_enable_speaker();
  sb_cmdwrite(DSP_SET_TIMECONSTANT);
  sb_cmdwrite(sbsamplerate);
  if (dspmajor == 3) {
    if (stereo)
      sb_mixwrite(MIXER_OUTPUT_STEREO_SELECT,
		  sb_mixread(MIXER_OUTPUT_STEREO_SELECT) | 0x2);
    else
      sb_mixwrite(MIXER_OUTPUT_STEREO_SELECT,
		  sb_mixread(MIXER_OUTPUT_STEREO_SELECT) & 0xfd);
    }
  switch (config_sound_mode & 3) {
    case 0: actualrate = 45454; return 45454;
    case 1: actualrate = 31300; return 31300;
    case 2: actualrate = 21739; return 43478;
    case 3: actualrate = 15650; return 31300;
    }
  actualrate = 31300;
  return 31300;
}

/*=================================================*/
/* Set callbacks for putting samples in the buffer */
/*=================================================*/

static void sb_setcallback(ULO i) {
  config_sound_setuproutines[i] = sb_mode_setup;
  if (i & 8) {
    if (i & 4)
      config_sound_bufferroutines[i] = sb_8bit_mono_put_in_buffer;
    else 
      config_sound_bufferroutines[i] = sb_8bit_stereo_put_in_buffer;
    }
  else {
    if (i & 4)
      config_sound_bufferroutines[i] = sb_16bit_mono_put_in_buffer;
    else 
      config_sound_bufferroutines[i] = sb_16bit_stereo_put_in_buffer;
    }
}

/*=================*/
/* Get DSP version */
/*=================*/

static void sb_iddsp(void) {
  int i, default_mode;

  sb_cmdwrite(DSP_VERSION);
  dspmajor = sb_cmdread();
  dspminor = sb_cmdread();

  if (dspmajor > 4) dspmajor = 4;
  if (dspmajor == 1 || config_sb_forceV1 || (dspmajor == 2 && dspminor == 0)) {
    addlog("Soundblaster V1.X or V2.0\n");
    config_soundcard_found = TRUE;
    for (i = 14; i < 16; i++) {
      config_soundmodes[i] = TRUE;
      sb_setcallback(i);
      }
    default_mode = 14;
    dspmajor = 1;
    }
  else if (dspmajor == 2 && dspminor > 0) {
    addlog("Soundblaster V2.01+\n");
    config_soundcard_found = TRUE;
    for (i = 12; i < 16; i++) {
      config_soundmodes[i] = TRUE;
      sb_setcallback(i);
      }
    default_mode = 12;
    }
  else if (dspmajor == 3) {
    addlog("Soundblaster V3.X (PRO)\n");
    config_soundcard_found = TRUE;   
    for (i = 10; i < 16; i++) {
      config_soundmodes[i] = TRUE;
      sb_setcallback(i);
      }
    default_mode = 10;
    }
  else if (dspmajor == 4) {
    addlog("Soundblaster V4.X (16/32/64 and so on)\n");
    for (i = 0; i < 16; i++) {
      config_soundmodes[i] = TRUE;
      sb_setcallback(i);
      }
    config_soundcard_found = TRUE;
    default_mode = 0;
    }
  if (!configaudiomodesetbylog)
    config_sound_mode = default_mode;
  else if (!config_soundmodes[config_sound_mode])
    config_sound_mode = default_mode;
}

/*==========================*/
/* Top level initialization */
/*==========================*/

void sb_init(void) {
  int i,j;

  if (!sb_examine_blaster_var()) {
    addlog("Error in, or no BLASTER variable, sound off\n");
    config_soundcard_found = FALSE;
    return;
    }
  if (sb_resetdsp()) {
    addlog("Didn't find DSP\n");
    config_soundcard_found = FALSE;
    return;
    }
  sb_iddsp();
  if (sb_allocatebuffer(40000) == 1) {
    addlog("Error while allocating DMA buffer");
    config_soundcard_found = FALSE;
    return;
    }
  sb_clear_dmabuffer();
  sb_initirq();
  sb_halted = FALSE;
  sb_enable_speaker();
}

void sb_close(void) {
  sb_resetdsp();
  sb_restoreirq();
  sb_freebuffer();
}
