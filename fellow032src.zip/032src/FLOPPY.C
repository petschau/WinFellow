/*=========================*/
/* Fellow Emulator         */
/* Floppy Emulation        */
/* Petter Schau 1996/1997  */
/*=========================*/

#include <stdio.h>
#include <stdlib.h>
#include <sys/types.h>
#include <sys/stat.h>

#include "defs.h"
#include "fellow.h"
#include "memory.h"
#include "68000.h"
#include "led.h"

#include "zlib/zlib.h"  /* zlib, check header file for authors */
#include "bzip2.h"


/*-----------*/
/*  ADT's    */
/*-----------*/

/* Info about a track in the small cache */

typedef struct {
  ULO track;
  ULO side;
  ULO drive;
  ULO age;
  ULO timesused;
} trackinfostruct;

/* Info about a started disk transfer */

typedef struct {
  ULO cachebuffer;
  ULO position;
  ULO wordsleft;
  ULO destination;
  ULO drive;
  ULO initial_wait;
} diskdmatransferinfostruct;

/*---------------*/
/* Configuration */
/*---------------*/

/* Name of diskimages */

char config_floppy_name[4][256];
char realdiskname[4][256];

/* Times original speed */

ULO config_floppy_fast;

/* Gzip stuff */

ULO gzserialno = 0;
UBY gzipped[4];
ULO gzippedserno[4];
char *tmppath;                  /* Pointer to TMP or TEMP */

/*----------------------------------*/
/* State of the virtual disk drives */
/*----------------------------------*/

/* Drive selected when 1 */

ULO sel[4];

/* Track position of head */

ULO track[4];

/* Write protected if 1 */

ULO writeprot[4];

/* Direction of head-movement if stepped */

ULO dir[4];

/* State of motor on or off */

ULO motor[4];

/* Side of disk to read or write */

ULO side[4];
ULO step[4];

/* Valid disk-image inserted */

ULO inserted[4];

/* Valid disk-image inserted and detected */

ULO active[4];

ULO changed[4];

/* Counts the number of times the ID has been read */

ULO idmode[4];
ULO idcount[4];

/* Drive enabled or disabled */

ULO config_floppy_enabled[4];

/*--------------------------*/
/* 8 entry cache for tracks */
/*--------------------------*/

/* Track data */

UBY tracks[8][11*1088];

/* Track info */

trackinfostruct trackinfo[8];

/* Pointer to image in memory if it is fully cached */
/* NULL otherwise */

UBY *diskinmem[4];

/* Record latest track read from a fully cached image */

ULO inmemlasttrack[4];

/* Record how many times the same track is read */

ULO inmemtimesused[4];

/*---------------------------------------*/
/* Temporary track for reading from disk */
/*---------------------------------------*/

UBY tmptrack[512*11];

/*---------------------------*/
/* Info about a dma transfer */
/*---------------------------*/

diskdmatransferinfostruct diskdmainfo;
ULO diskdmainprogress;
ULO diskdmaread;

/*-------------------------------------------------------------*/
/* Status for knowing which drives have inserted valid images  */
/* 0 - disk found and OK                                       */
/* 1 - disk not found                                          */
/* 2 - disk image has wrong size                               */
/* 3 - none inserted                                           */
/*-------------------------------------------------------------*/

ULO diskimagestatus[4];

/*-----------------------------------*/
/* Disk registers and help variables */
/*-----------------------------------*/

/* Counts the number of writes to dsklen */

ULO diskdmaen;   

/* Registers */

ULO dsklen, dsksync, dskpt, adcon;

void do_diskdma(void);	// implicit declaration of further function

/*----------*/
/* DSKBYTR  */
/* $dff01a  */
/*----------*/

#pragma aux rdskbytr parm [ecx] value [edx];
ULO rdskbytr(ULO address) {
  ULO tmp = diskdmainprogress<<14;
  if (dsklen & 0x4000) tmp |= 0x2000;
  return tmp;
}

/*----------*/
/* DSKPTH   */
/* $dff020  */
/*----------*/

#pragma aux wdskpth parm [ecx] [edx];
void wdskpth(ULO address, ULO data) {
  *(((UWO *)&dskpt)+1) = data & 0x1f;
}

/*----------*/
/* DSKPTL   */
/* $dff022  */
/*----------*/

#pragma aux wdskptl parm [ecx] [edx];
void wdskptl(ULO address, ULO data) {
  *((UWO *)&dskpt) = data & 0xfffe;
}

/*----------*/
/* DSKLEN   */
/* $dff024  */
/*----------*/

#pragma aux wdsklen parm [ecx] [edx];
void wdsklen(ULO address, ULO data) {
  push_ad();
  dsklen = data;
  if (data & 0x8000) if (++diskdmaen >= 2) {
        do_diskdma();
        }
  pop_ad();
}

/*----------*/
/* DSKSYNC  */
/* $dff07e  */
/*----------*/

#pragma aux wdsklen parm [ecx] [edx];
void wdsksync(ULO address, ULO data) {
  dsksync = data;
}

/*==================================*/
/* Some functions used from cia.c   */
/*==================================*/

int floppy_drive_get_selected(void) {
  int i = 0;
  while (i < 4) {
    if (sel[i]) return i;
    i++;
    }
  return -1;
}

int floppy_drive_is_track0(int drive) {
  if (drive != -1) return (track[drive] == 0);
  return FALSE;
}

int floppy_drive_is_writeprotected(int drive) {
  if (drive != -1) return writeprot[drive];
  return FALSE;
}

int floppy_drive_is_ready(int drive) {
  if (drive != -1) {
    if (idmode[drive]) return (idcount[drive]++ < 32);
    else return (motor[drive] && inserted[drive]);
    }
  return FALSE;
}

int floppy_drive_is_changed(int drive) {
  if (drive != -1) return changed[drive];
  return TRUE;
}

void floppy_set_sel(ULO selbits) {
  int i;
  for (i = 0; i < 4; i++) {
    sel[i] = ((selbits & 1) == 0);
    selbits >>= 1;
    }
}


/* If motor is turned off, idmode is reset and on */
/* If motor is turned on, idmode is off */

void floppy_set_motor(ULO mtr) {
  int i;
  for (i = 0; i < 4; i++) {
    if (sel[i]) {
      if (motor[i] && mtr) {
        idmode[i] = TRUE;
        idcount[i] = 0;
        }
      else if (!motor[i] && !mtr) idmode[i] = FALSE;
      if (motor[i] != (!mtr))
        drawled(150 + (50*i), (mtr == 0) ? drivemotorcolor:0);
      motor[i] = !mtr;
      }
    }
}

void floppy_set_side(ULO s) {
  int i;
  for (i = 0; i < 4; i++) side[i] = !s;
}
    
void floppy_set_dir(ULO dr) {
  int i;
  for (i = 0; i < 4; i++) dir[i] = dr;
}

void floppy_set_step(ULO stp) {
  int i;
  for (i = 0; i < 4; i++) {
    if (sel[i]) {
      if (!stp && changed[i] && inserted[i]) changed[i] = FALSE;
      if (!step[i] && !stp) {
        if (!dir[i]) {
          if (track[i] < 79) track[i]++;
          }
        else {
          if (track[i] > 0) track[i]--;
          }
        }
      step[i] = !stp;
      }
    }
}

/*========================================*/
/* Makemfmsector                          */
/* Will MFM encode the sector in tmptrack */
/*========================================*/

void makemfmsector(ULO tra,ULO sec,UBY *dest) {
  ULO tmp, x, odd, even, hck = 0, dck = 0;
  ULO tmptindex = sec*512;

  /* Preamble and sync */

  *(dest + 0) = 0xaa;
  *(dest + 1) = 0xaa;
  *(dest + 2) = 0xaa;
  *(dest + 3) = 0xaa;
  *(dest + 4) = 0x44;
  *(dest + 5) = 0x89;
  *(dest + 6) = 0x44;
  *(dest + 7) = 0x89;

  /* Track and sector info */

  tmp = 0xff000000 | ((tra & 0xff)<<16) | ((sec & 0xff)<<8) | ((11-sec) & 0xff);
  odd = tmp & 0x55555555;
  even = (tmp>>1) & 0x55555555;

  *(dest +  8) = (even & 0xff000000)>>24;
  *(dest +  9) = (even & 0xff0000)>>16;
  *(dest + 10) = (even & 0xff00)>>8;
  *(dest + 11) = (even & 0xff);
  *(dest + 12) = (odd & 0xff000000)>>24;
  *(dest + 13) = (odd & 0xff0000)>>16;
  *(dest + 14) = (odd & 0xff00)>>8;
  *(dest + 15) = (odd & 0xff);

  /* Fill unused space */

  for (x = 16 ; x < 48; x++) *(dest + x) = 0x55;

  /* Encode data section of sector */

  for (x = 64 ; x < 576; x++) {
    tmp = tmptrack[tmptindex + x - 64];
    odd = (tmp & 0x55);
    even = (tmp>>1) & 0x55;
    *(dest + x) = even | 0xaa;
    *(dest + x + 512) = odd | 0xaa;
  }

  /* Calculate checksum for unused space */

  for(x = 8; x < 48; x += 4)
    hck ^= (((ULO) *(dest + x    ))<<24) | (((ULO) *(dest + x + 1))<<16) |
      (((ULO) *(dest + x + 2))<< 8) |  ((ULO) *(dest + x + 3));
   
  even = odd = hck; 
  odd >>= 1;

  *(dest + 48) = (odd & 0xff000000) >> 24;
  *(dest + 49) = (odd & 0xff0000) >> 16;
  *(dest + 50) = (odd & 0xff00) >> 8;
  *(dest + 51) = odd & 0xff;
  *(dest + 52) = (even & 0xff000000) >> 24;
  *(dest + 53) = (even & 0xff0000) >> 16;
  *(dest + 54) = (even & 0xff00) >> 8;
  *(dest + 55) = even & 0xff;

  /* Calculate checksum for data section */

  for(x = 64; x < 1088; x += 4)
    dck ^= (((ULO) *(dest + x    ))<<24) | (((ULO) *(dest + x + 1))<<16) |
      (((ULO) *(dest + x + 2))<< 8) |  ((ULO) *(dest + x + 3));

  even = odd = dck;
  odd >>= 1;

  *(dest + 56) = (odd & 0xff000000) >> 24;
  *(dest + 57) = (odd & 0xff0000) >> 16;
  *(dest + 58) = (odd & 0xff00) >> 8;
  *(dest + 59) = odd & 0xff;
  *(dest + 60) = (even & 0xff000000) >> 24;
  *(dest + 61) = (even & 0xff0000) >> 16;
  *(dest + 62) = (even & 0xff00) >> 8;
  *(dest + 63) = even & 0xff;
}

/*================================*/
/* insert gzip or bzip2 image     */
/* Unzip the image to tempdir     */
/* Return tempname                */
/*================================*/

char gzbuff[512];
char gzname[256];

void prepare_gzip_image(char *diskname,int drive) {
  gzFile zfile;
  FILE *bfile;
  FILE *F;
  int ended,siz;

  if (tmppath == NULL) {
        //addlog("GZIP image insert failed, reason: TMP or TEMP not set.\n");
        //addlog("I have no temporary directory to dump the GUNZIPPED images.\n");
        return;
        }
  gzippedserno[drive] = gzserialno++;
  sprintf(gzname,"%s\\FTMP%d.ADF",tmppath,gzippedserno[drive]);

  F = fopen(gzname,"wb");
  if (F == NULL) {
        //addlog("gzfile error, could not open temporary-image file\n");
        return;
        }
  if( !strcmpi( strrchr( diskname, '.' ), ".bz2" ) ||
      !strcmpi( strrchr( diskname, '.' ), ".bz" ) ) {
    bfile = fopen(diskname,"rb");
    Bz2uncompressStream( bfile, F );
    fclose( bfile );
  } else {
    addlog("Inserting gzip-image\n");
    addlog(diskname);
    zfile = gzopen(diskname,"rb");
    ended = 0;
    while (!ended) {
      siz = gzread(zfile,gzbuff,512);
      if (siz != 512) ended = 1;
      else fwrite(gzbuff,1,siz,F);
      }
    gzclose(zfile);
  }
    fclose(F);

  strcpy(realdiskname[drive],gzname);
  gzipped[drive] = 1;
}

void remove_gzip_image(int drive) {
  static char command[256];

  if (tmppath == NULL) return;

  if (gzipped[drive]) {
    gzipped[drive] = 0;
    sprintf(command,"del %s",realdiskname[drive]);
    system(command);
    }
}

/*================================*/
/* insert_diskimage               */
/* Will insert the diskimage in   */
/* drive, or flag file not found  */
/* If the drive is fully cached   */
/* Then the entire disk-image is  */
/* loaded and mfm encoded         */
/*================================*/

void insert_diskimage(char *diskname,int drive) {
  FILE *F;
  int i, j;
  struct stat mystat;
  
  if (gzipped[drive]) remove_gzip_image(drive);

  strcpy(realdiskname[drive],diskname);

  /* Diskname __none__ means no disk inserted */

  changed[drive] = TRUE;
  if (strcmp(diskname,"__None__") == 0) {
    diskimagestatus[drive] = 3;
    inserted[drive] = active[drive] = 0;
    return;
  }

  /* Attempt to open file to check if it exists */

  if( !strcmpi( strrchr( diskname, '.' ), ".bz2" ) )
    prepare_gzip_image(diskname,drive);

  if( !strcmpi( strrchr( diskname, '.' ), ".bz" ) )
    prepare_gzip_image(diskname,drive);

  if( !strcmpi( strrchr( diskname, '.' ), ".gz" ) )
    prepare_gzip_image(diskname,drive);

  if( !strcmpi( strrchr( diskname, '.' ), ".z" ) )
    prepare_gzip_image(diskname,drive);

  if( !strcmpi( strrchr( diskname, '.' ), ".adz" ) )
    prepare_gzip_image(diskname,drive);

  if ((F = fopen(realdiskname[drive],"rb")) != NULL) {

    /* Check if file is writable */

    stat(realdiskname[drive], &mystat);
    writeprot[drive] = !(mystat.st_mode & S_IWUSR); 

    /* Disk-image found and inserted, but not detected by the Amiga */

    if (diskinmem[drive] != NULL) {
      for (i = 0; i < 160; i++) {
	if (fread(tmptrack,1,5632,F) != 5632) {
	  inserted[drive] = active[drive] = 0;
	  diskimagestatus[drive] = 2;
	  return;
	}
	for (j = 0; j < 11; j++) {
	  makemfmsector(i, j, diskinmem[drive] + i*11968 + j*1088);
	}
      }
      diskimagestatus[drive] = 0;	/* Disk-image found and is OK */
      inserted[drive] = 1;
    }
    else {
      /* Seek to end of file to determine size of image */
      fseek(F,0,SEEK_END);
      if (ftell(F) != 901120) {
	inserted[drive] = active[drive] = 0;
	diskimagestatus[drive] = 2;
	return;
      }

      diskimagestatus[drive] = 0;	/* Disk-image found and is OK */
      inserted[drive] = 1;
      active[drive] = 0;
    }
    fclose(F);				
  }
}

/*==============================================*/
/* diskdmaloadtrack                             */
/* Loads the current track for a drive into the */
/* specified cache buffer.                      */
/* Only used when drive is not fully cached  	*/
/* Called when a disk dma is started, and the   */
/* track is not in any cache                    */
/*==============================================*/

void diskdmaloadtrack(ULO drive, ULO cbuf) {
  FILE *F;
  ULO trackpos = track[drive]*11264 + side[drive]*5632,i;
  
  if ((F = fopen(realdiskname[drive],"rb")) != NULL) {
    fseek(F,trackpos,SEEK_SET);	/* Seek to and load track */
    fread(tmptrack,1,5632,F);
    fclose(F);

    trackinfo[cbuf].track = track[drive];	/* Set info about this cache entry */
    trackinfo[cbuf].side = side[drive];
    trackinfo[cbuf].drive = drive;
    trackinfo[cbuf].age = 0;
    trackinfo[cbuf].timesused = 0;

    /* MFM encode the loaded track */

    for (i = 0; i < 11; i++)
      makemfmsector(track[drive]*2 + side[drive], i, &tracks[cbuf][i*1088]);

    /* Increase age of other cache entries */

    for (i = 0; i < 8; i++) if (i != cbuf) trackinfo[i].age++;
  }
}


/*========================================*/
/* diskdmafindbuffer                      */
/* Called when the diskimage is not fully */
/* cached.                                */
/* Will return the number of the cache    */
/* buffer the current track of the drive  */
/* resides in.                            */
/* If it is not in the cache, a cache     */
/* entry will be replaced with this track */
/*========================================*/

ULO diskdmafindbuffer(ULO drive, ULO invalidateflag) {
  ULO t, trkfound, oldest, oldbuf;

  t = trkfound = oldbuf = 0;
  oldest = trackinfo[0].age;

  /* Search for track in cache and also record the oldest entry */

  while (t < 8) {
    if ((trackinfo[t].track == track[drive]) &&
	(trackinfo[t].side == side[drive]) &&
	(trackinfo[t].drive == drive)) {
      if (!invalidateflag) trackinfo[t].timesused++;
      return t;			/* Track found and buffer returned */
    }
    else {
      if (trackinfo[t].age > oldest) {
	oldest = trackinfo[t].age;
	oldbuf = t;
      }
    }
    t++;
  }

  /* Here the track was not found, replace oldest entry */

  if (!invalidateflag) {
    diskdmaloadtrack(drive, oldbuf);
    return oldbuf;
  }
  else return -1;
}


/*==============================================*/
/* diskdmasetupread                             */
/* Final setup of a disk dma read operation     */
/* Called when all other parameters are checked */
/* Will fill inn needed information in the  	*/
/* diskdmainfo structure, and set a flag so   	*/
/* that the end of line handler will move       */
/* words into the Amiga memory space until	*/
/* the number of words requested are transferred*/
/*==============================================*/

void diskdmasetupread(ULO drive) {

  /* Fill in info about transfer */

  diskdmainfo.drive = drive;
  diskdmainfo.wordsleft = dsklen & 0x3fff;
  diskdmainfo.destination = dskpt & 0x1fffff;
  diskdmainfo.initial_wait = 10; /* 10 lines should do */
  diskdmaread = 1;

  /* Determine pointer to MFM data */

  if (diskinmem[drive] == NULL) {
    diskdmainfo.cachebuffer = diskdmafindbuffer(drive,0);
    diskdmainfo.position = 1088*(trackinfo[diskdmainfo.cachebuffer].timesused % 11);
  }
  else {
    diskdmainfo.cachebuffer = (ULO) diskinmem[drive]+(track[drive]*23936)+(side[drive]*11968);
    diskdmainfo.position = 0;
    if (((track[drive]*2)+side[drive]) == inmemlasttrack[drive]) {
      diskdmainfo.position += ((++inmemtimesused[drive])*1088)%11968;
    }
    else {
      inmemlasttrack[drive] = track[drive]*2 + side[drive];
      inmemtimesused[drive] = 0;
    } 
  }

  /* Adjust pointer if the disk controller is waiting for a dsksync word */

  if (dsksync == 0x4489) diskdmainfo.position += 6;

  /* Set flag used by the end of line handler */

  diskdmainprogress = 1;
}



ULO diskwritedecode(ULO pos) {
  ULO sector;
  ULO odd,even,i;

  odd = (cmem[pos]<<24) | (cmem[pos+1]<<16) | (cmem[pos+2]<<8) | (cmem[pos+3]);
  even = (cmem[pos+4]<<24) | (cmem[pos+5]<<16) | (cmem[pos+6]<<8) | (cmem[pos+7]);
  even &= 0x55555555;
  odd  = (odd & 0x55555555) << 1;
  even |= odd;
  sector = (even & 0xff00)>>8;

  /* We know the sector number */
  /* Decode it to tmpsector */

  for (i = 0; i < 512; i++) {
    even = (cmem[pos+i+56]) & 0x55;
    odd = (cmem[pos+i+56+512]) & 0x55;
    tmptrack[i] = (even<<1) | odd;
  }
  return sector;
}
        
/* I don't want to spend much time with this, this is a hack and will */
/* only work with fully cached images in df0 */

void doio(void) {
  int i,even,odd,j,cmemstart,diskindex,size;

  if ((diskinmem[0] == NULL) || (cmem[a[1]+0x1d] == 9)) return;
  cmemstart = fetl(a[1]+0x28) & 0x1ffffe;
  diskindex = (fetl(a[1]+0x2c)/512)*1088;
  if (diskindex > (901120*2)) return;
  size = fetl(a[1]+0x24)/512;
  if (size > 1760) return;
  for (j = 0; j < size; j++) {
    for (i = 0; i < 512; i++) {
      even = (diskinmem[0][diskindex+i+64]) & 0x55;
      odd = (diskinmem[0][diskindex+i+64+512]) & 0x55;
      cmem[cmemstart++] = (even<<1) | odd;
    }
    diskindex += 1088;
  }
}

void copy_bootblock(void) {
  ULO i,j,even,odd;

  if (diskinmem[0] == NULL) return;
  for (j = 0; j < 2; j++)
    for (i = 0; i < 512; i++) {
      even = (diskinmem[0][j*1088+i+64]) & 0x55;
      odd = (diskinmem[0][j*1088+i+64+512]) & 0x55;
      cmem[0x2000+i+j*512] = (even<<1) | odd;
    }
}

/* Actual write of data to disk-image */

void diskwritetoimage(ULO drive, ULO sector) {
  FILE *F;

  if (!writeprot[drive])
    if ((F = fopen(realdiskname[drive],"r+b")) != NULL) {
      fseek(F,(track[drive]*11264) + (side[drive]*5632) + sector*512,SEEK_SET);
      fflush(F);
      fwrite(tmptrack,1,512,F);
      fclose(F);
    }
}

/* Copy MFM data to cache */

void diskwriteupdatecache(ULO drive, ULO sector, ULO pos) {
  int i;
  UBY *imp; 

  if (diskinmem[drive] != NULL) {
    imp = diskinmem[drive] + (track[drive]*23936) + side[drive]*11968 + sector*1088 + 8;

    for (i = 0; i < 1080; i++) *(imp+i) = cmem[pos+i];                        
  }
  else {
    i = diskdmafindbuffer(drive,1);
    trackinfo[i].track = 0xffffffff;
    trackinfo[i].side = 0xffffffff;
    trackinfo[i].drive = 0xffffffff;
    trackinfo[i].age = 0x500;
    trackinfo[i].timesused = 0;
  }
}

/*==========================================*/
/* Process a disk dma write operation       */
/* Do it all in one piece, and delay irq    */
/* a bit.						  */
/* If anyone is doing tricks during a write */
/* they deserve problems.....               */
/*==========================================*/

void diskdmasetupwrite(ULO drive) {
  ULO length = (dsklen & 0x3fff)*2;
  ULO pos = dskpt & 0x1ffffe;
  ULO i=0, ended = 0, sector;
  int syncfound = 0;
  char o[100];

  while (!ended) {
    /* Search for sync */
    while (!syncfound && !ended) {
      if (cmem[pos+i] == 0x44 && cmem[pos+i+1] == 0x89) syncfound = 1;		
      i+=2;
      if (i >= length) ended = 1;
    }
    if (!ended) {
      if (cmem[pos+i] == 0x44 && cmem[pos+i+1] == 0x89) {
	i+=2;
	if (i >= length) ended = 1;
      }
    }
    /* Here i either points to first word after a sync, or we went beyond length */
    if (!ended) {
      /* if there's less words left that a full sector in transfer, ignore sector */
      if ((length-i) >= 1080) {
	/* Now we have a full sector to decode */
	/* and i points to first byte after sync */
	/* Decode block */

	sector = diskwritedecode(pos+i);

	/* Write block to disk-image */

	diskwritetoimage(drive,sector);

	/* Copy block to cache */

	diskwriteupdatecache(drive,sector,pos+i);
			
	/* Update pointer to after sector */

	i += 1080;
	syncfound = 0;
      }
      else ended = 1;
    }
  }
  diskdmaread = 0;
  diskdmainfo.wordsleft = 2000;
  diskdmainprogress = 1;
}



/*========================================*/
/* do_diskdma                             */
/* Called when the dsklen register        */
/* has been written twice                 */
/* Will check all necessary parameters    */
/* and initiate a disk dma read or write  */
/*========================================*/

void do_diskdma(void) {
  ULO selcount, drive, i;
  /* BUG? Some programs reads from disk with the master DMA bit off? */
  /* Why?  Test dmaconr instead to ignore the master bit */

  if (dmaconr & 0x0010) {          /* Dma channel must be enabled */
    if (dsklen & 0x8000) {	/* Disk dma must be on */

      /* Will only allow 1 selected drive */

      selcount = 0;
      for (i = 0; i < 4; i++) {
	if (sel[i]) {
	  selcount++;
	  drive = i;
	}
      }

      if (selcount == 1) {	/* Only one drive must be selected */
	if (inserted[drive]) {	/* A disk must be inserted */
	  if (1/*motor[dnum]*/) {	/* The motor must be on */
	    if (1/*(dsksync == 0x4489) || (dsksync == 0)*/) {/* Check dsksync */
	      if (1/*adcon & 0x1000*/) {/* Must be in MFM mode */
		if (1/*adcon & 0x100*/) {/* Must be in FAST MFM mode */
		  if (dsklen & 0x4000)
		    diskdmasetupwrite(drive);
		  else
		    diskdmasetupread(drive);
		}
	      }
	    }
	  }
	}
      }
    }
  }
  diskdmaen = 0;
}


/*========================================*/
/* read_loop                              */
/* Called by the end of line handler      */
/* every line until the number of words   */
/* in the disk dma transfer has been      */
/* copied into the Amiga memory space     */
/* The number of words to transfer each   */
/* time is set in configdiskspeed         */
/*========================================*/

void read_loop(void) {
  static rli;

  /* Initial wait to give programs some time to set up things */

  if (diskdmainfo.initial_wait != 0) {
    diskdmainfo.initial_wait--;
    return;
  }

  /* Number of words to transfer */

  rli = 1<<((config_floppy_fast == TRUE) ? 12:1);

  if (diskinmem[diskdmainfo.drive] == NULL) {

    /* Copy from cache entry */

    while ((rli != 0) && (diskdmainfo.wordsleft != 0)) {
      cmem[diskdmainfo.destination++] = tracks[diskdmainfo.cachebuffer][diskdmainfo.position++%11968];
      cmem[diskdmainfo.destination++] = tracks[diskdmainfo.cachebuffer][diskdmainfo.position++%11968];
      diskdmainfo.wordsleft--;
      rli--;
    }
  }
  else {

    /* Copy from fully cached disk image */

    while ((rli != 0) && (diskdmainfo.wordsleft != 0)) {
      cmem[diskdmainfo.destination++] = *((UBY *)diskdmainfo.cachebuffer + (diskdmainfo.position++%11968));
      cmem[diskdmainfo.destination++] = *((UBY *)diskdmainfo.cachebuffer + (diskdmainfo.position++%11968));
      diskdmainfo.wordsleft--;
      rli--;
    }
  }

  /* Raise irq when finished, and clear flag */

  if (diskdmainfo.wordsleft == 0) {
    wriw(0x8002,0xdff09c);
    diskdmainprogress = 0;
  }
}
          

void write_loop(void) {
  if (--diskdmainfo.wordsleft == 0) {
    diskdmainprogress = 0;
    wriw(0x8002,0xdff09c);
  }
}


void disk_reinsertImages(void) {
  int i;
  for( i = 0; i < 4; i++ ) {
    fgui_print_diskname( config_floppy_name[ i ], i );
    insert_diskimage( config_floppy_name[ i ], i );
  }
}


/*============================*/
/* disk_initstate             */
/* Resets disk-emulation      */
/*============================*/

void disk_initstate(void) {
  ULO i;

  for (i = 0; i < 4; i++) {
    sel[i] = 0;
    track[i] = 0;
    writeprot[i] = 0;
    dir[i] = 0;
    motor[i] = 0;
    side[i] = 0;
    inserted[i] = 0;
    active[i] = 0;
    idmode[i] = FALSE;
    idcount[i] = 0;
    diskimagestatus[i] = 3;
    gzipped[i] = 0;
    changed[i] = TRUE;
  }
  diskdmainprogress = 0;
  diskdmaen = 0;
}

/*========================*/
/* disk_initinmem         */
/* Try to allcate space   */
/* for full-image cache   */
/*========================*/

void disk_initinmem(void) {
  ULO i;

  for (i = 0; i < 4; i++) diskinmem[i] = (UBY *) malloc(1914880);
}


/*=========================*/
/* disk_initcache          */
/*=========================*/

void disk_initcache(void) {
  ULO i;

  for (i = 0; i < 8; i++) {
    trackinfo[i].track = 0xffffffff;
    trackinfo[i].side = 0xffffffff;
    trackinfo[i].drive = 0xffffffff;
    trackinfo[i].age = 0x500;
    trackinfo[i].timesused = 0;
  }
}
  
/*============================*/
/* disk_initiotable           */
/*============================*/

void disk_initiotable(void) {
  ioread[0x1a/2] = rdskbytr;
  iowrite[0x20/2] = wdskpth;
  iowrite[0x22/2] = wdskptl;
  iowrite[0x24/2] = wdsklen;
  iowrite[0x7e/2] = wdsksync;
}

/*============================*/
/* diskinit                   */
/* Top level disk-emulation   */
/* initialization             */
/*============================*/

void diskinit(void) {
  int i;
  char s[80];

  disk_initstate();
  disk_initinmem();
  disk_initcache();
  disk_initiotable();

  tmppath = getenv("TMP");
  if (tmppath == NULL) tmppath = getenv("TEMP");

  disk_reinsertImages();
}

/*======================*/
/* freeadfcache		*/
/*======================*/

void freeadfcache(void) {
  ULO i;
  for (i = 0; i < 4; i++) if (diskinmem[i] != NULL) free(diskinmem[i]);
}


