#include "defs.h"
#include "68000ini.h"
#include "68030ini.h"
#include "68000.h"
#include "memory.h"

ULO sfc,dfc,cacr,vbr,caar,msp,isp;    /* these are 68030 control regs */

/* 68030 specific instructions follow */

/*
 Instruction BFCHG <ea>{offset:size}
 Table-usage:

  0-Routineptr, 1-disasm routine,  2-srcreg, 3-srcroutine, 4 - cycle count
*/

ULO i301dis(ULO prc,ULO opc,char *st)
{
  ULO pos=13,reg=opc&0x7,dreg=(opc&0xe00)>>9,mode=(opc&0x38)>>3;
  if (mode == 7) mode += reg;
  sprintf(st,"$%.6X %.4X      !!!!!!       BFCHG   ");
  prc = disfordel(reg,prc+2,st,16,mode,&pos);
  strcat(st,",");
  disfordel(dreg,prc,st,16,0,&pos);
  return prc;
}

void i301ini(void) {
  ULO op=0xeac0,ind,modes,regs,flats;
  for (modes = 0; modes < 8; modes++)
    for (regs = 0; regs < 8; regs++)
      flats = (modes != 7) ? modes : modes+regs;
      if ((control[flats] && alterable[flats]) || (flats == 0)) {
        ind = op|modes<<3|regs;
        t[ind][0] = (ULO) ( (modes == 0) ? i301_R : i301_M );
        t[ind][1] = (ULO) i301dis;
        t[ind][2] = (ULO) ( regs*4 + ((modes == 0) ?
                                (ULO) d:
                                (ULO) a) );
        t[ind][3] = (ULO) eac[flats];
      }
}

/*
 Instruction BFCLR <ea>{offset:size}
 Table-usage:

  0-Routineptr, 1-disasm routine,  2-srcreg, 3-srcroutine, 4 - cycle count
*/

ULO i302dis(ULO prc,ULO opc,char *st)
{
  
  ULO pos=13,reg=opc&0x7,dreg=(opc&0xe00)>>9,mode=(opc&0x38)>>3;
  if (mode == 7) mode += reg;
  sprintf(st,"$%.6X %.4X      !!!!!!       BFCLR   ");
  prc = disfordel(reg,prc+2,st,16,mode,&pos);
  strcat(st,",");
  disfordel(dreg,prc,st,16,0,&pos);
  
  return prc;
}

void i302ini(void) {
  ULO op=0xecc0,ind,modes,regs,flats;
  for (modes = 0; modes < 8; modes++)
    for (regs = 0; regs < 8; regs++)
      flats = (modes != 7) ? modes : modes+regs;
      if ((control[flats] && alterable[flats]) || (flats == 0)) {
        ind = op|modes<<3|regs;
        t[ind][0] = (ULO) ( (modes == 0) ? i302_R : i302_M );
        t[ind][1] = (ULO) i302dis;
        t[ind][2] = (ULO) ( regs*4 + ((modes == 0) ?
                                (ULO) d:
                                (ULO) a) );
        t[ind][3] = (ULO) eac[flats];
      }
}

/*
 Instruction BFEXTS <ea>{offset:size},Dn
 Table-usage:

  0-Routineptr, 1 - disasm routine, 2-srcreg, 3-srcroutine, 4 - cycle count
*/

ULO i303dis(ULO prc,ULO opc,char *st)
{
  
  ULO pos=13,reg=opc&0x7,dreg=(opc&0xe00)>>9,mode=(opc&0x38)>>3;
  if (mode == 7) mode += reg;
  sprintf(st,"$%.6X %.4X      !!!!!!       BFEXTS  ");
  prc = disfordel(reg,prc+2,st,16,mode,&pos);
  strcat(st,",");
  disfordel(dreg,prc,st,16,0,&pos);
  
  return prc;
}

void i303ini(void) {
  ULO op=0xebc0,ind,modes,regs,flats;
  for (modes = 0; modes < 8; modes++)
    for (regs = 0; regs < 8; regs++)
      flats = (modes != 7) ? modes : modes+regs;
      if ((control[flats] && alterable[flats]) || (flats == 0)) {
        ind = op|modes<<3|regs;
        t[ind][0] = (ULO) ( (modes == 0) ? i303_R : i303_M );
        t[ind][1] = (ULO) i303dis;
        t[ind][2] = (ULO) ( regs*4 + ((modes == 0) ?
                                (ULO) d:
                                (ULO) a) );
        t[ind][3] = (ULO) eac[flats];
      }
}

/*
 Instruction BFEXTU <ea>{offset:size},Dn
 Table-usage:

  0-Routineptr, 1 - disasm routine, 2-srcreg, 3-srcroutine, 4 - cycle count
*/

ULO i304dis(ULO prc,ULO opc,char *st)
{
  
  ULO pos=13,reg=opc&0x7,dreg=(opc&0xe00)>>9,mode=(opc&0x38)>>3;
  if (mode == 7) mode += reg;
  sprintf(st,"$%.6X %.4X      !!!!!!       BFEXTU  ");
  prc = disfordel(reg,prc+2,st,16,mode,&pos);
  strcat(st,",");
  disfordel(dreg,prc,st,16,0,&pos);
  
  return prc;
}

void i304ini(void) {
  ULO op=0xe9c0,ind,modes,regs,flats;
  for (modes = 0; modes < 8; modes++)
    for (regs = 0; regs < 8; regs++)
      flats = (modes != 7) ? modes : modes+regs;
      if ((control[flats] && alterable[flats]) || (flats == 0)) {
        ind = op|modes<<3|regs;
        t[ind][0] = (ULO) ( (modes == 0) ? i304_R : i304_M );
        t[ind][1] = (ULO) i304dis;
        t[ind][2] = (ULO) ( regs*4 + ((modes == 0) ?
                                (ULO) d:
                                (ULO) a) );
        t[ind][3] = (ULO) eac[flats];
      }
}

/*
 Instruction BFFFO <ea>{offset:size},Dn
 Table-usage:

  0-Routineptr, 1 - disasm routine, 2-srcreg, 3-srcroutine, 4 - cycle count
*/

ULO i305dis(ULO prc,ULO opc,char *st)
{
  
  ULO pos=13,reg=opc&0x7,dreg=(opc&0xe00)>>9,mode=(opc&0x38)>>3;
  if (mode == 7) mode += reg;
  sprintf(st,"$%.6X %.4X      !!!!!!       BFFFO   ");
  prc = disfordel(reg,prc+2,st,16,mode,&pos);
  strcat(st,",");
  disfordel(dreg,prc,st,16,0,&pos);
  
  return prc;
}

void i305ini(void) {
  ULO op=0xedc0,ind,modes,regs,flats;
  for (modes = 0; modes < 8; modes++)
    for (regs = 0; regs < 8; regs++)
      flats = (modes != 7) ? modes : modes+regs;
      if ((control[flats] && alterable[flats]) || (flats == 0)) {
        ind = op|modes<<3|regs;
        t[ind][0] = (ULO) ( (modes == 0) ? i305_R : i305_M );
        t[ind][1] = (ULO) i305dis;
        t[ind][2] = (ULO) ( regs*4 + ((modes == 0) ?
                                (ULO) d:
                                (ULO) a) );
        t[ind][3] = (ULO) eac[flats];
      }
}

/*
 Instruction BFINS Dn,<ea>{offset:size}
 Table-usage:

  0-Routineptr, 1 - disasm routine, 2-srcreg, 3-srcroutine, 4 - cycle count
*/

ULO i306dis(ULO prc,ULO opc,char *st)
{
  
  ULO pos=13,reg=opc&0x7,dreg=(opc&0xe00)>>9,mode=(opc&0x38)>>3;
  if (mode == 7) mode += reg;
  sprintf(st,"$%.6X %.4X      !!!!!!       BFINS   ");
  prc = disfordel(reg,prc+2,st,16,mode,&pos);
  strcat(st,",");
  disfordel(dreg,prc,st,16,0,&pos);
  
  return prc;
}

void i306ini(void) {
  ULO op=0xefc0,ind,modes,regs,flats;
  for (modes = 0; modes < 8; modes++)
    for (regs = 0; regs < 8; regs++)
      flats = (modes != 7) ? modes : modes+regs;
      if ((control[flats] && alterable[flats]) || (flats == 0)) {
        ind = op|modes<<3|regs;
        t[ind][0] = (ULO) ( (modes == 0) ? i306_R : i306_M );
        t[ind][1] = (ULO) i306dis;
        t[ind][2] = (ULO) ( regs*4 + ((modes == 0) ?
                                (ULO) d:
                                (ULO) a) );
        t[ind][3] = (ULO) eac[flats];
      }
}

/*
 Instruction BFSET <ea>{offset:size}
 Table-usage:

  0-Routineptr, 1-disasm routine,  2-srcreg, 3-srcroutine, 4 - cycle count
*/

ULO i307dis(ULO prc,ULO opc,char *st)
{
  
  ULO pos=13,reg=opc&0x7,dreg=(opc&0xe00)>>9,mode=(opc&0x38)>>3;
  if (mode == 7) mode += reg;
  sprintf(st,"$%.6X %.4X      !!!!!!       BFSET   ");
  prc = disfordel(reg,prc+2,st,16,mode,&pos);
  strcat(st,",");
  disfordel(dreg,prc,st,16,0,&pos);
  
  return prc;
}

void i307ini(void) {
  ULO op=0xeec0,ind,modes,regs,flats;
  for (modes = 0; modes < 8; modes++)
    for (regs = 0; regs < 8; regs++)
      flats = (modes != 7) ? modes : modes+regs;
      if ((control[flats] && alterable[flats]) || (flats == 0)) {
        ind = op|modes<<3|regs;
        t[ind][0] = (ULO) ( (modes == 0) ? i307_R : i307_M );
        t[ind][1] = (ULO) i307dis;
        t[ind][2] = (ULO) ( regs*4 + ((modes == 0) ?
                                (ULO) d:
                                (ULO) a) );
        t[ind][3] = (ULO) eac[flats];
      }
}

/*
 Instruction BFTST <ea>{offset:size}
 Table-usage:

  0-Routineptr, 1-disasm routine,  2-srcreg, 3-srcroutine, 4 - cycle count
*/

ULO i308dis(ULO prc,ULO opc,char *st)
{
  
  ULO pos=13,reg=opc&0x7,dreg=(opc&0xe00)>>9,mode=(opc&0x38)>>3;
  if (mode == 7) mode += reg;
  sprintf(st,"$%.6X %.4X      !!!!!!       BFTST   ");
  prc = disfordel(reg,prc+2,st,16,mode,&pos);
  strcat(st,",");
  disfordel(dreg,prc,st,16,0,&pos);
  
  return prc;
}

void i308ini(void) {
  ULO op=0xe8c0,ind,modes,regs,flats;
  for (modes = 0; modes < 8; modes++)
    for (regs = 0; regs < 8; regs++)
      flats = (modes != 7) ? modes : modes+regs;
      if ((control[flats] && alterable[flats]) || (flats == 0)) {
        ind = op|modes<<3|regs;
        t[ind][0] = (ULO) ( (modes == 0) ? i308_R : i308_M );
        t[ind][1] = (ULO) i308dis;
        t[ind][2] = (ULO) ( regs*4 + ((modes == 0) ?
                                (ULO) d:
                                (ULO) a) );
        t[ind][3] = (ULO) eac[flats];
      }
}

/*
 Instruction CAS Dc,Du,<ea>
 Table-usage:

  0-Routineptr, 1-disasm routine,  2-srcreg, 3-srcroutine, 4 - cycle count
*/

ULO i309dis(ULO prc,ULO opc,char *st)
{
  
  ULO pos=13,reg=opc&0x7,dreg=(opc&0xe00)>>9,mode=(opc&0x38)>>3;
  if (mode == 7) mode += reg;
  sprintf(st,"$%.6X %.4X      !!!!!!       CAS     ");
  prc = disfordel(reg,prc+2,st,16,mode,&pos);
  strcat(st,",");
  disfordel(dreg,prc,st,16,0,&pos);
  
  return prc;
}

void i309ini(void) {
  ULO op=0x08c0,ind,siz,modes,regs,flats;
  for (siz = 0; siz < 3; siz++)
    for (modes = 0; modes < 8; modes++)
      for (regs = 0; regs < 8; regs++)
        flats = (modes != 7) ? modes : modes+regs;
        if (memory[flats] && alterable[flats]) {
          ind = op|siz<<9|modes<<3|regs;
          t[ind][0] = (ULO) ( (siz == 0) ? i309_B :
                              (siz == 1) ? i309_W : i309_L );
          t[ind][1] = (ULO) i309dis;
          t[ind][2] = (ULO) (regs*4 + a);
          t[ind][3] = (ULO) eac[flats];
        }
}

/*
 Instruction CAS2 Dc1:Dc2,Du1:Du2,(Rx1):(Rx2)
 Table-usage:

  0-Routineptr, 1-disasm routine, 2 - cycle count
*/

ULO i310dis(ULO prc,ULO opc,char *st)
{
  
  ULO pos=13,reg=opc&0x7,dreg=(opc&0xe00)>>9,mode=(opc&0x38)>>3;
  if (mode == 7) mode += reg;
  sprintf(st,"$%.6X %.4X      !!!!!!       CAS2    ");
  prc = disfordel(reg,prc+2,st,16,mode,&pos);
  strcat(st,",");
  disfordel(dreg,prc,st,16,0,&pos);
  
  return prc;
}

void i310ini(void) {
  ULO op=0x08fc,ind,siz;
  for (siz = 1; siz < 3; siz++) {
    ind = op|siz<<9;
    t[ind][0] = (ULO) ( (siz == 1) ? i310_W : i310_L );
    t[ind][1] = (ULO) i310dis;
  }
}

/*
 Instruction CHK.L <ea>,Dn
 Table-usage:

  0-Routinepointer 1-disasm routine  2-sourreg 3-sourceroutine
                   4-Dreg        5 - cycle count
*/

ULO i311dis(ULO prc,ULO opc,char *st) {
  
  ULO pos=13,reg=opc&0x7,dreg=(opc&0xe00)>>9,mode=(opc&0x38)>>3;
  if (mode == 7) mode += reg;
  sprintf(st,"$%.6X %.4X                   CHK.L   ",prc,opc);
  prc = disfordel(reg,prc+2,st,16,mode,&pos);
  strcat(st,",");
  disfordel(dreg,prc,st,16,0,&pos);
  
  return prc;
}

void i311ini(void) {
  ULO op=0x4100,ind,regd,modes,regs,flats;
  for (regd = 0; regd < 8; regd++)
    for (modes = 0; modes < 8; modes++)
      for (regs = 0; regs < 8; regs++)
        if (data[(flats = (modes != 7) ? modes : modes+regs)]) {
          ind = op|regd<<9|modes<<3|regs;
          t[ind][0] = (ULO) i311;
          t[ind][1] = (ULO) i311dis;
          t[ind][2] = (ULO) ( regs*4 + ((modes == 0) ?
                                  (ULO) d:
                                  (ULO) a) );
          t[ind][3] = (ULO) arw[flats];
          t[ind][4] = regd*4 + (ULO) d;
          t[ind][5] = 10+tarl[flats];
          }
}

/*
 Instruction CHK2.X <ea>,Rn / CMP2.X <ea>,Rn
 Table-usage:

  0 - Routinepointer, 1 - disasm routine, 2 - sourreg
  3 - sourceroutine, 4 - cycle count
*/

ULO i312dis(ULO prc,ULO opc,char *st) {
  
  ULO pos=13,reg=opc&0x7,dreg=(opc&0xe00)>>9,mode=(opc&0x38)>>3;
  if (mode == 7) mode += reg;
  sprintf(st,"$%.6X %.4X      !!!!!!       CHK2.?   ",prc,opc);
  prc = disfordel(reg,prc+2,st,16,mode,&pos);
  strcat(st,",");
  disfordel(dreg,prc,st,16,0,&pos);
  
  return prc;
}

void i312ini(void) {
  ULO op=0x00c0,ind,siz,modes,regs,flats;
  for (siz = 0; siz < 3; siz++)
    for (modes = 0; modes < 8; modes++)
      for (regs = 0; regs < 8; regs++)
        if (control[(flats = (modes != 7) ? modes : modes+regs)]) {
          ind = op|siz<<9|modes<<3|regs;
          t[ind][0] = (ULO) ( (siz == 0) ? i312_B :
                              (siz == 1) ? i312_W : i312_L);
          t[ind][1] = (ULO) i312dis;
          t[ind][2] = (ULO) ( regs*4 + ((modes == 0) ?
                                  (ULO) d:
                                  (ULO) a) );
          t[ind][3] = (ULO) ( (siz == 0) ? arb[flats] :
                              (siz == 1) ? arw[flats] : arl[flats]);
          t[ind][4] = 10 + (siz == 0) ? tarb[flats] :
                           (siz == 1) ? tarw[flats] : tarl[flats];
        }
}

/*
 Instruction cpBcc <label>
 Table-usage:

  0 - Routinepointer, 1 - disasm routine, 2 - coprocessor, 3 - condition
*/

ULO i313dis(ULO prc,ULO opc,char *st) {
  
  ULO pos=13,reg=opc&0x7,dreg=(opc&0xe00)>>9,mode=(opc&0x38)>>3;
  if (mode == 7) mode += reg;
  sprintf(st,"$%.6X %.4X      !!!!!!       cpBcc    ",prc,opc);
  prc = disfordel(reg,prc+2,st,16,mode,&pos);
  strcat(st,",");
  disfordel(dreg,prc,st,16,0,&pos);
  
  return prc;
}

void i313ini(void) {
  ULO op=0xf080,ind,cpnum,cond,siz;
  for (siz = 0; siz < 2; siz++)
    for (cpnum = 1; cpnum < 8; cpnum++)
      for (cond = 0; cond < 64; cond++) {
        ind = op|cpnum<<9|siz<<6|cond;
        t[ind][0] = (ULO) ( (siz == 0) ? i313_W : i313_L );
        t[ind][1] = (ULO) i313dis;
        t[ind][2] = cpnum;
        t[ind][3] = cond;
      }
}

/*
 Instruction cpDBcc <label>
 Table-usage:

  0 - Routinepointer, 1 - disasm routine, 2 - coprocessor, 3 - *Dn
*/

ULO i314dis(ULO prc,ULO opc,char *st) {
  
  ULO pos=13,reg=opc&0x7,dreg=(opc&0xe00)>>9,mode=(opc&0x38)>>3;
  if (mode == 7) mode += reg;
  sprintf(st,"$%.6X %.4X      !!!!!!       cpDBcc   ",prc,opc);
  prc = disfordel(reg,prc+2,st,16,mode,&pos);
  strcat(st,",");
  disfordel(dreg,prc,st,16,0,&pos);
  
  return prc;
}

void i314ini(void) {
  ULO op=0xf480,ind,cpnum,reg;
  for (cpnum = 1; cpnum < 8; cpnum++)
    for (reg = 0; reg < 8; reg++) {
      ind = op|cpnum<<9|reg;
      t[ind][0] = (ULO) i314;
      t[ind][1] = (ULO) i314dis;
      t[ind][2] = cpnum;
      t[ind][3] = (ULO) (d+reg*4);
    }
}

/*
 Instruction cpGEN
 Table-usage:

  0 - Routinepointer, 1 - disasm routine
  2 - coprocessor, 3 - reg, 4 - srcproc
*/

ULO i315dis(ULO prc,ULO opc,char *st) {
  
  ULO pos=13,reg=opc&0x7,dreg=(opc&0xe00)>>9,mode=(opc&0x38)>>3;
  if (mode == 7) mode += reg;
  sprintf(st,"$%.6X %.4X      !!!!!!       cpGEN    ",prc,opc);
  prc = disfordel(reg,prc+2,st,16,mode,&pos);
  strcat(st,",");
  disfordel(dreg,prc,st,16,0,&pos);
  
  return prc;
}

void i315ini(void) {
  ULO op=0xf000,ind,cpnum,modes,regs,flats;
  for (cpnum = 1; cpnum < 8; cpnum++)
    for (modes = 0; modes < 8; modes++)
      for (regs = 0; regs < 8; regs++) {
        if( allmodes[(flats = (modes != 7) ? modes : modes + regs)] ) {
          ind = op|cpnum<<9|modes<<3|regs;
          t[ind][0] = (ULO) i315;
          t[ind][1] = (ULO) i315dis;
          t[ind][2] = cpnum;
          t[ind][3] = (ULO) ( (flats==0) ? (d+regs*4) : (a+regs*4) );
          t[ind][4] = (ULO) arw[flats];
        }
      }
}

/*
 Instruction cpRESTORE <ea>
 Table-usage:

  0 - Routinepointer, 1 - disasm routine
  2 - coprocessor, 3 - reg, 4 - srcproc
*/

ULO i316dis(ULO prc,ULO opc,char *st) {
  
  ULO pos=13,reg=opc&0x7,dreg=(opc&0xe00)>>9,mode=(opc&0x38)>>3;
  if (mode == 7) mode += reg;
  sprintf(st,"$%.6X %.4X      !!!!!!       cpRESTORE",prc,opc);
  prc = disfordel(reg,prc+2,st,16,mode,&pos);
  strcat(st,",");
  disfordel(dreg,prc,st,16,0,&pos);
  
  return prc;
}

void i316ini(void) {
  ULO op=0xf140,ind,cpnum,modes,regs,flats;
  for (cpnum = 1; cpnum < 8; cpnum++)
    for (modes = 0; modes < 8; modes++)
      for (regs = 0; regs < 8; regs++) {
        flats = (modes != 7) ? modes : modes + regs;
        if( control[flats] || flats == 2 ) {
          ind = op|cpnum<<9|modes<<3|regs;
          t[ind][0] = (ULO) i316;
          t[ind][1] = (ULO) i316dis;
          t[ind][2] = cpnum;
          t[ind][3] = (ULO) (a+regs*4);
          t[ind][4] = (ULO) arw[flats];
        }
      }
}

/*
 Instruction cpSAVE <ea>
 Table-usage:

  0 - Routinepointer, 1 - disasm routine
  2 - coprocessor, 3 - reg, 4 - dstproc
*/

ULO i317dis(ULO prc,ULO opc,char *st) {
  
  ULO pos=13,reg=opc&0x7,dreg=(opc&0xe00)>>9,mode=(opc&0x38)>>3;
  if (mode == 7) mode += reg;
  sprintf(st,"$%.6X %.4X      !!!!!!       cpSAVE   ",prc,opc);
  prc = disfordel(reg,prc+2,st,16,mode,&pos);
  strcat(st,",");
  disfordel(dreg,prc,st,16,0,&pos);
  
  return prc;
}

void i317ini(void) {
  ULO op=0xf100,ind,cpnum,modes,regs,flats;
  for (cpnum = 1; cpnum < 8; cpnum++)
    for (modes = 0; modes < 8; modes++)
      for (regs = 0; regs < 8; regs++) {
        flats = (modes != 7) ? modes : modes + regs;
        if( control[flats] || flats == 3 ) {
          ind = op|cpnum<<9|modes<<3|regs;
          t[ind][0] = (ULO) i317;
          t[ind][1] = (ULO) i317dis;
          t[ind][2] = cpnum;
          t[ind][3] = (ULO) (a+regs*4);
          t[ind][4] = (ULO) aww[flats];
        }
      }
}

/*
 Instruction cpScc <ea>
 Table-usage:

  0 - Routinepointer, 1 - disasm routine
  2 - coprocessor, 3 - reg, 4 - dstproc
*/

ULO i318dis(ULO prc,ULO opc,char *st) {
  
  ULO pos=13,reg=opc&0x7,dreg=(opc&0xe00)>>9,mode=(opc&0x38)>>3;
  if (mode == 7) mode += reg;
  sprintf(st,"$%.6X %.4X      !!!!!!       cpScc    ",prc,opc);
  prc = disfordel(reg,prc+2,st,16,mode,&pos);
  strcat(st,",");
  disfordel(dreg,prc,st,16,0,&pos);
  
  return prc;
}

void i318ini(void) {
  ULO op=0xf040,ind,cpnum,modes,regs,flats;
  for (cpnum = 1; cpnum < 8; cpnum++)
    for (modes = 0; modes < 8; modes++)
      for (regs = 0; regs < 8; regs++) {
        flats = (modes != 7) ? modes : modes + regs;
        if( data[flats] && alterable[flats] ) {
          ind = op|cpnum<<9|modes<<3|regs;
          t[ind][0] = (ULO) i318;
          t[ind][1] = (ULO) i318dis;
          t[ind][2] = cpnum;
          t[ind][3] = (ULO) ( (flats==0) ? (d+regs*4) : (a+regs*4) );
          t[ind][4] = (ULO) awb[flats];
        }
      }
}

/*
 Instruction cpTRAPcc #
 Table-usage:

  0 - Routinepointer, 1 - disasm routine
  2 - coprocessor, 3 - operand type
*/

ULO i319dis(ULO prc,ULO opc,char *st) {
  
  ULO pos=13,reg=opc&0x7,dreg=(opc&0xe00)>>9,mode=(opc&0x38)>>3;
  if (mode == 7) mode += reg;
  sprintf(st,"$%.6X %.4X      !!!!!!       cpTRAPcc ",prc,opc);
  prc = disfordel(reg,prc+2,st,16,mode,&pos);
  strcat(st,",");
  disfordel(dreg,prc,st,16,0,&pos);
  
  return prc;
}

void i319ini(void) {
  ULO op=0xf040,ind,cpnum,optype;
  for (cpnum = 1; cpnum < 8; cpnum++)
    for( optype = 2; optype < 5; optype++) {
      ind = op|cpnum<<9|optype;
      t[ind][0] = (ULO) i319;
      t[ind][1] = (ULO) i319dis;
      t[ind][2] = cpnum;
      t[ind][3] = (ULO) ( (optype!=4) ? optype-1 : 0 );
    }
}

/*
 Instruction DIV(S/U).L <ea>,Dq / DIV(S/U).L <ea>,Dr:Dq / DIV(S/U)L <ea>,Dr:Dq
 Table-usage:

  0-Routinepointer 1-disasm routine  2-sourreg 3-sourceroutine
*/

ULO i320dis(ULO prc,ULO opc,char *st)
{
  
  ULO pos=13,reg=opc&0x7,dreg=(opc&0xe00)>>9,mode=(opc&0x38)>>3;
  if (mode == 7) mode += reg;
  sprintf(st,"$%.6X %.4X      !!!!!!!      DIVS.L  ",prc,opc);
  prc = disfordel(reg,prc+2,st,16,mode,&pos);
  strcat(st,",");
  disfordel(dreg,prc,st,16,0,&pos);
  
  return prc;
}

void i320ini(void)
{
  ULO op=0x4c40,ind,modes,regs,flats;
  for (modes = 0; modes < 8; modes++)
    for (regs = 0; regs < 8; regs++)
      if (data[(flats = (modes != 7) ? modes : (modes+regs))]) {
        ind = op|modes<<3|regs;
        t[ind][0] = (ULO) i320;
        t[ind][1] = (ULO) i320dis;
        t[ind][2] = (ULO) ( regs*4 + (modes == 0) ? d : a );
        t[ind][3] = (ULO) arl[flats];
      }
}

/*
 Instruction EXTB Dx
 Table-usage:

  0-Routinepointer 1-disasm routine  2-reg 3-cycle count
*/

ULO i321dis(ULO prc,ULO opc,char *st) {
  
  ULO pos=13,o=opc&BIT6,reg=opc&SREG;
  sprintf(st,"$%.6X %.4X                   EXTB    D%d",prc,opc,reg);
  
  return prc+2;
}

void i321ini(void) {
  ULO op=0x49c0,ind,o,regs;
  for (regs = 0; regs < 8; regs++) {
    ind = op|regs;
    t[ind][0] = (ULO) i321;
    t[ind][1] = (ULO) i321dis;
    t[ind][2] = regs*4 + (ULO) d;
  }
}

/*
 Instruction LINK.L An,#
 Table-usage:

  0 - Routinepointer, 1 - disasm routine, 2 - reg
*/

ULO i322dis(ULO prc,ULO opc,char *st) {
  
  ULO pos=13,o=opc&BIT6,reg=opc&SREG;
  sprintf(st,"$%.6X %.4X                   LINK.L  A%d",prc,opc,reg);
  
  return prc+2;
}

void i322ini(void) {
  ULO op=0x4808,ind,o,regs;
  for (regs = 0; regs < 8; regs++) {
    ind = op|regs;
    t[ind][0] = (ULO) i322;
    t[ind][1] = (ULO) i322dis;
    t[ind][2] = regs*4 + (ULO) d;
  }
}

/*
 Instruction MOVE.W CCR,<ea>
 Table-usage:

  0-Routinepointer, 1-disasm routine, 2-dstreg, 3-dstroutine, 4-cycle count
*/

ULO i323dis(ULO prc,ULO opc,char *st)
{
  
  ULO pos=13,reg=opc&SREG,mode=(opc&SMOD)>>3;
  sprintf(st,"$%.6X %.4X                   MOVE.W  ",prc,opc);
  if (mode == 7) mode += reg;
  prc = disfordel(reg,prc+2,st,8,mode,&pos);
  strcat(st,",CCR");
  
  return prc;
}

void i323ini(void)
{
  ULO op=0x42c0,ind,reg,mode,flat;
  for (reg = 0; reg < 8; reg++)
    for (mode = 0; mode < 8; mode++) {
      flat = (mode != 7) ? mode : (mode+reg);
      if (data[flat] && alterable[flat]) {
        ind = op|mode<<3|reg;
        t[ind][0] = (ULO) i323;
        t[ind][1] = (ULO) i323dis;
        t[ind][2] = (ULO) ( (mode == 0) ? (reg*4 + d): (reg*4 + a) );
        t[ind][3] = (ULO) aww[flat];
        t[ind][4] = 12 + tarw[flat];
      }
    }
}

/*
 Instruction MOVEC Rc,Rn / Rn,Rc
 Table-usage:

  0-Routinepointer, 1-disasm routine
*/

ULO i324dis(ULO prc,ULO opc,char *st)
{
  
  ULO pos=13,reg=opc&SREG,mode=(opc&SMOD)>>3;
  sprintf(st,"$%.6X %.4X                   MOVEC   ",prc,opc);
  if (mode == 7) mode += reg;
  prc = disfordel(reg,prc+2,st,8,mode,&pos);
  strcat(st,",CCR");
  
  return prc;
}

void i324ini(void)
{
  ULO op=0x4e7a,ind,mode;
  for (mode = 0; mode < 2; mode++) {
    ind = op|mode;
    t[ind][0] = (ULO) ( (mode == 0) ? i324_R : i324_W );
    t[ind][1] = (ULO) i324dis;
  }
}

/*
 Instruction MOVES Rn,<ea> / <ea>,Rn
 Table-usage:

  0-Routinepointer, 1-disasm routine, 2-reg
  3-srcroutine, 4-dstroutine, 5-cycle count
*/

ULO i325dis(ULO prc,ULO opc,char *st)
{
  
  ULO pos=13,reg=opc&SREG,mode=(opc&SMOD)>>3;
  sprintf(st,"$%.6X %.4X                   MOVES   ",prc,opc);
  if (mode == 7) mode += reg;
  prc = disfordel(reg,prc+2,st,8,mode,&pos);
  strcat(st,",CCR");
  
  return prc;
}

void i325ini(void)
{
  ULO op=0x0e00,ind,siz,reg,mode,flat;
  for (siz = 0; siz < 3; siz++)
    for (reg = 0; reg < 8; reg++)
      for (mode = 0; mode < 8; mode++) {
        flat = (mode != 7) ? mode : (mode+reg);
        if (memory[flat] && alterable[flat]) {
          ind = op|siz<<6|mode<<3|reg;
          t[ind][0] = (ULO) ( (siz == 0) ? i325_B :
                              (siz == 1) ? i325_W : i325_L );
          t[ind][1] = (ULO) i325dis;
          t[ind][2] = (ULO) ( reg*4 + a );
          t[ind][3] = (ULO) ( (siz == 0) ? arb[flat] :
                              (siz == 1) ? arw[flat] : arl[flat] );
          t[ind][4] = (ULO) ( (siz == 0) ? awb[flat] :
                              (siz == 1) ? aww[flat] : awl[flat] );
          t[ind][5] = 12 + tarw[flat];
        }
      }
}

/*
 Instruction MUL(S/U).L <ea>,Dn / MUL(S/U).L <ea>,Dh:Dl
 Table-usage:

  0-Routinepointer 1-disasm routine  2-sourreg 3-sourceroutine
*/

ULO i326dis(ULO prc,ULO opc,char *st)
{
  
  ULO pos=13,reg=opc&0x7,dreg=(opc&0xe00)>>9,mode=(opc&0x38)>>3;
  if (mode == 7) mode += reg;
  sprintf(st,"$%.6X %.4X      !!!!!!!      MULS.L  ",prc,opc);
  prc = disfordel(reg,prc+2,st,16,mode,&pos);
  strcat(st,",");
  disfordel(dreg,prc,st,16,0,&pos);
  
  return prc;
}

void i326ini(void)
{
  ULO op=0x4c00,ind,modes,regs,flats;
  for (modes = 0; modes < 8; modes++)
    for (regs = 0; regs < 8; regs++)
      if (data[(flats = (modes != 7) ? modes : (modes+regs))]) {
        ind = op|modes<<3|regs;
        t[ind][0] = (ULO) i326;
        t[ind][1] = (ULO) i326dis;
        t[ind][2] = (ULO) ( regs*4 + (modes == 0) ? d : a );
        t[ind][3] = (ULO) arw[flats];
      }
}

/*
 Instruction PACK -(Ax),-(Ay),# / Dx,Dy,#
 Table-usage:

  0 - Routinepointer, 1 - disasm routine, 2-srcreg
  3-srcroutine, 4 - dstreg, 5 - dstroutine
*/

ULO i327dis(ULO prc,ULO opc,char *st)
{
  
  ULO pos=13,reg=opc&0x7,dreg=(opc&0xe00)>>9,mode=(opc&0x38)>>3;
  if (mode == 7) mode += reg;
  sprintf(st,"$%.6X %.4X      !!!!!!!      PACK    ",prc,opc);
  prc = disfordel(reg,prc+2,st,16,mode,&pos);
  strcat(st,",");
  disfordel(dreg,prc,st,16,0,&pos);
  
  return prc;
}

void i327ini(void)
{
  ULO op=0x8140,ind,mode,regs,regd;
  for (mode = 0; mode < 2; mode++)
    for (regs = 0; regs < 8; regs++)
      for (regd = 0; regd < 8; regd++) {
        ind = op|regd<<9|mode<<3|regs;
        t[ind][0] = (ULO) i327;
        t[ind][1] = (ULO) i327dis;
        t[ind][2] = (ULO) ( regs*4 + (mode == 0) ? d : a );
        t[ind][3] = (ULO) arw[mode<<2];
        t[ind][4] = (ULO) ( regd*4 + (mode == 0) ? d : a );
        t[ind][5] = (ULO) awb[mode<<2];
      }
}

/*
 Instruction PFLUSH A / <fc>,# / <fc>,#,<ea>
 Instruction PLOADR <fc>,<ea> / PLOADW <fc>,<ea>
 Instruction PMOVE reg,<ea> / <ea>,reg / PMOVEFD <ea>,reg
 Instruction PTESTR/W <fc>,<ea>,# / <fc>,<ea>,#,An
 Table-usage:

  0-Routinepointer 1-disasm routine  2-srcreg 3-srcroutine
*/

ULO i328dis(ULO prc,ULO opc,char *st)
{
  
  ULO pos=13,reg=opc&0x7,dreg=(opc&0xe00)>>9,mode=(opc&0x38)>>3;
  if (mode == 7) mode += reg;
  sprintf(st,"$%.6X %.4X      !!!!!!!      P____   ",prc,opc);
  prc = disfordel(reg,prc+2,st,16,mode,&pos);
  strcat(st,",");
  disfordel(dreg,prc,st,16,0,&pos);
  
  return prc;
}

void i328ini(void)
{
  ULO op=0xf000,ind,modes,regs,flats;
  for (modes = 0; modes < 8; modes++)
    for (regs = 0; regs < 8; regs++)
      flats = (modes != 7) ? modes : (modes+regs);
      if (control[flats] && alterable[flats]) {
        ind = op|modes<<3|regs;
        t[ind][0] = (ULO) i328;
        t[ind][1] = (ULO) i328dis;
        t[ind][2] = (ULO) ( regs*4 + (modes == 0) ? d : a );
        t[ind][3] = (ULO) arl[flats];
      }
}

/*
 Instruction RTD
 Table-usage:

  0-Routinepointer, 1-disasm routine
*/

ULO i329dis(ULO prc,ULO opc,char *st)
{
  
  ULO pos=13,reg=opc&SREG,mode=(opc&SMOD)>>3;
  sprintf(st,"$%.6X %.4X                   RTD #   ",prc,opc);
  if (mode == 7) mode += reg;
  prc = disfordel(reg,prc+2,st,8,mode,&pos);
  strcat(st,",CCR");
  
  return prc;
}

void i329ini(void)
{
  ULO ind = 0x4e74;
  t[ind][0] = (ULO) i329;
  t[ind][1] = (ULO) i329dis;
}

/*
 Instruction TRAPcc
 Table-usage:

  0 - Routinepointer, 1 - disasm routine, 2 - handle routine, 3 - paramsize
*/

ULO i330dis(ULO prc,ULO opc,char *st)
{
  
  ULO pos=13,j,adr;
  sprintf(st,"$%.6X %.4X                   TRAP",prc,opc);
  switch ((opc&0xf00)>>8) {
     case 0:  strcat(st,"RA.");
              break;
     case 1:  strcat(st,"SR.");
              break;
     case 2:  strcat(st,"HI.");
              break;
     case 3:  strcat(st,"LS.");
              break;
     case 4:  strcat(st,"CC.");
              break;
     case 5:  strcat(st,"CS.");
              break;
     case 6:  strcat(st,"NE.");
              break;
     case 7:  strcat(st,"EQ.");
              break;
     case 8:  strcat(st,"VC.");
              break;
     case 9:  strcat(st,"VS.");
              break;
     case 10: strcat(st,"PL.");
              break;
     case 11: strcat(st,"MI.");
              break;
     case 12: strcat(st,"GE.");
              break;
     case 13: strcat(st,"LT.");
              break;
     case 14: strcat(st,"GT.");
              break;
     case 15: strcat(st,"LE.");
              break;
       }
  strcat(st,(t[opc][2] == 0) ? "W  ":"B  ");
  if (t[opc][2] == 0) {
    prc += 2;
    j = fetw(prc);
    sprintf(&st[13],"%4.4X",j);
    st[17] = ' ';
    adr = (j > 32767) ?
             prc+j-65536:
             prc+j;
    }
  else adr = prc+2+t[opc][2];
  sprintf(&st[36],"   $%6.6X",adr);
  
  return prc+2;
}

void i330ini(void)
{
  ULO op=0x50f8,c,mode,ind;
  ULO routines[16] = {(ULO) cc0,(ULO) cc1,(ULO) cc2,(ULO) cc3,(ULO) cc4,(ULO) cc5,(ULO) cc6,(ULO) cc7,(ULO) cc8,(ULO) cc9,(ULO) cca,(ULO) ccb,(ULO) ccc,(ULO) ccd,(ULO) cce,(ULO) ccf};
  for (c = 0; c < 16; c++)
    for (mode = 2; mode < 5; mode++) {
      ind = op|c<<8|mode;
      t[ind][0] = (ULO) i330;
      t[ind][1] = (ULO) i330dis;
      t[ind][2] = routines[c];
      t[ind][3] = (mode!=4) ? mode-1 : 0;
      }
}

/*
 Instruction UNPK -(Ax),-(Ay),# / Dx,Dy,#
 Table-usage:

  0 - Routinepointer, 1 - disasm routine, 2-srcreg
  3-srcroutine, 4 - dstreg, 5 - dstroutine
*/

ULO i331dis(ULO prc,ULO opc,char *st)
{
  
  ULO pos=13,reg=opc&0x7,dreg=(opc&0xe00)>>9,mode=(opc&0x38)>>3;
  if (mode == 7) mode += reg;
  sprintf(st,"$%.6X %.4X      !!!!!!!      UNPK    ",prc,opc);
  prc = disfordel(reg,prc+2,st,16,mode,&pos);
  strcat(st,",");
  disfordel(dreg,prc,st,16,0,&pos);
  
  return prc;
}

void i331ini(void)
{
  ULO op=0x8180,ind,mode,regs,regd;
  for (mode = 0; mode < 2; mode++)
    for (regs = 0; regs < 8; regs++)
      for (regd = 0; regd < 8; regd++) {
        ind = op|regd<<9|mode<<3|regs;
        t[ind][0] = (ULO) i331;
        t[ind][1] = (ULO) i331dis;
        t[ind][2] = (ULO) ( regs*4 + (mode == 0) ? d : a );
        t[ind][3] = (ULO) arb[mode<<2];
        t[ind][4] = (ULO) ( regd*4 + (mode == 0) ? d : a );
        t[ind][5] = (ULO) aww[mode<<2];
      }
}

void init_adrmode_tables_68030(void) {
  int i;

  for (i = 0; i < 12; i++) {    /* Set adressmode data to 680x0 stubs */
    arb[i] = arb68000[i];// 12*cputype];
    arw[i] = arw68000[i];// 12*cputype];
    arl[i] = arl68000[i];// 12*cputype];
    parb[i] = parb68000[i];// 12*cputype];
    parw[i] = parw68000[i];// 12*cputype];
    parl[i] = parl68000[i];// 12*cputype];
    awb[i] = awb68000[i];// 12*cputype];
    aww[i] = aww68000[i];// 12*cputype];
    awl[i] = awl68000[i];// 12*cputype];
    eac[i] = eac68000[i];// 12*cputype];
    tarb[i] = tarb68000[i];    /* let even 68030 instrs to have same timing */
    tarw[i] = tarw68000[i];    /* not right, though... */
    tarl[i] = tarl68000[i];
    }
}

void cpureset68030(void) {
        int i;

        for (i = 0; i < 8; i++) d[i] = a[i] = 0;
        usp = a[7] = config_memory_chipsize;
        ssp = config_memory_chipsize - 0x2000;
}

void cpuinit68030(void) {
    i301ini();                          /* BFCHG */
    i302ini();                          /* BFCLR */
    i303ini();                          /* BFEXTS */
    i304ini();                          /* BFEXTU */
    i305ini();                          /* BFFFO */
    i306ini();                          /* BFINS */
    i307ini();                          /* BFSET */
    i308ini();                          /* BFTST */
    i309ini();                          /* CAS */
    i310ini();                          /* CAS2 */
    i311ini();                          /* CHK.D */
    i312ini();                          /* CHK2/CMP2 */
    i313ini();                          /* cpBcc */
    i314ini();                          /* cpDBcc */
    i315ini();                          /* cpGEN */
    i316ini();                          /* cpRESTORE */
    i317ini();                          /* cpSAVE */
    i318ini();                          /* cpScc */
    i319ini();                          /* cpTRAPcc */
    i320ini();                          /* DIVSL/DIVUL */
    i321ini();                          /* EXTB */
    i322ini();                          /* LINK.L */
    i323ini();                          /* MOVE.W CCR */
    i324ini();                          /* MOVEC */
    i325ini();                          /* MOVES */
    i326ini();                          /* MULSL/MULUL */
    i327ini();                          /* PACK */
    i328ini();                          /* PFLUSH/PLOAD/PMOVE/PTEST */
    i329ini();                          /* RTD */
    i330ini();                          /* TRAPcc */
    i331ini();                          /* UNPK */
}



