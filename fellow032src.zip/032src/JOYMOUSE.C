/*==========================*/
/* Fellow 1997 Petter Schau */
/* Joystick first try       */
/* Mouse                    */
/*==========================*/

/* Slightly inspired by the DOS UAE joystick code */
/* The auto-calibration is not very good, fix me sometime */

#include <stdio.h>
#include <dos.h>
#include <i86.h>
#include "defs.h"
#include "fellow.h"
#include "inout.h"
#include "memory.h"
#include "sddsdk\\pmpro.h"

/* Registers */

ULO potgor,potdat[2];

/* Joystickdata */
/* Flags, TRUE or FALSE */

ULO fire1[2], fire2[2], joyleft[2], joyright[2], joyup[2], joydown[2];

/* Mouse data */

short int mouseDX[2], mouseDY[2];
short int mouseLastPosX[2], mouseLastPosY[2];
short int mouseLastReadX[2], mouseLastReadY[2];
ULO mouseIrqFirstTime;

ULO mouse_pages_locked = FALSE;
ULO mouse_irq_installed = FALSE;

/* Config                 */
/*------------------------*/
/* 0 - not emulated */
/* 1 - emulate from keyboard arrows/right CTRL */
/* 2 - emulate from keyboard DFG R left CTRL */
/* 3 - emulate from Analog Joystick */
/* 5 - Mouse */

ULO config_joy[2], config_analogjoystickfound, config_mousefound;

/* Other stuff */

int joymaxx, joymaxy, joyminx, joyminy;

/* Read joystick state and set variables, is only called when */
/* analog joystick is selected */

void read_joysticks(void) {
  if (config_joy[0] == 3 || config_joy[1] == 3) {
    int i=0, j, Ax = 0, Ay = 0, tmpleft, tmpright, tmpup, tmpdown, tmpfire[2];

    j = inp(0x201);
    tmpfire[0] = !((j>>4) & 1);  /* Read buttons */
    tmpfire[0] = !((j>>5) & 1);

    irq_off();                   /* Read Joystick Values */
    outp(0x201,0xff);
    do {
      j = inp(0x201);
      Ax += (j & 1);
      Ay += ((j & 2)>>1);
    } while ( ((j & 3) != 0)  && (++i != 65536));
    irq_on();

    if (joymaxx < Ax) joymaxx = Ax; /* Update Calibration data */
    if (joymaxy < Ay) joymaxy = Ay;
    if (joyminx > Ax) joyminx = Ax;
    if (joyminy > Ay) joyminy = Ay;
    Ax -= joyminx;
    Ay -= joyminy;

    if (Ax < ((joymaxx - joyminx)/3)) tmpleft = TRUE;  /* Joystick direction */
    else tmpleft = FALSE;
    if (Ax > (((joymaxx - joyminx)/3)*2)) tmpright = TRUE;
    else tmpright = FALSE;
    if (Ay < ((joymaxy - joyminy)/3)) tmpup = TRUE;
    else tmpup = FALSE;
    if (Ay > (((joymaxy - joyminy)/3)*2)) tmpdown = TRUE;
    else tmpdown = FALSE;

    for (i = 0; i < 2; i++)
      if (config_joy[i] == 3) {
	fire1[i] = tmpfire[0];
	fire2[i] = tmpfire[1];
	joyleft[i] = tmpleft;
	joyright[i] = tmpright;
	joyup[i] = tmpup;
	joydown[i] = tmpdown;
      }
  }
}
       

/* Handle joystick keyboard replacements */

/* Arrowkeys, return TRUE if scancode is used */

int joy_keyreplacement1(int scancode) {
  if ((scancode & 0x7f) == 72) {
    if (config_joy[0] == 1) joyup[0] = !(scancode & 0x80);
    if (config_joy[1] == 1) joyup[1] = !(scancode & 0x80);
    return TRUE;
  }
  else if ((scancode & 0x7f) == 80) {
    if (config_joy[0] == 1) joydown[0] = !(scancode & 0x80);
    if (config_joy[1] == 1) joydown[1] = !(scancode & 0x80);
    return TRUE;
  }
  else if ((scancode & 0x7f) == 77) {
    if (config_joy[0] == 1) joyright[0] = !(scancode & 0x80);
    if (config_joy[1] == 1) joyright[1] = !(scancode & 0x80);
    return TRUE;
  }
  else if ((scancode & 0x7f) == 75) {
    if (config_joy[0] == 1) joyleft[0] = !(scancode & 0x80);
    if (config_joy[1] == 1) joyleft[1] = !(scancode & 0x80);
    return TRUE;
  }
  else if ((scancode & 0x7f) == 0x1d) {  /* Right CTRL */
    if (config_joy[0] == 1) fire1[0] = !(scancode & 0x80);
    if (config_joy[1] == 1) fire1[1] = !(scancode & 0x80);
    return TRUE;
  }
  else if ((scancode & 0x7f) == 0x38) {  /* Right ALT */
    if (config_joy[0] == 1) fire2[0] = !(scancode & 0x80);
    if (config_joy[1] == 1) fire2[1] = !(scancode & 0x80);
    return TRUE;
  }
  return FALSE;
}

/* DFGR LCTRL */

int joy_keyreplacement2(int scancode) {
  if ((scancode & 0x7f) == 0x13) {
    if (config_joy[0] == 2) joyup[0] = !(scancode & 0x80);
    if (config_joy[1] == 2) joyup[1] = !(scancode & 0x80);
    return TRUE;
  }
  else if ((scancode & 0x7f) == 0x21) {
    if (config_joy[0] == 2) joydown[0] = !(scancode & 0x80);
    if (config_joy[1] == 2) joydown[1] = !(scancode & 0x80);
    return TRUE;
  }
  else if ((scancode & 0x7f) == 0x22) {
    if (config_joy[0] == 2) joyright[0] = !(scancode & 0x80);
    if (config_joy[1] == 2) joyright[1] = !(scancode & 0x80);
    return TRUE;
  }
  else if ((scancode & 0x7f) == 0x20) {
    if (config_joy[0] == 2) joyleft[0] = !(scancode & 0x80);
    if (config_joy[1] == 2) joyleft[1] = !(scancode & 0x80);
    return TRUE;
  }
  else if ((scancode & 0x7f) == 29) {  /* Left CTRL */
    if (config_joy[0] == 2) fire1[0] = !(scancode & 0x80);
    if (config_joy[1] == 2) fire1[1] = !(scancode & 0x80);
    return TRUE;
  }
  else if ((scancode & 0x7f) == 0x38) {  /* Left ALT */
    if (config_joy[0] == 2) fire2[0] = !(scancode & 0x80);
    if (config_joy[1] == 2) fire2[1] = !(scancode & 0x80);
    return TRUE;
  }
  return FALSE;
}

/* Find analog joysticks */

void detect_joysticks(void) {
  int i,j;
  char s[80];
  config_analogjoystickfound = FALSE;
  i = 0;
  irq_off();
  outp(0x201,0xff);
  do {
    j = inp(0x201);
    config_analogjoystickfound += (j & 0x1);
  } while (++i != 65535);
  irq_on();
  config_analogjoystickfound =
    (config_analogjoystickfound != 65535) ? TRUE:FALSE;
  joymaxx = joymaxy = 0;
  joyminx = joyminy = 65536;
}

/* Clear variables and detect physical joysticks */
/* Called once during emulator startup */

void init_joysticks(void) {
  int i;
  for (i = 0; i < 2; i++) {
    fire1[i] = FALSE;
    fire2[i] = FALSE;
    joyleft[i] = FALSE;
    joyright[i] = FALSE;
    joyup[i] = FALSE;
    joydown[i] = FALSE;
  }
  detect_joysticks();
}

/* Mouse handler */

#pragma off (check_stack)
void _loadds far mymousehandler(int max, int mbx, int mcx, int mdx, int msi, int mdi) {
#pragma aux mymousehandler parm [EAX] [EBX] [ECX] [EDX] [ESI] [EDI]
  int i;
  
  if (mouseIrqFirstTime) {
    for (i = 0; i < 2; i++) {
      mouseLastPosX[i] = msi;
      mouseLastPosY[i] = mdi;
    }
    mouseIrqFirstTime = FALSE;
  }

  for (i = 0; i < 2; i++) 
    if (config_joy[i] == 5) {                     /* Joystick Port i */
      if ((!fire2[i]) && ((mbx & 2) == 2))
	potdat[i] = (potdat[i] + 0x100) & 0xffff; 
      fire1[i] = mbx & 1;                         /* Mouse Buttons */
      fire2[i] = (mbx & 2)>>1;
      mouseDX[i] += msi - mouseLastPosX[i];       /* Relative since last irq */
      mouseDY[i] += mdi - mouseLastPosY[i];
      mouseLastPosX[i] = msi;                     /* Current mouse position */
      mouseLastPosY[i] = mdi;
    }
}

/*==============*/
/* IO-Registers */
/*==============*/

/* General joydat calculation */

static ULO rjoydat(ULO i) {
  if (config_joy[i] == 5) {    /* Mouse in this port */
    int tmpx, tmpy;
    if (mouseDX[i] > 127) tmpx = 127;  /* Find relative movement */
    else if (mouseDX[i] < -127) tmpx = -127;
    else tmpx = mouseDX[i];
    if (mouseDY[i] > 127) tmpy = 127;
    else if (mouseDY[i] < -127) tmpy = -127;
    else tmpy = mouseDY[i];
    mouseDX[i] -= tmpx;
    mouseDY[i] -= tmpy;
    tmpx += mouseLastReadX[i];
    tmpy += mouseLastReadY[i];
    mouseLastReadX[i] = tmpx;         /* Record current Amiga mouse position */
    mouseLastReadY[i] = tmpy;
    return ((tmpy & 0xff)<<8) | (tmpx & 0xff);
  }
  else {
    ULO retval = 0;
    if (joyright[i]) retval |= 3;
    if (joyleft[i]) retval |= 0x300;
    if (joyup[i]) retval ^= 0x100;
    if (joydown[i]) retval ^= 1;
    return retval;
  }
}

/* JOY0DATR - $A */

#pragma aux rjoy0dat parm [ecx] [edx] value [edx];
ULO rjoy0dat(ULO address, ULO data) {
  return rjoydat(0);
}

/* JOY1DATR - $C */

#pragma aux rjoy1dat parm [ecx] [edx] value [edx];
ULO rjoy1dat(ULO address, ULO data) {
  return rjoydat(1);
}

/* POT0DATR - $12 */

#pragma aux rpot0dat parm [ecx] [edx] value [edx];
ULO rpot0dat(ULO address, ULO data) { return potdat[0];}

/* POT1DATR - $14 */

#pragma aux rpot1dat parm [ecx] [edx] value [edx];
ULO rpot1dat(ULO address, ULO data) { return potdat[1];}

/* POTGOR - $16 */

#pragma aux rpotgor parm [ecx] [edx] value [edx];
ULO rpotgor(ULO address, ULO data) {
  ULO val = potgor & 0xbbff;
  if (!fire2[0]) val |= 0x400;
  if (!fire2[1]) val |= 0x4000;
  return val;
}

/* JOYTEST $36 */

#pragma aux wjoytest parm [ecx] [edx];

void wjoytest(ULO address, ULO data) {
  push_eax();
  mouseLastReadX[0] = mouseLastReadX[1] = (BYT) (data & 0xff);
  mouseLastReadY[0] = mouseLastReadY[1] = (BYT) ((data>>8) & 0xff);
  mouseDX[0] = mouseDX[1] = mouseDY[0] = mouseDY[1] = 0;
  pop_eax();
}

/* Sets our mouse irq handler, and clears variables */
/* Called before any emulation is started           */

void init_mouseirq(void) {
  struct SREGS sregs;
  union REGS inregs, outregs;
  int far *ptr;
  int (far *function_ptr)();
  reset_mouse();
  mouseIrqFirstTime = TRUE;
  segread(&sregs);

  /* check for mouse driver */

  inregs.w.ax = 0;
  int386 (0x33, &inregs, &outregs);
  if ((config_mousefound = !(outregs.w.ax == -1))) {
    addlog("Mouse found\n");
    if (!mouse_pages_locked) {
      mouse_pages_locked = TRUE;
      lock_region((void near *) mymousehandler, 1024);
      lock_region(config_joy, sizeof(config_joy));
      lock_region(fire1, sizeof(fire1));
      lock_region(fire2, sizeof(fire2));
      lock_region(potdat, sizeof(potdat));
      lock_region(mouseDX, sizeof(mouseDX));
      lock_region(mouseDY, sizeof(mouseDY));
      lock_region(mouseLastPosX, sizeof(mouseLastPosX));
      lock_region(mouseLastPosY, sizeof(mouseLastPosY));
      lock_region(&mouseIrqFirstTime, sizeof(mouseIrqFirstTime));
    }
    inregs.w.ax = 0xC;
    inregs.w.cx = 0x001f;
    function_ptr = mymousehandler;
    inregs.x.edx = FP_OFF (function_ptr);
    sregs.es        = FP_SEG (function_ptr);
    int386x (0x33, &inregs, &outregs, &sregs);
    mouse_irq_installed = TRUE;
  }
  else addlog("Mouse not found\n");
  ioread[0xa>>1] = rjoy0dat;
  ioread[0xc>>1] = rjoy1dat;
  ioread[0x12>>1] = rpot0dat;
  ioread[0x14>>1] = rpot1dat;
  ioread[0x16>>1] = rpotgor;
  iowrite[0x36>>1] = wjoytest;
}

void restore_mouseirq(void) {
  union REGS inregs, outregs;
  if (config_mousefound && mouse_irq_installed) {
    inregs.w.ax = 0;
    int386 (0x33, &inregs, &outregs);
    mouse_irq_installed = FALSE;
  }
}

void mouse_close(void) {
  if (mouse_pages_locked) {
      unlock_region((void near *) mymousehandler, 1024);
      unlock_region(config_joy, sizeof(config_joy));
      unlock_region(fire1, sizeof(fire1));
      unlock_region(fire2, sizeof(fire2));
      unlock_region(potdat, sizeof(potdat));
      unlock_region(mouseDX, sizeof(mouseDX));
      unlock_region(mouseDY, sizeof(mouseDY));
      unlock_region(mouseLastPosX, sizeof(mouseLastPosX));
      unlock_region(mouseLastPosY, sizeof(mouseLastPosY));
      unlock_region(&mouseIrqFirstTime, sizeof(mouseIrqFirstTime));
  }
  restore_mouseirq();
}

void reset_mouse(void) {
  int i;
  potgor = 0xffff;
  for (i = 0; i < 2; i++) {
    potdat[i] = 0;
    fire1[i] = FALSE;
    fire2[i] = FALSE;
    mouseDX[i] = 0;
    mouseDY[i] = 0;
    joyup[i] = joydown[i] = joyright[i] = joyleft[i] = FALSE;
  }
}
