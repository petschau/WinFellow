/*=======================*/
/* Cia emulation         */
/* Petter Schau 1997     */
/*=======================*/

#include <stdio.h>
#include "defs.h"
#include "bus.h"
#include "joymouse.h"
#include "memory.h"
#include "led.h"

#define CIA_NO_EVENT 0
#define CIAA_TA_TIMEOUT_EVENT 1
#define CIAA_TB_TIMEOUT_EVENT 2
#define CIAB_TA_TIMEOUT_EVENT 3
#define CIAB_TB_TIMEOUT_EVENT 4

#define CIA_TA_IRQ 1
#define CIA_TB_IRQ 2
#define CIA_ALARM_IRQ 4
#define CIA_KBD_IRQ 8

LON cia_next_event_time; /* Cycle for cia-event, measured from sof */
ULO cia_next_event_type; /* What type of event */

/* Cia registers, index 0 is Cia A, index 1 is Cia B */

ULO cia_ta[2];
ULO cia_tb[2];              
ULO cia_talatch[2];
ULO cia_tblatch[2];          
LON cia_taleft[2];
LON cia_tbleft[2];
ULO cia_icrreq[2];
ULO cia_icrmsk[2];           
ULO cia_evalarm[2];          
ULO cia_evlatch[2];               
ULO cia_evlatching[2];
ULO cia_evwritelatch[2];               
ULO cia_evwritelatching[2];               
ULO cia_evalarmlatch[2];
ULO cia_evalarmlatching[2];
ULO cia_ev[2];
ULO cia_cra[2];              
ULO cia_crb[2];              
ULO cia_pra[2];
ULO cia_prb[2];              
ULO cia_ddra[2];             
ULO cia_ddrb[2];             
ULO cia_sp[2];               

/* Translate timer -> cycles until timeout from current sof */

ULO cia_unstabilize_value(ULO value) {
  return (value*5) + curcycle;
}

/* Translate cycles until timeout from current sof -> timer value */

ULO cia_stabilize_value(ULO value) {
  return (value-curcycle)/5;
}

void cia_ta_stabilize(ULO i) {
  if (cia_cra[i] & 1) cia_ta[i] = cia_stabilize_value(cia_taleft[i]);
  cia_taleft[i] = -1;
}

void cia_tb_stabilize(ULO i) {
  if ((cia_crb[i] & 0x41) == 1) cia_tb[i] = cia_stabilize_value(cia_tbleft[i]);
  cia_tbleft[i] = -1;
}

void cia_stabilize(ULO i) {
  cia_ta_stabilize(i);
  cia_tb_stabilize(i);
}

void cia_ta_unstabilize(ULO i) {
  if (cia_cra[i] & 1) cia_taleft[i] = cia_unstabilize_value(cia_ta[i]);
}

void cia_tb_unstabilize(ULO i) {
  if ((cia_crb[i] & 0x41) == 1)
    cia_tbleft[i] = cia_unstabilize_value(cia_tb[i]);
}

void cia_unstabilize(ULO i) {
  cia_ta_unstabilize(i);
  cia_tb_unstabilize(i);
}  

void cia_update_irq(ULO i) {
  if (cia_icrreq[i] & cia_icrmsk[i]) {
    cia_icrreq[i] |= 0x80;
    wriw((i == 0) ? 0x8008 : 0xa000, 0xdff09c);
  }
  else wriw((i == 0) ? 8 : 0x2000, 0xdff09c);
}  

void cia_raise_irq(ULO i, ULO req) {
  cia_icrreq[i] |= (req & 0x1f);
  cia_update_irq(i);
}

/* Timeout handlers */

void cia_handle_tb_timeout(ULO i) {
  cia_tb[i] = cia_tblatch[i];      /* Reload from latch */
  if (cia_crb[i] & 8) {            /* One Shot Mode */
    cia_crb[i] &= 0xfe;            /* Stop timer */
    cia_tbleft[i] = -1;
  }
  else if (!(cia_crb[i] & 0x40))   /* Continuous mode, no attach */
    cia_tbleft[i] = cia_unstabilize_value(cia_tb[i]);
  cia_raise_irq(i, CIA_TB_IRQ);   /* Raise irq */
}

void cia_handle_ta_timeout(ULO i) {
  cia_ta[i] = cia_talatch[i];      /* Reload from latch */
  if ((cia_crb[i] & 0x41) == 0x41){/* Timer B attached and started */
    cia_tb[i] = (cia_tb[i] - 1) & 0xffff;
    if (cia_tb[i] == 0) cia_handle_tb_timeout(i);
  }
  if (cia_cra[i] & 8) {            /* One Shot Mode */
    cia_cra[i] &= 0xfe;            /* Stop timer */
    cia_taleft[i] = -1;
  }
  else                             /* Continuous mode */
    cia_taleft[i] = cia_unstabilize_value(cia_ta[i]);
  cia_raise_irq(i, CIA_TA_IRQ);    /* Raise irq */
}

/* Called from eol-handler (B) or eof handler (A) */

void cia_update_eventcounter(ULO i) {
  if (!cia_evwritelatching[i]) {
    cia_ev[i] = (cia_ev[i] + 1) & 0xffffff;
    if (cia_evalarm[i] == cia_ev[i]) cia_raise_irq(i, CIA_ALARM_IRQ);
  }
}

/* Called from the eof-handler to update timers */

void cia_update_timers_eof(void) {
  int i;
  for (i = 0; i < 2; i++) {
    if (cia_taleft[i] >= 0)
      if ((cia_taleft[i] -= CYCLESPERFRAME) < 0) cia_taleft[i] = 0;
    if (cia_tbleft[i] >= 0)
      if ((cia_tbleft[i] -= CYCLESPERFRAME) < 0) cia_tbleft[i] = 0;
  }
  if (cia_next_event_time >= 0)
    if ((cia_next_event_time -= CYCLESPERFRAME) < 0) cia_next_event_time = 0;
  cia_update_eventcounter(0);
}

/* Record next timer timeout */

void cia_setup_next_event(void) {
  ULO nextevtime = 0xffffffff, nextevtype = CIA_NO_EVENT, j;
  for (j = 0; j < 2; j++) {
    if (cia_taleft[j] < nextevtime) {
      nextevtime = cia_taleft[j];
      nextevtype = (j*2) + 1;
    }
    if (cia_tbleft[j] < nextevtime) {
      nextevtime = cia_tbleft[j];
      nextevtype = (j*2) + 2;
    }
  }  
  cia_next_event_time = nextevtime;
  cia_next_event_type = nextevtype;
  cia_setup_event_wrapper();
}

void cia_handle_event(void) {
  switch (cia_next_event_type) {
  case CIAA_TA_TIMEOUT_EVENT:
    cia_handle_ta_timeout(0);
    break;
  case CIAA_TB_TIMEOUT_EVENT:
    cia_handle_tb_timeout(0);
    break;
  case CIAB_TA_TIMEOUT_EVENT:
    cia_handle_ta_timeout(1);
    break;
  case CIAB_TB_TIMEOUT_EVENT:
    cia_handle_tb_timeout(1);
    break;
  default:
    break;
  }
  cia_setup_next_event();
}

/* PRA */

ULO rcia_a_pra(void) {
  ULO result = 0;
  int drivesel;
  if (!fire1[0]) result |= 0x40;	/* Two firebuttons on port 1 */
  if (!fire1[1]) result |= 0x80;
  drivesel = floppy_drive_get_selected();  /* Floppy bits */
  if (!floppy_drive_is_ready(drivesel)) result |= 0x20;
  if (!floppy_drive_is_track0(drivesel)) result |= 0x10;
  if (!floppy_drive_is_writeprotected(drivesel)) result |= 8;
  if (!floppy_drive_is_changed(drivesel)) result |= 4;    
  return result;
}

ULO rcia_pra(ULO i) {
  if (i == 0) return rcia_a_pra();
  return cia_pra[1];
}

void wcia_a_pra(ULO data) {
  if (cia_pra[0] == (data & 0x2)) {
    if ((cia_pra[0] = (data & 0x2))) drawled(100, 0);
    else drawled(100, powerledcolor);
  }
}
    
void wcia_pra(ULO i, ULO data) {
  if (i == 0) wcia_a_pra(data);
  else cia_pra[1] = data;
}

/* PRB */

ULO rcia_prb(ULO i) {return cia_prb[i];};

void wcia_b_prb(ULO data) {
  cia_prb[1] = data;
  floppy_set_sel((data & 0x78)>>3);
  floppy_set_motor((data & 0x80)>>7);
  floppy_set_side((data & 4)>>2);
  floppy_set_dir((data & 2)>>1);
  floppy_set_step(data & 1);  
}

void wcia_prb(ULO i, ULO data) {
  if (i == 0) cia_prb[0] = data;
  else wcia_b_prb(data);
}

/* DDRA */

ULO rcia_ddra(ULO i) {
  if (i == 0) return 3;
  return 0xc0;
}

void wcia_ddra(ULO i, ULO data) {};

/* DDRB */

ULO rcia_ddrb(ULO i) {
  if (i == 0) return cia_ddrb[0];
  return 0xff;
}

void wcia_ddrb(ULO i, ULO data) {
  if (i == 0) cia_ddrb[0] = data;
}

/* SP (Keyboard serial data on Cia A) */

ULO rcia_sp(ULO i) {
  return cia_sp[i];
}

void wcia_sp(ULO i, ULO data) {};

/* Timer A */

ULO rcia_talo(ULO i) {
  if (cia_cra[i] & 1) return cia_stabilize_value(cia_taleft[i]) & 0xff;
  return cia_ta[i] & 0xff;
}

ULO rcia_tahi(ULO i) {
  if (cia_cra[i] & 1) return (cia_stabilize_value(cia_taleft[i])>>8) & 0xff;
  return (cia_ta[i]>>8) & 0xff;
}  

void wcia_talo(ULO i, ULO data) {
  cia_talatch[i] = (cia_talatch[i] & 0xff00) | (data & 0xff);
}

void wcia_tahi(ULO i, ULO data) {
  cia_talatch[i] = (cia_talatch[i] & 0xff) | ((data & 0xff)<<8);
  if (!(cia_cra[i] & 1)) {
    cia_stabilize(i);
    cia_ta[i] = cia_talatch[i];
    if (cia_cra[i] & 8) cia_cra[i] |= 1;
    cia_unstabilize(i);
    cia_setup_next_event();
  }
}

/* Timer B */

ULO rcia_tblo(ULO i) {
  if ((cia_crb[i] & 1) && !(cia_crb[i] & 0x40))
    return cia_stabilize_value(cia_tbleft[i]) & 0xff;
  return cia_tb[i] & 0xff;
}

ULO rcia_tbhi(ULO i) {
  if ((cia_crb[i] & 1) && !(cia_crb[i] & 0x40))
    return (cia_stabilize_value(cia_tbleft[i])>>8) & 0xff;
  return (cia_tb[i]>>8) & 0xff;
}

void wcia_tblo(ULO i, ULO data) {
  cia_tblatch[i] = (cia_tblatch[i] & 0xff00) | (data & 0xff);
}

void wcia_tbhi(ULO i, ULO data) {
  cia_tblatch[i] = (cia_tblatch[i] & 0xff) | ((data & 0xff)<<8);
  if (!(cia_crb[i] & 1)) {
    cia_stabilize(i);
    cia_tb[i] = cia_tblatch[i];
    if (cia_crb[i] & 8) cia_crb[i] |= 1;
    cia_unstabilize(i);
    cia_setup_next_event();
  }
}

/* Event counter */

ULO rcia_evlo(ULO i) {
  if (cia_evlatching[i]) {
    cia_evlatching[i] = FALSE;
    return cia_evlatch[i] & 0xff;
  }
  return cia_ev[i] & 0xff;
}

ULO rcia_evmi(ULO i) {
  if (cia_evlatching[i]) return (cia_evlatch[i]>>8) & 0xff;
  return (cia_ev[i]>>8) & 0xff;
}

ULO rcia_evhi(ULO i) {
  cia_evlatching[i] = TRUE;
  cia_evlatch[i] = cia_ev[i];
  return (cia_ev[i]>>16) & 0xff;
}

void wcia_evlo(ULO i, ULO data) {
  cia_evwritelatching[i] = FALSE;
  cia_evwritelatch[i] = (cia_evwritelatch[i] & 0xffff00) | (data & 0xff);
  if (cia_crb[i] & 0x80) cia_evalarm[i] = cia_evwritelatch[i];
  else cia_ev[i] = cia_evwritelatch[i];
  if (cia_ev[i] == cia_evalarm[i]) cia_raise_irq(i, CIA_ALARM_IRQ);
}

void wcia_evmi(ULO i, ULO data) {
  cia_evwritelatching[i] = TRUE;
  cia_evwritelatch[i] = (cia_evwritelatch[i] & 0xff00ff) | ((data & 0xff)<<8);
}

void wcia_evhi(ULO i, ULO data) {
  cia_evwritelatching[i] = TRUE;
  cia_evwritelatch[i] = (cia_evwritelatch[i] & 0xffff) | ((data & 0xff)<<16);
}

/* ICR */

ULO rcia_icr(ULO i) {
  int tmp = cia_icrreq[i];
  cia_icrreq[i] = 0;
  return tmp;
}

void wcia_icr(ULO i, ULO data) {
  if (data & 0x80) {
    cia_icrmsk[i] |= (data & 0x1f);
    if (cia_icrreq[i] & cia_icrmsk[i]) cia_raise_irq(i, 0);
  }
  else {
    cia_icrmsk[i] &= ~(data & 0x1f);
    cia_update_irq(i);
  }
}

/* CRA */

ULO rcia_cra(ULO i) {return cia_cra[i] & 0xff;};

void wcia_cra(ULO i, ULO data) {
  cia_stabilize(i);
  if (data & 0x10) {
    cia_ta[i] = cia_talatch[i];
    data &= 0xef;
  }
  cia_cra[i] = data & 0xff;
  cia_unstabilize(i);
  cia_setup_next_event();
}  

/* CRB */

ULO rcia_crb(ULO i) {return cia_crb[i] & 0xff;};

void wcia_crb(ULO i, ULO data) {
  cia_stabilize(i);
  if (data & 0x10) {
    cia_tb[i] = cia_tblatch[i];
    data &= 0xef;
  }
  cia_crb[i] = data & 0xff;
  cia_unstabilize(i);
  cia_setup_next_event();
}  

/* Dummy read and write */

ULO rcia_nothing(ULO i) { return 0xff;};
void wcia_nothing(ULO i, ULO data) {};
	
/* Table of CIA read/write functions */

ciareadfunc cia_read[16] = {rcia_pra,rcia_prb,rcia_ddra,rcia_ddrb,rcia_talo,
                            rcia_tahi,rcia_tblo,rcia_tbhi,rcia_evlo,
                            rcia_evmi,rcia_evhi,rcia_nothing,rcia_sp,rcia_icr,
                            rcia_cra,rcia_crb};
ciawritefunc cia_write[16]={wcia_pra,wcia_prb,wcia_ddra,wcia_ddrb,wcia_talo,
                            wcia_tahi,wcia_tblo,wcia_tbhi,wcia_evlo,
                            wcia_evmi,wcia_evhi,wcia_nothing,wcia_sp,wcia_icr,
                            wcia_cra,wcia_crb};

/* Routine callbacks called by memory system */

#pragma aux readciabyte parm [ecx] value [edx]; 
ULO readciabyte(ULO address) {
  if ((address & 0xa01001) == 0xa00001)
    return cia_read[(address & 0xf00)>>8](0);
  else if ((address & 0xa02001) == 0xa00000)
    return cia_read[(address & 0xf00)>>8](1);
  return 0xff;
}

#pragma aux readciaword parm [ecx] value [edx]; 
ULO readciaword(ULO address) {
  return (readciabyte(address)<<8) | readciabyte(address + 1);
}

#pragma aux readcialong parm [ecx] value [edx]; 
ULO readcialong(ULO address) {
  return (readciabyte(address)<<24)    | (readciabyte(address + 1)<<16) |
         (readciabyte(address + 2)<<8) | readciabyte(address + 3);
}

#pragma aux writeciabyte parm [ecx] [edx]; 
void writeciabyte(ULO address, ULO data) {
  push_eax();
  if ((wriorgadr & 0xa01001) == 0xa00001)
    cia_write[(wriorgadr & 0xf00)>>8](0, data & 0xff);
  else if ((wriorgadr & 0xa02001) == 0xa00000)
    cia_write[(wriorgadr & 0xf00)>>8](1, data & 0xff);
  pop_eax();
}

#pragma aux writeciaword parm [ecx] [edx]; 
void writeciaword(ULO address, ULO data) {
  push_eax();
  writeciabyte(wriorgadr, data>>8);
  writeciabyte(wriorgadr + 1, data);
  pop_eax();
}

#pragma aux writecialong parm [ecx] [edx]; 
void writecialong(ULO address, ULO data) {
  push_eax();
  writeciabyte(wriorgadr, data>>24);
  writeciabyte(wriorgadr + 1, data>>16);
  writeciabyte(wriorgadr + 2, data>>8);
  writeciabyte(wriorgadr + 3, data);
  pop_eax();
}

void cia_map(void) {
  ULO bank;
  for (bank = 0xa00000>>16; bank < (0xc00000>>16); bank++)
    memory_bank_set(readciabyte, readciaword, readcialong, writeciabyte,
		    writeciaword, writecialong, NULL, bank, 0xa00000>>16);
}

/* Set all variables to initial state */

void cia_init(void) {
  int i;
  for (i = 0; i < 2; i++) {
    cia_ev[i] = 0;		/* Zero out event counters */
    cia_evlatch[i] = 0;
    cia_evlatching[i] = 0;
    cia_evalarm[i] = 0;
    cia_evalarmlatch[i] = 0;
    cia_evalarmlatching[i] = 0;
    cia_evwritelatch[i] = 0;
    cia_evwritelatching[i] = 0;
    cia_taleft[i] = -1;		/* Zero out timers */
    cia_tbleft[i] = -1;
    cia_ta[i] = 0xffff;        
    cia_tb[i] = 0xffff;
    cia_talatch[i] = 0xffff;
    cia_tblatch[i] = 0xffff;
    cia_pra[i] = 0xff;
    cia_prb[i] = 0;
    cia_ddra[i] = 0;
    cia_ddrb[i] = 0;
    cia_icrreq[i] = 0;
    cia_icrmsk[i] = 0;
    cia_cra[i] = 0;
    cia_crb[i] = 0;
  }
  cia_next_event_time = -1;
  cia_next_event_type = 0;
}
