/* Roman Dolejsi 1997                                */
/* CPU coprocessor code for Fellow's 680x0 emulation */
/*    (currently dummy, later at least FPU 6888x)    */

#include "defs.h"

/* in the following functions have the calling
   read/write routines this format:

   UWO data = getpc( UWO cpc ); cpc+=2;         ... get word from current PC
   UWO data = ar( UWO ctbl );                   ... get word from <ea>
   aw( ctbl, UWO data );                        ... put word to <ea>
*/


/* this routine tests coprocessor condition
    in: condition number, *routine for data get from pc
        *emutable, current pc
   out: (0=not met / 1=met) <<16 | 16-bit pc step forward
*/

ULO cpr_cond_dm( ULO condition, ULO *getpc, ULO ctbl, ULO cpc ) {
  return 0;      /* condition not met, no steps further */
};

/* this routine does all coprocessor commands got from CPU
    in: command, *routine for data get from pc
        *routine for data get from <ea>, *routine for data put to <ea>
        *emutable, current pc
   out: 16-bit pc step forward
*/

ULO cpr_gen_dm( ULO command, void *getpc, void *ar, void *aw, ULO ctbl, ULO cpc ) {
  return 0;      /* no steps further */
};

/* this routine restores coprocessor status from <ea>
    in: *routine for data get from <ea>, *emutable, current pc
   out: (0=not met / 1=met) <<16 | 16-bit pc step forward
*/

ULO cpr_rest_dm( void *ar, ULO ctbl, ULO cpc ) {
  return 0;      /* no steps further */
};

/* this routine saves coprocessor status from <ea>
    in: *routine for data put to <ea>, *emutable, current pc
   out: (0=not met / 1=met) <<16 | 16-bit pc step forward
*/

ULO cpr_save_dm( void *aw, ULO ctbl, ULO cpc ) {
  return 0;      /* no steps further */
};

/* this table contains coprocessor procedure addresses which are
   later called from assembler CPU emulation. It consists of four
   addresses for every coprocessor (680x0 can have up to seven -
   slot 0 must remain dummy).
*/

void *coproc_tbl[4*8] = { cpr_cond_dm, cpr_gen_dm, cpr_rest_dm, cpr_save_dm,
                          cpr_cond_dm, cpr_gen_dm, cpr_rest_dm, cpr_save_dm,
                          cpr_cond_dm, cpr_gen_dm, cpr_rest_dm, cpr_save_dm,
                          cpr_cond_dm, cpr_gen_dm, cpr_rest_dm, cpr_save_dm,
                          cpr_cond_dm, cpr_gen_dm, cpr_rest_dm, cpr_save_dm,
                          cpr_cond_dm, cpr_gen_dm, cpr_rest_dm, cpr_save_dm,
                          cpr_cond_dm, cpr_gen_dm, cpr_rest_dm, cpr_save_dm,
                          cpr_cond_dm, cpr_gen_dm, cpr_rest_dm, cpr_save_dm };
