/* Fellow Amiga Emulator */
/* Everything that didn't fit in elsewhere */
/* Main */
/* Petter Schau, Roman Doljesi */

#include <stdio.h>
#include <stdlib.h>

#include "defs.h"
#include "inout.h"
#include "68000.h"
#include "memory.h"
#include "eventid.h"
#include "floppy.h"
#include "sblast.h"
#include "sound.h"
#include "joymouse.h"
#include "keyboard.h"
#include "draw.h"
#include "graphem.h"
#include "fhfile.h"
#include "bus.h"
#include "gui.h"
#include "copper.h"
#include "led.h"
#include "cianew.h"
#include "blit.h"
#include "various.h"

#ifdef UAE_FILESYS
#include "uaefsys.h"
#endif

/* Some vital paths used by various functions */

char fellow_homedir[256];          /* The home-directory of fellow */
char fellow_homeoriginaldir[256]; /* Original path for drive containing flw */
char fellow_startdir[256];         /* The directory fellow was started in */


ULO debug_screentables_not_set = TRUE;

char *tmploc;

ULO trackmo = 0;
extern ULO emuspeed;

extern ULO bytestotransfer;

extern ULO indexx,leng;

extern ULO leftbutton;
extern ULO rightbutton;
extern ULO curcycle;


ULO mmx_detected;
ULO configdoublebuffer;
ULO config_printspeed;
ULO configguires;
ULO configmakelogfile;
ULO save_permit = TRUE;

char configfilename[80] = "Fellow.cfg";

#ifdef CYCLE_EXACT
ULO configcycleexact = 0;
#endif

/* Flags set if option was on cmd-line */

UBY cmddf[4] = {FALSE,FALSE,FALSE,FALSE};
UBY cmddfenabled[4] = {FALSE,FALSE,FALSE,FALSE};
UBY cmdfhfile[FHFILE_MAX_DEVICES], cmdfhfileenabled = FALSE;
UBY cmdfhfileinit = FALSE;
UBY cmdkick = FALSE, cmdfloppyfast = FALSE, cmddiskpath = FALSE;
UBY cmdchip = FALSE, cmdbogo = FALSE, cmdfast = FALSE;
UBY cmdjoya = FALSE, cmdjoyb = FALSE;
UBY cmdsoundmode = FALSE, cmdsoundmethod = FALSE;
UBY cmdmaxfps = FALSE, cmdlace = FALSE, cmdleds = FALSE, cmdkbdl = FALSE;
UBY cmdprintspeed = FALSE, cmdnogui = FALSE, cmdgmode = FALSE;
UBY cmdskip = FALSE, cmdcpuspeed = FALSE, cmdcputype = FALSE;
UBY cmddm1 = FALSE, cmddm2 = FALSE, cmddm3 = FALSE, cmddm4 = FALSE;
UBY cmddm5 = FALSE, cmddm6 = FALSE, cmddm7 = FALSE, cmddm8 = FALSE;
UBY cmddm9 = FALSE, cmddm0 = FALSE;
UBY cmdaltn = FALSE, cmdarun = FALSE;
UBY cmdmpos = FALSE, cmdsmpos = FALSE;
UBY cmdcycleexact = FALSE, cmdscaley = FALSE;
UBY cmdnommx = FALSE;

#ifdef AF_MODE
UBY cmdkeyname = FALSE;
#endif

ULO a7pointer;

#ifdef DEBUGBUILD
ULO cputracebuffer[524288];
ULO cputracebase[524288];
int cputraceflag;
int cputracecount=0;
int cputraceptr=0;
#endif


int gmodefirsttime[NROFMODES];

#ifdef DEBUGBUILD
/* ******************************************************************
   EVENT LOG CONFIGURATION DATA
   ******************************************************************

   Log buffer
   Layout:  
   -----------
   event id
   Frame number
   Ypos
   Xpos
  12 data longwords */

ULO logbuffer[EVENTCOUNT][16];
int logfirst;
int loglast;


/* Logging flags */
ULO logserialtransmitbufferemptyirq = FALSE;
ULO logdiskdmatransferdoneirq = FALSE;
ULO logsoftwareirq = FALSE;
ULO logciaairq = FALSE;
ULO logcopperirq = FALSE;
ULO logverticalblankirq = FALSE;
ULO logblitterreadyirq = FALSE;
ULO logaudioirq = FALSE;
ULO logserialreceivebufferfullirq = FALSE;
ULO logdisksyncvaluerecognizedirq = FALSE;
ULO logciabirq = FALSE;
ULO logstop = FALSE;
ULO logbuserrorex = FALSE;
ULO logoddaddressex = FALSE;
ULO logillegalinstructionex = FALSE;
ULO logdivisionby0ex = FALSE;
ULO logprivilegieviolationex = FALSE;
ULO logtrapex = FALSE;

/* ******************************************************************
   END OF CONFIGURATION DATA
   ****************************************************************** */

#endif


void load_fellow_cfg(void) {
  FILE *C;
  char var[80];
  char val[256];
  char ledstr[256];
  char kbdstr[256];
  char arnstr[256];
  UWO *lptcfg;
  int i;

  /* Set default values, unless option was set on cmd-line */

  if (!cmdkbdl) kbdleds = 0;
  ledstr[0] = 0; kbdstr[0] = 0; arnstr[0] = 0;
  menupos_want1[0] = 0;
  for (i = 0; i < 4; i++) {
    if (!cmddf[i]) strcpy(config_floppy_name[i],"__None__");
    if (!cmddfenabled[i]) config_floppy_enabled[i] = TRUE;
  }
  for (i = 0; i < FHFILE_MAX_DEVICES; i++) {
    if (!cmdfhfile[i]) strcpy(config_fhfile_name[i],"__None__");
  }
  if (!cmdfhfileenabled) config_fhfile_enabled = TRUE;
  if (!cmdkick) strcpy(config_memory_kickname,"kick.rom");
#ifdef AF_MODE
  if (!cmdkeyname) strcpy(config_memory_keyname,"rom.key");
#endif
  if (!cmdfloppyfast) config_floppy_fast = FALSE;
  if (!cmdchip) config_memory_chipsize = CHIPMEM;
  if (!cmdbogo) config_memory_bogosize = 0;
  if (!cmdfast) config_memory_fastsize = 0;
  if (!cmdjoya) config_joy[0] = 5;
  if (!cmdjoyb) config_joy[1] = 0;
  if (!cmdsoundmode) config_sound_mode = 0;
  if (!cmdsoundmethod) config_sound = 0;
  if (!cmdskip) config_graphics_skiprate = 0;
  if (!cmdleds) config_enableleds = 1;
  if (!cmdcpuspeed) config_cpu_speed = 0;
  if (!cmdprintspeed) config_printspeed = FALSE;
  if (!cmdlace) config_graphics_flickerfree = FALSE;
  if (!cmdmaxfps) config_graphics_maxfps = 0;
  if (!cmdcputype) config_cpu_type = 0;
  if (!cmdaltn) config_altn_loop = 0;
  if (!cmddiskpath) config_diskpath[0] = 0;
  if (!cmdmpos) { menupos_want0[0] = 0; config_store_mpos = FALSE; };
  if (!cmdarun) config_autorun = 0;
  if (!cmdcycleexact) config_draw_cycleexact = FALSE;
  if (!cmdscaley) config_graphics_scaley = 0;

  if ((C = fopen(configfilename,"r")) != NULL) {
    while (!feof(C)) {
      fscanf(C,"%s %s\n",var,val);
      if (!strcmpi("Df0",var) && !cmddf[0])
        strcpy(config_floppy_name[0],val);
      else if (!strcmpi("Df1",var) && !cmddf[1])
        strcpy(config_floppy_name[1],val);
      else if (!strcmpi("Df2",var) && !cmddf[2])
        strcpy(config_floppy_name[2],val);
      else if (!strcmpi("Df3",var) && !cmddf[3])
        strcpy(config_floppy_name[3],val);
      else if (!strcmpi("Df0enabled",var) && !cmddfenabled[0])
        config_floppy_enabled[0] = atoi(val);
      else if (!strcmpi("Df1enabled",var) && !cmddfenabled[1])
        config_floppy_enabled[1] = atoi(val);
      else if (!strcmpi("Df2enabled",var) && !cmddfenabled[2])
        config_floppy_enabled[2] = atoi(val);
      else if (!strcmpi("Df3enabled",var) && !cmddfenabled[3])
        config_floppy_enabled[3] = atoi(val);
      else if (!strnicmp("HDfile",var,6)) {
	if (!cmdfhfile[var[6] - 0x30]) {
          strcpy(config_fhfile_name[var[6] - 0x30],val);
	}
      }
      else if (!strcmpi("HDfileenabled",var) && !cmdfhfileenabled)
        config_fhfile_enabled = atoi(val);
      else if (!strcmpi("Kickfile",var) && !cmdkick)
        strcpy(config_memory_kickname,val);
#ifdef AF_MODE
      else if (!strcmpi("Keyfile",var) && !cmdkeyname)
        strcpy(config_memory_keyname,val);
#endif
      else if (!strcmpi("Floppyfast",var) && !cmdfloppyfast)
        config_floppy_fast = atoi(val);
      else if (!strcmp("Diskpath",var) && !cmddiskpath)
        strcpy(config_diskpath,val);
      else if (!strcmpi("Diskmem1",var) && !cmddm1)
        strcpy(memnames[0],val);
      else if (!strcmpi("Diskmem2",var) && !cmddm2)
        strcpy(memnames[1],val);
      else if (!strcmpi("Diskmem3",var) && !cmddm3)
        strcpy(memnames[2],val);
      else if (!strcmpi("Diskmem4",var) && !cmddm4)
        strcpy(memnames[3],val);
      else if (!strcmpi("Diskmem5",var) && !cmddm5)
        strcpy(memnames[4],val);
      else if (!strcmpi("Diskmem6",var) && !cmddm6)
        strcpy(memnames[5],val);
      else if (!strcmpi("Diskmem7",var) && !cmddm7)
        strcpy(memnames[6],val);
      else if (!strcmpi("Diskmem8",var) && !cmddm8)
        strcpy(memnames[7],val);
      else if (!strcmpi("Diskmem9",var) && !cmddm9)
        strcpy(memnames[8],val);
      else if (!strcmpi("Diskmem0",var) && !cmddm0)
        strcpy(memnames[9],val);
      else if (!strcmpi("Chipmem",var) && !cmdchip)
        config_memory_chipsize = atoi(val);
      else if (!strcmpi("Bogomem",var) && !cmdbogo)
        config_memory_bogosize = atoi(val);
      else if (!strcmpi("Fastmem",var) && !cmdfast)
        config_memory_fastsize = atoi(val);
      else if (!strcmpi("Sound",var) && !cmdsoundmethod)
        config_sound = atoi(val);
      else if (!strcmpi("Soundmode",var) && !cmdsoundmode) {
        config_sound_mode = atoi(val);
        configaudiomodesetbylog = TRUE;
      }
      else if (!strcmpi("JoystickA",var) && !cmdjoya)
        config_joy[0] = atoi(val);
      else if (!strcmpi("JoystickB",var) && !cmdjoyb)
        config_joy[1] = atoi(val);
      else if (!strcmpi("Skiprate",var) && !cmdskip)
        config_graphics_skiprate = atoi(val);
      else if (!strcmpi("CycleExact",var) && !cmdcycleexact)
        config_draw_cycleexact = atoi(val);
      else if (!strcmpi("Scaley",var) && !cmdscaley)
        config_graphics_scaley = atoi(val);
      else if (!strcmpi("EnableLeds",var) && !cmdleds)
        strcpy( &ledstr, val );
      else if (!strcmpi("KbdLeds",var) && !cmdkbdl)
        strcpy( &kbdstr, val );
      else if (!strcmpi("Enableleds",var) && !cmdleds)
        config_enableleds = atoi(val);
      else if (!strcmpi("Cputype",var) && !cmdcputype)
        config_cpu_type = atoi(val);
      else if (!strcmpi("Cpuspeed",var) && !cmdcpuspeed)
        config_cpu_speed = atoi(val);
      else if (!strcmpi("Printspeed",var) && !cmdprintspeed)
        config_printspeed = atoi(val);
      else if (!strcmpi("Vesamode",var) && !cmdgmode)
        config_graphics_mode = atoi(val);
      else if (!strcmpi("Maxfps",var) && !cmdmaxfps)
        config_graphics_maxfps = atoi(val);
      else if (!strcmpi("Flickerfree",var) && !cmdlace)
        config_graphics_flickerfree = atoi(val);
      else if (!strcmpi("AltNloop",var) && !cmdaltn)
        config_altn_loop = atoi(val) - 1;
      else if (!strcmpi("MenuPosActive",var) && !cmdsmpos)
        config_store_mpos = atoi(val);
      else if (!strcmpi("MenuPos",var) && !cmdmpos)
        strcpy( &menupos_want0, val );
      else if (!strcmpi("AutoRun",var) && !cmdarun)
        strcpy( &arnstr, val );
    }
    fclose(C);
    config_memory_chipsize &= 0x3c0000;
    if (config_memory_chipsize > CHIPMEM || config_memory_chipsize == 0)
      config_memory_chipsize = 0x200000;
    config_memory_bogosize &= 0x1c0000;
    if (config_memory_bogosize > BOGOMEM) config_memory_bogosize = BOGOMEM;
    if (config_memory_fastsize != 0x800000 &&
        config_memory_fastsize != 0x400000 &&
        config_memory_fastsize != 0x200000 &&
        config_memory_fastsize != 0x100000) config_memory_fastsize = 0;
    if (config_joy[0] > 5) config_joy[0] = 5;
    if (config_joy[1] > 5) config_joy[1] = 0;
    if (config_sound_mode > 16) config_sound_mode = 0;
    if (config_sound > 3) config_sound = 0;
    if (config_cpu_type != 0 && config_cpu_type != 3) config_cpu_type = 0;
    if (config_cpu_speed > 1) config_cpu_speed = 1;
    if (config_printspeed > 1) config_printspeed = 0;
    if (config_graphics_mode > NROFMODES) config_graphics_mode = 0;
    if (config_graphics_flickerfree > 1) config_graphics_flickerfree = 0;
    if (config_graphics_maxfps > 2) config_graphics_maxfps = 0;
    if( ledstr[0] ) {
      if( !strcmpi( &ledstr, "off" ) ) config_enableleds = 0;/* no led diags */
      else if( !strcmpi( &ledstr, "scr" ) )
	config_enableleds = 1;/* PWR,DFx on SCR */
      else if( !strcmpi( &ledstr, "kb1" ) )
	config_enableleds = 0x81; /* DF123 on KBD */
      else if( !strcmpi( &ledstr, "kb2" ) )
	config_enableleds = 0x82; /* PWR,DF12 on KBD */
      else if( !strcmpi( &ledstr, "kb3" ) )
	config_enableleds = 0x83; /* PWR,DF1+2/3+4 on KBD */
      else if( !strcmpi( &ledstr, "lp1" ) )
	config_enableleds = 0x41; /* PWR,DFx on LPT1 */
      else if( !strcmpi( &ledstr, "lp2" ) )
	config_enableleds = 0x42; /* PWR,DFx on LPT2 */
      else if( !strcmpi( &ledstr, "lp3" ) )
	config_enableleds = 0x43; /* PWR,DFx on LPT3 */
      else if( !strcmpi( &ledstr, "lp1m" ) )
	config_enableleds = 0x51; /* PWR,DFx on LPT1 mirrored */
      else if( !strcmpi( &ledstr, "lp2m" ) )
	config_enableleds = 0x52; /* PWR,DFx on LPT2 mirrored */
      else if( !strcmpi( &ledstr, "lp3m" ) )
	config_enableleds = 0x53; /* PWR,DFx on LPT3 mirrored */
    };
    if( kbdstr[0] ) {
      if( !strcmpi( &kbdstr, "ncs" ) ) kbdleds = 0;      /* Num/Caps/Scroll */
      else if( !strcmpi( &kbdstr, "nsc" ) ) kbdleds = 1; /* Num/Scroll/Caps */
      else if( !strcmpi( &kbdstr, "cns" ) ) kbdleds = 2; /* Caps/Num/Scroll */
      else if( !strcmpi( &kbdstr, "csn" ) ) kbdleds = 3; /* Caps/Scroll/Num */
      else if( !strcmpi( &kbdstr, "scn" ) ) kbdleds = 4; /* Scroll/Caps/Num */
      else if( !strcmpi( &kbdstr, "ncs" ) ) kbdleds = 5; /* Scroll/Num/Caps */
    };
  }
  if( config_enableleds & 0x40 ) {
    lptcfg = (UWO *)0x410;                    /* paralel port config address */
    if( (config_enableleds & 3) > (lptcfg[0] >> 14) ) config_enableleds = 1;
    else {
      lptcfg = (UWO *)0x406;
      ledlpt = lptcfg[ config_enableleds & 3 ];  /* get info from BIOS area */
    };
  };
  if( cmdfhfileinit ) {
    cmdfhfileinit = FALSE;
    fhfile_create();
  };
  if( config_altn_loop > 3 ) config_altn_loop = 0;
  i = -1;
  while( ++i < strlen( &menupos_want0 ) )
    if( menupos_want0[i] == '~' ) menupos_want0[i] = ' ';
  if( !config_store_mpos ) menupos_want0[0] = 0;
  if( arnstr[0] ) {
    if( !strcmpi( &arnstr, "AltN" ) ) config_autorun = 1;
    if( !strcmpi( &arnstr, "Res" ) ) config_autorun = 2;
    if( !strcmpi( &arnstr, "AltNRes" ) ) config_autorun = 3;
  };
}

void save_fellow_cfg(void) {
  FILE *C;
  char ledstr[5];
  char kbdstr[4];
  char menustr[128];
  char arnstr[10];
  int i = -1;

  strcpy( &menustr, &menupos_act );
  while( ++i < strlen( &menustr ) )
    if( menustr[i] == ' ' ) menustr[i] = '~';
  if( save_permit ) {
    switch( config_enableleds ) {
      case    1: strcpy( ledstr, "scr" ); break;
      case 0x81: strcpy( ledstr, "kb1" ); break;
      case 0x82: strcpy( ledstr, "kb2" ); break;
      case 0x83: strcpy( ledstr, "kb3" ); break;
      case 0x41: strcpy( ledstr, "lp1" ); break;
      case 0x42: strcpy( ledstr, "lp2" ); break;
      case 0x43: strcpy( ledstr, "lp3" ); break;
      case 0x51: strcpy( ledstr, "lp1m" ); break;
      case 0x52: strcpy( ledstr, "lp2m" ); break;
      case 0x53: strcpy( ledstr, "lp3m" ); break;
      default: strcpy( ledstr, "off" ); break;
    };
    switch( kbdleds ) {
      case 1: strcpy( kbdstr, "nsc" ); break;
      case 2: strcpy( kbdstr, "cns" ); break;
      case 3: strcpy( kbdstr, "csn" ); break;
      case 4: strcpy( kbdstr, "scn" ); break;
      case 5: strcpy( kbdstr, "snc" ); break;
      default: strcpy( kbdstr, "ncs" ); break;
    };
    switch( config_autorun ) {
      case 1: strcpy( arnstr, "AltN" ); break;
      case 2: strcpy( arnstr, "Res" ); break;
      case 3: strcpy( arnstr, "AltNRes" ); break;
      default: strcpy( arnstr, "None" ); break;
    };
    if ((C = fopen(configfilename,"w")) != NULL) {
      for (i = 0; i < 4; i++) fprintf(C,"Df%d           %s\n",i,config_floppy_name[i]);
      for (i = 0; i < FHFILE_MAX_DEVICES; i++) {
	fprintf(C,"HDfile%d       %s\n",i,config_fhfile_name[i]);
      }
      fprintf(C,"Kickfile      %s\n",config_memory_kicknameloaded);
#ifdef AF_MODE
      fprintf(C,"Keyfile       %s\n",config_memory_keyname);
#endif

      for (i = 0; i < 4; i++) fprintf(C,"Df%denabled    %d\n",i,config_floppy_enabled[i]);
      fprintf(C,"HDfileenabled %d\n",config_fhfile_enabled);
      fprintf(C,"Floppyfast    %d\n",config_floppy_fast);
      for( i = 0; i < 10; i++ ) {
	if( strcmp( memnames[i], "__None__" ) )
	  fprintf(C,"Diskmem%i      %s\n",(i==9) ? 0 : i+1, memnames[i]);
      };
      if( config_diskpath[0] )
	fprintf(C,"Diskpath      %s\n",config_diskpath);
      fprintf(C,"Chipmem       %d\n",config_memory_chipsize);
      fprintf(C,"Bogomem       %d\n",config_memory_bogosize);
      fprintf(C,"Fastmem       %d\n",config_memory_fastsize);
      fprintf(C,"JoystickA     %d\n",config_joy[0]);
      fprintf(C,"JoystickB     %d\n",config_joy[1]);
      fprintf(C,"Sound         %d\n",config_sound);
      fprintf(C,"Soundmode     %d\n",config_sound_mode);
      fprintf(C,"Skiprate      %d\n",config_graphics_skiprate);
      fprintf(C,"CycleExact    %d\n",config_draw_cycleexact);
      fprintf(C,"Scaley        %d\n",config_graphics_scaley);
      fprintf(C,"EnableLeds    %s\n",ledstr);
      fprintf(C,"KbdLeds       %s\n",kbdstr);
      fprintf(C,"Cputype       %d\n",config_cpu_type);
      fprintf(C,"Cpuspeed      %d\n",config_cpu_speed);
      fprintf(C,"Printspeed    %d\n",config_printspeed);
      fprintf(C,"Vesamode      %d\n",config_graphics_mode);
      fprintf(C,"Maxfps        %d\n",config_graphics_maxfps);
      fprintf(C,"Flickerfree   %d\n",config_graphics_flickerfree);
      fprintf(C,"AltNloop      %d\n",config_altn_loop + 1);
      fprintf(C,"MenuPosActive %d\n",config_store_mpos);
      if( strlen( &menustr ) && config_store_mpos )
	fprintf(C,"MenuPos       %s\n",&menustr);
      fprintf(C,"Autorun       %s\n",arnstr);
      fclose(C);
    }
  }
}





#ifdef DEBUGBUILD
/* ******************************************************************
   LOGGING CONFIGURATION PROCEDURES
   ******************************************************************

   Returns false when something went wrong */


ULO loadlogconfig(void) {
  FILE *F;
  char var[80];
  ULO value;

  if ((F = fopen("log.cfg","r")) == NULL) return 0;
  while (!feof(F)) {
    fscanf(F,"%s %d\n",var,&value);
    if (strcmp("LOGSERIALTRANSMITBUFFEREMPTYIRQ",var) == 0) logserialtransmitbufferemptyirq = value;
    else if (strcmp("LOGDISKDMATRANSFERDONEIRQ",var) == 0) logdiskdmatransferdoneirq = value;
    else if (strcmp("LOGSOFTWAREIRQ",var) == 0) logsoftwareirq = value;
    else if (strcmp("LOGCIAAIRQ",var) == 0) logciaairq = value;
    else if (strcmp("LOGCOPPERIRQ",var) == 0) logcopperirq = value;
    else if (strcmp("LOGVERTICALBLANKIRQ",var) == 0) logverticalblankirq = value;
    else if (strcmp("LOGBLITTERREADYIRQ",var) == 0) logblitterreadyirq = value;
    else if (strcmp("LOGAUDIOIRQ",var) == 0) logaudioirq = value;
    else if (strcmp("LOGSERIALRECEIVEBUFFERFULLIRQ",var) == 0) logserialreceivebufferfullirq = value;
    else if (strcmp("LOGDISKSYNCVALUERECOGNIZEDIRQ",var) == 0) logdisksyncvaluerecognizedirq = value;
    else if (strcmp("LOGCIABIRQ",var) == 0) logciabirq = value;
    else if (strcmp("LOGSTOP",var) == 0) logstop = value;
    else if (strcmp("LOGBUSERROREX",var) == 0) logbuserrorex = value;
    else if (strcmp("LOGODDADDRESSEX",var) == 0) logoddaddressex = value;
    else if (strcmp("LOGILLEGALINSTRUCTIONEX",var) == 0) logillegalinstructionex = value;
    else if (strcmp("LOGDIVISIONBY0EX",var) == 0) logdivisionby0ex = value;
    else if (strcmp("LOGPRIVILEGIEVIOLATIONEX",var) == 0) logprivilegieviolationex = value;
    else if (strcmp("LOGTRAPEX",var) == 0) logtrapex = value;
  }
  fclose(F);
  return 1;
}    

ULO savelogconfig(void) {
  FILE *F;

  if ((F = fopen("log.cfg","w")) == NULL) return 0;
  fprintf(F,"%s %d\n","LOGSERIALTRANSMITBUFFEREMPTYIRQ",logserialtransmitbufferemptyirq);
  fprintf(F,"%s %d\n","LOGDISKDMATRANSFERDONEIRQ",logdiskdmatransferdoneirq);
  fprintf(F,"%s %d\n","LOGSOFTWAREIRQ",logsoftwareirq);
  fprintf(F,"%s %d\n","LOGCIAAIRQ",logciaairq);
  fprintf(F,"%s %d\n","LOGCOPPERIRQ",logcopperirq);
  fprintf(F,"%s %d\n","LOGVERTICALBLANKIRQ",logverticalblankirq);
  fprintf(F,"%s %d\n","LOGBLITTERREADYIRQ",logblitterreadyirq);
  fprintf(F,"%s %d\n","LOGAUDIOIRQ",logaudioirq);
  fprintf(F,"%s %d\n","LOGSERIALRECEIVEBUFFERFULLIRQ",logserialreceivebufferfullirq);
  fprintf(F,"%s %d\n","LOGDISKSYNCVALUERECOGNIZEDIRQ",logdisksyncvaluerecognizedirq);
  fprintf(F,"%s %d\n","LOGCIABIRQ",logciabirq);
  fprintf(F,"%s %d\n","LOGSTOP",logstop);
  fprintf(F,"%s %d\n","LOGBUSERROREX",logbuserrorex);
  fprintf(F,"%s %d\n","LOGODDADDRESSEX",logoddaddressex);
  fprintf(F,"%s %d\n","LOGILLEGALINSTRUCTIONEX",logillegalinstructionex);
  fprintf(F,"%s %d\n","LOGDIVISIONBY0EX",logdivisionby0ex);
  fprintf(F,"%s %d\n","LOGPRIVILEGIEVIOLATIONEX",logprivilegieviolationex);
  fprintf(F,"%s %d\n","LOGTRAPEX",logtrapex);    
  fclose(F);
  return 1;
}    

#endif



void setup_trackmo(void) {   
  a[1] = 0x3000;
  set_pc(0x200c);
  intena = intenar = 0xc020;
  dmacon = dmaconr = 0x3d0;
  wril(0x1000,0x60);
  wril(0x1000,0x64);
  wril(0x1000,0x68);
  wril(0x1000,0x6c);
  wril(0x1000,0x70);
  wril(0x1000,0x74);
  wril(0x1000,0x78);
  wril(0x1000,0x7c);        /* Might lose some ints here..... */
  wril(0x33fc3fff,0x1000);  /* move #$3fff,$dff09c */
  wril(0x00dff09c,0x1004);  
  wril(0x4e730000,0x1008);  /* rte */
  copy_bootblock();
}

extern ULO keybufferconsumepos;
extern ULO keybufferproducepos;
extern UBY keybuffer[];


UBY emuspeedstring[20];

void print_emuspeed(void) {
  if ((config_sound == 1) || (config_graphics_maxfps == 1)) {
    if (emuspeed > 10000) emuspeed = 10000;
  }
  sprintf(emuspeedstring,"%3d%%",emuspeed/100);
  plot_text_speedbuffer(emuspeedstring,0x7fff,0);
}



void vesa_scaley(void) {
  int hey;
  outp(0x3d4,9);
  hey = inp(0x3d5);
  outp(0x3d4,9);
  outp(0x3d5,(hey&0xe0)|config_graphics_scaley);
}

void setup_320w_tables(void) {
  init_drawtables_320w();
  graphem_init_p2c_320();
  wriw(bplcon0,0xdff100);
}

void setup_320b_tables(void) {
  init_drawtables_320b();
  graphem_init_p2c_320();
  wriw(bplcon0,0xdff100);
}

void setup_640w_tables(void) {
  init_drawtables_640w();
  graphem_init_p2c_800();
  wriw(bplcon0,0xdff100);
}

void setup_800w_tables(void) {
  init_drawtables_800w();
  graphem_init_p2c_800();
  wriw(bplcon0,0xdff100);
}

void setup_emu_800600w(void) {
  int hey;
  setup_800w_tables();
  set_mode800600w();
  clipleftx = 88;
  cliprightx = 472;
  cliptop = 0x1a;
  clipbot = 0x139;
  
  if (!config_graphics_flickerfree && config_graphics_scaley > 0) {
    vesa_scaley();
  }
}

void setup_emu_320200w(void) {
  setup_320w_tables();
  set_mode320200w();
  if (gmodefirsttime[config_graphics_mode]) {
    clipleftx = 129;
    cliprightx = 449;
    cliptop = 0x2c;
    clipbot = 0xf4;
    gmodefirsttime[config_graphics_mode] = 0;
  }
}

void setup_emu_320200b_bank(void) {
  setup_320b_tables();
  set_mode320200oldvga();
  if (gmodefirsttime[config_graphics_mode]) {
    clipleftx = 129;
    cliprightx = 449;
    cliptop = 0x2c;
    clipbot = 0xf4;
    gmodefirsttime[config_graphics_mode] = 0;
  }
  screenptr = (ULO) framebuffer;
}

void setup_emu_320240w(void) {
  setup_320w_tables();
  set_mode320240w();
  if (gmodefirsttime[config_graphics_mode]) {
    clipleftx = 129;
    cliprightx = 449;
    cliptop = 0x2c;
    clipbot = 0x11c;
    gmodefirsttime[config_graphics_mode] = 0;
  }
}

void setup_emu_320240b(void) {
  setup_320b_tables();
  set_mode320240b();
  if (gmodefirsttime[config_graphics_mode]) {
    clipleftx = 129;
    cliprightx = 449;
    cliptop = 0x2c;
    clipbot = 0x11c;
    gmodefirsttime[config_graphics_mode] = 0;
  }
}

void setup_emu_320400b(void) {
  setup_320b_tables();
  set_mode320400b();
  if (gmodefirsttime[config_graphics_mode]) {
    clipleftx = 129;
    cliprightx = 449;
    cliptop = 0x1a;
    clipbot = 0x139;
    gmodefirsttime[config_graphics_mode] = 0;
  }
}

void setup_emu_320480b(void) {
  setup_320b_tables();
  set_mode320480b();
  if (gmodefirsttime[config_graphics_mode]) {
    clipleftx = 129;
    cliprightx = 449;
    cliptop = 0x1a;
    clipbot = 0x139;
    gmodefirsttime[config_graphics_mode] = 0;
  }
}

void setup_emu_400300b(void) {
  setup_320b_tables();
  set_mode400300b();
  clipleftx = 88;
  cliprightx = 472;
  cliptop = 0x1a;
  clipbot = 0x139;
}

void setup_emu_320400w(void) {
  setup_320w_tables();
  set_mode320400w();
  if (gmodefirsttime[config_graphics_mode]) {
    clipleftx = 129;
    cliprightx = 449;
    cliptop = 0x1a;
    clipbot = 0x139;
    gmodefirsttime[config_graphics_mode] = 0;
  }
}

void setup_emu_320480w(void) {
  setup_320w_tables();
  set_mode320480w();
  if (gmodefirsttime[config_graphics_mode]) {
    clipleftx = 129;
    cliprightx = 449;
    cliptop = 0x1a;
    clipbot = 0x139;
    gmodefirsttime[config_graphics_mode] = 0;
  }
}

void setup_emu_400300w(void) {
  setup_320w_tables();
  set_mode400300w();
  clipleftx = 88;
  cliprightx = 472;
  cliptop = 0x1a;
  clipbot = 0x139;
}

void setup_emu_640480w(void) {
  int hey;
  setup_640w_tables();
  set_mode640480w();
  if (gmodefirsttime[config_graphics_mode]) {
    if (config_graphics_scaley == 0) {
      clipleftx = 129;
      cliprightx = 449;
      cliptop = 0x1a;
      clipbot = 0x139;
    }
    else {
      clipleftx = 129;
      cliprightx = 449;
      cliptop = 0x2c;
      clipbot = 0x2c + (480/(config_graphics_scaley + 1));
    }
    gmodefirsttime[config_graphics_mode] = 0;
  }
  if (config_graphics_scaley > 0) {
    vesa_scaley();
  }
}

void setup_emu_640400w(void) {
  int hey;
  setup_640w_tables();
  set_mode640400w();
  if (gmodefirsttime[config_graphics_mode]) {
    if (config_graphics_scaley == 0) {
      clipleftx = 129;
      cliprightx = 449;
      cliptop = 0x1a;
      clipbot = 0x139;
    }
    else {
      clipleftx = 129;
      cliprightx = 449;
      cliptop = 0x2c;
      clipbot = 0x2c + (400/(config_graphics_scaley + 1));
    }
    gmodefirsttime[config_graphics_mode] = 0;
  }
  if (config_graphics_scaley > 0) {
    vesa_scaley();
  }
}

void setup_emu_640350w(void) {
  int hey;
  setup_640w_tables();
  set_mode640350w();
  if (gmodefirsttime[config_graphics_mode]) {
    if (config_graphics_scaley == 0) {
      clipleftx = 129;
      cliprightx = 449;
      cliptop = 0x1a;
      clipbot = 0x139;
    }
    else {
      clipleftx = 129;
      cliprightx = 449;
      cliptop = 0x2c;
      clipbot = 0x2c + (350/(config_graphics_scaley + 1));
    }
    gmodefirsttime[config_graphics_mode] = 0;
  }
  if (config_graphics_scaley > 0) {
    vesa_scaley();
  }
}

void setup_emu_videomode(void) {
  int hey;
  
  debug_screentables_not_set = FALSE;
  if (newvmode == 2) {
    gmodefirsttime[config_graphics_mode] = TRUE;
    if (config_graphics_scaley == 0) newvmode = 1;
    }
  switch (config_graphics_mode) {
    case 0: setup_emu_800600w();
            break;
    case 1: setup_emu_320200w();
            break;
    case 2: setup_emu_320240w();
            break;
    case 3: setup_emu_640480w();
            break;
    case 4: setup_emu_640400w();
            break;
    case 5: setup_emu_640350w();
            break;
    case 6: setup_emu_320200b_bank();
            break;
    case 7: setup_emu_320240b();
            break;
    case 8: setup_emu_320400b();
            break;
    case 9: setup_emu_320480b();
            break;
    case 10: setup_emu_400300b();
            break;
    case 11: setup_emu_320400w();
            break;
    case 12: setup_emu_320480w();
            break;
    case 13: setup_emu_400300w();
            break;
    }

  if (configdoublebuffer == 1) {
    showbuffer = 0;
    drawbuffer = 1;
  }
  else if (configdoublebuffer == 2) {
    showbuffer = 2;
    drawbuffer = 1;
  }
  else {
    showbuffer = drawbuffer = 0;
  }

  mem_initcolortranslation();
  clear_framebuffer();
  draw_init_lineflagstables();
  if (config_graphics_mode != 6)
    screenptr = ( (ULO) framebuffer) + bufferoffsets[drawbuffer] + startoffset;
  init_copperytable();
  newvmode = 0;
}

ULO oldprintspeed;

void print_usage(void) {
  printf("Option summary:\n");
  printf("-log                       Generate log-file while initializing\n");
  printf("-nogui                     Bypass initial GUI-session.\n");
  printf("-config file               Use file instead of default cfg-file\n");
  printf("-ns                        Don't save settings on exit\n" );
  printf("-nommx                     Don't use MMX even if it is present\n" );
  printf("-0 file                    Diskfile in df0\n");
  printf("-1 file                    Diskfile in df1\n");
  printf("-2 file                    Diskfile in df2\n");
  printf("-3 file                    Diskfile in df3\n");
  printf("-0e +|-                    Enable/disable df0\n");
  printf("-1e +|-                    Enable/disable df1\n");
  printf("-2e +|-                    Enable/disable df2\n");
  printf("-3e +|-                    Enable/disable df3\n");
  printf("-hfX file                  Hardfile filename, X is a number below %d\n", FHFILE_MAX_DEVICES);
  printf("-he +|-                    Hardfile enable/disable\n");
  printf("-hi size                   Create (erase!) specified hardfile, size in MB\n" );
  printf("-r file                    Kickstart file\n");
#ifdef AF_MODE
  printf("-K file                    Kickstart key-file\n");
#endif
  printf("-ds +|-                    Fast floppy-disk enable/disable\n");
  printf("-dmX file                  Disk memory X (0..9) contents\n" );
  printf("-dpath dir/file            Active disk path\n" );
  printf("-c size                    Chipmemory size, size*256k, default: 2MB\n");
  printf("-b size                    Bogomemory size, size*256k, default: 1.75MB\n");
  printf("-fm size                   Fastmemory size, size in MB, (0,1,2,4,8)\n");
  printf("-j1 n|a|m|k1|k2\n");
  printf("-j2 n|a|m|k1|k2            Joystick port 1 or 2:\n");
  printf("                           n - none, a - Analog Joystick\n");
  printf("                           m - mouse, k1 - Keyboard replacement 1\n");
  printf("                           k2 - Keyboard replacement 2\n");
  printf("-s d|n|c|e                 Sound-emulation:\n");
  printf("                           d - disable n - normal c - continuous\n");
  printf("                           e - emulated, no output\n");
  printf("-s1                        Force Soundblaster V1.0 driver\n");
  printf("-sf quality                Sound quality: 44100,31300,22050,15650\n");
  printf("-ss on|off                 Stereo, on or off\n");
  printf("-sb bits                   8 or 16 bits\n");
  printf("-res 320200b|320200|320240|640350|640400|640480|800600\n");
  printf("                           Resolution, default: 800600\n");
  printf("-fl none|50|vga             Framerate limit: none, 50 - 50hz, vga - from card\n");
  printf("-f number                  Skip 1/number of frames.\n");
  printf("-i on|off                  Interlaced in 800x600 resolution\n");
  printf("-gc on|off                 Cycle-exact color update\n");
  printf("-p on|off                  On-screen speedmeasurement.\n");
  printf("-l scr|kb?|lp?|lp?m|off    Power/diskdrive led indicators:\n");
  printf("                               scr - on screen (800x600 only)\n");
  printf("                               kb1 - on keyboard (drive 0, 1, 2)\n");
  printf("                               kb2 - on keyboard (power, drive 0, 1)\n");
  printf("                               kb3 - on keyboard (power, drive 0+1, 2+3)\n");
  printf("                            lp1/2/3 - on parallel port led meter\n");
  printf("                           lp1/2/3m - on parallel port led meter (mirrored)\n");
  printf("-lk ncs|nsc...             Use leds on PC keyboard in specified order\n" );
  printf("                           (Num lock = N, Caps lock = C, Scroll lock = S)\n" );
  printf("-cpu 0|3                   Cpu-type 0 - 68000  3 - 68030\n");
  printf("-cs normal|max             Clock speed of emulated M68000 and Blitter.\n");
  printf("-altn 1..4                 Alt-N drive looping\n" );
  printf("-arun none|altn|res        Automatic Run after commands\n" );
  printf("-rmpos +|-                 Enable/Disable menu position remembering.\n" );
  printf("-mpos /../...              Specify active menu position\n" );
  printf("-h                         This command-line option summary\n");
  printf("\nPlease consult documentation for more information.\n");
  exit(1);
}

/* Whoa!  Bastard Monster Function from Hell coming up */
/* Kludge, must be performed using the startup directory, not fellow homedir */

void parsecmd(int argc, char *argv[]) {
  int i,j;

  various_switch_to_startdir();

  config_graphics_flickerfree = FALSE;
  config_printspeed = FALSE;
  config_enableleds = TRUE;
  config_sb_forceV1 = FALSE;
  configmakelogfile = FALSE;
  config_sound_mode = 0;
  for (i = 1; i < argc; i++) {
    if (!strcmpi(argv[i],"-s1")) config_sb_forceV1 = TRUE;
    else if (!strcmpi(argv[i],"-log")) configmakelogfile = 1;
    else if (!strcmpi(argv[i],"-ns")) save_permit = FALSE;
    else if (!strcmpi(argv[i],"-nommx")) cmdnommx = TRUE;
    else if (!strcmpi(argv[i],"-h")) print_usage();
    else if (!strcmpi(argv[i],"-nogui")) cmdnogui = TRUE;
#ifdef CYCLE_EXACT
    else if (!strcmpi(argv[i],"-cc")) configcycleexact = 1;
#endif

#ifdef UAE_FILESYS
    else if ((!strcmpi(argv[i],"-m")) ||
	     (!strcmpi(argv[i],"-v"))) {
      char buf[256];
      char *s2, *ptr;
      int c = argv[i][1];
      int readonly = isupper(c);
      int vfs_module = (tolower(c) == 'v');
      int vfs_mangle_size = 8;
      
      strncpy(buf, argv[i + 1], 255); buf[255] = 0;
      s2 = strchr(buf, ':');
      if(s2) {
	*s2++ = '\0';
	if (vfs_module) {
	  ptr = strchr(s2, '*');
	  if (ptr) {
	    *ptr++ = '\0';
	    if ((*ptr) != 0)
	      vfs_mangle_size = atoi(ptr);
	    if ((vfs_mangle_size<1) ||  (vfs_mangle_size>8))
	      vfs_mangle_size = 8;
	  }
	}

	{
	  char *tmp;
	  while ((tmp = strchr(s2, '\\')))
	    *tmp = '/';
	}

	//various_make_relative_path(s2);
	various_switch_to_homedir();
	add_filesys_unit(buf, s2, readonly, vfs_module, vfs_mangle_size);
	various_switch_to_startdir();
      } else {
	if (!vfs_module)
	  fprintf(stderr, "Usage: [-m | -M] VOLNAME:/mount_point\n");
	else
	  fprintf(stderr, "Usage: [-v | -V] VOLNAME:/mount_point*mangle_size\n");
      }
    i += 2;
    }
#endif


    else if (!strcmpi(argv[i],"-c")) {
      cmdchip = TRUE;
      if (++i < argc) {
	config_memory_chipsize = atoi(argv[i]);
	if (config_memory_chipsize < 1) config_memory_chipsize = 1;
	else if (config_memory_chipsize > 8) config_memory_chipsize = 8;
	config_memory_chipsize *= 262144;
      }
      else {
	printf("Missing size for -c\n");
	exit(1);
      }
    }
    else if (!strcmpi( argv[ i ], "-dm1" )) {
      cmddm1 = 1; if (++i < argc) strcpy( memnames[ 0 ], argv[ i ] );
      else { printf( "Missing argument for -dm1\n" ); exit( 1 ); };
    }
    else if (!strcmpi( argv[ i ], "-dm2" )) {
      cmddm2 = 1; if (++i < argc) strcpy( memnames[ 1 ], argv[ i ] );
      else { printf( "Missing argument for -dm2\n" ); exit( 1 ); };
    }
    else if (!strcmpi( argv[ i ], "-dm3" )) {
      cmddm3 = 1; if (++i < argc) strcpy( memnames[ 2 ], argv[ i ] );
      else { printf( "Missing argument for -dm3\n" ); exit( 1 ); };
    }
    else if (!strcmpi( argv[ i ], "-dm4" )) {
      cmddm4 = 1; if (++i < argc) strcpy( memnames[ 3 ], argv[ i ] );
      else { printf( "Missing argument for -dm4\n" ); exit( 1 ); };
    }
    else if (!strcmpi( argv[ i ], "-dm5" )) {
      cmddm5 = 1; if (++i < argc) strcpy( memnames[ 4 ], argv[ i ] );
      else { printf( "Missing argument for -dm5\n" ); exit( 1 ); };
    }
    else if (!strcmpi( argv[ i ], "-dm6" )) {
      cmddm6 = 1; if (++i < argc) strcpy( memnames[ 5 ], argv[ i ] );
      else { printf( "Missing argument for -dm6\n" ); exit( 1 ); };
    }
    else if (!strcmpi( argv[ i ], "-dm7" )) {
      cmddm7 = 1; if (++i < argc) strcpy( memnames[ 6 ], argv[ i ] );
      else { printf( "Missing argument for -dm7\n" ); exit( 1 ); };
    }
    else if (!strcmpi( argv[ i ], "-dm8" )) {
      cmddm8 = 1; if (++i < argc) strcpy( memnames[ 7 ], argv[ i ] );
      else { printf( "Missing argument for -dm8\n" ); exit( 1 ); };
    }
    else if (!strcmpi( argv[ i ], "-dm9" )) {
      cmddm9 = 1; if (++i < argc) strcpy( memnames[ 8 ], argv[ i ] );
      else { printf( "Missing argument for -dm9\n" ); exit( 1 ); };
    }
    else if (!strcmpi( argv[ i ], "-dm0" )) {
      cmddm0 = 1; if (++i < argc) strcpy( memnames[ 9 ], argv[ i ] );
      else { printf( "Missing argument for -dm0\n" ); exit( 1 ); };
    }
    else if (!strcmpi(argv[i],"-j1")) {
      cmdjoya = TRUE;
      if (++i < argc) {
	if (!strcmpi(argv[i],"n")) config_joy[0] = 0;
	else if (!strcmpi(argv[i],"k1")) config_joy[0] = 1;
	else if (!strcmpi(argv[i],"k2")) config_joy[0] = 2;
	else if (!strcmpi(argv[i],"a")) config_joy[0] = 3;
	else if (!strcmpi(argv[i],"m")) config_joy[0] = 5;
	else {
	  printf("Unknown argument for -j1\n");
	  exit(1);
	}
      }
      else {
	printf("Missing argument for -j1\n");
	exit(1);
      }
    }
    else if (!strcmpi(argv[i],"-j2")) {
      cmdjoyb = TRUE;
      if (++i < argc) {
	if (!strcmpi(argv[i],"n")) config_joy[1] = 0;
	else if (!strcmpi(argv[i],"k1")) config_joy[1] = 1;
	else if (!strcmpi(argv[i],"k2")) config_joy[1] = 2;
	else if (!strcmpi(argv[i],"a")) config_joy[1] = 3;
	else if (!strcmpi(argv[i],"m")) config_joy[1] = 5;
	else {
	  printf("Unknown argument for -j2\n");
	  exit(1);
	}
      }
      else {
	printf("Missing argument for -j2\n");
	exit(1);
      }
    }
    else if (!strcmpi(argv[i],"-s")) {
      cmdsoundmethod = TRUE;
      if (++i < argc) {
	if (!strcmpi(argv[i],"d")) config_sound = 0;
	else if (!strcmpi(argv[i],"n")) config_sound = 1;
	else if (!strcmpi(argv[i],"c")) config_sound = 2;
	else if (!strcmpi(argv[i],"e")) config_sound = 3;
	else {
	  printf("Unknown argument for -s\n");
	  exit(1);
	}
      }
      else {
	printf("Missing d/n/c/e for -s\n");
	exit(1);
      }
    }
    else if (!strcmpi(argv[i],"-sb")) {
      cmdsoundmode = TRUE;
      if (++i < argc) {
	configaudiomodesetbylog = TRUE;
	if (!strcmpi(argv[i],"8")) config_sound_mode |= 8;
	else if (!strcmpi(argv[i],"16")) config_sound_mode &= 0x7;
	else {
	  printf("Unknown argument for -sb\n");
	  exit(1);
	}
      }
      else {
	printf("Missing 8/16 for -sb\n");
	exit(1);
      }
    }
    else if (!strcmpi(argv[i],"-ss")) {
      cmdsoundmode = TRUE;
      if (++i < argc) {
	configaudiomodesetbylog = TRUE;
	if (!strcmpi(argv[i],"on")) config_sound_mode &= 0xb;
	else if (!strcmpi(argv[i],"off")) config_sound_mode |= 4;
	else {
	  printf("Unknown argument for -ss\n");
	  exit(1);
	}
      }
      else {
	printf("Missing on/off for -ss\n");
	exit(1);
      }
    }
    else if (!strcmpi(argv[i],"-sf")) {
      cmdsoundmode = TRUE;
      if (++i < argc) {
	configaudiomodesetbylog = TRUE;
	if (!strcmpi(argv[i],"44100")) config_sound_mode &= 0xc;
	else if (!strcmpi(argv[i],"31300")) config_sound_mode |= 1;
	else if (!strcmpi(argv[i],"22050")) config_sound_mode |= 2;
	else if (!strcmpi(argv[i],"15650")) config_sound_mode |= 3;
	else {
	  printf("Unknown argument for -sf\n");
	  exit(1);
	}
      }
      else {
	printf("Missing frequency for -sf\n");
	exit(1);
      }
    }
    else if (!strcmpi(argv[i],"-b")) {
      cmdbogo = TRUE;
      if (++i < argc) {
	config_memory_bogosize = atoi(argv[i]);
	if (config_memory_bogosize > 7) config_memory_bogosize = 8;
	config_memory_bogosize *= 262144;
      }
      else {
	printf("Missing size for -b\n");
	exit(1);
      }
    }
    else if (!strcmpi(argv[i],"-fm")) {
      cmdfast = TRUE;
      if (++i < argc) {
	config_memory_fastsize = atoi(argv[i]);
	if (config_memory_fastsize == 0 ||
	    config_memory_fastsize == 1 ||
	    config_memory_fastsize == 2 ||
	    config_memory_fastsize == 4 ||
	    config_memory_fastsize == 8) config_memory_fastsize *= 0x100000;
	else {
	  printf("Unknown size for -fm\n");
	  exit(1);
	}
      }
      else {
	printf("Missing size for -fm\n");
	exit(1);
      }
    }
    else if (!strcmpi(argv[i],"-f")) {
      cmdskip = TRUE;
      if (++i < argc) {
	config_graphics_skiprate = atoi(argv[i]);
	if (config_graphics_skiprate < 1) config_graphics_skiprate = 1;
	else if (config_graphics_skiprate > 25) config_graphics_skiprate = 25;
	config_graphics_skiprate--;
      }
      else {
	printf("Missing size for -b\n");
	exit(1);
      }
    }
    else if (!strcmpi(argv[i],"-fl")) {
      cmdmaxfps = TRUE;
      if (++i < argc) {
	if (!strcmpi(argv[i],"none")) config_graphics_maxfps = 0;
	else if (!strcmpi(argv[i],"50")) config_graphics_maxfps = 1;
	else if (!strcmpi(argv[i],"vga")) config_graphics_maxfps = 2;
	else {
	  printf("Unknown argument for -v\n");
	  exit(1);
	}
      }
      else {
	printf("Missing none|50|vga for -v\n");
	exit(1);
      }
    }
    else if (!strcmpi(argv[i],"-i")) {
      cmdlace = TRUE;
      if (++i < argc) {
	if (!strcmpi(argv[i],"on")) config_graphics_flickerfree = 1;
	else if (!strcmpi(argv[i],"off")) config_graphics_flickerfree = 0;
	else {
	  printf("Unknown argument for -i\n");
	  exit(1);
	}
      }
      else {
	printf("Missing on|off for -i\n");
	exit(1);
      }
    }
    else if (!strcmpi(argv[i],"-gc")) {
      cmdcycleexact = TRUE;
      if (++i < argc) {
	if (!strcmpi(argv[i],"on")) config_draw_cycleexact = TRUE;
	else if (!strcmpi(argv[i],"off")) config_draw_cycleexact = FALSE;
	else {
	  printf("Unknown argument for -gc\n");
	  exit(1);
	}
      }
      else {
	printf("Missing on|off for -gc\n");
	exit(1);
      }
    }
    else if (!strcmpi(argv[i],"-gs")) {
      cmdscaley = TRUE;
      if (++i < argc) {
	if (!strcmpi(argv[i],"0")) config_graphics_scaley = 0;
	else if (!strcmpi(argv[i],"1")) config_graphics_scaley = 1;
	else if (!strcmpi(argv[i],"2")) config_graphics_scaley = 2;
	else {
	  printf("Unknown argument for -gs\n");
	  exit(1);
	}
      }
      else {
	printf("Missing 0|1|2 for -gs\n");
	exit(1);
      }
    }
    else if (!strcmpi(argv[i],"-cs")) {
      cmdcpuspeed = TRUE;
      if (++i < argc) {
	if (!strcmpi(argv[i],"normal")) config_cpu_speed = 0;
	else if (!strcmpi(argv[i],"max")) config_cpu_speed = 1;
	else {
	  printf("Unknown argument for -cpu\n");
	  exit(1);
	}
      }
      else {
	printf("Missing normal|max for -cs\n");
	exit(1);
      }
    }
    else if (!strcmpi(argv[i],"-cpu")) {
      cmdcputype = TRUE;
      if (++i < argc) {
	if (!strcmpi(argv[i],"0")) config_cpu_type = 0;
	else if (!strcmpi(argv[i],"3")) config_cpu_type = 3;
	else {
	  printf("Unknown argument for -cpu\n");
	  exit(1);
	}
      }
      else {
	printf("Missing normal|max for -cpu\n");
	exit(1);
      }
    }
    else if (!strcmpi(argv[i],"-p")) {
      cmdprintspeed = TRUE;
      if (++i < argc) {
	if (!strcmpi(argv[i],"on")) config_printspeed = 1;
	else if (!strcmpi(argv[i],"off")) config_printspeed = 0;
	else {
	  printf("Unknown argument for -p\n");
	  exit(1);
	}
      }
      else {
	printf("Missing on|off for -p\n");
	exit(1);
      }
    }
    else if (!strcmpi(argv[i],"-l")) {
      cmdleds = 1;
      if (++i < argc) {
	if (!strcmpi(argv[i],"off")) config_enableleds = 0;
	else if (!strcmpi(argv[i],"scr")) config_enableleds = 1;
	else if (!strcmpi(argv[i],"kb1")) config_enableleds = 0x81;
	else if (!strcmpi(argv[i],"kb2")) config_enableleds = 0x82;
	else if (!strcmpi(argv[i],"kb3")) config_enableleds = 0x83;
	else if (!strcmpi(argv[i],"lp1")) config_enableleds = 0x41;
	else if (!strcmpi(argv[i],"lp2")) config_enableleds = 0x42;
	else if (!strcmpi(argv[i],"lp3")) config_enableleds = 0x43;
	else if (!strcmpi(argv[i],"lp1m")) config_enableleds = 0x51;
	else if (!strcmpi(argv[i],"lp2m")) config_enableleds = 0x52;
	else if (!strcmpi(argv[i],"lp3m")) config_enableleds = 0x53;
	else {
	  printf("Unknown argument for -l\n");
	  exit(1);
	}
      }
      else {
	printf("Missing scr|kb?|lp?|lp?m|off for -l\n");
	exit(1);
      }
    }
    else if (!strcmpi(argv[i],"-lk")) {
      cmdkbdl = 1;
      if (++i < argc) {
	if (!strcmpi(argv[i],"ncs")) kbdleds = 0;
	else if (!strcmpi(argv[i],"nsc")) kbdleds = 1;
	else if (!strcmpi(argv[i],"cns")) kbdleds = 2;
	else if (!strcmpi(argv[i],"csn")) kbdleds = 3;
	else if (!strcmpi(argv[i],"scn")) kbdleds = 4;
	else if (!strcmpi(argv[i],"snc")) kbdleds = 5;
	else {
	  printf("Unknown argument for -lk\n");
	  exit(1);
	}
      }
      else {
	printf("Missing ncs|nsc|cns|csn|scn|snc for -lk\n");
	exit(1);
      }
    }
    else if (!strcmpi(argv[i],"-config")) {
      if (++i < argc) {
	strcpy(configfilename,argv[i]);
        various_make_relative_path(configfilename);
      }
      else {
	printf("Missing filename for -config\n");
	exit(1);
      }
    }
    else if (!strcmpi(argv[i],"-0")) {
      if (++i < argc) {
	cmddf[0] = TRUE;
	strcpy(config_floppy_name[0],argv[i]);
        various_make_relative_path(config_floppy_name[0]);
      }
      else {
	printf("Missing filename for diskimage in drive 0\n");
	exit(1);
      }
    }
    else if (!strcmpi(argv[i],"-1")) {
      if (++i < argc) {
	cmddf[1] = TRUE;
	strcpy(config_floppy_name[1],argv[i]);
        various_make_relative_path(config_floppy_name[1]);
      }
      else {
	printf("Missing filename for diskimage in drive 1\n");
	exit(1);
      }
    }
    else if (!strcmpi(argv[i],"-2")) {
      if (++i < argc) {
	cmddf[2] = TRUE;
	strcpy(config_floppy_name[2],argv[i]);
        various_make_relative_path(config_floppy_name[2]);
      }
      else {
	printf("Missing filename for diskimage in drive 2\n");
	exit(1);
      }
    }
    else if (!strcmpi(argv[i],"-3")) {
      if (++i < argc) {
	cmddf[3] = TRUE;
	strcpy(config_floppy_name[3],argv[i]);
        various_make_relative_path(config_floppy_name[3]);
      }
      else {
	printf("Missing filename for diskimage in drive 3\n");
	exit(1);
      }
    }
    else if (!strcmpi(argv[i],"-0e")) {
      if (++i < argc) {
	cmddfenabled[0] = TRUE;
	if (!strcmpi(argv[i],"+"))
	  config_floppy_enabled[0] = TRUE;
	else if (!strcmpi(argv[i],"-"))
	  config_floppy_enabled[0] = FALSE;
	else {
	  printf("Error in df0 enable: + to enable, - to disable\n");
	  exit(1);
	}
      }
      else {
	printf("Missing argument for df0 enable.\n");
	exit(1);
      }
    }
    else if (!strcmpi(argv[i],"-1e")) {
      if (++i < argc) {
	cmddfenabled[1] = TRUE;
	if (!strcmpi(argv[i],"+"))
	  config_floppy_enabled[1] = TRUE;
	else if (!strcmpi(argv[i],"-"))
	  config_floppy_enabled[1] = FALSE;
	else {
	  printf("Error in df1 enable: + to enable, - to disable\n");
	  exit(1);
	}
      }
      else {
	printf("Missing argument for df1 enable.\n");
	exit(1);
      }
    }
    else if (!strcmpi(argv[i],"-2e")) {
      if (++i < argc) {
	cmddfenabled[2] = TRUE;
	if (!strcmpi(argv[i],"+"))
	  config_floppy_enabled[2] = TRUE;
	else if (!strcmpi(argv[i],"-"))
	  config_floppy_enabled[2] = FALSE;
	else {
	  printf("Error in df2 enable: + to enable, - to disable\n");
	  exit(1);
	}
      }
      else {
	printf("Missing argument for df2 enable.\n");
	exit(1);
      }
    }
    else if (!strcmpi(argv[i],"-3e")) {
      if (++i < argc) {
	cmddfenabled[3] = TRUE;
	if (!strcmpi(argv[i],"+"))
	  config_floppy_enabled[3] = TRUE;
	else if (!strcmpi(argv[i],"-"))
	  config_floppy_enabled[3] = FALSE;
	else {
	  printf("Error in df3 enable: + to enable, - to disable\n");
	  exit(1);
	}
      }
      else {
	printf("Missing argument for df3 enable.\n");
	exit(1);
      }
    }
    else if (!strcmpi(argv[i],"-ds")) {
      if (++i < argc) {
	cmdfloppyfast = TRUE;
	if (!strcmpi(argv[i],"+"))
	  config_floppy_fast = TRUE;
	else if (!strcmpi(argv[i],"-"))
	  config_floppy_fast = FALSE;
	else {
	  printf("Error in fast floppy enable: + to enable, - to disable\n");
	  exit(1);
	}
      }
      else {
	printf("Missing argument for fast floppy enable.\n");
	exit(1);
      }
    }
    else if (!strnicmp(argv[i],"-hf",3)) {
      if (((UBY) (argv[i][3] - 0x30)) >= FHFILE_MAX_DEVICES) {
	printf("Error in -hfX, X must be a number less than %d\n",FHFILE_MAX_DEVICES);
	exit(1);
      }
      else {
	if (++i < argc) {
	  cmdfhfile[argv[i - 1][3] - 0x30] = TRUE;
	  strcpy(config_fhfile_name[argv[i-1][3] - 0x30],argv[i]);
          various_make_relative_path(config_fhfile_name[argv[i-1][3]-0x30]);
	}
	else {
	  printf("Missing filename for hardfile\n");
	  exit(1);
	}
      }
    }
    else if (!strcmpi(argv[i],"-he")) {
      if (++i < argc) {
	cmdfhfileenabled = TRUE;
	if (!strcmpi(argv[i],"+"))
	  config_fhfile_enabled = TRUE;
	else if (!strcmpi(argv[i],"-"))
	  config_fhfile_enabled = FALSE;
	else {
	  printf("Error in hardfile enable: + to enable, - to disable\n");
	  exit(1);
	}
      }
      else {
	printf("Missing argument for hardfile enable.\n");
	exit(1);
      }
    }
    else if (!strcmpi(argv[i],"-hi")) {
      cmdfhfileinit = TRUE;
      if (++i < argc) {
	config_fhfile_init = atoi( argv[i] );
      }
      else {
	printf("Missing size for -hi\n");
	exit(1);
      }
    }
    else if (!strcmpi(argv[i],"-r")) {
      if (++i < argc) {
	cmdkick = TRUE;
	strcpy(config_memory_kickname,argv[i]);
        various_make_relative_path(config_memory_kickname);
      }
      else {
	printf("Missing filename for Kickstart-image\n");
	exit(1);
      }
    }
    else if (!strcmpi(argv[i],"-K")) {
      if (++i < argc) {
	cmdkeyname = TRUE;
	strcpy(config_memory_keyname,argv[i]);
        various_make_relative_path(config_memory_keyname);
      }
      else {
	printf("Missing filename for Kickstart-key\n");
	exit(1);
      }
    }
    else if (!strcmpi(argv[i],"-dpath")) {
      if (++i < argc) {
	cmddiskpath = TRUE;
	strcpy(config_diskpath,argv[i]);
        various_make_relative_path(config_diskpath);
      }
      else {
	printf("Missing disk path string\n");
	exit(1);
      }
    }
    else if (!strcmpi(argv[i],"-altn")) {
      cmdaltn = TRUE;
      if (++i < argc) {
	config_altn_loop = atoi( argv[i] ) - 1;
      }
      else {
	printf("Missing argument for -altn\n");
	exit(1);
      }
    }
    else if (!strcmpi(argv[i],"-arun")) {
      if (++i < argc) {
	cmdarun = TRUE;
	if( !strcmpi( argv[i], "None" ) ) config_autorun = 0;
	else if( !strcmpi( argv[i], "AltN" ) ) config_autorun = 1;
	else if( !strcmpi( argv[i], "Res" ) ) config_autorun = 2;
	else if( !strcmpi( argv[i], "AltNRes" ) ) config_autorun = 3;
	else {
	  printf("Invalid argument for -rmpos\n" );
	  exit(1);
	}
      }
      else {
	printf("Missing +|- for -rmpos\n");
	exit(1);
      }
    }
    else if (!strcmpi(argv[i],"-rmpos")) {
      if (++i < argc) {
	cmdsmpos = TRUE;
	if( !strcmpi( argv[i], "+" ) )
	  config_store_mpos = TRUE;
	else if( !strcmpi( argv[i], "-" ) )
	  config_store_mpos = FALSE;
	else {
	  printf("Invalid argument for -rmpos\n" );
	  exit(1);
	}
      }
      else {
	printf("Missing +|- for -rmpos\n");
	exit(1);
      }
    }
    else if (!strcmpi(argv[i],"-mpos")) {
      if (++i < argc) {
	cmdmpos = TRUE;
	strcpy(&menupos_want0, argv[i]);
      }
      else {
	printf("Missing menu position string\n");
	exit(1);
      }
    }
    else if (!strcmpi(argv[i],"-res")) {
      if (++i < argc) {
	cmdgmode = TRUE;
	if (!strcmpi(argv[i],"800600")) config_graphics_mode = 0;
	else if (!strcmpi(argv[i],"320200")) config_graphics_mode = 1;
	else if (!strcmpi(argv[i],"320240")) config_graphics_mode = 2;
	else if (!strcmpi(argv[i],"640480")) config_graphics_mode = 3;
	else if (!strcmpi(argv[i],"640400")) config_graphics_mode = 4;
	else if (!strcmpi(argv[i],"640350")) config_graphics_mode = 5;
	else if (!strcmpi(argv[i],"320200b")) config_graphics_mode = 6;
	else {
	  printf("Unknown resolution in -res\n");
	  exit(1);
	}
      }
      else {
	printf("Missing resolution for -res\n");
	exit(1);
      }
    }

    else print_usage();
  }

  various_switch_to_homedir();
}

/* The run-time log */

ULO addlogfirst = 1;

void addlog(char *msg) {
  FILE *F;

  if (!configmakelogfile) return;
  if (addlogfirst) {
    F = fopen("fellow.log","w");
    addlogfirst = 0;
  }
  else F = fopen("fellow.log","a");
  if (F != NULL) {
    fprintf(F,"%s",msg);
    fclose(F);
  }
}

/* Softreset */

void fellow_softreset(void) {
  bg2ddf = 0;
  softreset = 0;

  /* Set new pc */

  set_pc(fetl(0xf80004));
#ifdef PREFETCH
  prefetch_fill(pc);
#endif

  a[7] = config_memory_chipsize;
  usp = config_memory_chipsize;
  ssp = config_memory_chipsize-0x2000;
  sr = 0;

  interruptflag = cpustopflag = 0;
  blitterstatus = 0;
  sr = 0;

  /*        cop1lc = cop2lc = 0;
	    nxtcopaccess = 0xffffffff;
	    */
  /* Clear interrupts */

  intreq = 0;
  /*
    intena = intenar = 0; */
  if (config_memory_nokick) setup_trackmo();
  /*        reset_keyboard(); */
  /*        reset_mouse();    */
}

/* Hardreset, reinit memory, hardfile */

ULO fellow_reset_firsttime = TRUE;

void fellow_hardreset(void) {
  FILE *F;
  bg2ddf = 0;

#ifdef CPU_TRACE_TO_FILE
  cpu_trace_to_file_reset();
#endif
  
#ifdef UAE_FILESYS
  if (!fellow_reset_firsttime) {
    filesys_prepare_reset();
    filesys_reset();
  }
  fellow_reset_firsttime = FALSE;
#endif
  
  memory_init();
  fhfile_setup();
  
#ifdef UAE_FILESYS
  rtarea_init();          /* UAE */
  hardfile_install();     /* UAE */
  rtarea_setup();         /* UAE */
  filesys_install();      /* UAE */
  if (config_memory_romversion >= 0x200) 
    memory_emem_add_card(expamem_init_filesys, expamem_map_filesys);  
#endif

  memory_emem_this_card_init();

  /*disk_initstate();
    cpuinit();
    chipinit();
    soundinit();
    sb_initvars();
    reset_mousekeyboard();
    */
  /* Set new pc */

  set_pc(fetl(0xf80004));
#ifdef PREFETCH
  prefetch_fill(pc);
#endif
  a[7] = config_memory_chipsize;
  usp = config_memory_chipsize;
  ssp = config_memory_chipsize-0x2000;
  sr = 0;

  interruptflag = cpustopflag = 0;
  blitterstatus = 0;
  blitend = 0xffffffff;
  irq_next = 0xffffffff;
  cop1lc = cop2lc = 0;
  nxtcopaccess = 0xffffffff;

  /* Clear interrupts */

  intreq = 0;
  intena = intenar = 0;
  if (config_memory_nokick) setup_trackmo();
  reset_keyboard();
  reset_mouse();
  curcycle = 0;
  xpos = ypos = 0;
  cpu_next = 0;
  eol_next = CYCLESPERLINE - 1;
  eof_next = CYCLESPERFRAME;
  bus_clear_eventlist();
}

/* Called from debugger */

void fellow_step(void) {
  ULO oldpc = get_pc(pc);
  if (config_sound != 1) start_timerirq();
  audio_hblanks = 0;
  init_mouseirq();
  /*        init_kbdirq(); */
  if (config_sound > 0) (*sound_before_emu)();
  debugging = TRUE;
  bus_debug();
  debugging = FALSE;
  if (config_sound != 1) stop_timerirq();
  if (config_sound > 0) (*sound_after_emu)();
  /*        restore_kbdirq(); */
  restore_mouseirq();
}

/* Called from debugger */

void fellow_step_over(void) {
  ULO mpc,opco;
  union { ULO lo; ULO (*fun)(); } yeah;
  char s[80];

  mpc = get_pc(pc);
  opco = fetw(mpc);
  yeah.lo = t[opco][1];
  mpc = yeah.fun(mpc,opco,s);
  if (config_sound != 1) start_timerirq();
  audio_hblanks = 0;
  init_mouseirq();
  /*        init_kbdirq(); */
  if (config_sound > 0) (*sound_before_emu)();
  debugging = TRUE;
  while (mpc != get_pc(pc) && !f12pressed) bus_debug();
  debugging = FALSE;
  if (config_sound != 1) stop_timerirq();
  if (config_sound > 0) (*sound_after_emu)();
  /*        restore_kbdirq(); */
  restore_mouseirq();
  f12pressed = FALSE;
}

/* Called from wav_do */

void fellow_wav_run(ULO frames_to_run) {
  int frame_to_end = frames + frames_to_run;  

  if (config_sound != 1) start_timerirq();
  audio_hblanks = 0;
  init_mouseirq();
  init_kbdirq();
  if (config_sound > 0) (*sound_before_emu)();
  debugging = TRUE;
  while (frames < frame_to_end) bus_run();
  debugging = FALSE;
  if (config_sound != 1) stop_timerirq();
  if (config_sound > 0) (*sound_after_emu)();
  restore_kbdirq();
  restore_mouseirq();
  f12pressed = FALSE;
}

/* Called from debugger */

void fellow_run_until_breakpoint(ULO breakpoint) {
  setup_emu_videomode();
  if (config_sound != 1) start_timerirq();
  audio_hblanks = 0;
  init_mouseirq();
  init_kbdirq();
  if (config_sound > 0) (*sound_before_emu)();
  debugging = TRUE;
  while (get_pc(pc) != breakpoint && !f12pressed) bus_debug();
  debugging = FALSE;
  if (config_sound != 1) stop_timerirq();
  if (config_sound > 0) (*sound_after_emu)();
  restore_kbdirq();
  restore_mouseirq();
  f12pressed = FALSE;
}


#ifdef DEBUGBUILD

/* Called from debugger */

void fellow_run_until_event(void) {
  int oldlogpos = loglast;

  if (config_sound != 1) start_timerirq();
  audio_hblanks = 0;
  init_mouseirq();
  init_kbdirq();
  if (config_sound > 0) (*sound_before_emu)();
  debugging = TRUE;
  while ((loglast == oldlogpos) && !f12pressed) bus_debug();
  debugging = FALSE;
  if (config_sound != 1) stop_timerirq();
  if (config_sound > 0) (*sound_after_emu)();
  restore_kbdirq();
  restore_mouseirq();
  f12pressed = FALSE;
}

#endif

/* Called from debugger */

void fellow_run_until_line(int line) {
  if (line < 0) line = 0;
  else if (line > 312) line = 312;
  if (config_sound != 1) start_timerirq();
  audio_hblanks = 0;
  init_mouseirq();
  init_kbdirq();
  if (config_sound > 0) (*sound_before_emu)();
  debugging = TRUE;
  if (ypos == line) while (ypos == line && !f12pressed) bus_debug();
  while (ypos != line && !f12pressed) bus_debug();
  debugging = FALSE;
  if (config_sound != 1) stop_timerirq();
  if (config_sound > 0) (*sound_after_emu)();
  restore_kbdirq();
  restore_mouseirq();
  f12pressed = FALSE;
}

/* Called when RUN is selected, will run until F12 is pressed */

void fellow_run(void) {
  UBY *kbdstat = (UBY *)0x417;
  int i;
  setup_emu_videomode();
  if (config_sound != 1) start_timerirq();
  audio_hblanks = 0;
  init_mouseirq();
  init_kbdirq();
  if( config_enableleds & 0xc0 ) drawledlpt(); /* update leds */
  if (config_sound > 0) (*sound_before_emu)();
  debugging = FALSE;
  /*debugging = TRUE; */
  bus_run();
  if (config_sound > 0) (*sound_after_emu)();
  if (config_sound != 1) stop_timerirq();
  restore_kbdirq();
  restore_mouseirq();
  if( config_enableleds & 0x40 ) outp( ledlpt, 0 );/* Clear par port leds*/
  /*  if( config_enableleds & 0x80 ) drawoldkbd();       restore kbd leds */
  audio_hblanks = 0;
  debugging = FALSE;
  f12pressed = FALSE;
}


/* Something is seriously wrong, try to clean up irqs and exit */

void fellow_nasty_exit(void) {
  mouse_close();
  kbd_close();
  if (config_sound != 1) stop_timerirq();
  if (config_soundcard_found) sb_close();
  printf("Serious error! Exit.\n");
  various_switch_to_startdir();
  exit(EXIT_FAILURE);
}


void main(int argc,char *argv[]) {
  int i;
  FILE *F;

  /* Set some config-vars to default values */

  for (i = 0; i < FHFILE_MAX_DEVICES; i++) cmdfhfile[i] = FALSE;
  for (i = 0; i < NROFMODES; i++) gmodefirsttime[i] = TRUE;
  gui_clear_memnames();

  various_resolve_original_paths(argv[0]);

#ifdef UAE_FILESYS
  /* From UAE, the UAE hardfile is always named hardfile */
  /* Tests for existance of that file, and records the filesize */

  strcpy(uaehf0, "hardfile");
  F = fopen("hardfile","rb");
  if (F) {
    fseek(F,0,SEEK_END);
    hardfile_size = ftell(F);
    fclose(F);
  }
  else hardfile_size = 0;

  rtarea_init();          /* UAE */
  
  hardfile_install();     /* UAE */
#endif
  
  /* Parse command-line args, and load config-file */
  
  parsecmd(argc, argv);
  load_fellow_cfg();

#ifdef UAE_FILESYS
  rtarea_setup();         /* UAE */
  filesys_install();      /* UAE */
#endif



  strcpy(config_memory_kicknameloaded,"__None__");
  config_memory_nokick = TRUE;
#ifdef DEBUGBUILD
  loadlogconfig();
#endif
  mmx_detected = detect_mmx();
  if (cmdnommx) mmx_detected = FALSE;
  bus_init();
  screeninit();
  soundinit();
  sb_init();
  if (!config_soundcard_found)
    if (config_sound == 1 || config_sound == 2) config_sound = 0;
    

  /*      mem_init();  Done in reset */
  cpuinit();
  blit_init();
  draw_init();
  copper_init();
  graphem_init_tables();
  fgui_preenter();
  diskinit();
  cia_init();
  init_joysticks();
  /*      fhfile_setup();  Done in reset */

  /* Hack */

  fix_a7pointer();
  sound_initmode();

  
  
  fgui_enter();

  for (i = 0; i < 4; i++) if (gzipped[i]) remove_gzip_image(i,0);

  /* Save configuration */

  save_fellow_cfg();

  /* Free memory allocated for the disk-image caches */

  freeadfcache();
  kbd_close();     
  mouse_close();     

  /* Kill soundblaster */

  if (config_soundcard_found) sb_close();
  memory_cleanup();
#ifdef DEBUGBUILD
  savelogconfig();
#endif

  various_switch_to_startdir();
}

