/* Petter Schau 1996
// io prototypes for use outside ioa.c/io.h
*/

struct window {
  ULO x1,y1,x2,y2;
  UWO fgcolor;
  UWO bgcolor;
};

struct numberfield {
  ULO x,y;
  ULO value;
  struct window *hostwindow;
};

// Struct to hold string field data
// --------------------------------
struct stringfield {
  ULO x,y;
  char value[120];
  struct window *hostwindow;
};

void init_number_field(struct numberfield *n,struct window *w,ULO v,ULO x,ULO y);
void enter_number(struct numberfield *n);

void init_string_field(struct stringfield *n,struct window *w,ULO x,ULO y);
void enter_string(struct stringfield *n);

extern UWO *framebuffer;
extern ULO scanlineadd;

extern ULO emulate_joystick;
extern ULO screeninit(void);
extern ULO screenclose(void);
extern void plot_text(char *str,ULO x,ULO y,UWO fgcol,UWO bgcol);
extern void clear(ULO starty, ULO stoppy);
extern void init_window(struct window *w,ULO x1,ULO y1,ULO x2,ULO y2,UWO fgcolor,UWO bgcolor);
extern void clear_window(struct window *w);
extern void plot_text_window(struct window *w,char *s,ULO x,ULO y);
extern void plot_text_window_reverse(struct window *w,char *s,ULO x,ULO y);
extern void print_window_borders(struct window *w);

extern ULO firebutton;
