// Petter Schau 1996
extern void chipinit(void);
extern void buscycle(void);
extern ULO ypos;
extern ULO blitterdmawaiting;
extern ULO curcopptr;

extern ULO drawptr;
extern ULO decoderoutineptr,drawroutineptr;

extern void drawlores();
extern void drawhires();
extern void drawdualhires();
extern void drawduallores();
extern void drawham();
extern void drawddfline();
extern void drawbgline();
extern void decodelo1();
extern void decodelo2();
extern void decodelo3();
extern void decodelo4();
extern void decodelo5();
extern void decodelo6();
extern void decodeduallo2();
extern void decodeduallo3();
extern void decodeduallo4org();
extern void decodeduallo5();
extern void decodeduallo6();
extern void decodehi1();
extern void decodehi2();
extern void decodehi3();
extern void decodehi4();
extern void decodedualhi2();
extern void decodedualhi3();
extern void decodedualhi4();

