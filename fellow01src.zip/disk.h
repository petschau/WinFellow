// Variables for 4 disks
// -------------------

extern ULO sel[4],track[4],writeprot[4],dir[4],motor[4],side[4];
extern ULO inserted[4],active[4];
extern UBY image[4][901120];


// Data to control the end of a transfer

extern ULO diskdmainprogress;
extern ULO diskdmalinesleft;
extern ULO diskdmaen;   // Counts the number of writes to dsklen

extern void copy_bootsector();
extern void disk_init(void);
extern void insert_diskimage(char *diskname,ULO drive);


extern ULO disknotfound[4];

extern ULO diskspeed;
