// Disk emulation V1.111111
// Petter Schau 1996

#include <stdio.h>
#include "defs.h"

extern UBY cmem[];

extern char df0name[120];
extern char df1name[120];
extern char df2name[120];
extern char df3name[120];


ULO diskspeed;

// selx,trackx,writeprot,motor,inserted,active 
//   is ordinary boolean, 1 means selected, as opposed to
//   the line values in the cia

// dirx, 1 means increasing the track variable on a step
// sidex, 1 means side 1, 0 side 0


// Variables for 4 disks
// -------------------

ULO sel[4],track[4],writeprot[4],dir[4],motor[4],side[4];
ULO inserted[4],active[4];
ULO idcount[4];
UBY image[1914880*2];
UBY bootsector[1024];
UBY tmpsector[512];
//UBY tmpimage[901120];

// Data to control the end of a transfer

ULO diskdmainprogress;
ULO diskdmalinesleft;
ULO diskdmaen;   // Counts the number of writes to dsklen

ULO disknotfound[4];

// I have no docs for the correct format here, so I kind of looked at
// what uae did :-) I should credit Bernd Schmidt here for making uae sources
// available.  

void makemfmsector(ULO t,ULO s,ULO drive) {
  ULO tmp,x,odd,even,hck=0,dck=0;
  ULO tracki = t*11968+s*1088+drive*1914880;

  image[tracki + 0] = 0xaa;
  image[tracki + 1] = 0xaa;
  image[tracki + 2] = 0xaa;
  image[tracki + 3] = 0xaa;
  image[tracki + 4] = 0x44;
  image[tracki + 5] = 0x89;
  image[tracki + 6] = 0x44;
  image[tracki + 7] = 0x89;

  for (x = 8; x < 1088; x++) image[tracki+x] = 0x55;


  tmp = 0xff000000 | ((t&0xff)<<16) | ((s&0xff)<<8) | ((11-s)&0xff);
  even = tmp&0x55555555;
  odd = (tmp>>1)&0x55555555;
  image[tracki+8] =  (odd&0xff000000)>>24;
  image[tracki+9] =  (odd&0xff0000)>>16;
  image[tracki+10] = (odd&0xff00)>>8;
  image[tracki+11] = (odd&0xff);
  image[tracki+12] = (even&0xff000000)>>24;
  image[tracki+13] = (even&0xff0000)>>16;
  image[tracki+14] = (even&0xff00)>>8;
  image[tracki+15] = (even&0xff);



  for (x=16 ; x< 48; x++) image[tracki+x] = 0x55;

  for (x = 64 ; x < 576; x++) {
    tmp = tmpsector[x-64];
    odd = tmp&0x55;
    even = (tmp>>1)&0x55;
    image[tracki+x] = even;
    image[tracki+x+512] = odd;
    }
  for(x = 8; x < 48; x += 4)
    hck ^= (((ULO)image[tracki+x])<<24) |((ULO)(image[tracki+x+1])<<16) | (((ULO)image[tracki+x+2])<<8) |(((ULO)image[tracki+x+3]));
   
  even = odd = hck; odd >>= 1;

  image[tracki+48] = (odd&0xff000000) >> 24;
  image[tracki+49] = (odd&0xff0000) >> 16;
  image[tracki+50] = (odd&0xff00) >> 8;
  image[tracki+51] = odd&0xff;
  image[tracki+52] = (even&0xff000000) >> 24;
  image[tracki+53] = (even&0xff0000) >> 16;
  image[tracki+54] = (even&0xff00) >> 8;
  image[tracki+55] = even&0xff;

  for(x = 64; x < 1088; x += 4)
    dck ^= (((ULO)image[tracki+x])<<24) |((ULO)(image[tracki+x+1])<<16) | (((ULO)image[tracki+x+2])<<8) |(((ULO)image[tracki+x+3]));
    
  even = odd = dck; odd >>= 1;
  image[tracki+56] = (odd&0xff000000) >> 24;
  image[tracki+57] = (odd&0xff0000) >> 16;
  image[tracki+58] = (odd&0xff00) >> 8;
  image[tracki+59] = odd&0xff;
  image[tracki+60] = (even&0xff000000) >> 24;
  image[tracki+61] = (even&0xff0000) >> 16;
  image[tracki+62] = (even&0xff00) >> 8;
  image[tracki+63] = even&0xff;
}


void insert_diskimage(char *diskname,int drive) {
  FILE *F;
  int i,j,k;

  disknotfound[drive] = 1;
  inserted[drive] = active[0] = 0;

  if (strcmp(diskname,"__none__") == 0)
    return;  
  if ((F = fopen(diskname,"rb")) != NULL) {
    disknotfound[drive] = 0;
    inserted[drive] = 1;
    for (i=0 ; i < 160; i++) {
      for (j=0; j < 11; j++) {
        fread(tmpsector,1,512,F);
/*        if (drive == 0) {
            for (k = 0; k < 512; k++) tmpimage[i*5632 + j*512 + k] = tmpsector[k];
            }
  */
        makemfmsector(i,j,drive);
        }
      }
    fclose(F);
    }
}

// diskinit intializes the variables and loads diskfiles
// returns 0 on error

ULO diskinit(void) {
  ULO i;

  for (i = 0; i < 4; i++) {
    sel[i] = 0;
    track[i] = 0;
    writeprot[i] = 1;
    dir[i] = 0;
    motor[i] = 0;
    side[i] = 0;
    inserted[i] = 0;
    active[i] = 0;
    idcount[i] = 0;
    disknotfound[i] = 1;
    }

  diskdmainprogress = 0;
  diskdmalinesleft = 0;
  diskdmaen = 0;

  insert_diskimage(df0name,0);
  insert_diskimage(df1name,1);
  insert_diskimage(df2name,2);
  insert_diskimage(df3name,3);

  // No errors generated right now
  return 1;
}

void copy_bootsector() {
   int i;
//   for (i=0; i < 1024; i++) cmem[i+0x80000] = tmpimage[i];
}    
