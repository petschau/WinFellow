#include "defs.h"
#include "io.h"

extern struct window config_enterdisk_requester;
extern struct stringfield config_enterdiskstringfield;


struct menu {
  char entrytext[10][21];
  ULO activeentry;
  ULO numberofentries;
  struct window *menuwindow;
};

// Prints the menu in the associated window
void menu_print(struct menu *m) {
  ULO i;

  for (i = 0; i < m->numberofentries; i++) {
    if (m->activeentry == i)
      plot_text_window_reverse(m->menuwindow,m->entrytext[i],0,i);
    else
      plot_text_window(m->menuwindow,m->entrytext[i],0,i);
    }
}

// Waits for a selection and returns the entry position
ULO menu_select(struct menu *m)
{
  int c,selection = -1;

  while (selection == -1) {
    c = getch();
    if (c == 0) {
      c = getch();
      if (c == 72) { // UP
        if (m->activeentry > 0) {
          m->activeentry--;
          menu_print(m);
          }
        }
      else if (c == 80) { // DOWN
        if (m->activeentry < (m->numberofentries-1)) {
          m->activeentry++;
          menu_print(m);
          }
        }
      }
    if (c == 13) selection = m->activeentry;
    }
  return selection;
}

// YESNOMENU PROCEDURES

struct yesnomenuitem {
  char text[80];
  ULO  *value;
};

struct yesnomenu {
  struct yesnomenuitem items[80];
  ULO activeentry;
  ULO numberofentries;
  struct window *menuwindow;
  ULO yesnopos;
};

// Prints the yesnomenu in the associated window
void yesnomenu_print(struct yesnomenu *m) {
  ULO i;

  for (i = 0; i < m->numberofentries; i++) {
    plot_text_window(m->menuwindow,m->items[i].text,0,i);
    if (m->activeentry == i) {
      if (*(m->items[i].value) == 1)
        plot_text_window_reverse(m->menuwindow,"YES",m->yesnopos,i);
      else
        plot_text_window_reverse(m->menuwindow," NO",m->yesnopos,i);
      }
    else {
      if (*(m->items[i].value) == 1)
        plot_text_window(m->menuwindow,"YES",m->yesnopos,i);
      else
        plot_text_window(m->menuwindow," NO",m->yesnopos,i);
      }
    }
}

// Waits for a selection and returns the entry position
void yesnomenu_select(struct yesnomenu *m)
{
  int c,finished = 0;

  while (finished == 0) {
    c = getch();
    if (c == 0) {
      c = getch();
      if (c == 72) { // UP
        if (m->activeentry > 0) {
          m->activeentry--;
          yesnomenu_print(m);
          }
        }
      else if (c == 80) { // DOWN
        if (m->activeentry < (m->numberofentries-1)) {
          m->activeentry++;
          yesnomenu_print(m);
          }
        }
      }
    else if (c == 13) finished = 1;
    else if (c == 32) {
      if (*(m->items[m->activeentry].value) == 1)
        *(m->items[m->activeentry].value) = 0;
      else
        *(m->items[m->activeentry].value) = 1;
      yesnomenu_print(m);
      }
    }
}

// OPTIONMENU PROCEDURES


struct optionmenuoptionlist {
  char optiontext[26][10];
  ULO numberofentries;
  ULO optionvalues[26];
  ULO activeoption;
};

struct optionmenuitem {
  char text[30];
  ULO  type;             // 0 - text list of options 1 - enter string
  struct optionmenuoptionlist options;
  ULO  *intvalue;
  char *stringvalue;
};

struct optionmenu {
  struct optionmenuitem items[16];
  ULO activeentry;
  ULO numberofentries;
  struct window *menuwindow;
  ULO optionpos;
};


// Prints the optionmenu item value on the specified line
void optionmenu_print_item_value(struct window *win, struct optionmenuitem *omi,ULO activeentry,ULO valx,ULO y) {
  if (activeentry) {
    switch (omi->type) {
      case 0:
               plot_text_window_reverse(win,omi->options.optiontext[omi->options.activeoption],valx,y);
               break;
      case 1:  plot_text_window_reverse(win,omi->stringvalue,valx,y);
               break;
    }
  } 
  else {
    switch (omi->type) {
      case 0:
               plot_text_window(win,omi->options.optiontext[omi->options.activeoption],valx,y);
               break;
      case 1:  plot_text_window(win,omi->stringvalue,valx,y);
               break;
    }
  } 
}   

// Handles selection of an optionitem
void optionmenu_selection(struct optionmenuitem *omi) {
  // Test type of item
       switch (omi->type) {
       case 0:
                omi->options.activeoption++;
                if (omi->options.activeoption >= omi->options.numberofentries) 
		  omi->options.activeoption = 0;
                *(omi->intvalue) = omi->options.optionvalues[omi->options.activeoption];
		break;
       case 1:  
                config_print_enterdisk_requester();
                init_string_field(&config_enterdiskstringfield,&config_enterdisk_requester,1,3);
                enter_text(&config_enterdiskstringfield);
                strcpy(omi->stringvalue,config_enterdiskstringfield.value);
		break;
       }
}


// Prints the optionmenu item on the specified line
void optionmenu_print_item(struct window *win, struct optionmenuitem *omi,ULO activeentry,ULO valx,ULO y) {
  if (activeentry) {
    plot_text_window_reverse(win,omi->text,0,y);
    optionmenu_print_item_value(win,omi,activeentry,valx,y);
  }
  else {
    plot_text_window(win,omi->text,0,y);
    optionmenu_print_item_value(win,omi,activeentry,valx,y);
  }
}

// Prints the optionmenu in the associated window
void optionmenu_print(struct optionmenu *m) {
  ULO i;

  for (i = 0; i < m->numberofentries; i++) {
    optionmenu_print_item(m->menuwindow,&(m->items[i]),(m->activeentry == i) ? 1:0,m->optionpos,i);
    }
}

// Waits for a selection and returns the entry position
void optionmenu_select(struct optionmenu *m)
{
  int c,finished = 0;

  while (finished == 0) {
    c = getch();

    if (c == 27) finished = 1;
    else if (c == 32 || c == 13) {  // Return pressed = selection

      optionmenu_selection(&(m->items[m->activeentry]));
      clear_window(m->menuwindow);
      optionmenu_print(m);
      }
    else if (c == 0) {
      c = getch();
      if (c == 72) { // UP
        if (m->activeentry > 0) {
          m->activeentry--;
          clear_window(m->menuwindow);
          optionmenu_print(m);
          }
        }
      else if (c == 80) { // DOWN
        if (m->activeentry < (m->numberofentries-1)) {
          m->activeentry++;
          clear_window(m->menuwindow);
          optionmenu_print(m);
          }
        }
      }
    }
}









