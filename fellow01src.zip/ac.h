/* Petter Schau 1996 */
/* Functions and variables exported from ac.c */

extern char filename[];
extern int startpos,jmppos;
