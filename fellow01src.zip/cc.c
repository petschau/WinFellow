#include "defs.h"
#include "io.h"
#include "68.h"
#include "mem.h"

// Petter Schau 1996

extern ULO oddscroll,evenscroll;

extern void blittergeneral(void);
extern void blitter_00(void);
extern void blitter_01(void);
extern void blitter_02(void);
extern void blitter_03(void);
extern void blitter_04(void);
extern void blitter_05(void);
extern void blitter_06(void);
extern void blitter_07(void);
extern void blitter_08(void);
extern void blitter_09(void);
extern void blitter_0a(void);
extern void blitter_0b(void);
extern void blitter_0c(void);
extern void blitter_0d(void);
extern void blitter_0e(void);
extern void blitter_0f(void);
extern void blitter_2a(void);
extern void blitter_4a(void);
extern void blitter_ca(void);
extern void blitter_d8(void);
extern void blitter_ea(void);
extern void blitter_f0(void);
extern void blitter_fa(void);
extern void blitter_fc(void);
extern void blitter_ff(void);


ULO nxtcopaccess;

extern ULO readroutine;
extern ULO drawprepareroutine;

/* bpdmatab1 er en jump tabell til dekodingsrutiner basert p� de 4 �verste
   bits av BPLCON0 */

UBY lineflagstimes[314];

/* shadcol er 32K utgaver av farge-registrene, ligger lagret dobbelt for
   at det enkelt skal g� � plotte lores i full bredde
   Oppdateres hver gang det skrives til et farge-register  */

extern ULO shadcol[64];

/*  Used in translation of sprites 
    syntax: spritetranslate[0 - behind, 1 - front][bitplanedata][spritedata]
*/

UBY spritetranslate[2][256][256];

/* Used in translation of dual playfield
   syntax: dualtranslate[0 - PF1 behind, 1 - PF2 behind][PF1data][PF2data]
*/

UBY dualtranslate[2][256][256];

/* Used to select the minterm routines */

ULO blittertable[256] = {
// 0
   (ULO) blitter_00,
   (ULO) blitter_01,
   (ULO) blitter_02,
   (ULO) blitter_03,
   (ULO) blitter_04,
   (ULO) blitter_05,
   (ULO) blitter_06,
   (ULO) blitter_07,
   (ULO) blitter_08,
   (ULO) blitter_09,
   (ULO) blitter_0a,
   (ULO) blitter_0b,
   (ULO) blitter_0c,
   (ULO) blitter_0d,
   (ULO) blitter_0e,
   (ULO) blitter_0f,
// 0x10
   (ULO) blittergeneral,
   (ULO) blittergeneral,
   (ULO) blittergeneral,
   (ULO) blittergeneral,
   (ULO) blittergeneral,
   (ULO) blittergeneral,
   (ULO) blittergeneral,
   (ULO) blittergeneral,
   (ULO) blittergeneral,
   (ULO) blittergeneral,
   (ULO) blittergeneral,
   (ULO) blittergeneral,
   (ULO) blittergeneral,
   (ULO) blittergeneral,
   (ULO) blittergeneral,
   (ULO) blittergeneral,
// 0x20
   (ULO) blittergeneral,
   (ULO) blittergeneral,
   (ULO) blittergeneral,
   (ULO) blittergeneral,
   (ULO) blittergeneral,
   (ULO) blittergeneral,
   (ULO) blittergeneral,
   (ULO) blittergeneral,
   (ULO) blittergeneral,
   (ULO) blittergeneral,

   (ULO) blitter_2a,

   (ULO) blittergeneral,
   (ULO) blittergeneral,
   (ULO) blittergeneral,
   (ULO) blittergeneral,
   (ULO) blittergeneral,
// 0x30
   (ULO) blittergeneral,
   (ULO) blittergeneral,
   (ULO) blittergeneral,
   (ULO) blittergeneral,
   (ULO) blittergeneral,
   (ULO) blittergeneral,
   (ULO) blittergeneral,
   (ULO) blittergeneral,
   (ULO) blittergeneral,
   (ULO) blittergeneral,
   (ULO) blittergeneral,
   (ULO) blittergeneral,
   (ULO) blittergeneral,
   (ULO) blittergeneral,
   (ULO) blittergeneral,
   (ULO) blittergeneral,
// 0x40
   (ULO) blittergeneral,
   (ULO) blittergeneral,
   (ULO) blittergeneral,
   (ULO) blittergeneral,
   (ULO) blittergeneral,
   (ULO) blittergeneral,
   (ULO) blittergeneral,
   (ULO) blittergeneral,
   (ULO) blittergeneral,
   (ULO) blittergeneral,
   (ULO) blitter_4a,
   (ULO) blittergeneral,
   (ULO) blittergeneral,
   (ULO) blittergeneral,
   (ULO) blittergeneral,
   (ULO) blittergeneral,
// 0x50
   (ULO) blittergeneral,
   (ULO) blittergeneral,
   (ULO) blittergeneral,
   (ULO) blittergeneral,
   (ULO) blittergeneral,
   (ULO) blittergeneral,
   (ULO) blittergeneral,
   (ULO) blittergeneral,
   (ULO) blittergeneral,
   (ULO) blittergeneral,
   (ULO) blittergeneral,
   (ULO) blittergeneral,
   (ULO) blittergeneral,
   (ULO) blittergeneral,
   (ULO) blittergeneral,
   (ULO) blittergeneral,
// 0x60
   (ULO) blittergeneral,
   (ULO) blittergeneral,
   (ULO) blittergeneral,
   (ULO) blittergeneral,
   (ULO) blittergeneral,
   (ULO) blittergeneral,
   (ULO) blittergeneral,
   (ULO) blittergeneral,
   (ULO) blittergeneral,
   (ULO) blittergeneral,
   (ULO) blittergeneral,
   (ULO) blittergeneral,
   (ULO) blittergeneral,
   (ULO) blittergeneral,
   (ULO) blittergeneral,
   (ULO) blittergeneral,
// 0x70
   (ULO) blittergeneral,
   (ULO) blittergeneral,
   (ULO) blittergeneral,
   (ULO) blittergeneral,
   (ULO) blittergeneral,
   (ULO) blittergeneral,
   (ULO) blittergeneral,
   (ULO) blittergeneral,
   (ULO) blittergeneral,
   (ULO) blittergeneral,
   (ULO) blittergeneral,
   (ULO) blittergeneral,
   (ULO) blittergeneral,
   (ULO) blittergeneral,
   (ULO) blittergeneral,
   (ULO) blittergeneral,
// 0x80
   (ULO) blittergeneral,
   (ULO) blittergeneral,
   (ULO) blittergeneral,
   (ULO) blittergeneral,
   (ULO) blittergeneral,
   (ULO) blittergeneral,
   (ULO) blittergeneral,
   (ULO) blittergeneral,
   (ULO) blittergeneral,
   (ULO) blittergeneral,
   (ULO) blittergeneral,
   (ULO) blittergeneral,
   (ULO) blittergeneral,
   (ULO) blittergeneral,
   (ULO) blittergeneral,
   (ULO) blittergeneral,
// 0x90
   (ULO) blittergeneral,
   (ULO) blittergeneral,
   (ULO) blittergeneral,
   (ULO) blittergeneral,
   (ULO) blittergeneral,
   (ULO) blittergeneral,
   (ULO) blittergeneral,
   (ULO) blittergeneral,
   (ULO) blittergeneral,
   (ULO) blittergeneral,
   (ULO) blittergeneral,
   (ULO) blittergeneral,
   (ULO) blittergeneral,
   (ULO) blittergeneral,
   (ULO) blittergeneral,
   (ULO) blittergeneral,
// 0xa0
   (ULO) blittergeneral,
   (ULO) blittergeneral,
   (ULO) blittergeneral,
   (ULO) blittergeneral,
   (ULO) blittergeneral,
   (ULO) blittergeneral,
   (ULO) blittergeneral,
   (ULO) blittergeneral,
   (ULO) blittergeneral,
   (ULO) blittergeneral,
   (ULO) blittergeneral,
   (ULO) blittergeneral,
   (ULO) blittergeneral,
   (ULO) blittergeneral,
   (ULO) blittergeneral,
   (ULO) blittergeneral,
// 0xb0
   (ULO) blittergeneral,
   (ULO) blittergeneral,
   (ULO) blittergeneral,
   (ULO) blittergeneral,
   (ULO) blittergeneral,
   (ULO) blittergeneral,
   (ULO) blittergeneral,
   (ULO) blittergeneral,
   (ULO) blittergeneral,
   (ULO) blittergeneral,
   (ULO) blittergeneral,
   (ULO) blittergeneral,
   (ULO) blittergeneral,
   (ULO) blittergeneral,
   (ULO) blittergeneral,
   (ULO) blittergeneral,
// 0xc0
   (ULO) blittergeneral,
   (ULO) blittergeneral,
   (ULO) blittergeneral,
   (ULO) blittergeneral,
   (ULO) blittergeneral,
   (ULO) blittergeneral,
   (ULO) blittergeneral,
   (ULO) blittergeneral,
   (ULO) blittergeneral,
   (ULO) blittergeneral,
   (ULO) blitter_ca,
   (ULO) blittergeneral,
   (ULO) blittergeneral,
   (ULO) blittergeneral,
   (ULO) blittergeneral,
   (ULO) blittergeneral,
// 0xd0
   (ULO) blittergeneral,
   (ULO) blittergeneral,
   (ULO) blittergeneral,
   (ULO) blittergeneral,
   (ULO) blittergeneral,
   (ULO) blittergeneral,
   (ULO) blittergeneral,
   (ULO) blittergeneral,
   (ULO) blitter_d8,
   (ULO) blittergeneral,
   (ULO) blittergeneral,
   (ULO) blittergeneral,
   (ULO) blittergeneral,
   (ULO) blittergeneral,
   (ULO) blittergeneral,
   (ULO) blittergeneral,
// 0xe0
   (ULO) blittergeneral,
   (ULO) blittergeneral,
   (ULO) blittergeneral,
   (ULO) blittergeneral,
   (ULO) blittergeneral,
   (ULO) blittergeneral,
   (ULO) blittergeneral,
   (ULO) blittergeneral,
   (ULO) blittergeneral,
   (ULO) blittergeneral,
   (ULO) blitter_ea,
   (ULO) blittergeneral,
   (ULO) blittergeneral,
   (ULO) blittergeneral,
   (ULO) blittergeneral,
   (ULO) blittergeneral,
// 0xf0
   (ULO) blitter_f0,
   (ULO) blittergeneral,
   (ULO) blittergeneral,
   (ULO) blittergeneral,
   (ULO) blittergeneral,
   (ULO) blittergeneral,
   (ULO) blittergeneral,
   (ULO) blittergeneral,
   (ULO) blittergeneral,
   (ULO) blittergeneral,
   (ULO) blitter_fa,
   (ULO) blittergeneral,
   (ULO) blitter_fc,
   (ULO) blittergeneral,
   (ULO) blittergeneral,
   (ULO) blitter_ff};

UWO fillincfc0[65536];
UWO fillincfc1[65536];

UBY fillincfc0after[65536];
UBY fillincfc1after[65536];

UWO fillexcfc0[65536];
UWO fillexcfc1[65536];

UBY fillexcfc0after[65536];
UBY fillexcfc1after[65536];




ULO drawptr;
ULO teller;
ULO delay;

ULO curcopptr;
ULO curcycle;

ULO showbuffer = 0,drawbuffer = 1;



UBY curcol[18];

UBY deco1[256][8];
UBY deco2[256][8];
UBY deco3[256][8];
UBY deco4[256][8];
UBY deco5[256][8];
UBY deco6[256][8];

UBY decosc01[256][8];
UBY decosc11[256][8];
UBY decosc21[256][8];
UBY decosc31[256][8];
UBY decosc02[256][8];
UBY decosc12[256][8];
UBY decosc22[256][8];
UBY decosc32[256][8];
UBY decosc03[256][8];
UBY decosc04[256][8];


ULO playfieldon;


UBY linje[1000];  // Needs to be 960 pixels long
UBY linje2[1000];  // Needs to be 960 pixels long
UBY sprite[8][16];
ULO spritesonline;
ULO spriteonline[8];


void init_spritetranslation_table(void) {
    int i,j,k,l;

    for (k = 0; k < 2; k++) {
        for (i = 0; i < 256; i++) {
            for (j = 0; j < 256; j++) {
                if (k == 0)
                    l = (i == 0) ? j:i;
                else
                    l = (j == 0) ? i:j;
                spritetranslate[k][i][j] = l;
                }
            }
        }
}
void init_dualtranslation_table(void) {
    int i,j,k,l;

    for (k = 0; k < 2; k++) {
        for (i = 0; i < 256; i++) {
            for (j = 0; j < 256; j++) {
                if (k == 0) {
                    /* PF1 behind, PF2 in front */
                    if (j == 0) {
                        /* PF2 transparent, PF1 visible */
                        l = i;
                    }
                    else {
                        /* PF2 visible */
                        /* If color is higher than 0x3c it is a sprite */
                        if (j < 0x40) l = j+0x20;
                        else l = j;
                    }
                }
                else {
                    /* PF1 in front, PF2 behind */
                    if (i == 0) {
                        /* PF1 transparent, PF2 visible */
                        if (j == 0) l = 0;
                        else {
                            if (j < 0x40) l = j+0x20;
                            else l = j;
                        }
                    }
                    else {
                        /* PF1 visible amd not transparent */
                        l = i;
                    }
                }
                dualtranslate[k][i][j] = l;
                }
            }
        }
}


void set_displaybuffer(void) {
 if (showbuffer == 0) VBE_setDisplayStart(0,0,0);
 else VBE_setDisplayStart(0,300,0);
}


ULO copperytable[512];

void init_copperytable(void) {
  int i;

   for (i=0; i < 512; i++) {
     copperytable[i] = i*228 + 16;
     }
}

/* Initialiserer variable */

void initfilltable(void)
{
  int i,j,k,l;

/* inclusive fill, fc = 0 at start of word */
  for (i = 0; i< 65536; i++) {
    l = 0;
    j = i;
    for (k = 0; k < 16; k++) {
      j |= l<<k;                 /* Set fill for this bit */
/* Check if fill status has changed */
      if ((i & (0x1<<k))) {
        if (l == 1) l = 0; else l = 1;
        }
      }
    fillincfc0[i] = j;
    fillincfc0after[i] = l;
    }

/* inclusive fill, fc = 1 at start of word */
  for (i = 0; i< 65536; i++) {
    l = 1;
    j = i;
    for (k = 0; k < 16; k++) {
      j |= l<<k;                 /* Set fill for this bit */
/* Check if fill status has changed */
      if ((i & (0x1<<k))) {
        if (l == 1) l = 0; else l = 1;
        }
      }
    fillincfc1[i] = j;
    fillincfc1after[i] = l;
    }

/* exclusive fill, fc = 0 at start of word */
  for (i = 0; i< 65536; i++) {
    l = 0;
    j = i;
    for (k = 0; k < 16; k++) {
      j ^= l<<k;                 /* Set fill for this bit */
/* Check if fill status has changed */
      if ((i & (0x1<<k))) {
        if (l == 1) l = 0; else l = 1;
        }
      }
    fillexcfc0[i] = j;
    fillexcfc0after[i] = l;
    }

/* exclusive fill, fc = 1 at start of word */
  for (i = 0; i< 65536; i++) {
    l = 1;
    j = i;
    for (k = 0; k < 16; k++) {
      j ^= l<<k;                 /* Set fill for this bit */
/* Check if fill status has changed */
      if ((i & (0x1<<k))) {
        if (l == 1) l = 0; else l = 1;
        }
      }
    fillexcfc1[i] = j;
    fillexcfc1after[i] = l;
    }
}


void init_lineflagstables(void) {
  ULO i;

  for (i = 0; i < 314; i++) {
    lineflags[i] = 0xffffffff;
    lineflagstimes[i] = 2;
    }
}



void chipinit(void)
{
  ULO i,j;

  for (i=0; i< 1000; i++) linje[i] = 0;

  xpos = 0;
  ypos = 0 ;

  for(i=0;i<256;i++) 
    for(j=0;j<8;j++) {
      deco1[i][j] =  (i&(0x80>>j)) == 0 ? 0:0x4;
      deco2[i][j] =  (i&(0x80>>j)) == 0 ? 0:0x8;
      deco3[i][j] = (i&(0x80>>j)) == 0 ? 0:0x10;
      deco4[i][j] =  (i&(0x80>>j)) == 0 ? 0:0x20;
      deco5[i][j] =  (i&(0x80>>j)) == 0 ? 0:0x40;
      deco6[i][j] =  (i&(0x80>>j)) == 0 ? 0:0x80;
      }

  for(i=0;i<256;i++) 
    for(j=0;j<8;j++) {
      decosc01[i][j] =  (i&(0x80>>j)) == 0 ? 0:0x44;
      decosc02[i][j] =  (i&(0x80>>j)) == 0 ? 0:0x48;
      decosc03[i][j] =  (i&(0x80>>j)) == 0 ? 0:0x50;
      decosc04[i][j] =  (i&(0x80>>j)) == 0 ? 0:0x60;
      decosc11[i][j] =  (i&(0x80>>j)) == 0 ? 0:0x54;
      decosc12[i][j] =  (i&(0x80>>j)) == 0 ? 0:0x58;
      decosc21[i][j] =  (i&(0x80>>j)) == 0 ? 0:0x64;
      decosc22[i][j] =  (i&(0x80>>j)) == 0 ? 0:0x68;
      decosc31[i][j] =  (i&(0x80>>j)) == 0 ? 0:0x74;
      decosc32[i][j] =  (i&(0x80>>j)) == 0 ? 0:0x78;
      }


  initfilltable();
  init_copperytable();
  init_spritetranslation_table();
  init_dualtranslation_table();

  playfieldon = 0;
}
