extern void sbinit(void);
extern ULO dmaflataddr;
extern ULO dmapage;
