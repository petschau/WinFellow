/*
   Has keyboard handlers and keybuffer.

   C - part of the screen routines for the interface
       Not used in actual emulator code

   Routines meant to be used outside this file is:

   Init the screen and VESA drivers
   --------------------------------
   void screeninit(void)

   Close the screen and return to the old screenmode
   -------------------------------------------------
   void screenclose(void)

   Clear the lines from top to bot inclusive
   -------------------------------------------
   void clear(ULO top, ULO bot)

   Available variables is:
   -----------------------
   char *framebuffer;


*/

#define DPMI32

#include <dos.h>
#include <stdio.h>
#include "defs.h"
#include "vesavbe.h"
#include "mem.h"
#include "pmpro.h"

extern FILE *LOG;

extern ULO pot0dat;

// Keyboard buffer
// ---------------

extern ULO debugging;

// If you overrun this buffer, you're on your own.....

UBY keybuffer[512];
ULO keybufferconsumepos, keytimetowait, keybufferproducepos;

// PC scancodes to Amiga scancodes
UBY keytranslationtable[89] = {
  0xff,   // 0 - no key
  0x45,   // 1 - ESC, same on amiga 
  0x01,   // 2 - "1", same on amiga 
  0x02,   // 3 - "2", same on amiga 
  0x03,   // 4 - "3", same on amiga 
  0x04,   // 5 - "4", same on amiga 
  0x05,   // 6 - "5", same on amiga 
  0x06,   // 7 - "6", same on amiga 
  0x07,   // 8 - "7", same on amiga 
  0x08,   // 9 - "8", same on amiga 
  0x09,   // 10 - "9", same on amiga 
  0x0A,   // 11 - "0", same on amiga 
  0x0B,   // 12 - "+", same on amiga 
  0x0C,   // 13 - backslash, same on amiga 
  0x41,   // 14 - "Backspace", same on amiga 
  0x42,   // 15 - "Tab", same on amiga 
  0x10,   // 16 - "q", same on amiga 
  0x11,   // 17 - "w", same on amiga 
  0x12,   // 18 - "e", same on amiga 
  0x13,   // 19 - "r", same on amiga 
  0x14,   // 20 - "t", same on amiga 
  0x15,   // 21 - "y", same on amiga 
  0x16,   // 22 - "u", same on amiga 
  0x17,   // 23 - "i", same on amiga 
  0x18,   // 24 - "o", same on amiga 
  0x19,   // 25 - "p", same on amiga 
  0x1a,   // 26 - "�", same on amiga 
  0x1b,   // 27 - "�", same on amiga 
  0x44,   // 28 - "Ret", same on amiga 
  0x63,   // 29 - "Ctrl", same on amiga, but not same physical position 
  0x20,   // 30 - "a", same on amiga 
  0x21,   // 31 - "s", same on amiga 
  0x22,   // 32 - "d", same on amiga 
  0x23,   // 33 - "f", same on amiga 
  0x24,   // 34 - "g", same on amiga 
  0x25,   // 35 - "h", same on amiga 
  0x26,   // 36 - "j", same on amiga 
  0x27,   // 37 - "k", same on amiga 
  0x28,   // 38 - "l", same on amiga 
  0x29,   // 39 - "�", same on amiga 
  0x2a,   // 40 - "�", same on amiga 
  0x00,   // 41 - "|", same on amiga
  0x60,   // 42 - "LShift", same on amiga
  0x43,   // 43 - "*", maps to missing second right key in number row
  0x31,   // 44 - "z", same on amiga
  0x32,   // 45 - "x", same on amiga
  0x33,   // 46 - "c", same on amiga
  0x34,   // 47 - "v", same on amiga
  0x35,   // 48 - "b", same on amiga
  0x36,   // 49 - "n", same on amiga
  0x37,   // 50 - "m", same on amiga
  0x38,   // 51 - ",", same on amiga
  0x39,   // 52 - ".", same on amiga
  0x3a,   // 53 - "-", same on amiga, on PC, also / on keypad
  0x61,   // 54 - "RShift", same on amiga
  0xff,   // 55 - "*" on keypad, no key to map to on amiga
  0x64,   // 56 - "Both Alts", to the left alt on amiga
  0x40,   // 57 - "Space", same on amiga
  0x62,   // 58 - "Caps", same on amiga
  0x50,   // 59 - "F1", same on amiga
  0x51,   // 60 - "F2", same on amiga
  0x52,   // 61 - "F3", same on amiga
  0x53,   // 62 - "F4", same on amiga
  0x54,   // 63 - "F5", same on amiga
  0x55,   // 64 - "F6", same on amiga
  0x56,   // 65 - "F7", same on amiga
  0x57,   // 66 - "F8", same on amiga
  0x58,   // 67 - "F9", same on amiga
  0x59,   // 68 - "F10", same on amiga
  0xff,   // 69 - "NumLock", no key on amiga
  0xff,   // 70 - "Scroll Lock", no key on amiga
  0xff,   // 71 - "Home" and "7" on keypad, no key on amiga
  0x4c,   // 72 - "Arrow up" and "8" on keypad, Arrow up on amiga
  0xff,   // 73 - "Page up" and "9" on keypad, No key on amiga
  0xff,   // 74 - "-" on keypad, No key on amiga
  0x4f,   // 75 - "Arrow Left" and "4" on keypad, Arrow left on amiga
  0xff,   // 76 - "5" on keypad, No key on amiga
  0x4e,   // 77 - "Arrow right" and "6" on keypad, Arrow right on amiga
  0xff,   // 78 - "+" on keypad, No key on amiga
  0xff,   // 79 - "End" and "1" on keypad, No key on amiga
  0x4d,   // 80 - "Arrow Down" and "2" on keypad, Arrow down on amiga
  0xff,   // 81 - "Page down" and "3" on keypad, No key on amiga
  0xff,   // 82 - "Ins" and "0" on keypad, No key on amiga
  0x46,   // 83 - "Del" and "." on keypad, Delete on amiga
  0xff,   // 84 - No key
  0xff,   // 85 - No key
  0xff,   // 86 - No key
  0xff,   // 87 - F11, no key on amiga (firebutton)
  0xff   // 88 - F12, no key on amiga
  };

ULO f12pressed;

// Mouse data

ULO leftbutton;
ULO rightbutton;
ULO mousex;
ULO mousey;

// Joystickdata

ULO firebutton;
ULO joyleft;
ULO joyright;
ULO joyup;
ULO joydown;
ULO emulate_joystick;

// Pointer to the framebuffer
// It is a linear address in linear mode,
// else it is a pointer into the current bank
// --------------------------

UWO *framebuffer;
ULO currentbank;
ULO scanlineadd;

// Pointer to the 32bit bacnkswitch routine
// ----------------------------------------
ULO bankswitcher;

// Struct to hold window data
// --------------------------
struct window {
  ULO x1,y1,x2,y2;
  UWO fgcolor;
  UWO bgcolor;
};

// Struct to hold number field data
// --------------------------------
struct numberfield {
  ULO x,y;
  ULO value;
  struct window *hostwindow;
};

// Struct to hold string field data
// --------------------------------
struct stringfield {
  ULO x,y;
  char value[120];
  struct window *hostwindow;
};



ULO buffer2offset;


// Font to be used 8x8 characters
// ------------------------------

UBY font[128][8] = {
0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,  // Space
0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,  // Space
0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,  // Space
0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,  // Space
0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,  // Space
0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,  // Space
0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,  // Space
0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,  // Space
0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,  // Space
0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,  // Space
0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,  // Space
0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,  // Space
0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,  // Space
0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,  // Space
0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,  // Space
0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,  // Space
0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,  // Space
0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,  // Space
0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,  // Space
0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,  // Space
0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,  // Space
0x00,0x00,0xff,0xff,0xff,0xff,0x00,0x00,  // 11 border characters
0x3c,0x3c,0x3c,0x3c,0x3c,0x3c,0x3c,0x3c,  // 
0x3c,0x3c,0xff,0xff,0xff,0xff,0x3c,0x3c,  // 
0x3c,0x3c,0x3f,0x3f,0x3f,0x3f,0x3c,0x3c,  // 
0x3c,0x3c,0xff,0xff,0xff,0xff,0x00,0x00,  // 
0x3c,0x3c,0xfc,0xfc,0xfc,0xfc,0x3c,0x3c,  // 
0x00,0x00,0xff,0xff,0xff,0xff,0x3c,0x3c,  // 
0x3c,0x3c,0x3f,0x3f,0x3f,0x3f,0x00,0x00,  // 
0x3c,0x3c,0xfc,0xfc,0xfc,0xfc,0x00,0x00,  // 
0x00,0x00,0xfc,0xfc,0xfc,0xfc,0x3c,0x3c,  // 
0x00,0x00,0x3f,0x3f,0x3f,0x3f,0x3c,0x3c,  // 

0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,  // Space
0x18,0x18,0x18,0x18,0x00,0x00,0x18,0x00,  // !
0x66,0x66,0x66,0x00,0x00,0x00,0x00,0x00,  // "
0x66,0x66,0xFF,0x66,0xFF,0x66,0x66,0x00,  // #
0x18,0x3E,0x60,0x3C,0x06,0x7C,0x18,0x00,  // $
0x62,0x66,0x0C,0x18,0x30,0x66,0x46,0x00,  // %
0x3C,0x66,0x3C,0x38,0x67,0x66,0x3F,0x00,  // &
0x06,0x0C,0x18,0x00,0x00,0x00,0x00,0x00,  // '
0x0C,0x18,0x30,0x30,0x30,0x18,0x0C,0x00,  // (
0x30,0x18,0x0C,0x0C,0x0C,0x18,0x30,0x00,  // )
0x00,0x66,0x3C,0xFF,0x3C,0x66,0x00,0x00,  // *
0x00,0x18,0x18,0x7E,0x18,0x18,0x00,0x00,  // +
0x00,0x00,0x00,0x00,0x00,0x18,0x18,0x30,  // ,
0x00,0x00,0x00,0x7E,0x00,0x00,0x00,0x00,  // -
0x00,0x00,0x00,0x00,0x00,0x18,0x18,0x00,  // .
0x00,0x03,0x06,0x0C,0x18,0x30,0x60,0x00,  // /
0x3C,0x66,0x6E,0x76,0x66,0x66,0x3C,0x00,  // 0
0x18,0x18,0x38,0x18,0x18,0x18,0x7E,0x00,  // 1
0x3C,0x66,0x06,0x0C,0x30,0x60,0x7E,0x00,  // 2
0x3C,0x66,0x06,0x1C,0x06,0x66,0x3C,0x00,  // 3
0x06,0x0E,0x1E,0x66,0x7F,0x06,0x06,0x00,  // 4
0x7E,0x60,0x7C,0x06,0x06,0x66,0x3C,0x00,  // 5
0x3C,0x66,0x60,0x7C,0x66,0x66,0x3C,0x00,  // 6
0x7E,0x66,0x0C,0x18,0x18,0x18,0x18,0x00,  // 7
0x3C,0x66,0x66,0x3C,0x66,0x66,0x3C,0x00,  // 8
0x3C,0x66,0x66,0x3E,0x06,0x66,0x3C,0x00,  // 9
0x00,0x00,0x18,0x00,0x00,0x18,0x00,0x00,  // :
0x00,0x00,0x18,0x00,0x00,0x18,0x18,0x30,  // ;
0x0E,0x18,0x30,0x60,0x30,0x18,0x0E,0x00,  // <
0x00,0x00,0x7E,0x00,0x7E,0x00,0x00,0x00,  // =
0x70,0x18,0x0C,0x06,0x0C,0x18,0x70,0x00,  // >
0x3C,0x66,0x06,0x0C,0x18,0x00,0x18,0x00,  // ?
0x3C,0x66,0x6E,0x6E,0x60,0x62,0x3C,0x00,  // @
0x18,0x3C,0x66,0x7E,0x66,0x66,0x66,0x00,  // A
0x7C,0x66,0x66,0x7C,0x66,0x66,0x7C,0x00,  // B
0x3C,0x66,0x60,0x60,0x60,0x66,0x3C,0x00,  // C
0x78,0x6C,0x66,0x66,0x66,0x6C,0x78,0x00,  // D
0x7E,0x60,0x60,0x78,0x60,0x60,0x7E,0x00,  // E
0x7E,0x60,0x60,0x78,0x60,0x60,0x60,0x00,  // F
0x3C,0x66,0x60,0x6E,0x66,0x66,0x3C,0x00,  // G
0x66,0x66,0x66,0x7E,0x66,0x66,0x66,0x00,  // H
0x3C,0x18,0x18,0x18,0x18,0x18,0x3C,0x00,  // I
0x1E,0x0C,0x0C,0x0C,0x0C,0x6C,0x38,0x00,  // J
0x66,0x6C,0x78,0x70,0x78,0x6C,0x66,0x00,  // K
0x60,0x60,0x60,0x60,0x60,0x60,0x7E,0x00,  // L
0x63,0x77,0x7F,0x6B,0x63,0x63,0x63,0x00,  // M
0x66,0x76,0x7E,0x7E,0x6E,0x66,0x66,0x00,  // N
0x3C,0x66,0x66,0x66,0x66,0x66,0x3C,0x00,  // O
0x7C,0x66,0x66,0x7C,0x60,0x60,0x60,0x00,  // P
0x3C,0x66,0x66,0x66,0x66,0x3C,0x0E,0x00,  // Q
0x7C,0x66,0x66,0x7C,0x78,0x6C,0x66,0x00,  // R
0x3C,0x66,0x60,0x3C,0x06,0x66,0x3C,0x00,  // S
0x7E,0x18,0x18,0x18,0x18,0x18,0x18,0x00,  // T
0x66,0x66,0x66,0x66,0x66,0x66,0x3C,0x00,  // U
0x66,0x66,0x66,0x66,0x66,0x3C,0x18,0x00,  // V
0x63,0x63,0x63,0x6B,0x7F,0x77,0x63,0x00,  // W
0x66,0x66,0x3C,0x18,0x3C,0x66,0x66,0x00,  // X
0x66,0x66,0x66,0x3C,0x18,0x18,0x18,0x00,  // Y
0x7E,0x06,0x0C,0x18,0x30,0x60,0x7E,0x00,  // Z
0x3C,0x30,0x30,0x30,0x30,0x30,0x3C,0x00,  // [
0xc0,0x60,0x30,0x18,0x0c,0x06,0x03,0x00,  // 
0x3C,0x0C,0x0C,0x0C,0x0C,0x0C,0x3C,0x00,  // ]
0x00,0x18,0x3C,0x7E,0x18,0x18,0x18,0x18,  // Pil opp
0x00,0x10,0x30,0x7F,0x7F,0x30,0x10,0x00,  // Pil venstre

0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,  // Space

0x00,0x00,0x3C,0x06,0x3E,0x66,0x3E,0x00,  // a
0x00,0x60,0x60,0x7C,0x66,0x66,0x7C,0x00,  // b
0x00,0x00,0x3C,0x60,0x60,0x60,0x3C,0x00,  // c
0x00,0x06,0x06,0x3E,0x66,0x66,0x3E,0x00,  // d
0x00,0x00,0x3C,0x66,0x7E,0x60,0x3C,0x00,  // e
0x00,0x0E,0x18,0x3E,0x18,0x18,0x18,0x00,  // f
0x00,0x00,0x3E,0x66,0x66,0x3E,0x06,0x7C,  // g
0x00,0x60,0x60,0x7C,0x66,0x66,0x66,0x00,  // h
0x00,0x18,0x00,0x38,0x18,0x18,0x3C,0x00,  // i
0x00,0x06,0x00,0x06,0x06,0x06,0x06,0x3C,  // j
0x00,0x60,0x60,0x6C,0x78,0x6C,0x66,0x00,  // k
0x00,0x38,0x18,0x18,0x18,0x18,0x3C,0x00,  // l
0x00,0x00,0x66,0x7F,0x7F,0x6B,0x63,0x00,  // m
0x00,0x00,0x7C,0x66,0x66,0x66,0x66,0x00,  // n
0x00,0x00,0x3C,0x66,0x66,0x66,0x3C,0x00,  // o
0x00,0x00,0x7C,0x66,0x66,0x7C,0x60,0x60,  // p
0x00,0x00,0x3E,0x66,0x66,0x3E,0x06,0x06,  // q
0x00,0x00,0x7C,0x66,0x60,0x60,0x60,0x00,  // r
0x00,0x00,0x3E,0x60,0x3C,0x06,0x7C,0x00,  // s
0x00,0x18,0x7E,0x18,0x18,0x18,0x0E,0x00,  // t
0x00,0x00,0x66,0x66,0x66,0x66,0x3E,0x00,  // u
0x00,0x00,0x66,0x66,0x66,0x3C,0x18,0x00,  // v
0x00,0x00,0x63,0x6B,0x7F,0x3E,0x36,0x00,  // w
0x00,0x00,0x66,0x3C,0x18,0x3C,0x66,0x00,  // x
0x00,0x00,0x66,0x66,0x66,0x3E,0x0C,0x78,  // y
0x00,0x00,0x7E,0x0C,0x18,0x30,0x7E,0x00,  // z
0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,  // Space
0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,  // Space
0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,  // Space
0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,  // Space
0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00   // Space
};
  
// oldmode stores the screenmode present when the emulator was started
// screenclose() returns the screen to this mode
// -------------------------------------------------------------------

ULO oldmode;

// Variables and function provided for the VESA code
// -------------------------------------------------

uint             VESABuf_len = 1024;    /* Length of the VESABuf buffer         */
uint             VESABuf_sel = 0;    /* Selector for VESABuf                         */
uint             VESABuf_off;    /* Offset for VESABuf                           */
uint             VESABuf_rseg;   /* Real mode segment of VESABuf         */
uint             VESABuf_roff;   /* Real mode offset of VESABuf          */

// ===================================================
// Some routines grabbed from some VBE library I found
// ===================================================

static void ExitVBEBuf(void)
{ PM_freeRealSeg(VESABuf_sel,VESABuf_off); }

/****************************************************************************
*
* Function:             VBE_initRMBuf
*
* Description:  Initialises the VBE transfer buffer in real mode memory.
*                               This routine is called by the VESAVBE module every time
*                               it needs to use the transfer buffer, so we simply allocate
*                               it once and then return.
*
****************************************************************************/
void _PUBAPI VBE_initRMBuf(void)
{
	if (!VESABuf_sel) {
		/* Allocate a global buffer for communicating with the VESA VBE */
		if (!PM_allocRealSeg(VESABuf_len, &VESABuf_sel, &VESABuf_off,
				&VESABuf_rseg, &VESABuf_roff))
			exit(1);
		atexit(ExitVBEBuf);
		}
}


/**********************/
/* CODE FOR WINDOWING */
/**********************/


// Initialize window structure
// ---------------------------
void init_window(struct window *w,ULO x1,ULO y1,ULO x2,ULO y2,UWO fgcolor,UWO bgcolor) {
  int ypos,xpos;
  w->x1 = x1;
  w->y1 = y1;
  w->x2 = x2;
  w->y2 = y2;
  w->fgcolor = fgcolor;
  w->bgcolor = bgcolor;
}  

// Clear window
// --------------------------------------------
void clear_window(struct window *w) {
  ULO ypos,xpos;

  ypos = w->y1;
  while (ypos <= w->y2) {
    xpos = w->x1;
    while (xpos <= w->x2) {
      plot_char(' ',xpos,ypos,w->fgcolor,w->bgcolor);
      xpos++;
      }
    ypos++;
    }
}

void plot_text_window(struct window *w,char *s,ULO x,ULO y) {
  plot_text(s,x+w->x1,y+w->y1,w->fgcolor,w->bgcolor);
}

void plot_text_window_reverse(struct window *w,char *s,ULO x,ULO y) {
  plot_text(s,x+w->x1,y+w->y1,w->bgcolor,w->fgcolor);
}

void print_window_borders(struct window *w) {
  ULO i;
  plot_char(0x1f,w->x1-1,w->y1-1,w->fgcolor,w->bgcolor);
  plot_char(0x1c,w->x1-1,w->y2+1,w->fgcolor,w->bgcolor);
  plot_char(0x1d,w->x2+1,w->y2+1,w->fgcolor,w->bgcolor);
  plot_char(0x1e,w->x2+1,w->y1-1,w->fgcolor,w->bgcolor);
  for (i=w->x1; i <= w->x2; i++) plot_char(0x15,i,w->y1-1,w->fgcolor,w->bgcolor);
  for (i=w->x1; i <= w->x2; i++) plot_char(0x15,i,w->y2+1,w->fgcolor,w->bgcolor);
  for (i=w->y1; i <= w->y2; i++) plot_char(0x16,w->x1-1,i,w->fgcolor,w->bgcolor);
  for (i=w->y1; i <= w->y2; i++) plot_char(0x16,w->x2+1,i,w->fgcolor,w->bgcolor);
}

void init_number_field(struct numberfield *n,struct window *w,ULO v,ULO x,ULO y) {
  n->hostwindow = w;
  n->x = x;
  n->y = y;
  n->value = v;
}

void enter_number(struct numberfield *n) {
  char tall[10];
  ULO unchanged = 1, finished = 0,cursor = 0,c;
  sprintf(tall,"%X",n->value);
  plot_text_window(n->hostwindow,tall,n->x,n->y); 
  while (!finished) {
    c = getch();
    if (c == 13) { // RET
      finished = 1;
      }
    else if ((c >= '0' && c <= '9') || (c >= 'a' && c <= 'f')) { // NUMBER
      if (unchanged) {
        unchanged = 0;
        tall[0] = 0;
        plot_text_window(n->hostwindow,"        ",n->x,n->y);
        }
      if (cursor < 8) {
        tall[cursor++] = c;
        tall[cursor] = 0;
        }      
      plot_text_window(n->hostwindow,tall,n->x,n->y);
      }
    else if (c == 8) {  // DEL
      if (!unchanged) {
        if (cursor > 0) {
          tall[--cursor] = ' ';
          plot_text_window(n->hostwindow,tall,n->x,n->y);
          tall[cursor] = 0;
          }
        }
      }
    }
  sscanf(tall,"%X",&(n->value));
}

void init_string_field(struct stringfield *n,struct window *w,ULO x,ULO y) {
  n->hostwindow = w;
  n->x = x;
  n->y = y;
  n->value[0] = 0;
}


void enter_text(struct stringfield *n) {
  char text[100];
  ULO finished = 0,cursor = 0,c;
  text[0] = 0;
  while (!finished) {
    c = getch();
    if (c == 13) { // RET
      finished = 1;
      }
    else if (c >= 0x20) { // text
      if (cursor < 119) {
        text[cursor++] = c;
        text[cursor] = 0;
        }      
      plot_text_window(n->hostwindow,text,n->x,n->y);
      }
    else if (c == 0) getch();
    else if (c == 8) {  // DEL
        if (cursor > 0) {
          text[--cursor] = ' ';
          plot_text_window(n->hostwindow,text,n->x,n->y);
          text[cursor] = 0;
          }
      }
    }
  if (text[0] == 0) strcpy(n->value,"__none__");
  else strcpy(n->value,text);
}



// void plot_char(UBY character, ULO x, ULO y, UWO fgcolor, UWO bgcolor)
// Draws a character on the screen
// =====================================================================

void plot_char(UBY character, ULO x, ULO y, UWO fgcolor, UWO bgcolor)
{
  UWO *screenpointer=framebuffer;
  int i,j;  // Loop variables, must be signed
  UBY cdata;

  // Ignore plot request when x,y position is outside screen
  if (x <= 99 && y <= 74) {

    // Calculate bank and offset within bank

    screenpointer += x*8 + ((y*6400)+((y*8*scanlineadd)>>1));

    // Now plot character to screen

    for (i = 0; i < 8; i++) {
      cdata = font[character][i];
      for (j = 7; j >= 0; j--) {
        if (((cdata>>j) & 0x1) == 1) {  // Set point
          *screenpointer = fgcolor; 
          }
        else {                  // Clear point
          *screenpointer = bgcolor;
          }

        // Now check if we crossed a bank boundrary

        screenpointer++;
        }
      screenpointer += 792+(scanlineadd>>1);
      }
    }
}     

// 


// void plot_text(char *text,ULO x, ULO y, UWO fgcolor, UWO bgcolor) 
// Draws a string of text on the screen, string is \0 terminated
// =================================================================

char *txt;
ULO xx;
void plot_text(char *text,ULO x, ULO y, UWO fgcolor, UWO bgcolor) 
{
  txt = text;
  xx = x;  
  while (*txt != 0) {
    plot_char(*txt,xx,y,fgcolor,bgcolor);
    txt++;
    xx++;
    }
}

// Mouse handler

void PMAPI mymousehandler(uint event, uint butstate, uint x, uint y, uint mickeyX, uint mickeyY)
 {
   leftbutton = butstate & 0x1;
   if ((rightbutton == 0) && ((butstate & 0x2) == 0x2))
     pot0dat = (pot0dat + 0x100) & 0xffff; 
   rightbutton = (butstate & 0x2)>>1;
   joy0dat = ((mickeyX>>1)&0xff) | (((mickeyY>>1)&0xff)<<8);
   
}


// Keyboard routines
// -----------------

// Interrupt handler
// -----------------
// The scancodes I get here seem to be washed by the pmode library.
// I don't get proper scancodes for the keypad/arrowkeys etc.


// - Translate scancode to the corresponding amiga scancode
// - Check press and release bit
// - Add key to keybuffer
// - Set keytimetowait if buffer was empty
// - keytimetowait is horisontal blanks before key is transferred
//   to the CIA serial port.

static UBY tmpcode;

short PMAPI mykeyhandler(short scancode) {

   if (scancode == (88 | 0x80)) 
     debugging = f12pressed = 1; // F12 - exit to GUI
   if (scancode == 87) firebutton = 1;
   else if (scancode == (87 | 0x80)) firebutton = 0;

   if (emulate_joystick) {
     if (scancode == 72) {
       joyup = 1;
       return 0;
       }
     else if (scancode == 80) {
       joydown = 1;
       return 0;
       }
     else if (scancode == 77) {
       joyright = 1;
       return 0;
       }
     else if (scancode == 75) {
       joyleft = 1;
       return 0;
       }
     else if (scancode == (72|0x80)) {
       joyup = 0;
       return 0;
       }
     else if (scancode == (80|0x80)) {
       joydown = 0;
       return 0;
       }
     else if (scancode == (77|0x80)) {
       joyright = 0;
       return 0;
       }
     else if (scancode == (75|0x80)) {
       joyleft = 0;
       return 0;
       }
   }

   if ((scancode & 0x7f) >= 89)  
     return 0; // Illegal scancode, simply ignore

   tmpcode = keytranslationtable[scancode&0x7f];
   if (tmpcode == 0xff) 
     return 0;  // Scancode for nonmapped key

   // Here we've got a mapped scancode, set press/release bit

   tmpcode |= (scancode & 0x80);

   // Add scancode to end of keybuffer

   keybuffer[(keybufferproducepos) & 511] = tmpcode;
   keybufferproducepos++;

   return 0;
}

void init_mousekeyboard(void) {
  firebutton = 0;
  joyup = joydown = joyright = joyleft = 0;
  PM_setMouseHandler(0xff,mymousehandler);
  PM_setKey15Handler(mykeyhandler);
}

void restore_mousekeyboard(void) {
  PM_restoreKey15Handler();
  PM_restoreMouseHandler();
}

void reset_mousekeyboard(void) {
  keybufferconsumepos = 0;
  keytimetowait = 10;
  keybufferproducepos = 2;
  keybuffer[0] = 0xfd;
  keybuffer[1] = 0xfe;
  pot0dat = pot1dat = 0;
  leftbutton = 0;
  rightbutton = 0;
  f12pressed = 0;
  joyup = joydown = joyright = joyleft = 0;
  firebutton = 0;
}



ULO newbytes,newpixels,newmaxscans,dispx,dispy;

int setup_mode(int m,int linflag) {
  VBE_modeInfo mymodeinfo;


  fprintf(LOG,"Trying to set up %s mode %X\n",(linflag == 1) ? "linear":"banked",m);

  VBE_getModeInfo(m,&mymodeinfo);

  if (mymodeinfo.ModeAttributes & vbeMdAvailable) {
      fprintf(LOG,"Modeinfo block says mode %X is available\n",m);
          
      if (linflag) {
          if ((mymodeinfo.ModeAttributes & vbeMdLinear)) {
              fprintf(LOG,"Modeinfo block says linear framebuffer is available for mode %X\n",m);

              // Linear mode available, that's what we want, try to set it
              // ============================================================

              if (!(VBE_setVideoMode(m | 0x4000))) {
                  fprintf(LOG,"Linear mode %X is available, but setVideoMode failed!\n",m);
                  return 0;
                  }
              else {
                  // Here setVideoMode was successful
                  // Get linear address to framebuffer
                  if ((framebuffer = (UWO *) VBE_getLinearPointer(&mymodeinfo)) == NULL) {
                      fprintf(LOG,"setVideoMode %X successful, but VESA returned NULL for framebufferaddress\n",m);
                      // Here we have an invalid framebuffer address
                      // Restore old videomode 
                      if (!VBE_setVideoMode(oldmode)) {
                          // Restore of old videomode also failed
                          fprintf(LOG,"Failed to set old videomode, so something is terribly wrong!\n");
                          }
                      return 0;
                      }
                  else {

                      VBE_getDisplayStart(&dispx,&dispy);
                      fprintf(LOG,"Display start x %d\n",dispx);
                      fprintf(LOG,"Display start y %d\n",dispy);

                      if (dispx > 0) {
                          fprintf(LOG,"Display does not start on xposition 0, trying to fix that.\n");
                          framebuffer += dispx;
                          }
                      if (dispy > 0) {
                          fprintf(LOG,"Display does not start on xposition 0, trying to fix that.\n");
                          framebuffer += (dispy*800);
                          }
                      scanlineadd = 0;
                      if (VBE_getScanLineLength(&newbytes,&newpixels,&newmaxscans)) {
                          fprintf(LOG,"Bytes per line: %d\n",newbytes);
                          fprintf(LOG,"Pixels per line: %d\n",newpixels);
                          fprintf(LOG,"Scanlines: %d\n",newmaxscans);


                          if (newpixels > 800) {
                              fprintf(LOG,"Detected more than 800 pixels per line.\n");
                              fprintf(LOG,"Trying to fix that.\n");
                              scanlineadd = (newpixels-800)*2;
                              fprintf(LOG,"Adding %d bytes per line.\n",scanlineadd);
                              }
                          }
                       else fprintf(LOG,"getScanLineLength failed, ignored.\n");
                      // Got a linear framebuffer address return successfully
                      fprintf(LOG,"Linear mode %X successfully set, framebuffer is at %X\n",m,framebuffer);
                      return 1;
                      }
                  }
              }
          else {
              // Linear mode wanted but not available
              fprintf(LOG,"Linear mode %X requested, but linear mode %X not available\n",m,m);
              return 0;
              }
          }
    // Here mode is available, and banked mode is requested
    // ====================================================

    else {
      if (mymodeinfo.ModeAttributes & vbeMdNonBanked) {
        // The mode is non-banked, return failure
        fprintf(LOG,"Banked mode requested for mode %X, but Modeinfo block says mode is non-banked\n");
        return 0;
        }
      else {  // All is OK, set mode
        // Banked mode available, that's what we want, try to set it
        // ============================================================

        if (!(VBE_setVideoMode(m))) {
          // setVideoMode failed, return failure
          fprintf(LOG,"Banked mode %X is available, but setVideoMode failed!\n",m);
          return 0;
          }
        else {
          // Mode was set successfully
          // Do some initialization of the VBE library

	  // Init pm code for VBE, must be done after each modeset
         InitPMCode();

         // Now get pointer to the bankswitch routine

         bankswitcher = (ULO) VBE_getSetBank();
         if (bankswitcher == NULL) {
           // Bankswitch routine was NULL, return failure
           fprintf(LOG,"Banked mode %X set, but VESA getSetBank returned NULL, sorry, can't continue\n");
           VBE_freePMCode();
           return 0;
           }
          fprintf(LOG,"Banked mode %X successfully set.\n",m);

          return 1;
          }
        }
      }
    }
  else {
    fprintf(LOG,"Mode %X not available\n",m);
    }

  return 0;
}



// ULO screeninit(void) checks for VESA 2.0, records the current screenmode and sets
// 800x600x15 mode, linear for the moment
// Returns TRUE if intialization was successful, FALSE otherwise
// =============================================================================

ULO screeninit(void)
{
  VBE_vgaInfo myinfo;
  ULO i,version,found=0, returnvalue=1;
  UWO *yeah;

  // Find VESA 2.0 driver
  // Gets a data structure with capabilities of the display in myinfo

  version = VBE_detect(&myinfo);
  fprintf(LOG,"VESA version %d.%d found.\n",(version&0xff00)>>8,version&0xff);
  if ((version&0xff00) < 0x200) {
    fprintf(LOG,"Sorry, need at least VESA V2.0 driver to run.\n");
    printf("Sorry, need at least VESA V2.0 driver to run.\n");
    returnvalue = 0;
  }

  // Find a suitable video mode

  if (returnvalue == 1) {

    oldmode = VBE_getVideoMode();

    // First choice is linear 800x600x32k
    returnvalue = setup_mode(0x113,1);
    buffer2offset = (300*1600) + (300*scanlineadd);

  }
  return returnvalue;
}

// ULO screenclose(void)
// Restores old videomode and frees memory used by VBE library
// Returns TRUE when successful, FALSE otherwise
// ===========================================================

ULO screenclose(void)
{
  ULO returnvalue = 1;
  // Restore screen to old videomode

  if (!VBE_setVideoMode(oldmode)) {
    fprintf(LOG,"Failed to restore old video mode\n");
    returnvalue = 0;
    }
  
  // Free some memory

  VBE_freePMCode();
  return returnvalue;
}

// void clear(ULO top, ULO bot)
// Clears the lines from top to bot inclusive
// ==========================================
void clear(ULO top,ULO bot)
{
  ULO i;

  // Only do work when parameters are legal

  if ((top <= bot) && (bot <= 74))
    for (i = top; i <= bot; i++)
      plot_text("                                                                                                             ",0,i,0,0);
}


