/* Petter Schau 1996
// prototypes for cpu.cpp
*/
extern void cpuinit(void);
extern void prepare_exception(void);
extern void next_instruction(void);
extern ULO pc;
extern ULO thiscycle;
extern ULO t[65536][8];
extern ULO a[8],d[8];
extern ULO sr,usp,ssp;
extern ULO cpuspeed;
