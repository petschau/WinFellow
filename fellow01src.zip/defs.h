// Global constants and data from ac.c

#define DEFS


//#define CPUTRACE

//#define LOGGING

#define CHIPMEM 0x200000
#define FASTMEM 0x000000
#define BOGOMEM 0x100000
#define KICKMEM 0x080000

#define UBY unsigned char
#define UWO unsigned short int
#define ULO unsigned long
#define BYT signed char
#define WOR signed short int
#define LON signed long
#define FALSE 0
#define TRUE 1

typedef ULO amigaadress;
typedef ULO (*readfunc)();
typedef void (*writefunc)();
typedef ULO (*ciareadfunc)();
typedef void (*ciawritefunc)();
typedef ULO (*regreadfunc)();
typedef void (*regwritefunc)();

/*------------------------------------*/
/* The decode routines have this type */
/*------------------------------------*/

typedef void (*decoderoutinetype)(ULO,ULO);


