

struct menu {
  char entrytext[10][21];
  ULO activeentry;
  ULO numberofentries;
  struct window *menuwindow;
};

extern void menu_print(struct menu *m);
extern ULO menu_select(struct menu *m);

struct yesnomenuitem {
  char text[80];
  ULO  *value;
};

struct yesnomenu {
  struct yesnomenuitem items[80];
  ULO activeentry;
  ULO numberofentries;
  struct window *menuwindow;
  ULO yesnopos;
};

extern void yesnomenu_print(struct yesnomenu *m);
extern ULO yesnomenu_select(struct yesnomenu *m);



struct optionmenuoptionlist {
  char optiontext[26][10];
  ULO numberofentries;
  ULO optionvalues[26];
  ULO activeoption;
};

struct optionmenuitem {
  char text[30];
  ULO  type;             // 0 - text list of options 1 - enter string
  struct optionmenuoptionlist options;
  ULO  *intvalue;
  char *stringvalue;
};

struct optionmenu {
  struct optionmenuitem items[16];
  ULO activeentry;
  ULO numberofentries;
  struct window *menuwindow;
  ULO optionpos;
};

extern void optionmenu_print(struct optionmenu *m);
extern ULO optionmenu_select(struct optionmenu *m);
