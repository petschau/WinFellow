This archive contains the sources for Fellow V0.1++,
an experimental amiga emulator.
(C) Petter Schau in 1996/1997.  (pettersc@ifi.uio.no)

These sources are free in the sense that they
can be distributed freely as long as no money is
being charged for it.

You can do whatever you like with these sources
for personal use.

Public releases of Fellow however can only be made
by me (Petter Schau).

By using this program, you agree that the author can
not be held responible for any problems, disasters
or virtual incarnations of such events arising from
the use of this program.  This is alpha-version
software used at your own risk.


The above statements does of course not apply to the following
source files which has their own terms, see the relevant source files:

Some VESA code and a pmode libary taken from the Univbe SDK.


Information about the source-code:
----------------------------------
This is the source-code for Fellow V0.1 with
my latest changes that are not in the binary V0.1 release.
This is thus a post-V0.1 source-tree.

NOTE:
This is not a public release, but mostly for
those people who want to help and need the sources,
and those who would like to look at the source.

NOTE2:
There are a lot of broken routines in this source.
Blitter experiments have broken the blitter somewhat.
And optimizations in the video-emulation are
half finished, so some hires resolutions look
trashed.


Documenting the structure of the program is way to
timeconsuming, so the source is provided "as is".

There are unused files and also unused or experimental
code within the source files.  The source is in great
need of cleaning up.

The source will compile using the Watcom-compiler.

Fellow can be built with:

wmake ac.exe


List of major source files:
---------------------------

ac.c          -  Startup code with GUI.
6a.asm and       
6c.c          -  Motorola 68000 emulation and the bus loop.
ca.asm and
cc.c          -  Video, copper and blitter emulation.
da.asm and
dc.c          -  Floppy disk emulation.
ioc.c         -  Keyboard, mouse and some VESA code.
mc.c and
ma.asm        -  Memory system with io registers and cia emulation.
sc.c and
sa.asm        -  Sound emulation.
sb.c          -  Soundblaster specific code




The rest of this readme file is the readme contained in the binary
release.

Description:
------------

Fellow emulates the Amiga 500 computer.  The intention
is that Fellow will run demos well.  This version
upgrade however is one that finally runs AmigaDos, so
there's no major improvement for features that benefit 
demos over the 0.024 version apart from the fact that
now also one-file demos can run.

Other than the AmigaDos support, new features in this 
version are runtime control over things like changing
disk-images, processor and disk speed, joystick emulation
and the ratio of skipped frames.

The possibility to run some programs without a kickstart
is missing in this version.  That means this version does
not run without a kickstart file.  The kickstart software 
is copyrighted by whoever currently owns the remains of 
Commodore, and not provided.  To legally run the kickstart,
you must extract it from your own Amiga.

Simple instructions:
--------------------

The emulator takes one command line option:

-s

Will enable sound, played in 16-bit stereo. (SB16 or better required,
and the only soundcards supported.)


Initial GUI:
------------

When started, the emulator enters a simple UI.
The GUI is primitive and developed for the debugger.


The top-level menu has 4 options:

-RUN:
 Emulation is started with the RUN option.
 The emulator will run at the configured speed until F12 is pressed,
 which exits to the GUI.
 Initially the kickstart is run.  If the emulation was interrupted,
 execution continues, and changes in the configuration are active.

-DEBUGGER:

 Enters the debugger, with disassembly, memory inspection,
 register inspection, single stepping and breakpoints.
 If you want to use the debugger, you'll have to figure out how to do it
 yourself... It is simply a bonus.

-CONFIGURATION:
 This is a new feature, and the menu allows the user to change several
 things runtime, everything except new memory sizes take effect immediately.

 Navigate with up/down arrows, change setting with space or return and
 exit with Escape.

 Options are:

 -Changing disk-images.
  Select the desired drive, press space or return and type the 
  filename or path/filename of the diskimage.

 -Set the memory size, currently maximum 2MB chip and 1MB slow.
  New memory sizes will not take effect unless the emulator is restarted.

 -Turn joystick emulation on/off.  
  The joystick is in port 2 and mapped to the arroykeys.  
  F11 is the firebutton.

 -Turn the led symbols on/off.

 -Set the ratio of skipped frames.  
  A slow computer might need this.
  Skipping frames means that the emulator doesn't redraw the screen
  every time it is supposed to.  The screen emulation is the
  most resourceconsuming part of Fellow (about 60-70%) and 
  reducing the number of drawn frames might free enough time to
  help a slow processor emulate the rest of the machine at full speed.  

 -Set diskspeed.
  Determines how fast data from the disk is given to the "Amiga".
  The highest rate is 64 X the original speed, but some
  demos can't handle a speed this high. (Like the 9fingers demo.)
  1X is slightly slower than a usual Amiga.  2X is default. 

 -Set cpu speed.
  1X is default and supposed to be exactly like a 7.14 mhz M680000.
  2X and 4X is also supported and is twice and four times as fast.
  Some accuracy is lost in 2X and 4X, so it might not be exactly 2X or 4X.
  Please note that 2X and 4X is relative to the virtual timing in the
  emulator, so if your computer isn't fast enough to finish one second
  of emulation in one "real-world" second, you'll have
  to compensate by reducing the amount of drawn frames.

-QUIT:
 Quits the emulator.


Rom:
----
You need a kickstart-file to run this version of Fellow.
The file must be named "rom" and have a size of 512k.


Keyboard and mouse:
------------------
Keyboard and mouse are emulated, F12 exits to the GUI.

The keys are as usual, but not all Amiga-specific keys are supported
in this version.

F11 is always the firebutton on joystick 2.

When joystickemulation is enabled, the arrowkeys are used for the
joystick.

And of course, a mousedriver is needed to use the mouse.


Required hardware/OS:
---------------------
MSDOS
486 (recommend 166mhz Pentium to run at full speed.)
Soundblaster 16 or better (optional).
16MB free DPMI memory.
Vesa 2.0 compliant driver and screencard capable of linear 800x600x32k 
display mode, no other screenmode is supported right now.
Mouse driver.

Win95 might be useful for recovering from emulator crashes, but sometimes
slow down the overall speed :-)

Implemented features:
---------------------
MC68000
Blitter
Copper
Display with all screenmodes and sprites.
Sound, only DMA driven and no attached channels.
CIA (timers and event counters)
Disk (Only df0 and df1 avalable for use, and readonly.)
Keyboard and Mouse


For new versions, check:

http://rio.studby.uio.no/~pettersc/fellow/fellow.html

Petter Schau
pettersc@ifi.uio.no


