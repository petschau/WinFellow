#include "defs.h"

extern ULO dmaflataddr;
ULO left,right;

// These are external registers
ULO audpt[4];
ULO audlen[4];
ULO audper[4];
ULO audvol[4];
ULO auddat[4];

// These are internal registers 
ULO audlenw[4];  // Length counted down
ULO audperconstant[4]; // Period constant used for counting down percounter
ULO audpercounter[4];  
ULO auddatw[4];   // When this reg is loaded from auddat, ADL is set 
ULO audstate[4];
ULO auddma[4];
ULO audadl[4]; // Audio data load signal (to dma controller)
ULO audvolw[4]; // Internal volume control
ULO audptw[4];

// pointer to dma buffer
ULO auddmaptr;

ULO periodtable[65536];
WOR volumes[256][64];
UWO audioirqmask[4] = {0x0080,0x0100,0x0200,0x0400};
ULO audiodmaconmask[4] = {0x1,0x2,0x4,0x8};

extern ULO audiostate0();
extern ULO audiostate1();
extern ULO audiostate2();
extern ULO audiostate3();
extern ULO audiostate4();
extern ULO audiostate5();

ULO audstatejmptable[6] = {(ULO) audiostate0,(ULO) audiostate1,(ULO) audiostate2,(ULO)audiostate3,(ULO) audiostate4,(ULO)audiostate5};

void initvolumetable(void) {
  int i,j;
  for (i= -128; i< 128; i++) {
    for (j=0; j< 64; j++) {
      if (j == 0)
        volumes[(i&0xff)][j] = 0;
      else //if (i < 0)
        volumes[(i&0xff)][j] = i*j*2; //( (i*128) -  ( (i*128*(64-j))/64) );
     /* else 
        volumes[(i&0xff)][j] = ( (i*128)/(64-j));
       */
      }
    }
}

void initperiodtable(void) {
  double j;
  int i;
  periodtable[0] = 0x10000;
  for (i = 1; i < 65536; i++) {
    j = 228*312*50/i;  // Sample rate
    if (i < 114)
      periodtable[i] = 0x10000;
    else periodtable[i] = (ULO) ((j*65536)/31200);
 }
}
void soundinit(void) {
  int i;

  for (i = 0; i < 4; i++) {
    audpt[i] = 0;
    audptw[i] = 0;
    audlen[i] = 2;
    audper[i] = 0;
    audvol[i] = 0;
    audpercounter[i] = 0;
    audperconstant[i] = 0;
    auddat[i] = 0;
    auddatw[i] = 0;
    audlenw[i] = 2;
    audstate[i] = 0;
    auddma[i] = 0;
    audadl[i] = 0;
    audvolw[4] = 0;
  }

  auddmaptr = dmaflataddr;

  initperiodtable();
  initvolumetable();
}

