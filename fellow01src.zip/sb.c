#include <stdio.h>
#include <dos.h>
#include <stdlib.h>
#include "defs.h"
#include <conio.h>

extern ULO xpos,ypos,frames;

extern FILE *LOG;

extern ULO *framebuffer;

// sb stuff

ULO emuspeed;
ULO sbxpos,sbypos,sbframe;

ULO bufcount;

ULO playbuffer,editbuffer;

ULO sbio;
ULO sbirq;
ULO sbdma8;
ULO sbdma16;
ULO dspmajor;
ULO dspminor;
ULO sbversion;
ULO sboldirqvector;
ULO sbsamplerate;
ULO soundon;


ULO sbirqflag;

ULO irq1,irq2;  // irq masks

ULO dmasize;
ULO dmaselector;
ULO dmaaddress;
ULO dmapage;
ULO dmaflataddr;

void sbcmdwrite(UBY);


void dmadisable(int ch)
{
  if (ch<4) outp(0xa,ch+0x04);
  else outp(0xd4,(ch&3)+0x04);
}

void dmaclear(int ch) {
  if (ch<4) outp(0xc,0);
  else outp(0xd8,0);
}

void dmaenable(int ch) {
  if (ch<4) outp(0xa,ch);
  else outp(0xd4,(ch&3));
}


// Use AIREAD

void dmasetmode(int ch) {
  if (ch<4) outp(0xb,ch+0x18);
  else outp(0xd6,(ch&3)+0x18);
}

void dmasetoffset(int ch) {
  UWO address=(( ((ch < 4) ? (dmaflataddr): (dmaflataddr>>1)) &0xffff));

  if (ch < 4) {
    if (playbuffer == 1) address += 15000;
    outp (ch<<1, ((address)&0xFF) );
    outp (ch<<1, (address>>8) );
    }
  else {
    if (playbuffer == 1) address += 7500;
    outp (0xc0 | ((ch&3)<<2), ((address)&0xFF) );
    outp (0xc0 | ((ch&3)<<2), address>>8 );
    }

}

void dmasetpage(int ch) {
  switch(ch) {
    case 0:
      outp(0x87,dmapage);
      break;
    case 1:
      outp(0x83,dmapage);
      break;
    case 3:
      outp(0x82,dmapage);
      break;
    case 5:
      outp(0x8B,dmapage);
      break;
    case 6:
      outp(0x89,dmapage);
      break;
    case 7:
      outp(0x8A,dmapage);
      break;
    }
}

void dmasetlength(int ch) {
  if (ch < 4) {
    outp((ch<<1)|1,((15000)-1)&0xff);
    outp((ch<<1)|1,((15000)-1)>>8);
    }
  else {
    outp(0xc2|((ch&3)<<2),((6260)-1)&0xff);
    outp(0xc2|((ch&3)<<2),((6260)-1)>>8);
   }

}

void dmastarttransfer(void) {
// Old
//  sbcmdwrite(0x40);  // Timeconstant
//  sbcmdwrite(tc);

// new, but still rounded by the SB to nearest timeconstant 
    sbcmdwrite(0x41);
    sbcmdwrite(31300>>8);
    sbcmdwrite(31300&0xff);

// stereo, signed, 16bit
    sbcmdwrite(0xb0);
    sbcmdwrite(0x30);
    sbcmdwrite((dmasize)&0xff);
    sbcmdwrite((dmasize)>>8);

// old
//  sbcmdwrite(0x48);   // DMAsize
//  sbcmdwrite((dmasize)&0xff);  // Lo
//  sbcmdwrite((dmasize)>>8); // Hi
//  sbcmdwrite(0x1c); // Transfermode,  pcm_aiout

  sbirqflag = 0;


}


void dmainittransfer(void) {
  dmadisable(sbdma16);  
  dmaclear(sbdma16);
  dmasetmode(sbdma16);
  dmasetoffset(sbdma16);
  dmasetpage(sbdma16);
  dmasetlength(sbdma16);
  dmaenable(sbdma16);
}

void freedma (void)
{
  static union REGS reg;
  reg.x.eax = 0x0101;
  reg.x.edx = dmaselector;
  int386 ( 0x31, &reg, &reg );
}

int allocatedma(int size )
{
  ULO addr;
  static union REGS reg;
  reg.x.eax = 0x0100;                      // DPMI Mem. Allocation
  reg.x.ebx = ((size*2)+15>>4);    // # of paragraphs to alloc.
  int386 ( 0x31, &reg,&reg );      // do it!!
  if ( reg.x.cflag ) return 1;    // error alloc. mem.

  
  dmaselector = reg.x.edx;  // get the base selector
  addr=(reg.x.eax&0xFFFF)<<4;      // get the real segment adress
  if ( (addr>>16) != ((addr+size-1)>>16) )
    addr+=size;

  dmaflataddr = addr;// get the 20 bit real adress
  dmapage = dmaflataddr>>16;
  return 0;
}
static ULO flaggg = 0,yann=0,yonn;


static void interrupt sbinterrupt(void) {


  outp(sbio+0x4,0x82);
  if(inp(sbio+0x5)&1) inp(sbio+0xE);
  outp(sbio+0x4,0x82);
  if(inp(sbio+0x5)&2) inp(sbio+0xF);

  if((sbirq==10)||(sbirq==2)) outp(0xA0,0x20);
  outp(0x20,0x20);

  sbirqflag = 1;

  flaggg ^= 0xffff;

  *(framebuffer+yann) = flaggg;


  emuspeed = ((frames-sbframe)*71364)+(ypos*228)+xpos;
  emuspeed = (emuspeed*10000)/356820;
  if (emuspeed > 10000) emuspeed = 10000;
}


ULO sbcmdread(void) {
  while (!(inp(sbio+0xe)&0x80));
  return inp(sbio+0xa);
}

void sbcmdwrite(UBY val) {
  while ((inp(sbio+0xc)&0x80));
  outp (sbio+0xc, val);
 }

int resetdsp() {
  ULO i,j;
  // Reset DSP
  outp ( sbio+0x6, 1 );   // write 1 to reset port
  inp ( sbio );              
  inp ( sbio );               
  inp ( sbio );
  inp ( sbio );
  outp ( sbio+0x6, 0 );   // write 0 to reset port


  i=0;
  while (i++<100) {
    j = inp(sbio+0xe);
    if ((j&0x80)) {
      j = inp(sbio+0xa);
      if (j == 0xaa) {
        return 0;
        }
      }
    }
  return 1;
}

void iddsp(void) {
  sbcmdwrite(0xe1);
  dspmajor = sbcmdread();
  dspminor = sbcmdread();

  if (dspmajor == 1) {
    fprintf(LOG,"Found Soundblaster 1.0 or 1.5, NEED SB 16!\n");
    soundon = 0;   
  }
  else if (dspmajor == 3) {
    fprintf(LOG,"Found Soundblaster PRO, need SB 16!\n");
    soundon = 0;   
  }
  else if (dspmajor == 4) {
    fprintf(LOG,"Found Soundblaster 16\n");
  }
  else {
    fprintf(LOG,"Unknown soundblaster, major %d, minor %d\n",dspmajor,dspminor);
  }
}               

void setupsbirq(void) {
  irq1=inp(0x21);  // Get irq masks
  irq2=inp(0xa1);

  // Set irq vector
  if (sbirq < 8) {
    sboldirqvector = (ULO) _dos_getvect(sbirq+0x8);
    _dos_setvect(sbirq+0x8,sbinterrupt);
    }
    else {
    sboldirqvector = (ULO) _dos_getvect(sbirq+0x72);
    _dos_setvect(sbirq+0x72,sbinterrupt);
    }

    // Enable irq
    if (sbirq < 8)
        outp(0x21,(irq1^(1<<sbirq)));
    else
        outp(0xa1,(irq2^(1<<(sbirq-8))));
}

void stopsbirq(void) {

  // Disable irq
  if (sbirq < 8)
      outp(0x21,irq1);
  else
      outp(0xa1,irq2);

  // Set old irq vector
  if (sbirq < 8) {
    _dos_setvect(sbirq+0x8,(void *) sboldirqvector);
    }
    else {
    _dos_setvect(sbirq+0x72,(void *) sboldirqvector);
    }

}
int finder ( char tmp, char *env )
{
    char cpy[5];
    int i;
    i=0;

    // Extract individual segments of the BLASTER Env.
    while ( *(env+i) != 0 && *(env+i) != tmp )
        i++;
    if ( *(env+i) ==0 )
        return -1;      // not found in env str.
    else
    {
        env+=i+1; i=0;
        while ( *(env+i) != 0 && *(env+i) != ' ' )
            {cpy[i]=*(env+i);i++;}
        cpy[i]=0;
        return (atoi(cpy));
    }
}


int getBlaster(void)
{
    char *blastenv;
    char trans[20];

    if ( ( blastenv=getenv("BLASTER")) != NULL )
    {
        sbio = finder('A', blastenv);
        sbirq = finder('I', blastenv);
        sbdma8 = finder('D', blastenv);
        sbdma16 = finder('H', blastenv);

        sprintf(trans,"%d\n",sbio);
        sscanf(trans,"%X\n",&sbio);

        fprintf(LOG,"Result of BLASTER search:\n");
        fprintf(LOG,"sbio = %d\n",sbio);
        fprintf(LOG,"sbirq = %d\n",sbirq);
        fprintf(LOG,"sbdma8 = %d\n",sbdma8);
        fprintf(LOG,"sbdma16 = %d\n",sbdma16);
        return 1;
    }
    else
        return -1;      // Env. Table not found or incomplete
}


void sbinit(void) {
  int i,j;
  sbsamplerate = 31300;
  dmasize = 6260;
  soundon = 1;
  playbuffer = 0; editbuffer = 1;

  sbframe = 0;
  if (getBlaster() == -1) {
    fprintf(LOG,"No BLASTER variable, sound off\n");
    soundon = 0;
    return;
  }



  if (resetdsp() == 1) {
    fprintf(LOG,"Didn't find DSP\n");
    soundon = 0;
  }
  if (soundon == 1) {
    // Find dsp version
    iddsp();

    if (soundon == 1) setupsbirq();

    if (soundon == 1) {
      if (allocatedma(30000) == 1) {
        fprintf(LOG,"Error while allocating DMA buffer");
        soundon = 0;
      }
    }

    sbirqflag = 0;

    if (soundon == 1) {
      // Fill dma buffer with zeros
      for (i=0;i < 30000; i++) *((char *)(dmaflataddr+i)) = 0;
      bufcount = 5;
      dmainittransfer();
      dmastarttransfer();
    }
  }
}

void sbclose(void) {
  stopsbirq();
  freedma();
  resetdsp();
}


