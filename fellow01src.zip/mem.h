/*
// MEM routines, prototypes for use outside mem.cpp/mem.asm
*/

extern ULO fetb(ULO adress);
extern ULO fetw(ULO adress);
extern ULO fetl(ULO adress);

extern void wrib(ULO data,ULO adress);
extern void wriw(ULO data,ULO adress);
extern void wril(ULO data,ULO adress);
extern void dumpioblock(void);
extern ULO meminit(void);
extern void hexdump(ULO);

extern ULO dmaconr,dmacon;
extern ULO intenar,intena,intreq;
extern ULO potgor;

extern ULO lineflags[314];
/* Screen related registers */

extern ULO lof,xpos,ypos,diwxleft,diwxright,diwytop,diwybottom,ddfstrt,ddfstrtl,
    ddfstop,ddfstopl,topbottomflag,bpl1pt,bpl2pt,bpl3pt,bpl4pt,bpl5pt,bpl6pt,
    bplcon0,bplcon1,bplcon2,bpl1mod,bpl2mod,diwstrt,diwstop;

extern ULO DDFstartpos,DDFnumberofwords,DIWfirstvisiblepos,DIWlastvisiblepos;
extern ULO pagenr;

extern ULO shadcol[64];

extern ULO dskpt,dsklen,dsksync,pot0dat,pot1dat,joy0dat,joy1dat;

/* Copper registers */

extern ULO copcon,cop1lc,cop2lc,nxtcopaccess;

/* Blitter registers */

extern ULO bltcon,bltafwm,bltalwm,bltapt,bltbpt,bltcpt,bltdpt,bltamod,
    bltbmod,bltcmod,bltdmod,bltadat,bltbdat,bltcdat,blitteraccess,
    linenum,linecount,linelength,blitterdmawaiting,blitend,blitterstatus;


/* Memory arrays +4 because of a fucked up compiler */

extern UBY cmem[];
extern UBY fmem[];
extern UBY bmem[];
extern UBY kmem[];

/* Data for the CIAs */

extern ULO ciaaevstatus;               
extern ULO ciaata;               
extern ULO ciaatb;               
extern ULO ciaatalatch;
extern ULO ciaatblatch;          
extern ULO ciaataleft;
extern ULO ciaatbleft;
extern ULO ciaaicrreq;
extern ULO ciaaicrmsk;           
extern ULO ciaaevalarm;          
extern ULO ciaaevlatch;               
extern ULO ciaaevlatching;
extern ULO ciaaevwritelatch;               
extern ULO ciaaevwritelatching;               
extern ULO ciaaevalarmlatch;
extern ULO ciaaevalarmlatching;

extern ULO ciaaev;
extern ULO ciaacra;              
extern ULO ciaacrb;              
extern ULO ciaapra;
extern ULO ciaaprb;              
extern ULO ciaaddra;             
extern ULO ciaaddrb;             
extern ULO ciaasp;               

extern ULO ciabevstatus;               
extern ULO ciabta;               
extern ULO ciabtb;               
extern ULO ciabtalatch;          
extern ULO ciabtblatch;          
extern ULO ciabtaleft;
extern ULO ciabtbleft;
extern ULO ciabicrreq;           
extern ULO ciabicrmsk;           
extern ULO ciabevalarm;
extern ULO ciabevlatch;               
extern ULO ciabevlatching;               
extern ULO ciabevwritelatch;
extern ULO ciabevwritelatching;               
extern ULO ciabevalarmlatch;
extern ULO ciabevalarmlatching;
extern ULO ciabev;               
extern ULO ciabcra;              
extern ULO ciabcrb;              
extern ULO ciabpra;
extern ULO ciabprb;              
extern ULO ciabddra;             
extern ULO ciabddrb;             
extern ULO ciabsp;               
