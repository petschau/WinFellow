extern void soundinit(void);

extern ULO playbuffer,editbuffer;
extern ULO audstatejmptable[6];
extern ULO left,right;
extern ULO sbirqflag;

// These are external registers
extern ULO audpt[4];
extern ULO audlen[4];
extern ULO audper[4];
extern ULO audvol[4];
extern ULO auddat[4];

// These are internal registers 
extern ULO audptw[4];
extern ULO audlenw[4];  // Length counted down
extern ULO audperconstant[4]; // Period constant used for counting down percounter
extern ULO audpercounter[4];  
extern ULO auddatw[4];   // When this reg is loaded from auddat, ADL is set 
extern ULO audstate[4];
extern ULO auddma[4];
extern ULO audadl[4]; // Audio data load signal (to dma controller)
extern ULO audvolw[4]; // Internal volume control

// pointer to dma buffer
extern ULO auddmaptr;

extern ULO periodtable[65536];
extern WOR volumes[256][64];
extern UWO audioirqmask[4];
extern ULO audiodmaconmask[4];


