/* Petter Schau 1996 */
/* Initialization of the MC68000 emulation in Fellow */

#include <stdio.h>
#include <conio.h>
#include "defs.h"
#include "mem.h"
#include "io.h"
#include "chip.h"

extern struct window debugdisass;

#ifdef TESTUTSKRIFT
extern FILE *log;
#endif

#define SREG  0x00000007
#define SMOD  0x00000038
#define DMOD  0x000001c0
#define DREG  0x00000e00
#define SIZE  0x000000c0

#define BIT0  0x00000001
#define BIT1  0x00000002
#define BIT2  0x00000004
#define BIT3  0x00000008
#define BIT4  0x00000010
#define BIT5  0x00000020
#define BIT6  0x00000040
#define BIT7  0x00000080
#define BIT8  0x00000100
#define BIT9  0x00000200
#define BIT10 0x00000400
#define BIT11 0x00000800
#define BIT12 0x00001000
#define BIT13 0x00002000
#define BIT14 0x00004000
#define BIT15 0x00008000
#define BIT16 0x00010000
#define BIT17 0x00020000
#define BIT18 0x00040000
#define BIT19 0x00080000
#define BIT20 0x00100000
#define BIT21 0x00200000
#define BIT22 0x00400000
#define BIT23 0x00800000
#define BIT24 0x01000000
#define BIT25 0x02000000
#define BIT26 0x04000000
#define BIT27 0x08000000
#define BIT28 0x10000000
#define BIT29 0x20000000
#define BIT30 0x40000000
#define BIT31 0x80000000

ULO t[65536][8],pc,usp,ssp,cyclecount,lastcyclecount,thiscycle;
UWO sr;
UBY bcd2hex[256],hex2bcd[256];
UBY mulutab[256],mulstab[256];

ULO traceoldpc,tracesr;

extern ULO d[8];
extern ULO a[8];

/*
 External prototypes for the instructions
 They return the number of cycles used on a MC68000
 The disassembly routines return the instruction length in bytes
*/




extern void prepare_exception(void);

extern void next_instruction(void);
extern void i00(ULO);
extern void i01_1(ULO);
extern void i01_2(ULO);
extern void i02_B_1(ULO);
extern void i02_W_1(ULO);
extern void i02_L_1(ULO);
extern void i02_B_2(ULO);
extern void i02_W_2(ULO);
extern void i02_L_2(ULO);
extern void i03_W(ULO);
extern void i03_L(ULO);
extern void i04_B(ULO);
extern void i04_W(ULO);
extern void i04_L(ULO);
extern void i05_B(ULO);
extern void i05_W(ULO);
extern void i05_L(ULO);
extern void i05_ADR(ULO);
extern void i06_B_1(ULO);
extern void i06_W_1(ULO);
extern void i06_L_1(ULO);
extern void i06_B_2(ULO);
extern void i06_W_2(ULO);
extern void i06_L_2(ULO);
extern void i07_B_1(ULO);
extern void i07_W_1(ULO);
extern void i07_L_1(ULO);
extern void i07_B_2(ULO);
extern void i07_W_2(ULO);
extern void i07_L_2(ULO);
extern void i08_B(ULO);
extern void i08_W(ULO);
extern void i08_L(ULO);
extern void i08_B_CCR(ULO);
extern void i08_W_SR(ULO);
extern void i09_RI_I_B(ULO);
extern void i09_LE_I_B(ULO);
extern void i09_RI_I_W(ULO);
extern void i09_LE_I_W(ULO);
extern void i09_RI_I_L(ULO);
extern void i09_LE_I_L(ULO);
extern void i09_RI_R_B(ULO);
extern void i09_LE_R_B(ULO);
extern void i09_RI_R_W(ULO);
extern void i09_LE_R_W(ULO);
extern void i09_RI_R_L(ULO);
extern void i09_LE_R_L(ULO);
extern void i09_RI_M_W(ULO);
extern void i09_LE_M_W(ULO);
extern void i11_B(ULO);
extern void i11_W(ULO);
extern void i12_D_L(ULO);
extern void i12_D_B(ULO);
extern void i12_S_L(ULO);
extern void i12_S_B(ULO);
extern void i13_D_L(ULO);
extern void i13_D_B(ULO);
extern void i13_S_L(ULO);
extern void i13_S_B(ULO);   /* 14 is included in Bcc */
extern void i15_D_L(ULO);
extern void i15_D_B(ULO);
extern void i15_S_L(ULO);
extern void i15_S_B(ULO);   /* 16 is included in Bcc */
extern void i17_D_L(ULO);
extern void i17_D_B(ULO);
extern void i17_S_L(ULO);
extern void i17_S_B(ULO);
extern void i18(ULO);
extern void i19(ULO);
extern void i20_B(ULO);
extern void i20_W(ULO);
extern void i20_L(ULO);
extern void i21_W(ULO);
extern void i21_L(ULO);
extern void i22_B(ULO);
extern void i22_W(ULO);
extern void i22_L(ULO);
extern void i23_B(ULO);
extern void i23_W(ULO);
extern void i23_L(ULO);
extern void i24(ULO);
extern void i25(ULO);
extern void i26(ULO);
extern void i27_B(ULO);
extern void i27_W(ULO);
extern void i27_L(ULO);
extern void i28_B(ULO);
extern void i28_W(ULO);
extern void i28_L(ULO);
extern void i28_B_CCR(ULO);
extern void i28_W_SR(ULO);
extern void i29(ULO);
extern void i30_W(ULO);
extern void i30_L(ULO);
extern void i31(ULO);
extern void i32(ULO);
extern void i33(ULO);
extern void i34(ULO);
extern void i35_RI_I_B(ULO);
extern void i35_LE_I_B(ULO);
extern void i35_RI_I_W(ULO);
extern void i35_LE_I_W(ULO);
extern void i35_RI_I_L(ULO);
extern void i35_LE_I_L(ULO);
extern void i35_RI_R_B(ULO);
extern void i35_LE_R_B(ULO);
extern void i35_RI_R_W(ULO);
extern void i35_LE_R_W(ULO);
extern void i35_RI_R_L(ULO);
extern void i35_LE_R_L(ULO);
extern void i35_RI_M_W(ULO);
extern void i35_LE_M_W(ULO);
extern void i37_B(ULO);
extern void i37_W(ULO);
extern void i37_L(ULO);
extern void i38(ULO);
extern void i39(ULO);
extern void i40(ULO);
extern void i41_1(ULO);
extern void i41_2(ULO);
extern void i42_W(ULO);
extern void i42_L(ULO);
extern void i43_W_PREM(ULO);
extern void i43_L_PREM(ULO);
extern void i43_W_POSTR(ULO);
extern void i43_L_POSTR(ULO);
extern void i43_W_CONM(ULO);
extern void i43_L_CONM(ULO);
extern void i43_W_CONR(ULO);
extern void i43_L_CONR(ULO);
extern void i44_W_1(ULO);
extern void i44_L_1(ULO);
extern void i44_W_2(ULO);
extern void i44_L_2(ULO);
extern void i45(ULO);
extern void i46(ULO);
extern void i47(ULO);
extern void i48_B(ULO);
extern void i49_B(ULO);
extern void i49_W(ULO);
extern void i49_L(ULO);
extern void i50_B(ULO);
extern void i50_W(ULO);
extern void i50_L(ULO);
extern void i51(ULO);
extern void i52_B(ULO);
extern void i52_W(ULO);
extern void i52_L(ULO);
extern void i53_B_1(ULO);
extern void i53_W_1(ULO);
extern void i53_L_1(ULO);
extern void i53_B_2(ULO);
extern void i53_W_2(ULO);
extern void i53_L_2(ULO);
extern void i54_B(ULO);
extern void i54_W(ULO);
extern void i54_L(ULO);
extern void i54_B_CCR(ULO);
extern void i54_W_SR(ULO);
extern void i55(ULO);
extern void i56(ULO);
extern void i57_RI_I_B(ULO);
extern void i57_LE_I_B(ULO);
extern void i57_RI_I_W(ULO);
extern void i57_LE_I_W(ULO);
extern void i57_RI_I_L(ULO);
extern void i57_LE_I_L(ULO);
extern void i57_RI_R_B(ULO);
extern void i57_LE_R_B(ULO);
extern void i57_RI_R_W(ULO);
extern void i57_LE_R_W(ULO);
extern void i57_RI_R_L(ULO);
extern void i57_LE_R_L(ULO);
extern void i57_RI_M_W(ULO);
extern void i57_LE_M_W(ULO);
extern void i59_RI_I_B(ULO);
extern void i59_LE_I_B(ULO);
extern void i59_RI_I_W(ULO);
extern void i59_LE_I_W(ULO);
extern void i59_RI_I_L(ULO);
extern void i59_LE_I_L(ULO);
extern void i59_RI_R_B(ULO);
extern void i59_LE_R_B(ULO);
extern void i59_RI_R_W(ULO);
extern void i59_LE_R_W(ULO);
extern void i59_RI_R_L(ULO);
extern void i59_LE_R_L(ULO);
extern void i59_RI_M_W(ULO);
extern void i59_LE_M_W(ULO);
extern void i61(ULO);
extern void i62(ULO);
extern void i63(ULO);
extern void i64_1(ULO);
extern void i64_2(ULO);
extern void i65(ULO);
extern void i66(ULO);
extern void i67_B_1(ULO);
extern void i67_W_1(ULO);
extern void i67_L_1(ULO);
extern void i67_B_2(ULO);
extern void i67_W_2(ULO);
extern void i67_L_2(ULO);
extern void i68_W(ULO);
extern void i68_L(ULO);
extern void i69_B(ULO);
extern void i69_W(ULO);
extern void i69_L(ULO);
extern void i70_B(ULO);
extern void i70_W(ULO);
extern void i70_L(ULO);
extern void i70_ADR(ULO);
extern void i71_B_1(ULO);
extern void i71_W_1(ULO);
extern void i71_L_1(ULO);
extern void i71_B_2(ULO);
extern void i71_W_2(ULO);
extern void i71_L_2(ULO);
extern void i72(ULO);
extern void i73(ULO);
extern void i74(ULO);
extern void i75(ULO);
extern void i76_B(ULO);
extern void i76_W(ULO);
extern void i76_L(ULO);
extern void i77(ULO);

extern void cc0(void);
extern void cc1(void);
extern void cc2(void);
extern void cc3(void);
extern void cc4(void);
extern void cc5(void);
extern void cc6(void);
extern void cc7(void);
extern void cc8(void);
extern void cc9(void);
extern void cca(void);
extern void ccb(void);
extern void ccc(void);
extern void ccd(void);
extern void cce(void);
extern void ccf(void);
extern void cc1false(void);



extern ULO arb00(ULO);
extern ULO arb02(ULO);
extern ULO arb03(ULO);
extern ULO arb04(ULO);
extern ULO arb05(ULO);
extern ULO arb06(ULO);
extern ULO arb70(ULO);
extern ULO arb71(ULO);
extern ULO arb72(ULO);
extern ULO arb73(ULO);
extern ULO arb74(ULO);

extern ULO arw00(ULO);
extern ULO arw01(ULO);
extern ULO arw02(ULO);
extern ULO arw03(ULO);
extern ULO arw04(ULO);
extern ULO arw05(ULO);
extern ULO arw06(ULO);
extern ULO arw70(ULO);
extern ULO arw71(ULO);
extern ULO arw72(ULO);
extern ULO arw73(ULO);
extern ULO arw74(ULO);

extern ULO arl00(ULO);
extern ULO arl01(ULO);
extern ULO arl02(ULO);
extern ULO arl03(ULO);
extern ULO arl04(ULO);
extern ULO arl05(ULO);
extern ULO arl06(ULO);
extern ULO arl70(ULO);
extern ULO arl71(ULO);
extern ULO arl72(ULO);
extern ULO arl73(ULO);
extern ULO arl74(ULO);

extern ULO awb00(ULO);
extern ULO awb02(ULO);
extern ULO awb03(ULO);
extern ULO awb04(ULO);
extern ULO awb05(ULO);
extern ULO awb06(ULO);
extern ULO awb70(ULO);
extern ULO awb71(ULO);

extern ULO aww00(ULO);
extern ULO aww01(ULO);
extern ULO aww02(ULO);
extern ULO aww03(ULO);
extern ULO aww04(ULO);
extern ULO aww05(ULO);
extern ULO aww06(ULO);
extern ULO aww70(ULO);
extern ULO aww71(ULO);

extern ULO awl00(ULO);
extern ULO awl01(ULO);
extern ULO awl02(ULO);
extern ULO awl03(ULO);
extern ULO awl04(ULO);
extern ULO awl05(ULO);
extern ULO awl06(ULO);
extern ULO awl70(ULO);
extern ULO awl71(ULO);


extern ULO parb03(ULO);
extern ULO parb04(ULO);
extern ULO parb05(ULO);
extern ULO parb06(ULO);
extern ULO parb70(ULO);
extern ULO parb71(ULO);
extern ULO parb72(ULO);
extern ULO parb73(ULO);
extern ULO parb74(ULO);

extern ULO parw03(ULO);
extern ULO parw04(ULO);
extern ULO parw05(ULO);
extern ULO parw06(ULO);
extern ULO parw70(ULO);
extern ULO parw71(ULO);
extern ULO parw72(ULO);
extern ULO parw73(ULO);
extern ULO parw74(ULO);

extern ULO parl03(ULO);
extern ULO parl04(ULO);
extern ULO parl05(ULO);
extern ULO parl06(ULO);
extern ULO parl70(ULO);
extern ULO parl71(ULO);
extern ULO parl72(ULO);
extern ULO parl73(ULO);
extern ULO parl74(ULO);

extern ULO eac02(ULO);
extern ULO eac05(ULO);
extern ULO eac06(ULO);
extern ULO eac70(ULO);
extern ULO eac71(ULO);
extern ULO eac72(ULO);
extern ULO eac73(ULO);

#ifdef TESTUTSKRIFT
ULO opcodesgenerated = 0;
#endif

ULO eventlog[16384];
ULO tickcounter=0;
ULO interruptlevel=0;
ULO interruptadress=0;
ULO interruptflag=0;
ULO exceptionstack=0;
ULO cpustopflag=0;
ULO eventptr=(ULO) eventlog;
ULO eventcount=0;

ULO cpuspeed;


/* arx/awx routiner �ker PC og (Ax)+- */
/* parx routiner gj�r det ikke */
const ULO arb[12] = {(ULO) arb00,NULL,(ULO) arb02,(ULO) arb03,(ULO) arb04,(ULO) arb05,(ULO) arb06,(ULO) arb70,(ULO) arb71,(ULO) arb72,(ULO) arb73,(ULO) arb74};
const ULO arw[12] = {(ULO) arw00,(ULO) arw01,(ULO) arw02,(ULO) arw03,(ULO) arw04,(ULO) arw05,(ULO) arw06,(ULO) arw70,(ULO) arw71,(ULO) arw72,(ULO) arw73,(ULO) arw74};
const ULO arl[12] = {(ULO) arl00,(ULO) arl01,(ULO) arl02,(ULO) arl03,(ULO) arl04,(ULO) arl05,(ULO) arl06,(ULO) arl70,(ULO) arl71,(ULO) arl72,(ULO) arl73,(ULO) arl74};
const ULO parb[12] = {(ULO) arb00,NULL,(ULO) arb02,(ULO) parb03,(ULO) parb04,(ULO) parb05,(ULO) parb06,(ULO) parb70,(ULO) parb71,(ULO) parb72,(ULO) parb73,(ULO) parb74};
const ULO parw[12] = {(ULO) arw00,(ULO) arw01,(ULO) arw02,(ULO) parw03,(ULO) parw04,(ULO) parw05,(ULO) parw06,(ULO) parw70,(ULO) parw71,(ULO) parw72,(ULO) parw73,(ULO) parw74};
const ULO parl[12] = {(ULO) arl00,(ULO) arl01,(ULO) arl02,(ULO) parl03,(ULO) parl04,(ULO) parl05,(ULO) parl06,(ULO) parl70,(ULO) parl71,(ULO) parl72,(ULO) parl73,(ULO) parl74};
const ULO awb[12] = {(ULO) awb00,NULL,(ULO) awb02,(ULO) awb03,(ULO) awb04,(ULO) awb05,(ULO) awb06,(ULO) awb70,(ULO) awb71};
const ULO aww[12] = {(ULO) aww00,(ULO) aww01,(ULO) aww02,(ULO) aww03,(ULO) aww04,(ULO) aww05,(ULO) aww06,(ULO) aww70,(ULO) aww71};
const ULO awl[12] = {(ULO) awl00,(ULO) awl01,(ULO) awl02,(ULO) awl03,(ULO) awl04,(ULO) awl05,(ULO) awl06,(ULO) awl70,(ULO) awl71};
const ULO eac[12] = {0,0,(ULO) eac02,0,0,(ULO) eac05,(ULO) eac06,(ULO) eac70,(ULO) eac71,(ULO) eac72,(ULO) eac73,0};

const UBY tarb[12] =      {0,0,4,4, 6, 8,10, 8,12, 8,10,4};
const UBY tarw[12] =      {0,0,4,4, 6, 8,10, 8,12, 8,10,4};
const UBY tarl[12] =      {0,0,8,8,10,12,14,12,16,12,14,8};
const UBY allmodes[16]  = {1,1,1,1, 1, 1, 1, 1, 1, 1, 1,1,0,0,0,0};
const UBY data[16]      = {1,0,1,1, 1, 1, 1, 1, 1, 1, 1,1,0,0,0,0};
const UBY memory[16]    = {0,0,1,1, 1, 1, 1, 1, 1, 1, 1,1,0,0,0,0};
const UBY control[16]   = {0,0,1,0, 0, 1, 1, 1, 1, 1, 1,0,0,0,0,0};
const UBY alterable[16] = {1,1,1,1, 1, 1, 1, 1, 1, 0, 0,0,0,0,0,0};

ULO statustab[4096];


/*
 Cpu emulation initialization
*/

void makebcdtabs(void)
{
  ULO x;
  for (x = 0; x < 100; x++) {
    hex2bcd[x] = x % 10 | (x / 10) << 4;
    }
  for (x = 100; x < 256; x++) hex2bcd[x] = 0;

  for (x = 0; x < 256; x++) {
    bcd2hex[x] = (((x&0xf)<10)&&((x&0xf0)<0xa0)) ? (x&0xf)+((x&0xf0)>>4)*10:0;
    }
}


/* Disassembly of the different address-modes.
  Parameters:
   ULO reg  - The register used in the address-mode
   ULO pcp  - The address of the next byte not used.
   char *st - The string to write the dissassembly to.
   ULO *pos - The position in the string where the hex-words used are written
  Returnvalue:
   The address of the next byte not used. (PC after the modedata)
*/

ULO dis00(ULO reg,ULO pcp,char *st,ULO *pos)
{
  char dstr[3];
  sprintf(dstr,"D%1d",reg);
  strcat(st,dstr);
  return pcp;
}

ULO dis01(ULO reg,ULO pcp,char *st,ULO *pos)
{
  char dstr[3];
  sprintf(dstr,"A%1d",reg);
  strcat(st,dstr);
  return pcp;
}

ULO dis02(ULO reg,ULO pcp,char *st,ULO *pos)
{
  char dstr[5];
  sprintf(dstr,"(A%1d)",reg);
  strcat(st,dstr);
  return pcp;
}

ULO dis03(ULO reg,ULO pcp,char *st,ULO *pos)
{
  char dstr[6];
  sprintf(dstr,"(A%1d)+",reg);
  strcat(st,dstr);
  return pcp;
}

ULO dis04(ULO reg,ULO pcp,char *st,ULO *pos)
{
  char dstr[6];
  sprintf(dstr,"-(A%1d)",reg);
  strcat(st,dstr);
  return pcp;
}

ULO dis05(ULO reg,ULO pcp,char *st,ULO *pos)
{
  char dstr[10];
  ULO j;
  sprintf(dstr,"$%.4X(A%1d)",(j = fetw(pcp)),reg);
  sprintf(&st[*pos],"%.4X",j);
  *pos += 5;
  st[(*pos)-1] = ' '; 
  strcat(st,dstr);
  return pcp+2;
}

ULO dis06(ULO reg,ULO pcp,char *st,ULO *pos)
{
  char dstr[13];
  ULO j;
  j=fetw(pcp);
  if ((j&0x8000) == 0) {
    if (j&0x0800) sprintf(dstr,"$%.2X(A%1d,D%1d.L)",j&0xff,reg,(j&0x7000)>>12);
    else sprintf(dstr,"$%.2X(A%1d,D%1d.W)",(j & 0xff),reg,(j & 0x7000)>>12);
  }
  else {
    if (j&0x0800) sprintf(dstr,"$%.2X(A%1d,A%1d.L)",j&0xff,reg,(j&0x7000)>>12);
    else sprintf(dstr,"$%.2X(A%1d,A%1d.W)",(j & 0xff),reg,(j & 0x7000)>>12);
  }
  sprintf(&st[*pos],"%.4X",j);
  *pos += 5;
  st[(*pos)-1] = ' '; 
  strcat(st,dstr);
  return pcp+2;
}

ULO dis70(ULO reg,ULO pcp,char *st,ULO *pos)
{
  char dstr[110];
  ULO j;
  sprintf(dstr,"$%.4X.W",(j=fetw(pcp)));
  sprintf(&st[*pos],"%.4X",j);
  *pos += 5;
  st[(*pos)-1] = ' '; 
  strcat(st,dstr);
  return pcp+2;
}

ULO dis71(ULO reg,ULO pcp,char *st,ULO *pos)
{
  char dstr[110];
  ULO j;
  sprintf(dstr,"$%.8X.L",(j=fetl(pcp)));
  sprintf(&st[*pos],"%.8X",j);
  *pos += 9;
  st[(*pos)-1] = ' '; 
  strcat(st,dstr);
  return pcp+4;
}

ULO dis72(ULO reg,ULO pcp,char *st,ULO *pos)
{
  char dstr[110];
  ULO j;
  sprintf(dstr,"$%.4X(PC)",(j=fetw(pcp)));
  sprintf(&st[*pos],"%.4X",j);
  *pos += 5;
  st[(*pos)-1] = ' '; 
  strcat(st,dstr);
  return pcp+2;
}

ULO dis73(ULO reg,ULO pcp,char *st,ULO *pos)
{
  char dstr[110];
  ULO j;
  j=fetw(pcp);
  if ((j&0x8000) == 0) {
    if (j&0x0800) sprintf(dstr,"$%.2X(PC,D%1d.L)",(j & 0xff),(j & 0x7000)>>12);
    else sprintf(dstr,"$%.2X(PC,D%1d.W)",(j & 0xff),(j & 0x7000)>>12);
  }
  else {
    if (j&0x0800) sprintf(dstr,"$%.2X(PC,A%1d.L)",(j & 0xff),(j & 0x7000)>>12);
    else sprintf(dstr,"$%.2X(PC,A%1d.W)",(j & 0xff),(j & 0x7000)>>12);
  }
  sprintf(&st[*pos],"%.4X",j);
  *pos += 5;
  st[(*pos)-1] = ' '; 
  strcat(st,dstr);
  return pcp+2;
}

ULO disb74(ULO reg,ULO pcp,char *st,ULO *pos)
{
  char dstr[110];
  ULO j;
  sprintf(dstr,"#$%.2X",(j=fetw(pcp))&0x00ff);
  sprintf(&st[*pos],"%.4X",j);
  *pos += 5;
  st[(*pos)-1] = ' '; 
  strcat(st,dstr);
  return pcp+2;
}

ULO disw74(ULO reg,ULO pcp,char *st,ULO *pos)
{
  char dstr[110];
  ULO j;
  sprintf(dstr,"#$%.4X",(j=fetw(pcp)));
  sprintf(&st[*pos],"%.4X",j);
  *pos += 5;
  st[(*pos)-1] = ' '; 
  strcat(st,dstr);
  return pcp+2;
}

ULO disl74(ULO reg,ULO pcp,char *st,ULO *pos)
{
  char dstr[110];
  ULO j;
  sprintf(dstr,"#$%.8X",(j=fetl(pcp)));
  sprintf(&st[*pos],"%.8X",j);
  *pos += 9;
  st[(*pos)-1] = ' '; 
  strcat(st,dstr);
  return pcp+4;
}


ULO disfordel(ULO reg,ULO pcp,char *st,ULO size,ULO mode,ULO *pos)
{
  switch (mode) {
    case 0:  return dis00(reg,pcp,st,pos);
    case 1:  return dis01(reg,pcp,st,pos);
    case 2:  return dis02(reg,pcp,st,pos);
    case 3:  return dis03(reg,pcp,st,pos);
    case 4:  return dis04(reg,pcp,st,pos);
    case 5:  return dis05(reg,pcp,st,pos);
    case 6:  return dis06(reg,pcp,st,pos);
    case 7:  return dis70(reg,pcp,st,pos);
    case 8:  return dis71(reg,pcp,st,pos);
    case 9:  return dis72(reg,pcp,st,pos);
    case 10: return dis73(reg,pcp,st,pos);
    case 11: return (size==8)  ? disb74(reg,pcp,st,pos):
                    (size==16) ? disw74(reg,pcp,st,pos):
                                 disl74(reg,pcp,st,pos);
    default: return pcp;
    }
}


ULO size000110(ULO s)
{
  return (s == 0x00) ?
              8:
              (s == 0x40) ?
                16:
                32;
}


/*
 Illegal instruction
*/

ULO i00dis(ULO prc,ULO opc,ULO y) 
{
  char st[80];
  sprintf(st,"$%.6X %.4X                   ILLEGAL INSTRUCTION",prc,opc);
  plot_text_window(&debugdisass,st,0,y);
  return prc+2;
}

/*
 Instruction ABCD.B Ry,Rx / ABCD.B -(Ay),-(Ax)
 Table-usage: 0 - Routinepointer 1 - disasm routine 2 - Rx*4(dest) 3 - Ry*4
*/

ULO i01dis(ULO prc,ULO opc,ULO y)
{
  char st[110];
  sprintf(st,((opc&0x8 == 0) ?
                "$%.6X %.4X                   ABCD.B  D%1d,D%1d":
                "$%.6X %.4X                   ABCD.B  -(A%1d),-(A%1d)"),
                prc,opc,opc&0x3,(opc&0xe00)>>9);
  plot_text_window(&debugdisass,st,0,y);
  return prc+2;
}

void i01ini(void)
{
  ULO op=0xc100,ind,rm,rx,ry;
  for (rm = 0; rm <= 1; rm++) 
    for (rx = 0; rx <= 7; rx++) 
      for (ry = 0; ry <= 7; ry++) {
        ind = op|ry|rx<<9|rm<<3;
        t[ind][0] = (rm == 0) ?
                       (ULO) i01_1:
                       (ULO) i01_2;
        t[ind][1] = (ULO) i01dis;
        t[ind][2] = (rm == 0) ?
                       (rx*4 + (ULO) d):
                       (rx*4 + (ULO) a);
        t[ind][3] = (rm == 0) ?
                       (ry*4 + (ULO) d):
                       (ry*4 + (ULO) a);
        }
}


/*
 Instruction ADD.X <ea>,Dn / ADD.X Dn,<ea>
 Table-usage:
 Type 1:  add <ea>,Dn
  0-Routinepointer 1-disasm routine  2-sourreg 3-sourceroutine
                   4-Dreg        5-cycle count                   
 Type 2:  add Dn,<ea>
  0-Routinepointer 1-disasm routine  2-<ea>reg 3-get <ea> routine
                   4-Dreg        5-cycle count   6-write<ea> routine                
*/

ULO i02dis(ULO prc,ULO opc,ULO y) 
{
  char st[80];
  ULO pos=13,reg=opc&SREG,dreg=(opc&DREG)>>9,o=opc&0x100,mode=(opc&SMOD)>>3,
      size=size000110(opc&SIZE);
  if (mode == 7) mode += reg;
  sprintf(st,"$%.6X %.4X                   ADD.    ",prc,opc);
  st[35] = (size == 8) ?
              'B':
              (size == 16) ?
                 'W':
                 'L';
  prc = (o == 0) ? disfordel(reg,prc+2,st,size,mode,&pos) :
                   disfordel(dreg,prc+2,st,size,0,&pos);
  strcat(st,",");
  prc = (o != 0) ? disfordel(reg,prc,st,size,mode,&pos) :
                   disfordel(dreg,prc,st,size,0,&pos);
  plot_text_window(&debugdisass,st,0,y);
  return prc;
}

void i02ini(void)
{
  ULO op=0xd000,ind,regd,modes,regs,flats,size,o;
  for (o = 0; o < 2; o++)
    for (size = 0; size < 3; size++)
      for (regd = 0; regd < 8; regd++) 
        for (modes = 0; modes < 8; modes++) 
          for (regs = 0; regs < 8; regs++) {
            flats = (modes != 7) ?
                       modes:
                       (modes+regs);
            if ((o==0 && size == 0 && data[flats]) ||
                (o==0 && size != 0 && allmodes[flats]) ||
                (o==1 && alterable[flats] && memory[flats])) {
              ind = op|regd<<9|o<<8|size<<6|modes<<3|regs;
              t[ind][0] = (o == 0) ?
                             (size == 0) ?
                                (ULO) i02_B_1:
                                (size == 1) ?
                                   (ULO) i02_W_1:
                                   (ULO) i02_L_1:
                             (size == 0) ?
                                (ULO) i02_B_2:
                                (size == 1) ?
                                   (ULO) i02_W_2:
                                   (ULO) i02_L_2;
              t[ind][1] = (ULO) i02dis;
              t[ind][2] = (modes == 0) ?
                             (regs*4 + (ULO) d):
                             (regs*4 + (ULO) a);
              t[ind][3] = (o == 0) ?
                             (size == 0) ?
                                arb[flats]:
                                (size == 1) ?
                                   arw[flats]:
                                   arl[flats]:
                             (size == 0) ?
                                parb[flats]:
                                (size == 1) ?
                                   parw[flats]:
                                   parl[flats];
              t[ind][4] = regd*4 + (ULO) d;
              t[ind][5] = (o == 0) ?
                             (size == 0) ?
                                (4+tarb[flats]):
                                (size == 1) ?
                                   (4+tarw[flats]):
                                   (flats <= 1 || flats == 11) ?
                                      (8+tarl[flats]):
                                      (6+tarl[flats]):
                             (size == 0) ?
                                (8 + tarb[flats]):
                                (size == 1) ?
                                   (8 + tarw[flats]):
                                   (12 + tarl[flats]);
              if (o == 1) t[ind][6] = (size == 0) ?
                                         awb[flats]:
                                         (size == 1) ?
                                            aww[flats]:
                                            awl[flats];
              }
            }
}


/*
 Instruction ADDA.W/L <ea>,An
 Table-usage:

  0-Routinepointer 1-disasm routine  2-sourreg 3-sourceroutine
                   4-Areg        5-cycle count                   
*/



ULO i03dis(ULO prc,ULO opc,ULO y) 
{
  char st[80];
  ULO pos=13,reg=opc&SREG,dreg=(opc&DREG)>>9,o=opc&0x100,mode=(opc&SMOD)>>3,
      size;
  size = (o == 0) ?
            16:
            32;
  if (mode == 7) mode += reg;
  sprintf(st,"$%.6X %.4X                   ADDA.   ",prc,opc);
  st[36] = (size == 16) ?
              'W':
              'L';
  prc = disfordel(reg,prc+2,st,size,mode,&pos);
  strcat(st,",");
  disfordel(dreg,prc,st,size,1,&pos);
  plot_text_window(&debugdisass,st,0,y);
  return prc;
}

void i03ini(void)
{
  ULO op=0xd0c0,ind,regd,modes,regs,flats,o;
  for (o = 0; o < 2; o++)
    for (regd = 0; regd < 8; regd++) 
      for (modes = 0; modes < 8; modes++) 
        for (regs = 0; regs < 8; regs++) 
          if (allmodes[(flats = (modes != 7) ? modes : modes+regs)]) {
            ind = op|regd<<9|o<<8|modes<<3|regs;
            t[ind][0] = (o == 0) ?
                           (ULO) i03_W:
                           (ULO) i03_L;
            t[ind][1] = (ULO) i03dis;
            t[ind][2] = (modes == 0) ?
                           (regs*4 + (ULO) d):
                           (regs*4 + (ULO) a);
            t[ind][3] = (o == 0) ?
                           arw[flats]:
                           arl[flats];
            t[ind][4] = regd*4 + (ULO) a;
            t[ind][5] = (o==0) ?
                           (8 + tarw[flats]):
                           (flats <= 1 || flats == 11) ?
                              (8 + tarl[flats]):
                              (6 + tarl[flats]);
            }
}


/*
 Instruction ADDI.X #i,<ea>
 Table-usage:

  0-Routinepointer 1-disasm routine  2-eareg 3-ea read routine
                4-cycle count    5-ea write routine               
*/

ULO i04dis(ULO prc,ULO opc,ULO y) 
{
  char st[80];
  ULO pos=13,reg=opc&SREG,mode=(opc&SMOD)>>3,size=size000110(opc&SIZE);
  if (mode == 7) mode += reg;
  sprintf(st,"$%.6X %.4X                   ADDI.   ",prc,opc);
  st[36] = (size == 8) ?
              'B':
              (size == 16) ?
                 'W':
                 'L';
  prc = disfordel(4,prc+2,st,size,11,&pos);
  strcat(st,",");
  prc = disfordel(reg,prc,st,size,mode,&pos);
  plot_text_window(&debugdisass,st,0,y);
  return prc;
}

void i04ini(void)
{
  ULO op=0x0600,ind,modes,regs,flats,size;
  for (size = 0; size < 3; size++)
    for (modes = 0; modes < 8; modes++) 
      for (regs = 0; regs < 8; regs++) {
        flats = (modes != 7) ? modes : modes+regs;
        if (data[flats] && alterable[flats]) {
          ind = op|size<<6|modes<<3|regs;
          t[ind][0] = (size == 0) ?
                         (ULO) i04_B:
                         (size == 1) ?
                            (ULO) i04_W:
                            (ULO) i04_L; 
          t[ind][1] = (ULO) i04dis;
          t[ind][2] = (modes == 0) ?
                         (regs*4 + (ULO) d):
                         (regs*4 + (ULO) a);
          t[ind][3] = (size == 0) ?
                         parb[flats]:
                         (size == 1) ?
                            parw[flats]:
                            parl[flats];
          t[ind][4] = (size == 0) ?
                         (flats == 0) ?
                            8:
                            (12 + tarb[flats]):
                         (size == 1)  ?
                            (flats == 0) ?
                               8:
                               (12 + tarw[flats]):
                            (flats == 0) ?
                               16:
                               (20 + tarl[flats]);
          t[ind][5] = (size == 0) ?
                         awb[flats]:
                         (size == 1) ? 
                            aww[flats]:
                            awl[flats];
          }
        }
}

/*
 Instruction ADDQ.X #i,<ea>
 Table-usage:

  0-Routinepointer 1-disasm routine  2-eareg 3-ea read routine
                4-cycle count    5-ea write routine 6-add immediate              
*/

ULO i05dis(ULO prc,ULO opc,ULO y) 
{
  char st[80];
  ULO pos=13,reg=opc&SREG,mode=(opc&SMOD)>>3,size=size000110(opc&SIZE);
  if (mode == 7) mode += reg;
  sprintf(st,"$%.6X %.4X                   ADDQ.   #$%.1d,",prc,opc,t[opc][6]);
  st[36] = (size == 8) ?
              'B':
              (size == 16) ?
                 'W':
                 'L';
  prc = disfordel(reg,prc+2,st,size,mode,&pos);
  plot_text_window(&debugdisass,st,0,y);
  return prc;
}


void i05ini(void)
{
  ULO op=0x5000,ind,imm,modes,regs,flats,size,o;
    for (size = 0; size < 3; size++)
      for (modes = 0; modes < 8; modes++) 
        for (regs = 0; regs < 8; regs++) 
          for (imm = 0; imm < 8; imm++) {
            flats = (modes != 7) ?
                       modes:
                       modes+regs;
            if ((size == 0 && alterable[flats] && modes != 1) ||
                (size != 0 && alterable[flats])) {
              ind = op|imm<<9|size<<6|modes<<3|regs;
              if (modes == 1 && (size > 0)) t[ind][0] = (ULO) i05_ADR;
              else
                t[ind][0] =
                          (size == 0) ?
                             (ULO) i05_B:
                             (size == 1) ?
                                (ULO) i05_W:
                                (ULO) i05_L;
              t[ind][1] = (ULO) i05dis;
              t[ind][2] = (modes == 0) ?
                             (regs*4 + (ULO) d):
                             (regs*4 + (ULO) a);
              t[ind][3] = (size == 0) ?
                             parb[flats]:
                             (size == 1) ?
                                parw[flats]:
                                parl[flats];
              t[ind][4] = (size == 0) ?
                             (flats == 0) ?
                                (4+tarb[flats]):
                                (8+tarb[flats]):
                             (size == 1) ?
                                (flats == 0) ?
                                   (4+tarw[flats]):
                                   (8+tarw[flats]):
                                (flats < 2) ?
                                   (8+tarl[flats]):
                                   (12+tarl[flats]);
              t[ind][5] = (size == 0) ?
                             awb[flats]:
                             (size == 1) ?
                                aww[flats]:
                                awl[flats];
              t[ind][6] = (imm == 0) ?
                             8:
                             imm;
              }
            }
}

/*
 Instruction ADDX.X Ry,Rx / ADD.X -(Ay),-(Ax)
 Table-usage: 0 - Routinepointer 1 - disasm routine 2 - Rx*4(dest) 3 - Ry*4
*/

ULO i06dis(ULO prc,ULO opc,ULO y)
{
  char st[80];
  ULO size=(opc&0x00c0)>>6;
  sprintf(st,(((opc&0x8) == 0) ?
                "$%.6X %.4X                   ADDX.%s   D%d,D%d":
                "$%.6X %.4X                   ADDX.%s   -(A%d),-(A%d)"),
                prc,opc,(size == 0) ? "B":((size == 1) ? "W":"L"),(opc&SREG),(opc&DREG)>>9);
  plot_text_window(&debugdisass,st,0,y);
  return prc+2;
}

void i06ini(void)
{
  ULO op=0xd100,ind,rm,rx,ry,sz;
  for (sz = 0; sz <= 2; sz++)
    for (rm = 0; rm <= 1; rm++)
      for (rx = 0; rx <= 7; rx++) 
        for (ry = 0; ry <= 7; ry++) {
          ind = op|ry|rx<<9|rm<<3|sz<<6;
          t[ind][0] = (rm == 0) ?
                       ((sz == 0) ?
                          (ULO) i06_B_1:
                          (sz == 1) ?
                             (ULO) i06_W_1:
                             (ULO) i06_L_1):
                       ((sz == 0) ?
                          (ULO) i06_B_2:
                          (sz == 1) ?
                             (ULO) i06_W_2:
                             (ULO) i06_L_2);
        t[ind][1] = (ULO) i06dis;
        t[ind][2] = (rm == 0) ?
                       (rx*4 + (ULO) d):
                       (rx*4 + (ULO) a);
        t[ind][3] = (rm == 0) ?
                       (ry*4 + (ULO) d):
                       (ry*4 + (ULO) a);
        }
}

/*
 Instruction AND.X <ea>,Dn / AND.X Dn,<ea>
 Table-usage:
 Type 1:  and <ea>,Dn

  0-Routinepointer 1-disasm routine  2-sourreg 3-sourceroutine
                   4-Dreg        5-cycle count                   
 Type 2:  and Dn,<ea>

  0-Routinepointer 1-disasm routine  2-<ea>reg 3-get <ea> routine
                   4-Dreg        5-cycle count   6-write<ea> routine                
*/


ULO i07dis(ULO prc,ULO opc,ULO y) 
{
  char st[80];
  ULO pos=13,reg=opc&SREG,dreg=(opc&DREG)>>9,o=opc&0x100,mode=(opc&SMOD)>>3,
      size=size000110(opc&SIZE);
  if (mode == 7) mode += reg;
  sprintf(st,"$%.6X %.4X                   AND.    ",prc,opc);
  st[35] = (size == 8) ?
              'B':
              (size == 16) ?
                 'W':
                 'L';
  prc = (o == 0) ? disfordel(reg,prc+2,st,size,mode,&pos) :
                   disfordel(dreg,prc+2,st,size,0,&pos);
  strcat(st,",");
  prc = (o != 0) ? disfordel(reg,prc,st,size,mode,&pos) :
                   disfordel(dreg,prc,st,size,0,&pos);
  plot_text_window(&debugdisass,st,0,y);
  return prc;
}

void i07ini(void)
{
  ULO op=0xc000,ind,regd,modes,regs,flats,size,o;
  for (o = 0; o < 2; o++)
    for (size = 0; size < 3; size++)
      for (regd = 0; regd < 8; regd++) 
        for (modes = 0; modes < 8; modes++) 
          for (regs = 0; regs < 8; regs++) {
            flats = (modes != 7) ?
                       modes:
                       (modes+regs);
            if ((o==0 && data[flats]) ||
                (o==1 && alterable[flats] && memory[flats])) {
              ind = op|regd<<9|o<<8|size<<6|modes<<3|regs;
              t[ind][0] = (o == 0) ?
                             (size == 0) ?
                                (ULO) i07_B_1:
                                (size == 1) ?
                                   (ULO) i07_W_1:
                                   (ULO) i07_L_1:
                             (size == 0) ?
                                (ULO) i07_B_2:
                                (size == 1) ?
                                   (ULO) i07_W_2:
                                   (ULO) i07_L_2;
              t[ind][1] = (ULO) i07dis;
              t[ind][2] = (modes == 0) ?
                             (regs*4 + (ULO) d):
                             (regs*4 + (ULO) a);
              t[ind][3] = (o == 0) ?
                             (size == 0) ?
                                arb[flats]:
                                (size == 1) ?
                                   arw[flats]:
                                   arl[flats]:
                             (size == 0) ?
                                parb[flats]:
                                (size == 1) ?
                                   parw[flats]:
                                   parl[flats];
              t[ind][4] = regd*4 + (ULO) d;
              t[ind][5] = (o == 0) ?
                             (size == 0) ?
                                (4+tarb[flats]):
                                (size == 1) ?
                                   (4+tarw[flats]):
                                   (flats <= 1 || flats == 11) ?
                                      (8+tarl[flats]):
                                      (6+tarl[flats]):
                             (size == 0) ?
                                (8 + tarb[flats]):
                                (size == 1) ?
                                   (8 + tarw[flats]):
                                   (12 + tarl[flats]);
              if (o == 1) t[ind][6] = (size == 0) ?
                                         awb[flats]:
                                         (size == 1) ?
                                            aww[flats]:
                                            awl[flats];
              }
            }
}



/*
 Instruction ANDI.X #i,<ea>
 Table-usage:

  0-Routinepointer 1-disasm routine  2-eareg 3-ea read routine
                4-cycle count    5-ea write routine               
*/


ULO i08dis(ULO prc,ULO opc,ULO y) 
{
  char st[80];
  ULO pos=13,reg=opc&SREG,mode=(opc&SMOD)>>3,size=size000110(opc&SIZE);
  if (mode == 7) mode += reg;
  if (mode == 11 && size == 16)
    sprintf(st,"$%.6X %.4X            (PRIV) ANDI.   ",prc,opc);
  else
    sprintf(st,"$%.6X %.4X                   ANDI.   ",prc,opc);
  st[36] = (size == 8) ?
              'B':
              (size == 16) ?
                 'W':
                 'L';
  prc = disfordel(4,prc+2,st,size,11,&pos);
  strcat(st,",");
  if (mode == 11) strcat(st,(size == 8) ? "CCR":"SR");
  else prc = disfordel(reg,prc,st,size,mode,&pos);
  plot_text_window(&debugdisass,st,0,y);
  return prc;
}

void i08ini(void)
{
  ULO op=0x0200,ind,modes,regs,flats,size;
  for (size = 0; size < 3; size++)
    for (modes = 0; modes < 8; modes++) 
      for (regs = 0; regs < 8; regs++) {
        flats = (modes != 7) ? modes : modes+regs;
        if ((data[flats] && alterable[flats]) || (flats == 11 && size < 2)) {
          ind = op|size<<6|modes<<3|regs;
          t[ind][0] = (size == 0) ?
                         ((flats == 11) ?
                           (ULO) i08_B_CCR:
                           (ULO) i08_B):
                         (size == 1) ?
                            ((flats == 11) ?
                              (ULO) i08_W_SR:
                              (ULO) i08_W):
                            (ULO) i08_L; 
          t[ind][1] = (ULO) i08dis;
          t[ind][2] = (modes == 0) ?
                         (regs*4 + (ULO) d):
                         (regs*4 + (ULO) a);
          t[ind][3] = (size == 0) ?
                         parb[flats]:
                         (size == 1) ?
                            parw[flats]:
                            parl[flats];
          t[ind][4] = (flats == 11) ?
                        20:
                        (size == 0) ?
                         (flats == 0) ?
                            8:
                            (12 + tarb[flats]):
                         (size == 1)  ?
                            (flats == 0) ?
                               8:
                               (12 + tarw[flats]):
                            (flats == 0) ?
                               16:
                               (20 + tarl[flats]);
          t[ind][5] = (size == 0) ?
                         awb[flats]:
                         (size == 1) ? 
                            aww[flats]:
                            awl[flats];
          }
        }
}


/*
 Instruction ASL/ASR.X #i,<ea>
 3 versions: 
 Table-usage:

 ASX.X Dx,Dy
  0-Routinepointer 1-disasm routine  2-shcountreg 3-dreg
                4-cycle count               

 ASX.X #,Dy
  0-Routinepointer 1-disasm routine  2-shiftcount 3-dreg
                4-cycle count               

 ASX.X #1,<ea>
  0-Routinepointer 1-disasm routine  2-eareg 3-earead
                4-eawrite        5-cycle count               
*/


ULO i09dis(ULO prc,ULO opc,ULO y) 
{
  char st[80];
  ULO pos=13,reg=opc&SREG,mode=(opc&SMOD)>>3,size=((opc&SIZE) == 0xc0) ?
                                                      64:size000110(opc&SIZE);
  if (mode == 7) mode += reg;
  if (size == 64) {
    sprintf(st,"$%.6X %.4X                   AS .W   #$1,",prc,opc);
    prc = disfordel(reg,prc+2,st,16,mode,&pos);
    }
  else {
    if ((opc&BIT5) == 0)
      sprintf(st,"$%.6X %.4X                   AS .    #$%1X,D%1d",prc,opc,t[opc][2],reg);
    else  
      sprintf(st,"$%.6X %.4X                   AS .    D%1d,D%1d",prc,opc,(t[opc][2]-(ULO)d)>>2,(t[opc][3]-(ULO)d)>>2);
    st[35] = (size == 8) ?
                'B':
                (size == 16) ?
                   'W':
                   'L';
    prc += 2;
    }
  st[33] = ((opc&BIT8) == 0) ? 'R':'L';
  plot_text_window(&debugdisass,st,0,y);
  return prc;
}

void i09ini(void)
{
  ULO op=0xe000,ind,dir,modes,regs,regc,flats,size,immreg;
  for (size = 0; size < 3; size++)
    for (regc = 0; regc < 8; regc++) 
      for (dir = 0; dir < 2; dir++) 
        for (regs = 0; regs < 8; regs++)
          for (immreg = 0; immreg < 2; immreg++) {
            ind = op|regc<<9|dir<<8|size<<6|immreg<<5|regs;
            t[ind][0] = (size == 0) ?
                           ((immreg==0) ?
                             ((dir==0) ?
                               (ULO) i09_RI_I_B:
                               (ULO) i09_LE_I_B):
                             ((dir==0) ?
                               (ULO) i09_RI_R_B:
                               (ULO) i09_LE_R_B)):
                           ((size == 1) ?
                             ((immreg==0) ?
                               ((dir==0) ?
                                 (ULO) i09_RI_I_W:
                                 (ULO) i09_LE_I_W):
                               ((dir==0) ?
                                 (ULO) i09_RI_R_W:
                                 (ULO) i09_LE_R_W)):
                             ((immreg==0) ?
                               ((dir==0) ?
                                 (ULO) i09_RI_I_L:
                                 (ULO) i09_LE_I_L):
                               ((dir==0) ?
                                 (ULO) i09_RI_R_L:
                                 (ULO) i09_LE_R_L)));
            t[ind][1] = (ULO) i09dis;
            t[ind][2] = (immreg == 0) ?
                          ((regc == 0) ?
                            8:
                            regc):
                          (regc*4 + (ULO) d);
            t[ind][3] = regs*4 + (ULO) d;
            t[ind][4] = (size == 3) ?
                          ((immreg == 0) ?
                            (8+(t[ind][2]*2)):
                            8):
                          ((immreg == 0) ?
                            (6+(t[ind][2]*2)):
                            6);
            }


  op = 0xe0c0;
  for (dir = 0; dir < 2; dir++) 
    for (modes = 0; modes < 8; modes++) 
      for (regs = 0; regs < 8; regs++) {
        flats = (modes != 7) ? modes : modes+regs;
        if (memory[flats] && alterable[flats]) {
          ind = op|dir<<8|modes<<3|regs;
        
          t[ind][0] = (dir == 0) ?
                        (ULO) i09_RI_M_W:
                        (ULO) i09_LE_M_W;
          t[ind][1] = (ULO) i09dis;
          t[ind][2] = (modes == 0) ?
                         (regs*4 + (ULO) d):
                         (regs*4 + (ULO) a);
          t[ind][3] = parw[flats];
          t[ind][4] = aww[flats];
          t[ind][5] = 8+tarw[flats];
          }
        }
}





/*
 Instruction Bcc
 Table-usage:

  0-Routinepointer 1-disasm routine  2-displacement 32 bit 3-handle routine
                4-cycle count  not taken  5-cycle count taken
*/

ULO i11dis(ULO prc,ULO opc,ULO y)
{
  char st[80];
  ULO pos=13,j,adr;
  sprintf(st,"$%.6X %.4X                   B",prc,opc);
  switch ((opc&0xf00)>>8) {
     case 0:  strcat(st,"RA.");
              break;
     case 1:  strcat(st,"SR.");
              break;
     case 2:  strcat(st,"HI.");
              break;
     case 3:  strcat(st,"LS.");
              break;
     case 4:  strcat(st,"CC.");
              break;
     case 5:  strcat(st,"CS.");
              break;
     case 6:  strcat(st,"NE.");
              break;
     case 7:  strcat(st,"EQ.");
              break;
     case 8:  strcat(st,"VC.");
              break;
     case 9:  strcat(st,"VS.");
              break;
     case 10: strcat(st,"PL.");
              break;
     case 11: strcat(st,"MI.");
              break;
     case 12: strcat(st,"GE.");
              break;
     case 13: strcat(st,"LT.");
              break;
     case 14: strcat(st,"GT.");
              break;
     case 15: strcat(st,"LE.");
              break;
       }
  strcat(st,(t[opc][2] == 0) ? "W  ":"B  ");
  if (t[opc][2] == 0) {
    prc += 2;
    j = fetw(prc);
    sprintf(&st[13],"%4.4X",j);
    st[17] = ' ';
    adr = (j > 32767) ?
             prc+j-65536:
             prc+j; 
    }
  else adr = prc+2+t[opc][2];
  sprintf(&st[36],"   $%6.6X",adr);
  plot_text_window(&debugdisass,st,0,y);
  return prc+2;
}


void i11ini(void)
{
  ULO op=0x6000,c,ind;
  int di;
  ULO routines[16] = {(ULO) cc0,(ULO) cc1,(ULO) cc2,(ULO) cc3,(ULO) cc4,(ULO) cc5,(ULO) cc6,(ULO) cc7,(ULO) cc8,(ULO) cc9,(ULO) cca,(ULO) ccb,(ULO) ccc,(ULO) ccd,(ULO) cce,(ULO) ccf};
  for (c = 0; c < 16; c++)
    for (di = -128; di < 128; di++) {
      ind = op|di&0xff|c<<8;
      t[ind][0] = (di==0) ?
                     (ULO) i11_W:
                     (ULO) i11_B;
      t[ind][1] = (ULO) i11dis;
      t[ind][2] = di;
      t[ind][3] = routines[c];
      t[ind][4] = (di==0) ? 12:8;
      t[ind][5] = 10;
      }
}

/*
 Instruction BCHG.B/L 
 Table-usage dynamic:
 2 - eareg 3-earead 4-reg 5-cycle count 6-eawrite
 Table-usage static:
 2 - eareg 3-earead 4-cycle count 5-eawrite
*/

ULO i12dis(ULO prc,ULO opc,ULO y) 
{
  char st[80];
  ULO pos=18-(5*((opc&BIT8)>>8)),reg=opc&SREG,bitreg=(opc&DREG)>>9,
      mode=(opc&SMOD)>>3;

  if (mode == 7) mode += reg;
  if (pos == 18) {
    sprintf(st,"$%.6X %.4X %.4X              BCHG.%s  #$%.4X,",prc,opc,fetw(prc+2),
            (mode == 0) ? "L":"B",fetw(prc+2)&((mode == 0) ? 0x1f:0x7));
    prc += 2;
    }
  else sprintf(st,"$%.6X %.4X                   BCHG.%s  D%1X,",prc,opc,
               (mode == 0) ? "L":"B",bitreg);
  prc = disfordel(reg,prc+2,st,8,mode,&pos);
  plot_text_window(&debugdisass,st,0,y);
  return prc;
}


void i12ini(void)
{
  ULO op=0x0140,ind,breg,mode,reg,flat;

/* Dynamic first */

  for (breg = 0; breg < 8; breg++)
    for (mode = 0; mode < 8; mode++) 
      for (reg = 0; reg < 8; reg++) {
        flat = (mode != 7) ? mode : mode+reg;
        if (data[flat] && alterable[flat]) {
          ind = op|breg<<9|mode<<3|reg;
          t[ind][0] = (mode == 0) ? (ULO) i12_D_L:
                                    (ULO) i12_D_B;
          t[ind][1] = (ULO) i12dis;
          t[ind][2] = reg*4 + ((mode == 0) ? (ULO) d:
                                             (ULO) a);
          t[ind][3] = parb[flat];
          t[ind][4] = breg*4 + (ULO) d;
          t[ind][5] = (mode == 0) ? 8:
                                    (8+tarb[flat]);
          t[ind][6] = awb[flat];
          }
        }
/* Static */
  op=0x0840;
  for (mode = 0; mode < 8; mode++)
    for (reg = 0; reg < 8; reg++) {
      flat = (mode != 7) ? mode : mode+reg;
      if (data[flat] && alterable[flat]) {
        ind = op|mode<<3|reg;
        t[ind][0] = (mode == 0) ? (ULO) i12_S_L:
                                  (ULO) i12_S_B;
        t[ind][1] = (ULO) i12dis;
        t[ind][2] = reg*4 + ((mode == 0) ? (ULO) d:
                                           (ULO) a);
        t[ind][3] = parb[flat];
        t[ind][4] = (mode == 0) ? 12:
                                  (12+tarb[flat]);
        t[ind][5] = awb[flat];
        }
      }
}

/*
 Instruction BCLR.B/L 
 Table-usage dynamic:
 2 - eareg 3-earead 4-reg 5-cycle count 6-eawrite
 Table-usage static:
 2 - eareg 3-earead 4-cycle count 5-eawrite
*/

ULO i13dis(ULO prc,ULO opc,ULO y) 
{
  char st[80];
  ULO pos=18-(5*((opc&BIT8)>>8)),reg=opc & SREG,bitreg=(opc & DREG)>>9,mode=(opc & SMOD)>>3;

  if (mode == 7) mode += reg;
  if (pos == 18) {
    sprintf(st,"$%.6X %.4X %.4X              BCLR.%s  #$%.4X,",prc,opc,fetw(prc+2),
            (mode == 0) ? "L":"B",fetw(prc+2)&((mode == 0) ? 0x1f:0x7));
    prc += 2;
    }
  else sprintf(st,"$%.6X %.4X                   BCLR.%s  D%1X,",prc,opc,
               (mode == 0) ? "L":"B",bitreg);
  prc = disfordel(reg,prc+2,st,8,mode,&pos);
  plot_text_window(&debugdisass,st,0,y);
  return prc;
}


void i13ini(void)
{
  ULO op=0x0180,ind,breg,mode,reg,flat;

/* Dymnamisk f�rst */

  for (breg = 0; breg < 8; breg++)
    for (mode = 0; mode < 8; mode++) 
      for (reg = 0; reg < 8; reg++) {
        flat = (mode != 7) ? mode : mode+reg;
        if (data[flat] && alterable[flat]) {
          ind = op|breg<<9|mode<<3|reg;
          t[ind][0] = (mode == 0) ? (ULO) i13_D_L:
                                    (ULO) i13_D_B;
          t[ind][1] = (ULO) i13dis;
          t[ind][2] = reg*4 + ((mode == 0) ? (ULO) d:
                                             (ULO) a);
          t[ind][3] = (mode == 0) ? parl[flat]:
                                    parb[flat];
          t[ind][4] = breg*4 + (ULO) d;
          t[ind][5] = (mode == 0) ? 10:
                                    (8+tarb[flat]);
          t[ind][6] = (mode == 0) ? awl[flat]:
                                    awb[flat];
          }
        }
/* Static */
  op=0x0880;
  for (mode = 0; mode < 8; mode++)
    for (reg = 0; reg < 8; reg++) {
      flat = (mode != 7) ? mode : mode+reg;
      if (data[flat] && alterable[flat]) {
        ind = op|mode<<3|reg;
        t[ind][0] = (mode == 0) ? (ULO) i13_S_L:
                                  (ULO) i13_S_B;
        t[ind][1] = (ULO) i13dis;
        t[ind][2] = reg*4 + ((mode == 0) ? (ULO) d:
                                           (ULO) a);
        t[ind][3] = (mode == 0) ? parl[flat]:
                                  parb[flat];
        t[ind][4] = (mode == 0) ? 14:
                                  (12+tarb[flat]);
        t[ind][5] = (mode == 0) ? awl[flat]:
                                  awb[flat];
        }
      }
}

/*
 Instruction BSET.B/L 
 Table-usage dynamic:
 2 - eareg 3-earead 4-reg 5-cycle count 6-eawrite
 Table-usage static:
 2 - eareg 3-earead 4-cycle count 5-eawrite
*/

ULO i15dis(ULO prc,ULO opc,ULO y) 
{
  char st[80];
  ULO pos=18-(5*((opc&BIT8)>>8)),reg=opc & SREG,bitreg=(opc & DREG)>>9,mode=(opc & SMOD)>>3;

  if (mode == 7) mode += reg;
  if (pos == 18) {
    sprintf(st,"$%.6X %.4X %.4X              BSET.%s  #$%.4X,",prc,opc,fetw(prc+2),
            (mode == 0) ? "L":"B",fetw(prc+2)&((mode == 0) ? 0x1f:0x7));
    prc += 2;
    }
  else sprintf(st,"$%.6X %.4X                   BSET.%s  D%1X,",prc,opc,
               (mode == 0) ? "L":"B",bitreg);
  prc = disfordel(reg,prc+2,st,8,mode,&pos);
  plot_text_window(&debugdisass,st,0,y);
  return prc;
}


void i15ini(void)
{
  ULO op=0x01c0,ind,breg,mode,reg,flat;

/* Dynamic first */

  for (breg = 0; breg < 8; breg++)
    for (mode = 0; mode < 8; mode++) 
      for (reg = 0; reg < 8; reg++) {
        flat = (mode != 7) ? mode : mode+reg;
        if (data[flat] && alterable[flat]) {
          ind = op|breg<<9|mode<<3|reg;
          t[ind][0] = (mode == 0) ? (ULO) i15_D_L:
                                    (ULO) i15_D_B;
          t[ind][1] = (ULO) i15dis;
          t[ind][2] = reg*4 + ((mode == 0) ? (ULO) d:
                                             (ULO) a);
          t[ind][3] = (mode == 0) ? parl[flat]:
                                    parb[flat];
          t[ind][4] = breg*4 + (ULO) d;
          t[ind][5] = (mode == 0) ? 8:
                                    (8+tarb[flat]);
          t[ind][6] = (mode == 0) ? awl[flat]:
                                    awb[flat];
          }
        }
/* Static */
  op=0x08c0;
  for (mode = 0; mode < 8; mode++)
    for (reg = 0; reg < 8; reg++) {
      flat = (mode != 7) ? mode : mode+reg;
      if (data[flat] && alterable[flat]) {
        ind = op|mode<<3|reg;
        t[ind][0] = (mode == 0) ? (ULO) i15_S_L:
                                  (ULO) i15_S_B;
        t[ind][1] = (ULO) i15dis;
        t[ind][2] = reg*4 + ((mode == 0) ? (ULO) d:
                                           (ULO) a);
        t[ind][3] = (mode == 0) ? parl[flat]:
                                  parb[flat];
        t[ind][4] = (mode == 0) ? 12:
                                  (12+tarb[flat]);
        t[ind][5] = (mode == 0) ? awl[flat]:
                                  awb[flat];
        }
      }
}

/*
 Instruction BTST.B/L 
 Table-usage dynamic:
 2 - eareg 3-earead 4-reg 5-cycle count
 Table-usage static:
 2 - eareg 3-earead 4-cycle count
*/

ULO i17dis(ULO prc,ULO opc,ULO y) 
{
  char st[80];
  ULO pos=18-(5*((opc&BIT8)>>8)),reg=opc & SREG,bitreg=(opc & DREG)>>9,mode=(opc & SMOD)>>3;

  if (mode == 7) mode += reg;
  if (pos == 18) {
    sprintf(st,"$%.6X %.4X %.4X              BTST.%s  #$%.4X,",prc,opc,fetw(prc+2),
            (mode == 0) ? "L":"B",fetw(prc+2)&((mode == 0) ? 0x1f:0x7));
    prc += 2;
    }
  else sprintf(st,"$%.6X %.4X                   BTST.%s  D%1X,",prc,opc,
               (mode == 0) ? "L":"B",bitreg);
  prc = disfordel(reg,prc+2,st,8,mode,&pos);
  plot_text_window(&debugdisass,st,0,y);
  return prc;
}


void i17ini(void)
{
  ULO op=0x0100,ind,breg,mode,reg,flat;

/* Dynamic first */

  for (breg = 0; breg < 8; breg++)
    for (mode = 0; mode < 8; mode++) 
      for (reg = 0; reg < 8; reg++) {
        flat = (mode != 7) ? mode : mode+reg;
        if (data[flat] && alterable[flat]) {
          ind = op|breg<<9|mode<<3|reg;
          t[ind][0] = (mode == 0) ? (ULO) i17_D_L:
                                    (ULO) i17_D_B;
          t[ind][1] = (ULO) i17dis;
          t[ind][2] = reg*4 + ((mode == 0) ? (ULO) d:
                                             (ULO) a);
          t[ind][3] = (mode == 0) ? arl[flat]:
                                    arb[flat];
          t[ind][4] = breg*4 + (ULO) d;
          t[ind][5] = (mode == 0) ? 6:
                                    (4+tarb[flat]);
          }
        }
/* Static */
  op=0x0800;
  for (mode = 0; mode < 8; mode++)
    for (reg = 0; reg < 8; reg++) {
      flat = (mode != 7) ? mode : mode+reg;
      if (data[flat] && alterable[flat]) {
        ind = op|mode<<3|reg;
        t[ind][0] = (mode == 0) ? (ULO) i17_S_L:
                                  (ULO) i17_S_B;
        t[ind][1] = (ULO) i17dis;
        t[ind][2] = reg*4 + ((mode == 0) ? (ULO) d:
                                           (ULO) a);
        t[ind][3] = (mode == 0) ? arl[flat]:
                                  arb[flat];
        t[ind][4] = (mode == 0) ? 10:
                                  (8+tarb[flat]);
        }
      }
}

/*
 Instruction CHK.W <ea>,Dn
 Table-usage:

  0-Routinepointer 1-disasm routine  2-sourreg 3-sourceroutine
                   4-Dreg        5 - cycle count                     
*/

ULO i18dis(ULO prc,ULO opc,ULO y) 
{
  char st[80];
  ULO pos=13,reg=opc&0x7,dreg=(opc&0xe00)>>9,mode=(opc&0x38)>>3;
  if (mode == 7) mode += reg;
  sprintf(st,"$%.6X %.4X                   CHK.W   ",prc,opc);
  prc = disfordel(reg,prc+2,st,16,mode,&pos);
  strcat(st,",");
  disfordel(dreg,prc,st,16,0,&pos);
  plot_text_window(&debugdisass,st,0,y);
  return prc;
}

void i18ini(void)
{
  ULO op=0x4180,ind,regd,modes,regs,flats;
  for (regd = 0; regd < 8; regd++) 
    for (modes = 0; modes < 8; modes++) 
      for (regs = 0; regs < 8; regs++) 
        if (data[(flats = (modes != 7) ? modes : modes+regs)]) {
          ind = op|regd<<9|modes<<3|regs;
          t[ind][0] = (ULO) i18;
          t[ind][1] = (ULO) i18dis;
          t[ind][2] = regs*4 + ((modes == 0) ?
                                  (ULO) d:
                                  (ULO) a);
          t[ind][3] = arw[flats];
          t[ind][4] = regd*4 + (ULO) d;
          t[ind][5] = 10+tarw[flats];
          }
}

/*
 Instruction CLR.X <ea>
 Table-usage:
  0-Routinepointer 1-disasm routine  2-sourreg 3-sourceroutine
                   4-cycle count                   
*/

ULO i19dis(ULO prc,ULO opc,ULO y) 
{
  char st[80];
  ULO pos=13,reg=opc&0x7,mode=(opc&0x38)>>3,size=(1+((opc&0xc0)>>6))<<3;
  if (mode == 7) mode += reg;
  sprintf(st,"$%.6X %.4X                   CLR.    ",prc,opc);
  st[35] = (size == 8) ?
              'B':
              (size == 16) ?
                 'W':
                 'L';
  prc = disfordel(reg,prc+2,st,size,mode,&pos);
  plot_text_window(&debugdisass,st,0,y);
  return prc;
}

void i19ini(void)
{
  ULO op=0x4200,ind,modes,regs,flats,size;
  for (size = 0; size < 3; size++)
    for (modes = 0; modes < 8; modes++) 
      for (regs = 0; regs < 8; regs++) {
        flats = (modes != 7) ?
                   modes:
                   modes+regs;
        if (data[flats] && alterable[flats]) {
          ind = op|size<<6|modes<<3|regs;
        t[ind][0] = (ULO) i19;
        t[ind][1] = (ULO) i19dis;
        t[ind][2] = (modes == 0) ?
                       (regs*4 + (ULO) d):
                       (regs*4 + (ULO) a);
        t[ind][3] = (size == 0) ?
                       awb[flats]:
                       (size == 1) ?
                          aww[flats]:
                          awl[flats];
        t[ind][4] = (size == 0) ?
                       4+tarb[flats]:
                       (size == 1) ?
                          (4+tarw[flats]):
                          (modes == 0) ?
                             6:
                             (4+tarl[flats]);
        }
      }
}

/*
 Instruction CMP.X <ea>,Dn / CMP.X Dn,<ea>
 Table-usage:
 Type 1:  CMP <ea>,Dn
  0-Routinepointer 1-disasm routine  2-sourreg 3-sourceroutine
                   4-Dreg        5-cycle count                   
*/

ULO i20dis(ULO prc,ULO opc,ULO y) 
{
  char st[80];
  ULO pos=13,reg=opc&0x7,dreg=(opc&0xe00)>>9,mode=(opc&0x38)>>3,
      size=(1+((opc&0xc0)>>6))<<3;
  if (mode == 7) mode += reg;
  sprintf(st,"$%.6X %.4X                   CMP.    ",prc,opc);
  st[35] = (size == 8) ?
              'B':
              (size == 16) ?
                 'W':
                 'L';
  prc = disfordel(reg,prc+2,st,size,mode,&pos);
  strcat(st,",");
  disfordel(dreg,prc,st,size,0,&pos);
  plot_text_window(&debugdisass,st,0,y);
  return prc;
}

void i20ini(void)
{
  ULO op=0xb000,ind,regd,modes,regs,flats,size;
  for (size = 0; size < 3; size++)
    for (regd = 0; regd < 8; regd++) 
      for (modes = 0; modes < 8; modes++) 
        for (regs = 0; regs < 8; regs++) {
          flats = (modes != 7) ?
                     modes:
                     (modes+regs);
          if ((size == 0 && data[flats]) ||
              (size != 0 && allmodes[flats])) {
            ind = op|regd<<9|size<<6|modes<<3|regs;
            t[ind][0] = (size == 0) ?
                           (ULO) i20_B:
                           (size == 1) ?
                              (ULO) i20_W:
                              (ULO) i20_L;
            t[ind][1] = (ULO) i20dis;
            t[ind][2] = (modes == 0) ?
                           (regs*4 + (ULO) d):
                           (regs*4 + (ULO) a);
            t[ind][3] = (size == 0) ?
                           arb[flats]:
                           (size == 1) ?
                              arw[flats]:
                              arl[flats];
            t[ind][4] = regd*4 + (ULO) d;
            t[ind][5] = (size == 0) ?
                           (4+tarb[flats]):
                           (size == 1) ?
                              (4+tarw[flats]):
                              (6+tarl[flats]);
            }
          }
}

/*
 Instruction CMPA.W/L <ea>,An
 Table-usage:

  0-Routinepointer 1-disasm routine  2-sourreg 3-sourceroutine
                   4-Areg        5-cycle count                   
*/

ULO i21dis(ULO prc,ULO opc,ULO y) 
{
  char st[80];
  ULO pos=13,reg=opc&0x7,dreg=(opc&0xe00)>>9,o=opc&0x100,mode=(opc&0x38)>>3,size;
  size = (o == 0) ?
            16:
            32;
  if (mode == 7) mode += reg;
  sprintf(st,"$%.6X %.4X                   CMPA.   ",prc,opc);
  st[36] = (size == 16) ?
              'W':
              'L';
  prc = disfordel(reg,prc+2,st,size,mode,&pos);
  strcat(st,",");
  disfordel(dreg,prc,st,size,1,&pos);
  plot_text_window(&debugdisass,st,0,y);
  return prc;
}

void i21ini(void)
{
  ULO op=0xb0c0,ind,regd,modes,regs,flats,o;
  for (o = 0; o < 2; o++)
    for (regd = 0; regd < 8; regd++) 
      for (modes = 0; modes < 8; modes++) 
        for (regs = 0; regs < 8; regs++) 
          if (allmodes[(flats = (modes != 7) ? modes : (modes+regs))]) {
            ind = op|regd<<9|o<<8|modes<<3|regs;
            t[ind][0] = (o == 0) ?
                           (ULO) i21_W:
                           (ULO) i21_L;
            t[ind][1] = (ULO) i21dis;
            t[ind][2] = (modes == 0) ?
                           (regs*4 + (ULO) d):
                           (regs*4 + (ULO) a);
            t[ind][3] = (o == 0) ?
                           arw[flats]:
                           arl[flats];
            t[ind][4] = regd*4 + (ULO) a;
            t[ind][5] = (o==0) ?
                           (6 + tarw[flats]):
                           (6 + tarl[flats]);
            }
}


/*
 Instruction CMPI.X #i,<ea>
 Table-usage:

  0-Routinepointer 1-disasm routine  2-eareg 3-ea read routine
                4-cycle count               
*/

ULO i22dis(ULO prc,ULO opc,ULO y) 
{
  char st[80];
  ULO pos=13,reg=opc&0x7,mode=(opc&0x38)>>3,size=(1+((opc&0xc0)>>6))<<3;
  if (mode == 7) mode += reg;
  sprintf(st,"$%.6X %.4X                   CMPI.   ",prc,opc);
  st[36] = (size == 8) ?
              'B':
              (size == 16) ?
                 'W':
                 'L';
  prc = disfordel(4,prc+2,st,size,11,&pos);
  strcat(st,",");
  prc = disfordel(reg,prc,st,size,mode,&pos);
  plot_text_window(&debugdisass,st,0,y);
  return prc;
}

void i22ini(void)
{
  ULO op=0x0c00,ind,modes,regs,flats,size;
  for (size = 0; size < 3; size++)
    for (modes = 0; modes < 8; modes++) 
      for (regs = 0; regs < 8; regs++) {
        flats = (modes != 7) ? modes : (modes+regs);
        if (data[flats] && alterable[flats]) {
          ind = op|size<<6|modes<<3|regs;
          t[ind][0] = (size == 0) ?
                         (ULO) i22_B:
                         (size == 1) ?
                            (ULO) i22_W:
                            (ULO) i22_L; 
          t[ind][1] = (ULO) i22dis;
          t[ind][2] = (modes == 0) ?
                         (regs*4 + (ULO) d):
                         (regs*4 + (ULO) a);
          t[ind][3] = (size == 0) ?
                         arb[flats]:
                         (size == 1) ?
                            arw[flats]:
                            arl[flats];
          t[ind][4] = (size == 0) ?
                         (8 + tarb[flats]):
                         (size == 1)  ?
                            (8 + tarw[flats]):
                            (flats == 0) ?
                               14:
                               (12 + tarl[flats]);
          }
        }
}

/*
 Instruction CMPM.X (Ay)+,(Ax)+
 Table-usage: 0 - Routinepointer 1 - disasm routine 2 - sou 3 - dest
*/

ULO i23dis(ULO prc,ULO opc,ULO y)
{
  char st[80];
  ULO size=(opc&0xc0)>>6;
  sprintf(st,("$%.6X %.4X                   CMPX.%s  (A%1d)+,(A%1d)+"),
             prc,opc,(size == 0) ? "B":((size == 1) ? "W":"L"),opc&SREG,(opc&DREG)>>9);
  plot_text_window(&debugdisass,st,0,y);
  return prc+2;
}

void i23ini(void)
{
  ULO op=0xb108,ind,rx,ry,sz;
  for (sz = 0; sz <= 2; sz++)
      for (rx = 0; rx <= 7; rx++) 
        for (ry = 0; ry <= 7; ry++) {
          ind = op|ry|rx<<9|sz<<6;
        t[ind][0] = (sz == 0) ?
                      (ULO) i23_B:
                      (sz == 1) ?
                        (ULO) i23_W:
                        (ULO) i23_L;
        t[ind][1] = (ULO) i23dis;
        t[ind][2] = (ry*4 + (ULO) a);
        t[ind][3] = (rx*4 + (ULO) a);
        }
}
/*
 Instruction DBcc Dn,offset
 Table-usage:

  0-Routinepointer 1-disasm routine  2-displacement 32 bit 3-handle routine
*/

ULO i24dis(ULO prc,ULO opc,ULO y)
{
  char st[80];
  ULO pos=13,j,adr;
  prc += 2;
  j = fetw(prc);
  adr = (j > 32767) ?
           prc+j-65536:
           prc+j; 
  sprintf(st,"$%.6X %.4X %.4X              DB",prc-2,opc,j);
  switch ((opc&0xf00)>>8) {
     case 0:  strcat(st,"T    ");
              break;
     case 1:  strcat(st,"F    ");
              break;
     case 2:  strcat(st,"HI   ");
              break;
     case 3:  strcat(st,"LS   ");
              break;
     case 4:  strcat(st,"CC   ");
              break;
     case 5:  strcat(st,"CS   ");
              break;
     case 6:  strcat(st,"NE   ");
              break;
     case 7:  strcat(st,"EQ   ");
              break;
     case 8:  strcat(st,"VC   ");
              break;
     case 9:  strcat(st,"VS   ");
              break;
     case 10: strcat(st,"PL   ");
              break;
     case 11: strcat(st,"MI   ");
              break;
     case 12: strcat(st,"GE   ");
              break;
     case 13: strcat(st,"LT   ");
              break;
     case 14: strcat(st,"GT   ");
              break;
     case 15: strcat(st,"LE   ");
              break;
       }
  sprintf(&st[36],"   D%1d,$%6.6X",opc&0x7,adr);
  plot_text_window(&debugdisass,st,0,y);
  return prc+2;
}


void i24ini(void)
{
  ULO op=0x50c8,c,ind,reg;
  ULO routines[16] = {(ULO) cc0,(ULO) cc1false,(ULO) cc2,(ULO) cc3,(ULO) cc4,(ULO) cc5,(ULO) cc6,(ULO) cc7,(ULO) cc8,(ULO) cc9,(ULO) cca,(ULO) ccb,(ULO) ccc,(ULO) ccd,(ULO) cce,(ULO) ccf};
  for (c = 0; c < 16; c++)
    for (reg = 0; reg < 8; reg++) {
      ind = op|reg|c<<8;
      t[ind][0] = (ULO) i24;
      t[ind][1] = (ULO) i24dis;
      t[ind][2] = (reg*4) + (ULO) d;
      t[ind][3] = routines[c];
      }
}

/*
 Instruction DIVS.W <ea>,Dn
 Table-usage:

  0-Routinepointer 1-disasm routine  2-sourreg 3-sourceroutine
                   4-Dreg                          
*/

ULO i25dis(ULO prc,ULO opc,ULO y) 
{
  char st[80];
  ULO pos=13,reg=opc&0x7,dreg=(opc&0xe00)>>9,mode=(opc&0x38)>>3;
  if (mode == 7) mode += reg;
  sprintf(st,"$%.6X %.4X                   DIVS.W  ",prc,opc);
  prc = disfordel(reg,prc+2,st,16,mode,&pos);
  strcat(st,",");
  disfordel(dreg,prc,st,16,0,&pos);
  plot_text_window(&debugdisass,st,0,y);
  return prc;
}

void i25ini(void)
{
  ULO op=0x81c0,ind,regd,modes,regs,flats;
  for (regd = 0; regd < 8; regd++) 
    for (modes = 0; modes < 8; modes++) 
      for (regs = 0; regs < 8; regs++) 
        if (data[(flats = (modes != 7) ? modes : (modes+regs))]) {
          ind = op|regd<<9|modes<<3|regs;
          t[ind][0] = (ULO) i25;
          t[ind][1] = (ULO) i25dis;
          t[ind][2] = regs*4 + ((modes == 0) ?
                                  (ULO) d:
                                  (ULO) a);
          t[ind][3] = arw[flats];
          t[ind][4] = regd*4 + (ULO) d;
          }
}

/*
 Instruction DIVU.W <ea>,Dn
 Table-usage:

  0-Routinepointer 1-disasm routine  2-sourreg 3-sourceroutine
                   4-Dreg                          
*/

ULO i26dis(ULO prc,ULO opc,ULO y) 
{
  char st[80];
  ULO pos=13,reg=opc&0x7,dreg=(opc&0xe00)>>9,mode=(opc&0x38)>>3;
  if (mode == 7) mode += reg;
  sprintf(st,"$%.6X %.4X                   DIVU.W  ",prc,opc);
  prc = disfordel(reg,prc+2,st,16,mode,&pos);
  strcat(st,",");
  disfordel(dreg,prc,st,16,0,&pos);
  plot_text_window(&debugdisass,st,0,y);
  return prc;
}

void i26ini(void)
{
  ULO op=0x80c0,ind,regd,modes,regs,flats;
  for (regd = 0; regd < 8; regd++) 
    for (modes = 0; modes < 8; modes++) 
      for (regs = 0; regs < 8; regs++) 
        if (data[(flats = (modes != 7) ? modes : (modes+regs))]) {
          ind = op|regd<<9|modes<<3|regs;
          t[ind][0] = (ULO) i26;
          t[ind][1] = (ULO) i26dis;
          t[ind][2] = regs*4 + ((modes == 0) ?
                                  (ULO) d:
                                  (ULO) a);
          t[ind][3] = arw[flats];
          t[ind][4] = regd*4 + (ULO) d;
          }
}

/*
 Instruction EOR.X <ea>,Dn / EOR.X Dn,<ea>
 Table-usage:
 EOR Dn,<ea>
     0-Routinepointer 1-disasm routine  2-<ea>reg 3-get <ea> routine
                   4-Dreg        5-cycle count   6-write<ea> routine                
*/

ULO i27dis(ULO prc,ULO opc,ULO y)
{
  char st[80];
  ULO pos=13,reg=opc&0x7,dreg=(opc&0xe00)>>9,o=opc&0x100,mode=(opc&0x38)>>3,
      size=(1+((opc&0xc0)>>6))<<3;
  if (mode == 7) mode += reg;
  sprintf(st,"$%.6X %.4X                   EOR.    ",prc,opc);
  st[35] = (size == 8) ?
              'B':
              (size == 16) ?
                 'W':
                 'L';
  prc = disfordel((opc&0xe00)>>9,prc+2,st,size,0,&pos);
  strcat(st,",");
  prc = disfordel(reg,prc,st,size,mode,&pos);
  plot_text_window(&debugdisass,st,0,y);
  return prc;
}

void i27ini(void)
{
  ULO op=0xb100,ind,regd,modes,regs,flats,size;
  for (size = 0; size < 3; size++)
    for (regd = 0; regd < 8; regd++) 
      for (modes = 0; modes < 8; modes++) 
        for (regs = 0; regs < 8; regs++) {
          flats = (modes != 7) ?
                     modes:
                     (modes+regs);
          if (data[flats] && alterable[flats]) {
            ind = op|regd<<9|size<<6|modes<<3|regs;
            t[ind][0] = (size == 0) ?
                           (ULO) i27_B:
                           (size == 1) ?
                              (ULO) i27_W:
                              (ULO) i27_L;
            t[ind][1] = (ULO) i27dis;
            t[ind][2] = (modes == 0) ?
                           (regs*4 + (ULO) d):
                           (regs*4 + (ULO) a);
            t[ind][3] = (size == 0) ?
                           parb[flats]:
                           (size == 1) ?
                              parw[flats]:
                              parl[flats];
            t[ind][4] = regd*4 + (ULO) d;
            t[ind][5] = (size == 0) ?
                           (8 + tarb[flats]):
                           (size == 1) ?
                              (8 + tarw[flats]):
                              (12 + tarl[flats]);
            t[ind][6] = (size == 0) ?
                           awb[flats]:
                           (size == 1) ?
                              aww[flats]:
                              awl[flats];
            }
          }
}



/*
 Instruction EORI.X #i,<ea>
 Table-usage:

  0-Routinepointer 1-disasm routine  2-eareg 3-ea read routine
                4-cycle count    5-ea write routine               
*/


ULO i28dis(ULO prc,ULO opc,ULO y) 
{
  char st[80];
  ULO pos=13,reg=opc&0x7,mode=(opc&0x38)>>3,size=(1+((opc&0xc0)>>6))<<3;
  if (mode == 7) mode += reg;
  if (mode == 11 && size == 16)
    sprintf(st,"$%.6X %.4X            (PRIV) EORI.   ",prc,opc);
  else
    sprintf(st,"$%.6X %.4X                   EORI.   ",prc,opc);
  st[36] = (size == 8) ?
              'B':
              (size == 16) ?
                 'W':
                 'L';
  prc = disfordel(4,prc+2,st,size,11,&pos);
  strcat(st,",");
  if (mode == 11) strcat(st,(size == 8) ? "CCR":"SR");
  else prc = disfordel(reg,prc,st,size,mode,&pos);
  plot_text_window(&debugdisass,st,0,y);
  return prc;
}

void i28ini(void)
{
  ULO op=0x0a00,ind,modes,regs,flats,size;
  for (size = 0; size < 3; size++)
    for (modes = 0; modes < 8; modes++) 
      for (regs = 0; regs < 8; regs++) {
        flats = (modes != 7) ? modes : (modes+regs);
        if ((data[flats] && alterable[flats]) || (flats == 11 && size < 2)) {
          ind = op|size<<6|modes<<3|regs;
          t[ind][0] = (size == 0) ?
                         ((flats == 11) ?
                           (ULO) i28_B_CCR:
                           (ULO) i28_B):
                         (size == 1) ?
                            ((flats == 11) ?
                              (ULO) i28_W_SR:
                              (ULO) i28_W):
                            (ULO) i28_L; 
          t[ind][1] = (ULO) i28dis;
          t[ind][2] = (modes == 0) ?
                         (regs*4 + (ULO) d):
                         (regs*4 + (ULO) a);
          t[ind][3] = (size == 0) ?
                         parb[flats]:
                         (size == 1) ?
                            parw[flats]:
                            parl[flats];
          t[ind][4] = (flats == 11) ?
                        20:
                        (size == 0) ?
                         (flats == 0) ?
                            8:
                            (12 + tarb[flats]):
                         (size == 1)  ?
                            (flats == 0) ?
                               8:
                               (12 + tarw[flats]):
                            (flats == 0) ?
                               16:
                               (20 + tarl[flats]);
          t[ind][5] = (size == 0) ?
                         awb[flats]:
                         (size == 1) ? 
                            aww[flats]:
                            awl[flats];
          }
        }
}


/*
 Instruction exg Rx,Rx
 Table-usage:

  0-Routinepointer 1-disasm routine  2-reg1 3-reg2                   

*/

ULO i29dis(ULO prc,ULO opc,ULO y) 
{
  char st[80];
  ULO pos=13,o=(opc&0x00f8)>>3,reg1=(opc&0xe00)>>9,reg2=opc&7;
  if (o == 8) 
    sprintf(st,"$%.6X %.4X                   EXG.L   D%d,D%d",prc,opc,reg1,reg2);
  else if (o == 9)
    sprintf(st,"$%.6X %.4X                   EXG.L   A%d,A%d",prc,opc,reg1,reg2);
  else
    sprintf(st,"$%.6X %.4X                   EXG.L   A%d,D%d",prc,opc,reg1,reg2);
  plot_text_window(&debugdisass,st,0,y);
  return prc+2;
}

void i29ini(void)
{
  ULO op=0xc100,ind,reg1,reg2;

  for (reg2 = 0; reg2 < 8; reg2++)
    for (reg1 = 0; reg1 < 8; reg1++) {
      ind = op|0x8<<3|reg2<<9|reg1;
      t[ind][0] = (ULO) i29;
      t[ind][1] = (ULO) i29dis;
      t[ind][2] = reg1*4 + (ULO) d;
      t[ind][3] = reg2*4 + (ULO) d;
      }

  for (reg2 = 0; reg2 < 8; reg2++)
    for (reg1 = 0; reg1 < 8; reg1++) {
      ind = op|0x9<<3|reg2<<9|reg1;
      t[ind][0] = (ULO) i29;
      t[ind][1] = (ULO) i29dis;
      t[ind][2] = reg1*4 + (ULO) a;
      t[ind][3] = reg2*4 + (ULO) a;
      }

  for (reg2 = 0; reg2 < 8; reg2++)
    for (reg1 = 0; reg1 < 8; reg1++) {
      ind = op|0x11<<3|reg2<<9|reg1;
      t[ind][0] = (ULO) i29;
      t[ind][1] = (ULO) i29dis;
      t[ind][2] = reg1*4 + (ULO) a;
      t[ind][3] = reg2*4 + (ULO) d;
      }
}

/*
 Instruction ext Dx
 Table-usage:

  0-Routinepointer 1-disasm routine  2-reg 3-cycle count                   

*/

ULO i30dis(ULO prc,ULO opc,ULO y) 
{
  char st[80];
  ULO pos=13,o=opc&BIT6,reg=opc&SREG;
  sprintf(st,"$%.6X %.4X                   EXT.%s   D%d",prc,opc,(o==0) ? "W":"L",reg);
  plot_text_window(&debugdisass,st,0,y);
  return prc+2;
}

void i30ini(void)
{
  ULO op=0x4880,ind,o,regs;
  for (o = 0; o < 2; o++) 
    for (regs = 0; regs < 8; regs++) {
      ind = op|o<<6|regs;
      t[ind][0] = (o == 0) ? (ULO) i30_W:(ULO) i30_L;
      t[ind][1] = (ULO) i30dis;
      t[ind][2] = regs*4 + (ULO) d;
      }
}

/*
 Instruction jmp <ea>
 Table-usage:

  0-Routinepointer 1-disasm routine  2-sourreg 3-sourceread
                   4-cycle count                   
*/

ULO i31dis(ULO prc,ULO opc,ULO y) 
{
  char st[80];
  ULO pos=13,reg=opc&SREG,mode=(opc&SMOD)>>3;
  if (mode == 7) mode += reg;
  sprintf(st,"$%.6X %.4X                   JMP     ",prc,opc);
  prc = disfordel(reg,prc+2,st,32,mode,&pos);
  plot_text_window(&debugdisass,st,0,y);
  return prc;
}

void i31ini(void)
{
  ULO op=0x4ec0,ind,modes,regs,flats;
  for (modes = 0; modes < 8; modes++) 
    for (regs = 0; regs < 8; regs++) {
      flats = (modes != 7) ? modes : (modes+regs);
      if (control[flats]) {
        ind = op|modes<<3|regs;
        t[ind][0] = (ULO) i31;
        t[ind][1] = (ULO) i31dis;
        t[ind][2] = regs*4 + (ULO) a;
        t[ind][3] = eac[flats];
        t[ind][4] = (flats == 2) ? 8:
                      (flats == 5) ? 10:
                        (flats == 6) ? 14:
                          (flats == 7) ? 10:
                            (flats == 9) ? 12:
                              (flats == 10) ? 10:14;
        }
      }
}

/*
 Instruction jsr <ea>
 Table-usage:

  0-Routinepointer 1-disasm routine  2-sourreg 3-sourceread
                   4-cycle count                   
*/

ULO i32dis(ULO prc,ULO opc,ULO y) 
{
  char st[80];
  ULO pos=13,reg=opc&SREG,mode=(opc&SMOD)>>3;
  if (mode == 7) mode += reg;
  sprintf(st,"$%.6X %.4X                   JSR     ",prc,opc);
  prc = disfordel(reg,prc+2,st,32,mode,&pos);
  plot_text_window(&debugdisass,st,0,y);
  return prc;
}

void i32ini(void)
{
  ULO op=0x4e80,ind,modes,regs,flats;
  for (modes = 0; modes < 8; modes++) 
    for (regs = 0; regs < 8; regs++) {
      flats = (modes != 7) ? modes : (modes+regs);
      if (control[flats]) {
        ind = op|modes<<3|regs;
        t[ind][0] = (ULO) i32;
        t[ind][1] = (ULO) i32dis;
        t[ind][2] = regs*4 + (ULO) a;
        t[ind][3] = eac[flats];
        t[ind][4] = (flats == 2) ? 8:
                      (flats == 5) ? 10:
                        (flats == 6) ? 14:
                          (flats == 7) ? 10:
                            (flats == 9) ? 12:
                              (flats == 10) ? 10:14;
        }
      }
}

/*
 Instruction lea <ea>
 Table-usage:

  0-Routinepointer 1-disasm routine  2-sourreg 3-earead
                   4-Areg 5-cycle count                   
*/

ULO i33dis(ULO prc,ULO opc,ULO y) 
{
  char st[80];
  ULO pos=13,areg=(opc&DREG)>>9,reg=opc&SREG,mode=(opc&SMOD)>>3;
  if (mode == 7) mode += reg;
  sprintf(st,"$%.6X %.4X                   LEA.L   ",prc,opc);
  prc = disfordel(reg,prc+2,st,32,mode,&pos);
  strcat(st,",");
  prc = disfordel(areg,prc,st,32,1,&pos);
  plot_text_window(&debugdisass,st,0,y);
  return prc;
}

void i33ini(void)
{
  ULO op=0x41c0,ind,areg,modes,regs,flats;
  for (areg = 0; areg < 8; areg++)
  for (modes = 0; modes < 8; modes++)
    for (regs = 0; regs < 8; regs++) {
      flats = (modes != 7) ? modes : (modes+regs);
      if (control[flats]) {
        ind = op|areg<<9|modes<<3|regs;
        t[ind][0] = (ULO) i33;
        t[ind][1] = (ULO) i33dis;
        t[ind][2] = regs*4 + (ULO) a;
        t[ind][3] = eac[flats];
        t[ind][4] = areg*4 + (ULO) a;
        t[ind][5] = (flats == 2) ? 4:
                      (flats == 5) ? 8:
                        (flats == 6) ? 12:
                          (flats == 7) ? 8:
                            (flats == 8) ? 12:
                              (flats == 9) ? 8:12;
        }
      }
}


/*
 Instruction LINK An,#
 Table-usage:
     0-Routinepointer 1-disasm routine  2-reg
*/


ULO i34dis(ULO prc,ULO opc,ULO y) 
{
  char st[80];
  ULO j,pos=13,reg=opc&0x7;
  j=fetw(prc+2);
  sprintf(st,"$%.6X %.4X %.4X              LINK    A%1d,#$%.4X",prc,opc,j,reg,j);
  plot_text_window(&debugdisass,st,0,y);
  return prc+4;
}

void i34ini(void)
{
  ULO op=0x4e50,ind,reg;
  for (reg = 0; reg < 8; reg++) {
    ind = op|reg;
    t[ind][0] = (ULO) i34;
    t[ind][1] = (ULO) i34dis;
    t[ind][2] = reg*4 + (ULO) a;
    }    
}

/*
 Instruction LSL/LSR.X #i,<ea>
 3 versions: 
 Table-usage:

 LSX.X Dx,Dy
  0-Routinepointer 1-disasm routine  2-shcountreg 3-dreg
                4-cycle count               

 LSX.X #,Dy
  0-Routinepointer 1-disasm routine  2-shiftcount 3-dreg
                4-cycle count               

 LSX.X #1,<ea>
  0-Routinepointer 1-disasm routine  2-eareg 3-earead
                4-eawrite        5-cycle count               
*/


ULO i35dis(ULO prc,ULO opc,ULO y) 
{
  char st[80];
  ULO pos=13,reg=opc&SREG,mode=(opc&SMOD)>>3,size=((opc&SIZE) == 0xc0) ?
                                                      64:size000110(opc&SIZE);
  if (mode == 7) mode += reg;
  if (size == 64) {
    sprintf(st,"$%.6X %.4X                   LS .W   #$1,",prc,opc);
    prc = disfordel(reg,prc+2,st,16,mode,&pos);
    }
  else {
    if ((opc&BIT5) == 0)
      sprintf(st,"$%.6X %.4X                   LS .    #$%1X,D%1d",prc,opc,t[opc][2],(t[opc][3]-(ULO)d)>>2);
    else  
      sprintf(st,"$%.6X %.4X                   LS .    D%1d,D%1d",prc,opc,(t[opc][2]-(ULO)d)>>2,(t[opc][3]-(ULO)d)>>2);
    st[35] = (size == 8) ?
                'B':
                (size == 16) ?
                   'W':
                   'L';
    prc += 2;
    }
  st[33] = ((opc&BIT8) == 0) ? 'R':'L';
  plot_text_window(&debugdisass,st,0,y);
  return prc;
}

void i35ini(void)
{
  ULO op=0xe008,ind,dir,modes,regs,regc,flats,size,immreg;
  for (size = 0; size < 3; size++)
    for (regc = 0; regc < 8; regc++) 
      for (dir = 0; dir < 2; dir++) 
        for (regs = 0; regs < 8; regs++)
          for (immreg = 0; immreg < 2; immreg++) {
            ind = op|regc<<9|dir<<8|size<<6|immreg<<5|regs;
            t[ind][0] = (size == 0) ?
                           ((immreg==0) ?
                             ((dir==0) ?
                               (ULO) i35_RI_I_B:
                               (ULO) i35_LE_I_B):
                             ((dir==0) ?
                               (ULO) i35_RI_R_B:
                               (ULO) i35_LE_R_B)):
                           ((size == 1) ?
                             ((immreg==0) ?
                               ((dir==0) ?
                                 (ULO) i35_RI_I_W:
                                 (ULO) i35_LE_I_W):
                               ((dir==0) ?
                                 (ULO) i35_RI_R_W:
                                 (ULO) i35_LE_R_W)):
                             ((immreg==0) ?
                               ((dir==0) ?
                                 (ULO) i35_RI_I_L:
                                 (ULO) i35_LE_I_L):
                               ((dir==0) ?
                                 (ULO) i35_RI_R_L:
                                 (ULO) i35_LE_R_L)));
            t[ind][1] = (ULO) i35dis;
            t[ind][2] = (immreg == 0) ?
                          ((regc == 0) ?
                            8:
                            regc):
                          (regc*4 + (ULO) d);
            t[ind][3] = regs*4 + (ULO) d;
            t[ind][4] = (size == 3) ?
                          ((immreg == 0) ?
                            (8+(t[ind][2]*2)):
                            8):
                          ((immreg == 0) ?
                            (6+(t[ind][2]*2)):
                            6);
            }


  op = 0xe2c0;
  for (dir = 0; dir < 2; dir++) 
    for (modes = 0; modes < 8; modes++) 
      for (regs = 0; regs < 8; regs++) {
        flats = (modes != 7) ? modes : (modes+regs);
        if (memory[flats] && alterable[flats]) {
          ind = op|dir<<8|modes<<3|regs;
        
          t[ind][0] = (dir == 0) ?
                        (ULO) i35_RI_M_W:
                        (ULO) i35_LE_M_W;
          t[ind][1] = (ULO) i35dis;
          t[ind][2] = (modes == 0) ?
                         (regs*4 + (ULO) d):
                         (regs*4 + (ULO) a);
          t[ind][3] = parw[flats];
          t[ind][4] = aww[flats];
          t[ind][5] = 8+tarw[flats];
          }
        }
}





/*
 Instruction MOVE.X <ea>,<ea>
 Table-usage: 0-Routinepointer 1-disasm routine 2-sourcereg 3-sourcerut
                   4-destreg     5-destwrite 6-cycle count                   
*/

ULO i37dis(ULO prc,ULO opc,ULO y) 
{
  char st[80];
  ULO mode=(opc&SMOD)>>3,i,pos=13,reg=opc&SREG,size=opc&0x3000;
  sprintf(st,"$%.6X %.4X                   MOVE.   ",prc,opc);
  size = (size == 0x1000) ?
            8:
            (size == 0x3000) ?
               16:
               32;
  st[36] = (size == 8) ?
              'B':
              (size == 16) ?
                 'W':
                 'L';
  if (mode == 7) mode += reg;
  prc = disfordel(reg,prc+2,st,size,mode,&pos);
  strcat(st,",");
  mode = (opc & 0x01c0)>>6;
  if (mode == 7) mode += (opc & 0x0e00)>>9;
  prc = disfordel((opc & 0x0e00)>>9,prc,st,size,mode,&pos);
  plot_text_window(&debugdisass,st,0,y);
  return prc;
}

void i37ini(void)
{
  ULO op=0x0000,ind,moded,regd,modes,regs,size,flatd,flats;
  size = 0x1000; /* Byte */
  for (moded = 0; moded < 8; moded++) {
    for (regd = 0; regd < 8; regd++) {
      if (moded != 7) flatd = moded;
      else flatd = moded+regd;
      if (data[flatd] && alterable[flatd]) {
        for (modes = 0; modes < 8; modes++) {
          for (regs = 0; regs < 8; regs++) {
            if (modes != 7) flats = modes;
            else flats = modes+regs;
            if (data[flats]) {
              ind = op|size|regd<<9|moded<<6|modes<<3|regs;
              t[ind][0] = (ULO) i37_B;
              t[ind][1] = (ULO) i37dis;
              if (modes == 0) t[ind][2] = regs*4 + (ULO) d;
              else t[ind][2] = regs*4 + (ULO) a;
              t[ind][3] = (ULO) arb[flats];
              if (moded == 0) t[ind][4] = regd*4 + (ULO) d;
              else t[ind][4] = regd*4 + (ULO) a;
              t[ind][5] = (ULO) awb[flatd];
              t[ind][6] = 4+tarb[flats]+tarb[flatd];
              }
            }
          }
        }
      }
    }
  size = 0x3000; /* Word */
  for (moded = 0; moded < 8; moded++) {
    for (regd = 0; regd < 8; regd++) {
      if (moded != 7) flatd = moded;
      else flatd = moded+regd;
      if (data[flatd] && alterable[flatd]) {
        for (modes = 0; modes < 8; modes++) {
          for (regs = 0; regs < 8; regs++) {
            if (modes != 7) flats = modes;
            else flats = modes+regs;
            if (allmodes[flats]) {
              ind = op|size|regd<<9|moded<<6|modes<<3|regs;
              t[ind][0] = (ULO) i37_W;
              t[ind][1] = (ULO) i37dis;
              if (modes == 0) t[ind][2] = regs*4 + (ULO) d;
              else t[ind][2] = regs*4 + (ULO) a;
              t[ind][3] = (ULO) arw[flats];
              if (moded == 0) t[ind][4] = regd*4 + (ULO) d;
              else t[ind][4] = regd*4 + (ULO) a;
              t[ind][5] = (ULO) aww[flatd];
              t[ind][6] = 4+tarw[flats]+tarw[flatd];
              }
            }
          }
        }
      }
    }
  size = 0x2000; /* Long */
  for (moded = 0; moded < 8; moded++) {
    for (regd = 0; regd < 8; regd++) {
      if (moded != 7) flatd = moded;
      else flatd = moded+regd;
      if (data[flatd] && alterable[flatd]) {
        for (modes = 0; modes < 8; modes++) {
          for (regs = 0; regs < 8; regs++) {
            if (modes != 7) flats = modes;
            else flats = modes+regs;
            if (allmodes[flats]) {
              ind = op|size|regd<<9|moded<<6|modes<<3|regs;
              t[ind][0] = (ULO) i37_L;
              t[ind][1] = (ULO) i37dis;
              if (modes == 0) t[ind][2] = regs*4 + (ULO) d;
              else t[ind][2] = regs*4 + (ULO) a;
              t[ind][3] = (ULO) arl[flats];
              if (moded == 0) t[ind][4] = regd*4 + (ULO) d;
              else t[ind][4] = regd*4 + (ULO) a;
              t[ind][5] = (ULO) awl[flatd];
              t[ind][6] = 4+tarl[flats]+tarl[flatd];
              }
            }
          }
        }
      }
    }
}

/*
 Instruction MOVE.B to CCR
 Table-usage:

  0-Routinepointer 1-disasm routine  2-sourcereg 3-sourceroutine
                4-cycle count                   
*/

ULO i38dis(ULO prc,ULO opc,ULO y) 
{
  char st[80];
  ULO pos=13,reg=opc&SREG,mode=(opc&SMOD)>>3;
  sprintf(st,"$%.6X %.4X                   MOVE.B  ",prc,opc);
  if (mode == 7) mode += reg;
  prc = disfordel(reg,prc+2,st,8,mode,&pos);
  strcat(st,",CCR");
  plot_text_window(&debugdisass,st,0,y);
  return prc;
}

void i38ini(void)
{
  ULO op=0x44c0,ind,reg,mode,flat;
    for (reg = 0; reg < 8; reg++) 
      for (mode = 0; mode < 8; mode++) {
        flat = (mode != 7) ? mode : (mode+reg);
        if (data[flat]) {
            ind = op|mode<<3|reg;
            t[ind][0] = (ULO) i38;
            t[ind][1] = (ULO) i38dis;
            t[ind][2] = (mode == 0) ?
                           (reg*4 + (ULO) d):
                           (reg*4 + (ULO) a);
            t[ind][3] = arw[flat];
            t[ind][4] = 12 + tarw[flat];
            }
       }   
}
/*
 Instruction MOVE.W to SR
 Table-usage:

  0-Routinepointer 1-disasm routine  2-sourcereg 3-sourceroutine
                4-cycle count                   
*/

ULO i39dis(ULO prc,ULO opc,ULO y) 
{
  char st[80];
  ULO pos=13,reg=opc&SREG,mode=(opc&SMOD)>>3;
  sprintf(st,"$%.6X %.4X            (PRIV) MOVE.W  ",prc,opc);
  if (mode == 7) mode += reg;
  prc = disfordel(reg,prc+2,st,16,mode,&pos);
  strcat(st,",SR");
  plot_text_window(&debugdisass,st,0,y);
  return prc;
}

void i39ini(void)
{
  ULO op=0x46c0,ind,reg,mode,flat;
    for (reg = 0; reg < 8; reg++) 
      for (mode = 0; mode < 8; mode++) {
        flat = (mode != 7) ? mode : (mode+reg);
        if (data[flat]) {
            ind = op|mode<<3|reg;
            t[ind][0] = (ULO) i39;
            t[ind][1] = (ULO) i39dis;
            t[ind][2] = (mode == 0) ?
                           (reg*4 + (ULO) d):
                           (reg*4 + (ULO) a);
            t[ind][3] = arw[flat];
            t[ind][4] = 12 + tarw[flat];
            }
      }    
}
/*
 Instruction MOVE.W from SR
 Table-usage:

  0-Routinepointer 1-disasm routine  2-destreg 3-destroutine
                4-cycle count                   
*/

ULO i40dis(ULO prc,ULO opc,ULO y) 
{
  char st[80];
  ULO pos=13,reg=opc&SREG,mode=(opc&SMOD)>>3;
  sprintf(st,"$%.6X %.4X                   MOVE.W  SR,",prc,opc);
  if (mode == 7) mode += reg;
  prc = disfordel(reg,prc+2,st,16,mode,&pos);
  plot_text_window(&debugdisass,st,0,y);
  return prc;
}

void i40ini(void)
{
  ULO op=0x40c0,ind,reg,mode,flat;
    for (reg = 0; reg < 8; reg++) 
      for (mode = 0; mode < 8; mode++) { 
        flat = (mode != 7) ? mode : (mode+reg);
        if (data[flat] & alterable[flat]) {
            ind = op|mode<<3|reg;
            t[ind][0] = (ULO) i40;
            t[ind][1] = (ULO) i40dis;
            t[ind][2] = (mode == 0) ?
                           (reg*4 + (ULO) d):
                           (reg*4 + (ULO) a);
            t[ind][3] = aww[flat];
            t[ind][4] = (flat < 2) ? 6:(8 + tarw[flat]);
            }
     }     
}

/*
 Instruction MOVE.L USP to/from Ax
 Table-usage:

  0-Routinepointer 1-disasm routine  2-reg
*/

ULO i41dis(ULO prc,ULO opc,ULO y) 
{
  char st[80];
  ULO pos=13,reg=opc&SREG,dir=opc&0x8;
  if (dir == 0)
    sprintf(st,"$%.6X %.4X            (PRIV) MOVE.L  A%1d,USP",prc,opc,reg);
  else
    sprintf(st,"$%.6X %.4X            (PRIV) MOVE.L  USP,A%1d",prc,opc,reg);
  plot_text_window(&debugdisass,st,0,y);
  return prc+2;
}

void i41ini(void)
{
  ULO op=0x4e60,ind,reg,dir;
  for (dir = 0; dir < 2; dir++)
    for (reg = 0; reg < 8; reg++) {
      ind = op|reg|dir<<3;
      t[ind][0] = (dir == 0) ?
                           (ULO) i41_2:
                           (ULO) i41_1;
      t[ind][1] = (ULO) i41dis;
      t[ind][2] = (ULO) a + reg*4;
      }
}

/*
 Instruction MOVEA.W/L <ea>,An
 Table-usage:

  0-Routinepointer 1-disasm routine  2-sourreg 3-sourceroutine
                   4-Areg        5-cycle count                   
*/

ULO i42dis(ULO prc,ULO opc,ULO y) 
{
  char st[80];
  ULO pos=13,reg=opc&SREG,dreg=(opc&DREG)>>9,o=opc&0x1000,mode=(opc&SMOD)>>3,size;
  size = (o == 0) ? 32:16;
  if (mode == 7) mode += reg;
  sprintf(st,"$%.6X %.4X                   MOVEA.  ",prc,opc);
  st[37] = (size == 16) ?
              'W':
              'L';
  prc = disfordel(reg,prc+2,st,size,mode,&pos);
  strcat(st,",");
  disfordel(dreg,prc,st,size,1,&pos);
  plot_text_window(&debugdisass,st,0,y);
  return prc;
}

void i42ini(void)
{
  ULO op=0x2040,ind,regd,modes,regs,flats,o;
  for (o = 0; o < 2; o++)
    for (regd = 0; regd < 8; regd++) 
      for (modes = 0; modes < 8; modes++) 
        for (regs = 0; regs < 8; regs++) {
          flats = (modes != 7) ? modes : (modes+regs);
          if (allmodes[flats]) {
            ind = op|regd<<9|o<<12|modes<<3|regs;
            t[ind][0] = (o == 0) ?
                           (ULO) i42_L:
                           (ULO) i42_W;
            t[ind][1] = (ULO) i42dis;
            t[ind][2] = (modes == 0) ?
                           (regs*4 + (ULO) d):
                           (regs*4 + (ULO) a);
            t[ind][3] = (o == 0) ?
                           arl[flats]:
                           arw[flats];
            t[ind][4] = regd*4 + (ULO) a;
            t[ind][5] = (o == 0) ?
                           (4 + tarl[flats]):
                           (4 + tarw[flats]);
            }
          }
}

/*
 Instruction MOVEM.W/L 
 Table-usage:

  0-Routinepointer 1-disasm routine  2-eareg 3-earead/write  4-base cycle time
*/

ULO i43dis(ULO prc,ULO opc,ULO y) 
{
  char st[80],tmp[10];
  ULO i,first,pos=18,reg=opc&SREG,mode=(opc&SMOD)>>3,size,dir=opc&0x0400,regmask;
  ULO next=1;

  size = ((opc&BIT6) == 0) ? 16:32;
  regmask = fetw(prc+2);
  if (mode == 7) mode += reg;

  if (dir == 0 && mode == 4) {  /* Register to memory, predecrement */
    sprintf(st,"$%.6X %.4X %.4X              MOVEM.%s ",prc,opc,regmask,((size==16)?"W":"L"));
    first=TRUE;
    for (i=0;i<8;i++) {
      if ((regmask&(1<<i)) != 0)
        if (first) {
          sprintf(tmp,"A%d",(7-i));
          strcat(st,tmp);
          first = FALSE;
          }
        else {
          sprintf(tmp,"%d",(7-i));
          strcat(st,tmp);
          }
        }
    for (i=8;i<16;i++) {
      if ((regmask&(1<<i)) != 0)
        if (first) {
          sprintf(tmp,"D%d",(15-i));
          strcat(st,tmp);
          first = FALSE;
          next = FALSE;
          }
        else {
          if (next)
            sprintf(tmp,"D%d",(15-i));
          else
            sprintf(tmp,"%d",(15-i));
          next = FALSE;
          strcat(st,tmp);
          }
        }
      strcat(st,",");
      prc = disfordel(reg,prc+4,st,size,mode,&pos);
    }     
  else if (dir==0x0400) { /* Memory to register, any legal adressmode */
    sprintf(st,"$%.6X %.4X %.4X              MOVEM.%s ",prc,opc,regmask,((size==16)?"W":"L"));

    prc = disfordel(reg,prc+4,st,size,mode,&pos);
    strcat(st,",");
    first=TRUE;
    for (i=0;i<8;i++) {
      if ((regmask&(1<<i)) != 0)
        if (first) {
          sprintf(tmp,"D%d",i);
          strcat(st,tmp);
          first = FALSE;
          }
        else {
          sprintf(tmp,"%d",i);
          strcat(st,tmp);
          }
        }
    for (i=8;i<16;i++) {
      if ((regmask&(1<<i)) != 0)
        if (first) {
          sprintf(tmp,"A%d",i-8);
          strcat(st,tmp);
          first = FALSE;
          next = FALSE;
          }
        else {
          if (next)
            sprintf(tmp,"A%d",i-8);
          else
            sprintf(tmp,"%d",i-8);
          next = FALSE;  
          strcat(st,tmp);
          }
        }
    }     
  else {  /* Register to memory, the rest of the adr.modes */
    sprintf(st,"$%.6X %.4X %.4X              MOVEM.%s ",prc,opc,regmask,((size==16)?"W":"L"));
    first=TRUE;
    for (i=0;i<8;i++) {
      if ((regmask&(1<<i)) != 0)
        if (first) {
          sprintf(tmp,"D%d",i);
          strcat(st,tmp);
          first = FALSE;
          }
        else {
          sprintf(tmp,"%d",i);
          strcat(st,tmp);
          }
        }
    for (i=8;i<16;i++) {
      if ((regmask&(1<<i)) != 0)
        if (first) {
          sprintf(tmp,"A%d",(i-8));
          strcat(st,tmp);
          first = FALSE;
          next = FALSE;
          }
        else {
          if (next)
            sprintf(tmp,"A%d",(i-8));
          else
            sprintf(tmp,"%d",(i-8));
          next = FALSE;
          strcat(st,tmp);
          }

        }
    strcat(st,",");
    prc = disfordel(reg,prc+4,st,size,mode,&pos);
    }     

  plot_text_window(&debugdisass,st,0,y);
  return prc;
}

void i43ini(void)
{
  ULO op=0x4880,ind,modes,regs,flats,dir,sz;
  for (dir = 0; dir < 2; dir++)
    for (sz = 0; sz < 2; sz++) 
      for (modes = 0; modes < 8; modes++) 
        for (regs = 0; regs < 8; regs++) {
          flats = (modes != 7) ? modes : (modes+regs);
          if (control[flats] || ((flats == 3) && (dir == 1)) || ((flats == 4) && (dir == 0))) {
            ind = op|dir<<10|sz<<6|modes<<3|regs;
            t[ind][0] = (sz == 0) ?
                           ((dir == 0) ?
                             ((flats == 4) ?
                               (ULO) i43_W_PREM:
                               (ULO) i43_W_CONM):
                             ((flats == 3) ?
                               (ULO) i43_W_POSTR:
                               (ULO) i43_W_CONR)):
                           ((dir == 0) ?
                             ((flats == 4) ?
                               (ULO) i43_L_PREM:
                               (ULO) i43_L_CONM):
                             ((flats == 3) ?
                               (ULO) i43_L_POSTR:
                               (ULO) i43_L_CONR));
            t[ind][1] = (ULO) i43dis;
            t[ind][2] = regs*4 + (ULO) a;
            t[ind][3] = eac[flats];
            t[ind][4] = (sz == 0) ?
                           (8 + tarw[flats]):
                           (8 + tarl[flats]);
            }
          }
}

/*
 Instruction MOVEP
*/

ULO i44dis(ULO prc,ULO opc,ULO y) 
{
  char st[80];
  ULO i,pos=13;
  sprintf(st,"$%.6X %.4X                   MOVEP",prc,opc);
  plot_text_window(&debugdisass,st,0,y);
  return prc+4;
}

void i44ini(void)
{
  ULO op=0x0008,ind,dreg,areg,mode;
  for (areg = 0; areg < 8; areg++) 
   for (dreg = 0; dreg < 8; dreg++) 
    for (mode = 4; mode < 8; mode++) {
      ind = op|areg|mode<<6|dreg<<9;
      if (op == 4) t[ind][0] = (ULO) i44_W_1;
      else if (op == 5) t[ind][0] = (ULO) i44_L_1;
      else if (op == 6) t[ind][0] = (ULO) i44_W_2;
      else if (op == 7) t[ind][0] = (ULO) i44_L_2;
      t[ind][1] = (ULO) i44dis;
      t[ind][2] = (ULO) a + areg;
      t[ind][3] = (ULO) d + dreg;
      }
}

/*
 Instruction MOVEQ.L #8 bit signed imm,Dn
 Table-usage:

  0-Routinepointer 1-disasm routine  2-reg 3-32 bit immediate
                   4-flag byte                          
*/

ULO i45dis(ULO prc,ULO opc,ULO y) 
{
  char st[80];
  ULO i,pos=13,reg=(opc&0xe00)>>9;
  sprintf(st,"$%.6X %.4X                   MOVEQ.L #$%8.8X,D%d",prc,opc,t[opc][3],reg);
  plot_text_window(&debugdisass,st,0,y);
  return prc+2;
}

void i45ini(void)
{
  ULO op=0x7000,ind,reg;
  int imm;
  for (reg = 0; reg < 8; reg++) 
    for (imm = -128; imm < 128; imm++) {
      ind = op|reg<<9|imm&0xff;
      t[ind][0] = (ULO) i45;
      t[ind][1] = (ULO) i45dis;
      t[ind][2] = reg*4 + (ULO) d;
      t[ind][3] = imm;
      t[ind][4] = 0 | ((imm < 0) ? 0x8:0) | ((imm == 0) ? 0x4:0);
      }
}

/*
 Instruction MULS.W <ea>,Dn
 Table-usage:

  0-Routinepointer 1-disasm routine  2-sourreg 3-sourceroutine
                   4-Dreg                          
*/

ULO i46dis(ULO prc,ULO opc,ULO y) 
{
  char st[80];
  ULO pos=13,reg=opc&0x7,dreg=(opc&0xe00)>>9,mode=(opc&0x38)>>3;
  if (mode == 7) mode += reg;
  sprintf(st,"$%.6X %.4X                   MULS.W  ",prc,opc);
  prc = disfordel(reg,prc+2,st,16,mode,&pos);
  strcat(st,",");
  disfordel(dreg,prc,st,16,0,&pos);
  plot_text_window(&debugdisass,st,0,y);
  return prc;
}

void i46ini(void)
{
  ULO op=0xc1c0,ind,regd,modes,regs,flats;
  for (regd = 0; regd < 8; regd++) 
    for (modes = 0; modes < 8; modes++) 
      for (regs = 0; regs < 8; regs++) {
        flats = (modes != 7) ? modes : (modes+regs);
        if (data[flats]) {
          ind = op|regd<<9|modes<<3|regs;
          t[ind][0] = (ULO) i46;
          t[ind][1] = (ULO) i46dis;
          t[ind][2] = regs*4 + ((modes == 0) ?
                                  (ULO) d:
                                  (ULO) a);
          t[ind][3] = arw[flats];
          t[ind][4] = regd*4 + (ULO) d;
          }
       }
}

/*
 Instruction MULU.W <ea>,Dn
 Table-usage:

  0-Routinepointer 1-disasm routine  2-sourreg 3-sourceroutine
                   4-Dreg                          
*/

ULO i47dis(ULO prc,ULO opc,ULO y) 
{
  char st[80];
  ULO pos=13,reg=opc&0x7,dreg=(opc&0xe00)>>9,mode=(opc&0x38)>>3;
  if (mode == 7) mode += reg;
  sprintf(st,"$%.6X %.4X                   MULU.W  ",prc,opc);
  prc = disfordel(reg,prc+2,st,16,mode,&pos);
  strcat(st,",");
  disfordel(dreg,prc,st,16,0,&pos);
  plot_text_window(&debugdisass,st,0,y);
  return prc;
}

void i47ini(void)
{
  ULO op=0xc0c0,ind,regd,modes,regs,flats;
  for (regd = 0; regd < 8; regd++) 
    for (modes = 0; modes < 8; modes++) 
      for (regs = 0; regs < 8; regs++) 
        if (data[(flats = (modes != 7) ? modes : (modes+regs))]) {
          ind = op|regd<<9|modes<<3|regs;
          t[ind][0] = (ULO) i47;
          t[ind][1] = (ULO) i47dis;
          t[ind][2] = regs*4 + ((modes == 0) ?
                                  (ULO) d:
                                  (ULO) a);
          t[ind][3] = arw[flats];
          t[ind][4] = regd*4 + (ULO) d;
          }
}

/*
 Instruction NBCD.B <ea>
 Table-usage:
  0-Routinepointer 1-disasm routine  2-sourreg 3-sourceroutine 4-eawrite
                   5-cycle count                   
*/

ULO i48dis(ULO prc,ULO opc,ULO y) 
{
  char st[80];
  ULO pos=13,reg=opc&SREG,mode=(opc&SMOD)>>3;
  if (mode == 7) mode += reg;
  sprintf(st,"$%.6X %.4X                   NBCD.B  ",prc,opc);
  prc = disfordel(reg,prc+2,st,8,mode,&pos);
  plot_text_window(&debugdisass,st,0,y);
  return prc;
}

void i48ini(void)
{
  ULO op=0x4800,ind,modes,regs,flats,size;
    for (modes = 0; modes < 8; modes++) 
      for (regs = 0; regs < 8; regs++) {
        flats = (modes != 7) ?
                   modes:
                   (modes+regs);
        if (data[flats] && alterable[flats]) {
          ind = op|modes<<3|regs;
          t[ind][0] = (ULO) i48_B;
          t[ind][1] = (ULO) i48dis;
          t[ind][2] = (modes == 0) ?
                         (regs*4 + (ULO) d):
                         (regs*4 + (ULO) a);
          t[ind][3] = parb[flats];
          t[ind][4] = awb[flats];
          t[ind][5] = (modes == 0) ?
                               6:
                               (8+tarb[flats]);
          }
      }
}
/*
 Instruction NEG.X <ea>
 Table-usage:
  0-Routinepointer 1-disasm routine  2-sourreg 3-sourceroutine 4-eawrite
                   5-cycle count                   
*/

ULO i49dis(ULO prc,ULO opc,ULO y) 
{
  char st[80];
  ULO pos=13,reg=opc&SREG,mode=(opc&SMOD)>>3,size=size000110(opc&SIZE);
  if (mode == 7) mode += reg;
  sprintf(st,"$%.6X %.4X                   NEG.    ",prc,opc);
  st[35] = (size == 8) ?
              'B':
              (size == 16) ?
                 'W':
                 'L';
  prc = disfordel(reg,prc+2,st,size,mode,&pos);
  plot_text_window(&debugdisass,st,0,y);
  return prc;
}

void i49ini(void)
{
  ULO op=0x4400,ind,modes,regs,flats,size;
  for (size = 0; size < 3; size++)
    for (modes = 0; modes < 8; modes++) 
      for (regs = 0; regs < 8; regs++) {
        flats = (modes != 7) ?
                   modes:
                   (modes+regs);
        if (data[flats] && alterable[flats]) {
          ind = op|size<<6|modes<<3|regs;
        t[ind][0] = (size == 0) ? (ULO) i49_B:
                      (size == 1) ? (ULO) i49_W:(ULO) i49_L;
        t[ind][1] = (ULO) i49dis;
        t[ind][2] = (modes == 0) ?
                       (regs*4 + (ULO) d):
                       (regs*4 + (ULO) a);
        t[ind][3] = (size == 0) ?
                       parb[flats]:
                       ((size == 1) ?
                          parw[flats]:
                          parl[flats]);
        t[ind][4] = (size == 0) ?
                       awb[flats]:
                       ((size == 1) ?
                          aww[flats]:
                          awl[flats]);
        t[ind][5] = (size == 0) ?
                       (4+tarb[flats]):
                       ((size == 1) ?
                          (4+tarw[flats]):
                          ((modes == 0) ?
                             6:
                             (4+tarl[flats])));
        }
      }
}

/*
 Instruction NEGX.X <ea>
 Table-usage:
  0-Routinepointer 1-disasm routine  2-sourreg 3-sourceroutine 4-eawrite
                   5-cycle count                   
*/

ULO i50dis(ULO prc,ULO opc,ULO y) 
{
  char st[80];
  ULO pos=13,reg=opc&SREG,mode=(opc&SMOD)>>3,size=size000110(opc&SIZE);
  if (mode == 7) mode += reg;
  sprintf(st,"$%.6X %.4X                   NEGX.   ",prc,opc);
  st[36] = (size == 8) ?
              'B':
              (size == 16) ?
                 'W':
                 'L';
  prc = disfordel(reg,prc+2,st,size,mode,&pos);
  plot_text_window(&debugdisass,st,0,y);
  return prc;
}

void i50ini(void)
{
  ULO op=0x4000,ind,modes,regs,flats,size;
  for (size = 0; size < 3; size++)
    for (modes = 0; modes < 8; modes++) 
      for (regs = 0; regs < 8; regs++) {
        flats = (modes != 7) ?
                   modes:
                   (modes+regs);
        if (data[flats] && alterable[flats]) {
          ind = op|size<<6|modes<<3|regs;
        t[ind][0] = (size == 0) ? (ULO) i50_B:
                      (size == 1) ? (ULO) i50_W:(ULO) i50_L;
        t[ind][1] = (ULO) i50dis;
        t[ind][2] = (modes == 0) ?
                       (regs*4 + (ULO) d):
                       (regs*4 + (ULO) a);
        t[ind][3] = (size == 0) ?
                       parb[flats]:
                       (size == 1) ?
                          parw[flats]:
                          parl[flats];
        t[ind][4] = (size == 0) ?
                       awb[flats]:
                       (size == 1) ?
                          aww[flats]:
                          awl[flats];
        t[ind][5] = (size == 0) ?
                       (4+tarb[flats]):
                       (size == 1) ?
                          (4+tarw[flats]):
                          (modes == 0) ?
                             6:
                             (4+tarl[flats]);
        }
      }
}

/*
 Instruction NOP
 Table-usage:
     0-Routinepointer 1-disasm routine
*/

ULO i51dis(ULO prc,ULO opc,ULO y) 
{
  char st[80];
  ULO pos=13,reg=opc&0x7;
  sprintf(st,"$%.6X %.4X                   NOP",prc,opc);
  plot_text_window(&debugdisass,st,0,y);
  return prc+2;
}

void i51ini(void)
{
  ULO op=0x4e71;
  t[op][0] = (ULO) i51;
  t[op][1] = (ULO) i51dis;
}

/*
 Instruction NOT.X <ea>
 Table-usage:
  0-Routinepointer 1-disasm routine  2-sourreg 3-sourceroutine 4-eawrite
                   5-cycle count                   
*/

ULO i52dis(ULO prc,ULO opc,ULO y) 
{
  char st[80];
  ULO pos=13,reg=opc&SREG,mode=(opc&SMOD)>>3,size=size000110(opc&SIZE);
  if (mode == 7) mode += reg;
  sprintf(st,"$%.6X %.4X                   NOT.    ",prc,opc);
  st[35] = (size == 8) ?
              'B':
              (size == 16) ?
                 'W':
                 'L';
  prc = disfordel(reg,prc+2,st,size,mode,&pos);
  plot_text_window(&debugdisass,st,0,y);
  return prc;
}

void i52ini(void)
{
  ULO op=0x4600,ind,modes,regs,flats,size;
  for (size = 0; size < 3; size++)
    for (modes = 0; modes < 8; modes++) 
      for (regs = 0; regs < 8; regs++) {
        flats = (modes != 7) ?
                   modes:
                   (modes+regs);
        if (data[flats] && alterable[flats]) {
          ind = op|size<<6|modes<<3|regs;
        t[ind][0] = (size == 0) ? (ULO) i52_B:
                      (size == 1) ? (ULO) i52_W:(ULO) i52_L;
        t[ind][1] = (ULO) i52dis;
        t[ind][2] = (modes == 0) ?
                       (regs*4 + (ULO) d):
                       (regs*4 + (ULO) a);
        t[ind][3] = (size == 0) ?
                       parb[flats]:
                       (size == 1) ?
                          parw[flats]:
                          parl[flats];
        t[ind][4] = (size == 0) ?
                       awb[flats]:
                       (size == 1) ?
                          aww[flats]:
                          awl[flats];
        t[ind][5] = (size == 0) ?
                       (4+tarb[flats]):
                       (size == 1) ?
                          (4+tarw[flats]):
                          (modes == 0) ?
                             6:
                             (4+tarl[flats]);
        }
      }
}


/*
 Instruction OR.X <ea>,Dn / OR.X Dn,<ea>
 Table-usage:
 Type 1:  OR <ea>,Dn

  0-Routinepointer 1-disasm routine  2-sourreg 3-sourceroutine
                   4-Dreg        5-cycle count                   
 Type 2:  OR Dn,<ea>

  0-Routinepointer 1-disasm routine  2-<ea>reg 3-get <ea> routine
                   4-Dreg        5-cycle count   6-write<ea> routine                
*/

ULO i53dis(ULO prc,ULO opc,ULO y) 
{
  char st[80];
  ULO pos=13,reg=opc&0x7,dreg=(opc&0xe00)>>9,o=opc&0x100,mode=(opc&0x38)>>3,
      size=(1+((opc&0xc0)>>6))<<3;
  if (mode == 7) mode += reg;
  sprintf(st,"$%.6X %.4X                   OR.     ",prc,opc);
  st[34] = (size == 8) ?
              'B':
              (size == 16) ?
                 'W':
                 'L';
  prc = (o == 0) ? disfordel(reg,prc+2,st,size,mode,&pos) :
                   disfordel(dreg,prc+2,st,size,0,&pos);
  strcat(st,",");
  prc = (o != 0) ? disfordel(reg,prc,st,size,mode,&pos) :
                   disfordel(dreg,prc,st,size,0,&pos);
  plot_text_window(&debugdisass,st,0,y);
  return prc;
}

void i53ini(void)
{
  ULO op=0x8000,ind,regd,modes,regs,flats,size,o;
  for (o = 0; o < 2; o++)
    for (size = 0; size < 3; size++)
      for (regd = 0; regd < 8; regd++) 
        for (modes = 0; modes < 8; modes++) 
          for (regs = 0; regs < 8; regs++) {
            flats = (modes != 7) ?
                       modes:
                       (modes+regs);
            if ((o==0 && data[flats]) ||
                (o==1 && alterable[flats] && memory[flats])) {
              ind = op|regd<<9|o<<8|size<<6|modes<<3|regs;
              t[ind][0] = (o == 0) ?
                             (size == 0) ?
                                (ULO) i53_B_1:
                                (size == 1) ?
                                   (ULO) i53_W_1:
                                   (ULO) i53_L_1:
                             (size == 0) ?
                                (ULO) i53_B_2:
                                (size == 1) ?
                                   (ULO) i53_W_2:
                                   (ULO) i53_L_2;
              t[ind][1] = (ULO) i53dis;
              t[ind][2] = (modes == 0) ?
                             (regs*4 + (ULO) d):
                             (regs*4 + (ULO) a);
              t[ind][3] = (o == 0) ?
                             (size == 0) ?
                                arb[flats]:
                                (size == 1) ?
                                   arw[flats]:
                                   arl[flats]:
                             (size == 0) ?
                                parb[flats]:
                                (size == 1) ?
                                   parw[flats]:
                                   parl[flats];
              t[ind][4] = regd*4 + (ULO) d;
              t[ind][5] = (o == 0) ?
                             (size == 0) ?
                                (4+tarb[flats]):
                                (size == 1) ?
                                   (4+tarw[flats]):
                                   (flats <= 1 || flats == 11) ?
                                      (8+tarl[flats]):
                                      (6+tarl[flats]):
                             (size == 0) ?
                                (8 + tarb[flats]):
                                (size == 1) ?
                                   (8 + tarw[flats]):
                                   (12 + tarl[flats]);
              if (o == 1) t[ind][6] = (size == 0) ?
                                         awb[flats]:
                                         (size == 1) ?
                                            aww[flats]:
                                            awl[flats];
              }
            }
}



/*
 Instruction ORI.X #i,<ea>
 Table-usage:

  0-Routinepointer 1-disasm routine  2-eareg 3-ea read routine
                4-cycle count    5-ea write routine               
*/


ULO i54dis(ULO prc,ULO opc,ULO y) 
{
  char st[80];
  ULO pos=13,reg=opc&0x7,mode=(opc&0x38)>>3,size=(1+((opc&0xc0)>>6))<<3;
  if (mode == 7) mode += reg;
  if (mode == 11 && size == 16)
    sprintf(st,"$%.6X %.4X            (PRIV) ORI.    ",prc,opc);
  else
    sprintf(st,"$%.6X %.4X                   ORI.    ",prc,opc);
  st[35] = (size == 8) ?
              'B':
              (size == 16) ?
                 'W':
                 'L';
  prc = disfordel(4,prc+2,st,size,11,&pos);
  strcat(st,",");
  if (mode == 11)
    strcat(st,(size == 8) ? "CCR":"SR");
  else
    prc = disfordel(reg,prc,st,size,mode,&pos);
  plot_text_window(&debugdisass,st,0,y);
  return prc;
}

void i54ini(void)
{
  ULO op=0x0000,ind,modes,regs,flats,size;
  for (size = 0; size < 3; size++)
    for (modes = 0; modes < 8; modes++) 
      for (regs = 0; regs < 8; regs++) {
        flats = (modes != 7) ? modes : (modes+regs);
        if ((data[flats] && alterable[flats]) || (flats == 11 && size < 2)) {
          ind = op|size<<6|modes<<3|regs;
          t[ind][0] = (size == 0) ?
                         ((flats == 11) ?
                           (ULO) i54_B_CCR:
                           (ULO) i54_B):
                         (size == 1) ?
                            ((flats == 11) ?
                              (ULO) i54_W_SR:
                              (ULO) i54_W):
                            (ULO) i54_L; 
          t[ind][1] = (ULO) i54dis;
          t[ind][2] = (modes == 0) ?
                         (regs*4 + (ULO) d):
                         (regs*4 + (ULO) a);
          t[ind][3] = (size == 0) ?
                         parb[flats]:
                         (size == 1) ?
                            parw[flats]:
                            parl[flats];
          t[ind][4] = (flats == 11) ?
                        20:
                        (size == 0) ?
                         (flats == 0) ?
                            8:
                            (12 + tarb[flats]):
                         (size == 1)  ?
                            (flats == 0) ?
                               8:
                               (12 + tarw[flats]):
                            (flats == 0) ?
                               16:
                               (20 + tarl[flats]);
          t[ind][5] = (size == 0) ?
                         awb[flats]:
                         (size == 1) ? 
                            aww[flats]:
                            awl[flats];
          }
        }
}

/*
 Instruction pea <ea>
 Table-usage:

  0-Routinepointer 1-disasm routine  2-sourreg 3-earead
                   4-cycle count                   
*/

ULO i55dis(ULO prc,ULO opc,ULO y) 
{
  char st[80];
  ULO pos=13,areg=(opc&DREG)>>9,reg=opc&SREG,mode=(opc&SMOD)>>3;
  if (mode == 7) mode += reg;
  sprintf(st,"$%.6X %.4X                   PEA.L   ",prc,opc);
  prc = disfordel(reg,prc+2,st,32,mode,&pos);
  plot_text_window(&debugdisass,st,0,y);
  return prc;
}

void i55ini(void)
{
  ULO op=0x4840,ind,modes,regs,flats;
  for (modes = 0; modes < 8; modes++)
    for (regs = 0; regs < 8; regs++) {
      flats = (modes != 7) ? modes : (modes+regs);
      if (control[flats]) {
        ind = op|modes<<3|regs;
        t[ind][0] = (ULO) i55;
        t[ind][1] = (ULO) i55dis;
        t[ind][2] = regs*4 + (ULO) a;
        t[ind][3] = eac[flats];
        t[ind][4] = (flats == 2) ? 12:
                      (flats == 5) ? 16:
                        (flats == 6) ? 20:
                          (flats == 7) ? 16:
                            (flats == 9) ? 20:
                              (flats == 10) ? 16:20;
        }
      }
}

/*
 Instruction RESET
 Table-usage:
     0-Routinepointer 1-disasm routine
*/

ULO i56dis(ULO prc,ULO opc,ULO y) 
{
  char st[80];
  ULO pos=13,reg=opc&0x7;
  sprintf(st,"$%.6X %.4X                   RESET",prc,opc);
  plot_text_window(&debugdisass,st,0,y);
  return prc+2;
}

void i56ini(void)
{
  ULO op=0x4e70;
  t[op][0] = (ULO) i56;
  t[op][1] = (ULO) i56dis;
}

/*
 Instruction ROL/ROR.X #i,<ea>
 3 versions: 
 Table-usage:

 ROX.X Dx,Dy
  0-Routinepointer 1-disasm routine  2-shcountreg 3-dreg
                4-cycle count               

 RoX.X #,Dy
  0-Routinepointer 1-disasm routine  2-shiftcount 3-dreg
                4-cycle count               

 RoX.X #1,<ea>
  0-Routinepointer 1-disasm routine  2-eareg 3-earead
                4-eawrite        5-cycle count               
*/


ULO i57dis(ULO prc,ULO opc,ULO y) 
{
  char st[80];
  ULO pos=13,reg=opc&SREG,mode=(opc&SMOD)>>3,size=((opc&SIZE) == 0xc0) ?
                                                      64:size000110(opc&SIZE);
  if (mode == 7) mode += reg;
  if (size == 64) {
    sprintf(st,"$%.6X %.4X                   RO .W   #$1,",prc,opc);
    prc = disfordel(reg,prc+2,st,16,mode,&pos);
    }
  else {
    if ((opc&BIT5) == 0)
      sprintf(st,"$%.6X %.4X                   RO .    #$%1X,D%1d",prc,opc,t[opc][2],(t[opc][3]-(ULO)d)>>2);
    else  
      sprintf(st,"$%.6X %.4X                   RO .    D%1d,D%1d",prc,opc,(t[opc][2]-(ULO) d)>>2,(t[opc][3]-(ULO)d)>>2);
    st[35] = (size == 8) ?
                'B':
                (size == 16) ?
                   'W':
                   'L';
    prc += 2;
    }
  st[33] = ((opc&BIT8) == 0) ? 'R':'L';
  plot_text_window(&debugdisass,st,0,y);
  return prc;
}

void i57ini(void)
{
  ULO op=0xe018,ind,dir,modes,regs,regc,flats,size,immreg;
  for (size = 0; size < 3; size++)
    for (regc = 0; regc < 8; regc++) 
      for (dir = 0; dir < 2; dir++) 
        for (regs = 0; regs < 8; regs++)
          for (immreg = 0; immreg < 2; immreg++) {
            ind = op|regc<<9|dir<<8|size<<6|immreg<<5|regs;
            t[ind][0] = (size == 0) ?
                           ((immreg==0) ?
                             ((dir==0) ?
                               (ULO) i57_RI_I_B:
                               (ULO) i57_LE_I_B):
                             ((dir==0) ?
                               (ULO) i57_RI_R_B:
                               (ULO) i57_LE_R_B)):
                           ((size == 1) ?
                             ((immreg==0) ?
                               ((dir==0) ?
                                 (ULO) i57_RI_I_W:
                                 (ULO) i57_LE_I_W):
                               ((dir==0) ?
                                 (ULO) i57_RI_R_W:
                                 (ULO) i57_LE_R_W)):
                             ((immreg==0) ?
                               ((dir==0) ?
                                 (ULO) i57_RI_I_L:
                                 (ULO) i57_LE_I_L):
                               ((dir==0) ?
                                 (ULO) i57_RI_R_L:
                                 (ULO) i57_LE_R_L)));
            t[ind][1] = (ULO) i57dis;
            t[ind][2] = (immreg == 0) ?
                          ((regc == 0) ?
                            8:
                            regc):
                          (regc*4 + (ULO) d);
            t[ind][3] = regs*4 + (ULO) d;
            t[ind][4] = (size == 3) ?
                          ((immreg == 0) ?
                            (8+(t[ind][2]*2)):
                            8):
                          ((immreg == 0) ?
                            (6+(t[ind][2]*2)):
                            6);
            }


  op = 0xe6c0;
  for (dir = 0; dir < 2; dir++) 
    for (modes = 0; modes < 8; modes++) 
      for (regs = 0; regs < 8; regs++) {
        flats = (modes != 7) ? modes : (modes+regs);
        if (memory[flats] && alterable[flats]) {
          ind = op|dir<<8|modes<<3|regs;
          t[ind][0] = (dir == 0) ?
                        (ULO) i57_RI_M_W:
                        (ULO) i57_LE_M_W;
          t[ind][1] = (ULO) i57dis;
          t[ind][2] = (modes == 0) ?
                         (regs*4 + (ULO) d):
                         (regs*4 + (ULO) a);
          t[ind][3] = parw[flats];
          t[ind][4] = aww[flats];
          t[ind][5] = 8+tarw[flats];
          }
        }
}

/*
 Instruction ROXL/ROXR.X #i,<ea>
 3 versions: 
 Table-usage:

 ROXX.X Dx,Dy
  0-Routinepointer 1-disasm routine  2-shcountreg 3-dreg
                4-cycle count               

 ROXX.X #,Dy
  0-Routinepointer 1-disasm routine  2-shiftcount 3-dreg
                4-cycle count               

 ROXX.X #1,<ea>
  0-Routinepointer 1-disasm routine  2-eareg 3-earead
                4-eawrite        5-cycle count               
*/


ULO i59dis(ULO prc,ULO opc,ULO y) 
{
  char st[80];
  ULO pos=13,reg=opc&SREG,mode=(opc&SMOD)>>3,size=((opc&SIZE) == 0xc0) ?
                                                      64:size000110(opc&SIZE);
  if (mode == 7) mode += reg;
  if (size == 64) {
    sprintf(st,"$%.6X %.4X                   ROX .W  #$1,",prc,opc);
    prc = disfordel(reg,prc+2,st,16,mode,&pos);
    }
  else {
    if ((opc&BIT5) == 0)
      sprintf(st,"$%.6X %.4X                   ROX .   #$%1X,D%1d",prc,opc,t[opc][2],(t[opc][3]-(ULO)d)>>2);
    else  
      sprintf(st,"$%.6X %.4X                   ROX .   D%1d,D%1d",prc,opc,(t[opc][2]-(ULO)d)>>2,(t[opc][3]-(ULO)d)>>2);
    st[36] = (size == 8) ?
                'B':
                (size == 16) ?
                   'W':
                   'L';
    prc += 2;
    }
  st[34] = ((opc&BIT8) == 0) ? 'R':'L';
  plot_text_window(&debugdisass,st,0,y);
  return prc;
}

void i59ini(void)
{
  ULO op=0xe010,ind,dir,modes,regs,regc,flats,size,immreg;
  for (size = 0; size < 3; size++)
    for (regc = 0; regc < 8; regc++) 
      for (dir = 0; dir < 2; dir++) 
        for (regs = 0; regs < 8; regs++)
          for (immreg = 0; immreg < 2; immreg++) {
            ind = op|regc<<9|dir<<8|size<<6|immreg<<5|regs;
            t[ind][0] = (size == 0) ?
                           ((immreg==0) ?
                             ((dir==0) ?
                               (ULO) i59_RI_I_B:
                               (ULO) i59_LE_I_B):
                             ((dir==0) ?
                               (ULO) i59_RI_R_B:
                               (ULO) i59_LE_R_B)):
                           ((size == 1) ?
                             ((immreg==0) ?
                               ((dir==0) ?
                                 (ULO) i59_RI_I_W:
                                 (ULO) i59_LE_I_W):
                               ((dir==0) ?
                                 (ULO) i59_RI_R_W:
                                 (ULO) i59_LE_R_W)):
                             ((immreg==0) ?
                               ((dir==0) ?
                                 (ULO) i59_RI_I_L:
                                 (ULO) i59_LE_I_L):
                               ((dir==0) ?
                                 (ULO) i59_RI_R_L:
                                 (ULO) i59_LE_R_L)));
            t[ind][1] = (ULO) i59dis;
            t[ind][2] = (immreg == 0) ?
                          ((regc == 0) ?
                            8:
                            regc):
                          (regc*4 + (ULO) d);
            t[ind][3] = regs*4 + (ULO) d;
            t[ind][4] = (size == 3) ?
                          ((immreg == 0) ?
                            (8+(t[ind][2]*2)):
                            8):
                          ((immreg == 0) ?
                            (6+(t[ind][2]*2)):
                            6);
            }


  op = 0xe4c0;
  for (dir = 0; dir < 2; dir++) 
    for (modes = 0; modes < 8; modes++) 
      for (regs = 0; regs < 8; regs++) {
        flats = (modes != 7) ? modes : (modes+regs);
        if (memory[flats] && alterable[flats]) {
          ind = op|dir<<8|modes<<3|regs;
          t[ind][0] = (dir == 0) ?
                        (ULO) i59_RI_M_W:
                        (ULO) i59_LE_M_W;
          t[ind][1] = (ULO) i59dis;
          t[ind][2] = (modes == 0) ?
                         (regs*4 + (ULO) d):
                         (regs*4 + (ULO) a);
          t[ind][3] = parw[flats];
          t[ind][4] = aww[flats];
          t[ind][5] = 8+tarw[flats];
          }
        }
}




/*
 Instruction RTE
 Table-usage:
     0-Routinepointer 1-disasm routine
*/

ULO i61dis(ULO prc,ULO opc,ULO y) 
{
  char st[80];
  sprintf(st,"$%.6X %.4X                   RTE",prc,opc);
  plot_text_window(&debugdisass,st,0,y);
  return prc+2;
}

void i61ini(void)
{
  ULO op=0x4e73;
  t[op][0] = (ULO) i61;
  t[op][1] = (ULO) i61dis;
}

/*
 Instruction RTR
 Table-usage:
     0-Routinepointer 1-disasm routine
*/

ULO i62dis(ULO prc,ULO opc,ULO y) 
{
  char st[80];
  sprintf(st,"$%.6X %.4X                   RTR",prc,opc);
  plot_text_window(&debugdisass,st,0,y);
  return prc+2;
}

void i62ini(void)
{
  ULO op=0x4e77;
  t[op][0] = (ULO) i62;
  t[op][1] = (ULO) i62dis;
}    

/*
 Instruction RTS
 Table-usage:
     0-Routinepointer 1-disasm routine
*/

ULO i63dis(ULO prc,ULO opc,ULO y) 
{
  char st[80];
  sprintf(st,"$%.6X %.4X                   RTS",prc,opc);
  plot_text_window(&debugdisass,st,0,y);
  return prc+2;
}

void i63ini(void)
{
  ULO op=0x4e75;
  t[op][0] = (ULO) i63;
  t[op][1] = (ULO) i63dis;
}    

/*
 Instruction SBCD.B Ry,Rx / SBCD.B -(Ay),-(Ax)
 Table-usage: 0 - Routinepointer 1 - disasm routine 2 - Rx*4(dest) 3 - Ry*4
*/

ULO i64dis(ULO prc,ULO opc,ULO y)
{
  char st[80];
  sprintf(st,((opc&0x8 == 0) ?
                "$%.6X %.4X                   SBCD.B  D%1d,D%1d":
                "$%.6X %.4X                   SBCD.B  -(A%1d),-(A%1d)"),
                prc,opc,opc&0x3,(opc&0xe00)>>9);
  plot_text_window(&debugdisass,st,0,y);
  return prc+2;
}

void i64ini(void)
{
  ULO op=0x8100,ind,rm,rx,ry;
  for (rm = 0; rm <= 1; rm++) 
    for (rx = 0; rx <= 7; rx++) 
      for (ry = 0; ry <= 7; ry++) {
        ind = op|ry|rx<<9|rm<<3;
        t[ind][0] = (rm == 0) ?
                       (ULO) i64_1:
                       (ULO) i64_2;
        t[ind][1] = (ULO) i64dis;
        t[ind][2] = (rm == 0) ?
                       (rx*4 + (ULO) d):
                       (rx*4 + (ULO) a);
        t[ind][3] = (rm == 0) ?
                       (ry*4 + (ULO) d):
                       (ry*4 + (ULO) a);
        }
}

/*
 Instruction Scc.B <ea>
 Table-usage:

  0-Routinepointer 1-disasm routine  2-reg*4+d  3-ea write routine
                4-handle routine 5-cyclecount not taken  6-cycle count taken
*/

ULO i65dis(ULO prc,ULO opc,ULO y)
{
  char st[80];
  ULO pos=13,j,adr,mode=(opc&0x38)>>3,reg=(opc&0x7);
  sprintf(st,"$%.6X %.4X                   S",prc,opc);
  switch ((opc&0xf00)>>8) {
     case 0:  strcat(st,"T.B    ");
              break;
     case 1:  strcat(st,"F.B    ");
              break;           
     case 2:  strcat(st,"HI.B   ");
              break;
     case 3:  strcat(st,"LS.B   ");
              break;
     case 4:  strcat(st,"CC.B   ");
              break;
     case 5:  strcat(st,"CS.B   ");
              break;
     case 6:  strcat(st,"NE.B   ");
              break;
     case 7:  strcat(st,"EQ.B   ");
              break;
     case 8:  strcat(st,"VC.B   ");
              break;
     case 9:  strcat(st,"VS.B   ");
              break;
     case 10: strcat(st,"PL.B   ");
              break;
     case 11: strcat(st,"MI.B   ");
              break;
     case 12: strcat(st,"GE.B   ");
              break;
     case 13: strcat(st,"LT.B   ");
              break;
     case 14: strcat(st,"GT.B   ");
              break;
     case 15: strcat(st,"LE.B   ");
              break;
       }
  if (mode == 7) mode += reg;
  prc = disfordel(mode,prc+2,st,8,reg,&pos);
  plot_text_window(&debugdisass,st,0,y);
  return prc;
}


void i65ini(void)
{
  ULO op=0x50c0,c,ind,flat,mode,reg;
  ULO routines[16] = {(ULO) cc0,(ULO) cc1false,(ULO) cc2,(ULO) cc3,(ULO) cc4,(ULO) cc5,(ULO) cc6,(ULO) cc7,(ULO) cc8,(ULO) cc9,(ULO) cca,(ULO) ccb,(ULO) ccc,(ULO) ccd,(ULO) cce,(ULO) ccf};
  for (c = 0; c < 16; c++)
    for (mode = 0; mode < 8; mode++) 
      for (reg = 0; reg < 8; reg++) {
        flat = (mode != 7) ?
                   mode:
                   (mode+reg);
        if (data[flat] && alterable[flat]) {
          ind = op|c<<8|mode<<3|reg;
          t[ind][0] = (ULO) i65;
          t[ind][1] = (ULO) i65dis;
          t[ind][2] = (mode == 0) ? (reg*4 + (ULO) d):
                                    (reg*4 + (ULO) a);  
          t[ind][3] = awb[flat];
          t[ind][4] = routines[c];
          t[ind][5] = 4+tarb[flat];
          t[ind][6] = (flat == 0) ?
                         6:
                         (4+tarb[flat]);
          }
        }
}

/*
 Instruction STOP #
 Table-usage:
     0-Routinepointer 1-disasm routine
*/

ULO i66dis(ULO prc,ULO opc,ULO y) 
{
  char st[80];
  ULO pos=13,reg=opc&0x7;
  sprintf(st,"$%.6X %.4X                   STOP #$%.4X",prc,opc,fetw(prc+2));
  plot_text_window(&debugdisass,st,0,y);
  return prc+4;
}

void i66ini(void)
{
  ULO op=0x4e72;
  t[op][0] = (ULO) i66;
  t[op][1] = (ULO) i66dis;
}

/*
 Instruction SUB.X <ea>,Dn / SUB.X Dn,<ea>
 Table-usage:
 Type 1:  SUB <ea>,Dn

  0-Routinepointer 1-disasm routine  2-sourreg 3-sourceroutine
                   4-Dreg        5-cycle count                   
 Type 2:  SUB Dn,<ea>

  0-Routinepointer 1-disasm routine  2-<ea>reg 3-get <ea> routine
                   4-Dreg        5-cycle count   6-write<ea> routine                
*/

ULO i67dis(ULO prc,ULO opc,ULO y) 
{
  char st[80];
  ULO pos=13,reg=opc&0x7,dreg=(opc&0xe00)>>9,o=opc&0x100,mode=(opc&0x38)>>3,
      size=(1+((opc&0xc0)>>6))<<3;
  if (mode == 7) mode += reg;
  sprintf(st,"$%.6X %.4X                   SUB.    ",prc,opc);
  st[35] = (size == 8) ?
              'B':
              (size == 16) ?
                 'W':
                 'L';
  prc = (o == 0) ? disfordel(reg,prc+2,st,size,mode,&pos) :
                   disfordel(dreg,prc+2,st,size,0,&pos);
  strcat(st,",");
  prc = (o != 0) ? disfordel(reg,prc,st,size,mode,&pos) :
                   disfordel(dreg,prc,st,size,0,&pos);
  plot_text_window(&debugdisass,st,0,y);
  return prc;
}

void i67ini(void)
{
  ULO op=0x9000,ind,regd,modes,regs,flats,size,o;
  for (o = 0; o < 2; o++)
    for (size = 0; size < 3; size++)
      for (regd = 0; regd < 8; regd++) 
        for (modes = 0; modes < 8; modes++) 
          for (regs = 0; regs < 8; regs++) {
            flats = (modes != 7) ?
                       modes:
                       (modes+regs);
            if ((o==0 && size == 0 && data[flats]) ||
                (o==0 && size != 0 && allmodes[flats]) ||
                (o==1 && alterable[flats] && memory[flats])) {
              ind = op|regd<<9|o<<8|size<<6|modes<<3|regs;
              t[ind][0] = (o == 0) ?
                             (size == 0) ?
                                (ULO) i67_B_1:
                                (size == 1) ?
                                   (ULO) i67_W_1:
                                   (ULO) i67_L_1:
                             (size == 0) ?
                                (ULO) i67_B_2:
                                (size == 1) ?
                                   (ULO) i67_W_2:
                                   (ULO) i67_L_2;
              t[ind][1] = (ULO) i67dis;
              t[ind][2] = (modes == 0) ?
                             (regs*4 + (ULO) d):
                             (regs*4 + (ULO) a);
              t[ind][3] = (o == 0) ?
                             (size == 0) ?
                                arb[flats]:
                                (size == 1) ?
                                   arw[flats]:
                                   arl[flats]:
                             (size == 0) ?
                                parb[flats]:
                                (size == 1) ?
                                   parw[flats]:
                                   parl[flats];
              t[ind][4] = regd*4 + (ULO) d;
              t[ind][5] = (o == 0) ?
                             (size == 0) ?
                                (4+tarb[flats]):
                                (size == 1) ?
                                   (4+tarw[flats]):
                                   (flats <= 1 || flats == 11) ?
                                      (8+tarl[flats]):
                                      (6+tarl[flats]):
                             (size == 0) ?
                                (8 + tarb[flats]):
                                (size == 1) ?
                                   (8 + tarw[flats]):
                                   (12 + tarl[flats]);
              if (o == 1) t[ind][6] = (size == 0) ?
                                         awb[flats]:
                                         (size == 1) ?
                                            aww[flats]:
                                            awl[flats];
              }
            }
}


/*
 Instruction SUBA.W/L <ea>,An
 Table-usage:

  0-Routinepointer 1-disasm routine  2-sourreg 3-sourceroutine
                   4-Areg        5-cycle count                   
*/



ULO i68dis(ULO prc,ULO opc,ULO y) 
{
  char st[80];
  ULO pos=13,reg=opc&0x7,dreg=(opc&0xe00)>>9,o=opc&0x100,mode=(opc&0x38)>>3,size;
  size = (o == 0) ?
            16:
            32;
  if (mode == 7) mode += reg;
  sprintf(st,"$%.6X %.4X                   SUBA.   ",prc,opc);
  st[36] = (size == 16) ?
              'W':
              'L';
  prc = disfordel(reg,prc+2,st,size,mode,&pos);
  strcat(st,",");
  disfordel(dreg,prc,st,size,1,&pos);
  plot_text_window(&debugdisass,st,0,y);
  return prc;
}

void i68ini(void)
{
  ULO op=0x90c0,ind,regd,modes,regs,flats,o;
  for (o = 0; o < 2; o++)
    for (regd = 0; regd < 8; regd++) 
      for (modes = 0; modes < 8; modes++) 
        for (regs = 0; regs < 8; regs++) 
          if (allmodes[(flats = (modes != 7) ? modes : (modes+regs))]) {
            ind = op|regd<<9|o<<8|modes<<3|regs;
            t[ind][0] = (o == 0) ?
                           (ULO) i68_W:
                           (ULO) i68_L;
            t[ind][1] = (ULO) i68dis;
            t[ind][2] = (modes == 0) ?
                           (regs*4 + (ULO) d):
                           (regs*4 + (ULO) a);
            t[ind][3] = (o == 0) ?
                           arw[flats]:
                           arl[flats];
            t[ind][4] = regd*4 + (ULO) a;
            t[ind][5] = (o==0) ?
                           (8 + tarw[flats]):
                           (flats <= 1 || flats == 11) ?
                              (8 + tarl[flats]):
                              (6 + tarl[flats]);
            }
}


/*
 Instruction SUBI.X #i,<ea>
 Table-usage:

  0-Routinepointer 1-disasm routine  2-eareg 3-ea read routine
                4-cycle count    5-ea write routine               
*/

ULO i69dis(ULO prc,ULO opc,ULO y) 
{
  char st[80];
  ULO pos=13,reg=opc&0x7,mode=(opc&0x38)>>3,size=(1+((opc&0xc0)>>6))<<3;
  if (mode == 7) mode += reg;
  sprintf(st,"$%.6X %.4X                   SUBI.   ",prc,opc);
  st[36] = (size == 8) ?
              'B':
              (size == 16) ?
                 'W':
                 'L';
  prc = disfordel(4,prc+2,st,size,11,&pos);
  strcat(st,",");
  prc = disfordel(reg,prc,st,size,mode,&pos);
  plot_text_window(&debugdisass,st,0,y);
  return prc;
}

void i69ini(void)
{
  ULO op=0x0400,ind,modes,regs,flats,size;
  for (size = 0; size < 3; size++)
    for (modes = 0; modes < 8; modes++) 
      for (regs = 0; regs < 8; regs++) {
        flats = (modes != 7) ? modes : (modes+regs);
        if (data[flats] && alterable[flats]) {
          ind = op|size<<6|modes<<3|regs;
          t[ind][0] = (size == 0) ?
                         (ULO) i69_B:
                         (size == 1) ?
                            (ULO) i69_W:
                            (ULO) i69_L; 
          t[ind][1] = (ULO) i69dis;
          t[ind][2] = (modes == 0) ?
                         (regs*4 + (ULO) d):
                         (regs*4 + (ULO) a);
          t[ind][3] = (size == 0) ?
                         parb[flats]:
                         (size == 1) ?
                            parw[flats]:
                            parl[flats];
          t[ind][4] = (size == 0) ?
                         (flats == 0) ?
                            8:
                            (12 + tarb[flats]):
                         (size == 1)  ?
                            (flats == 0) ?
                               8:
                               (12 + tarw[flats]):
                            (flats == 0) ?
                               16:
                               (20 + tarl[flats]);
          t[ind][5] = (size == 0) ?
                         awb[flats]:
                         (size == 1) ? 
                            aww[flats]:
                            awl[flats];
          }
        }
}

/*
 Instruction SUBQ.X #i,<ea>
 Table-usage:

  0-Routinepointer 1-disasm routine  2-eareg 3-ea read routine
                4-cycle count    5-ea write routine 6-SUB immediate              
*/

ULO i70dis(ULO prc,ULO opc,ULO y) 
{
  char st[80];
  ULO pos=13,reg=opc&0x7,mode=(opc&0x38)>>3,size=(1+((opc&0xc0)>>6))<<3;
  if (mode == 7) mode += reg;
  sprintf(st,"$%.6X %.4X                   SUBQ.   #$%.1d,",prc,opc,t[opc][6]);
  st[36] = (size == 8) ?
              'B':
              (size == 16) ?
                 'W':
                 'L';
  prc = disfordel(reg,prc+2,st,size,mode,&pos);
  plot_text_window(&debugdisass,st,0,y);
  return prc;
}


void i70ini(void)
{
  ULO op=0x5100,ind,imm,modes,regs,flats,size,o;
    for (size = 0; size < 3; size++)
      for (modes = 0; modes < 8; modes++) 
        for (regs = 0; regs < 8; regs++) 
          for (imm = 0; imm < 8; imm++) {
            flats = (modes != 7) ?
                       modes:
                       (modes+regs);
            if ((size == 0 && alterable[flats] && modes != 1) ||
                (size != 0 && alterable[flats])) {
              ind = op|imm<<9|size<<6|modes<<3|regs;
              t[ind][0] = (size == 0) ?
                             (ULO) i70_B:
                             (size == 1) ?
                                ((modes == 1) ? (ULO) i70_ADR:(ULO) i70_W):
                                (ULO) i70_L;
              t[ind][1] = (ULO) i70dis;
              t[ind][2] = (modes == 0) ?
                             (regs*4 + (ULO) d):
                             (regs*4 + (ULO) a);
              t[ind][3] = (size == 0) ?
                             parb[flats]:
                             (size == 1) ?
                                parw[flats]:
                                parl[flats];
              t[ind][4] = (size == 0) ?
                             (flats == 0) ?
                                (4+tarb[flats]):
                                (8+tarb[flats]):
                             (size == 1) ?
                                (flats == 0) ?
                                   (4+tarw[flats]):
                                   (8+tarw[flats]):
                                (flats < 2) ?
                                   (8+tarl[flats]):
                                   (12+tarl[flats]);
              t[ind][5] = (size == 0) ?
                             awb[flats]:
                             (size == 1) ?
                                aww[flats]:
                                awl[flats];
              t[ind][6] = (imm == 0) ?
                             8:
                             imm;
              }
            }
}

/*
 Instruction SUB.X Ry,Rx / SUB.X -(Ay),-(Ax)
 Table-usage: 0 - Routinepointer 1 - disasm routine 2 - Rx*4(dest) 3 - Ry*4
*/

ULO i71dis(ULO prc,ULO opc,ULO y)
{
  char st[80];
  ULO size=(opc&0x00c0)>>6;
  sprintf(st,(((opc&0x8) == 0) ?
                "$%.6X %.4X                   SUBX.%s   D%d,D%d":
                "$%.6X %.4X                   SUBX.%s   -(A%d),-(A%d)"),
                prc,opc,(size == 0) ? "B":((size == 1) ? "W":"L"),(opc&SREG),(opc&DREG)>>9);
  plot_text_window(&debugdisass,st,0,y);
  return prc+2;
}


void i71ini(void)
{
  ULO op=0x9100,ind,rm,rx,ry,sz;
  for (sz = 0; sz <= 2; sz++)
    for (rm = 0; rm <= 1; rm++)
      for (rx = 0; rx <= 7; rx++) 
        for (ry = 0; ry <= 7; ry++) {
          ind = op|ry|rx<<9|rm<<3|sz<<6;
          t[ind][0] = (rm == 0) ?
                         (sz == 0) ?
                            (ULO) i71_B_1:
                            (sz == 1) ?
                               (ULO) i71_W_1:
                               (ULO) i71_L_1:
                         (sz == 0) ?
                            (ULO) i71_B_2:
                            (sz == 1) ?
                               (ULO) i71_W_2:
                               (ULO) i71_L_2;
          t[ind][1] = (ULO) i71dis;
          t[ind][2] = (rm == 0) ?
                         (rx*4 + (ULO) d):
                         (rx*4 + (ULO) a);
          t[ind][3] = (rm == 0) ?
                         (ry*4 + (ULO) d):
                         (ry*4 + (ULO) a);
          }
}

/*
 Instruction SWAP.W Dn
 Table-usage:
     0-Routinepointer 1-disasm routine  2-reg
*/

ULO i72dis(ULO prc,ULO opc,ULO y) 
{
  char st[80];
  sprintf(st,"$%.6X %.4X                   SWAP.W  D%1X",prc,opc,opc&0x7);
  plot_text_window(&debugdisass,st,0,y);
  return prc+2;
}

void i72ini(void)
{
  ULO op=0x4840,ind,reg;
  for (reg = 0; reg < 8; reg++) {
    ind = op|reg;
    t[ind][0] = (ULO) i72;
    t[ind][1] = (ULO) i72dis;
    t[ind][2] = reg*4 + (ULO) d;
    }    
}

/*
 Instruction TAS.B <ea>
 Table-usage:

  0-Routinepointer 1-disasm routine  2-eareg 3-ea read routine
                4-ea write routine  5-cycle count             
*/

ULO i73dis(ULO prc,ULO opc,ULO y) 
{
  char st[80];
  ULO pos=13,reg=opc&0x7,mode=(opc&0x38)>>3;
  if (mode == 7) mode += reg;
  sprintf(st,"$%.6X %.4X                   TAS.B   ",prc,opc);
  prc = disfordel(reg,prc+2,st,8,mode,&pos);
  plot_text_window(&debugdisass,st,0,y);
  return prc;
}

void i73ini(void)
{
  ULO op=0x4ac0,ind,modes,regs,flats;
  for (modes = 0; modes < 8; modes++) 
    for (regs = 0; regs < 8; regs++) {
      flats = (modes != 7) ? modes : (modes+regs);
      if (data[flats] && alterable[flats]) {
        ind = op|modes<<3|regs;
        t[ind][0] = (ULO) i73;
        t[ind][1] = (ULO) i73dis;
        t[ind][2] = (modes == 0) ?
                       (regs*4 + (ULO) d):
                       (regs*4 + (ULO) a);
        t[ind][3] = parb[flats];
        t[ind][4] = awb[flats];
        t[ind][5] = (flats == 0) ?
                       4:
                       (10 + tarb[flats]);
        }
      }
}

/*
 Instruction TRAP #
 Table-usage:
     0-Routinepointer 1-disasm routine  2-vector*4+80h
*/

ULO i74dis(ULO prc,ULO opc,ULO y) 
{
  char st[80];
  ULO pos=13;
  sprintf(st,"$%.6X %.4X                   TRAP    #$%1X",prc,opc,opc&0xf);
  plot_text_window(&debugdisass,st,0,y);
  return prc+2;
}

void i74ini(void)
{
  ULO op=0x4e40,ind,vektor;
  for (vektor = 0; vektor < 16; vektor++) {
    ind = op|vektor;
    t[ind][0] = (ULO) i74;
    t[ind][1] = (ULO) i74dis;
    t[ind][2] = vektor*4 + 0x80;
    }    
}

/*
 Instruction TRAPV
 Table-usage:
     0-Routinepointer 1-disasm routine
*/

ULO i75dis(ULO prc,ULO opc,ULO y) 
{
  char st[80];
  sprintf(st,"$%.6X %.4X                   TRAPV",prc,opc);
  plot_text_window(&debugdisass,st,0,y);
  return prc+2;
}

void i75ini(void)
{
  ULO op=0x4e76;
  t[op][0] = (ULO) i75;
  t[op][1] = (ULO) i75dis;
}

/*
 Instruction TST.X <ea>
 Table-usage:
  0-Routinepointer 1-disasm routine  2-sourreg 3-sourceroutine
                   4-cycle count                   
*/

ULO i76dis(ULO prc,ULO opc,ULO y) 
{
  char st[80];
  ULO pos=13,reg=opc&0x7,mode=(opc&0x38)>>3,size=(1+((opc&0xc0)>>6))<<3;
  if (mode == 7) mode += reg;
  sprintf(st,"$%.6X %.4X                   TST.    ",prc,opc);
  st[35] = (size == 8) ?
              'B':
              (size == 16) ?
                 'W':
                 'L';
  prc = disfordel(reg,prc+2,st,size,mode,&pos);
  plot_text_window(&debugdisass,st,0,y);
  return prc;
}

void i76ini(void)
{
  ULO op=0x4a00,ind,modes,regs,flats,size;
  for (size = 0; size < 3; size++)
    for (modes = 0; modes < 8; modes++) 
      for (regs = 0; regs < 8; regs++) {
        flats = (modes != 7) ?
                   modes:
                   (modes+regs);
        if (data[flats] && alterable[flats]) {
          ind = op|size<<6|modes<<3|regs;
        t[ind][0] = (size == 0) ?
                       (ULO) i76_B:
                       (size == 1) ?
                          (ULO) i76_W:
                          (ULO) i76_L;
        t[ind][1] = (ULO) i76dis;
        t[ind][2] = (modes == 0) ?
                       (regs*4 + (ULO) d):
                       (regs*4 + (ULO) a);
        t[ind][3] = (size == 0) ?
                       arb[flats]:
                       (size == 1) ?
                          arw[flats]:
                          arl[flats];
        t[ind][4] = (size == 0) ?
                       (4+tarb[flats]):
                       (size == 1) ?
                          (4+tarw[flats]):
                          (4+tarl[flats]);
        }
      }
}

/*
 Instruction UNLK An
 Table-usage:
     0-Routinepointer 1-disasm routine  2-reg
*/

ULO i77dis(ULO prc,ULO opc,ULO y) 
{
  char st[80];
  ULO reg=opc&0x7;
  sprintf(st,"$%.6X %.4X                   UNLK    A%1d",prc,opc,reg);
  plot_text_window(&debugdisass,st,0,y);
  return prc+2;
}

void i77ini(void)
{
  ULO op=0x4e58,ind,reg;
  for (reg = 0; reg < 8; reg++) {
    ind = op|reg;
    t[ind][0] = (ULO) i77;
    t[ind][1] = (ULO) i77dis;
    t[ind][2] = reg*4 + (ULO) a;
    }    
}

void cpuinit(void)
{
  ULO c,adr;
  int i,j,k;

  for (i = 0; i <= 65535; i++) {
    t[i][0] = (ULO) &i00;
    t[i][1] = (ULO) &i00dis;
    for (j = 2; j <= 7; j++) t[i][j] = 0;
    }
  makebcdtabs();
  createstatustab();

  i01ini();
  i02ini();
  i03ini();
  i04ini();
  i05ini();
  i06ini();
  i07ini();
  i08ini();
  i09ini();
  i11ini();
  i12ini();
  i13ini();
/* 14 included in 11 */
  i15ini();
/* 16 included in 11 */
  i17ini();
  i18ini();
  i19ini();
  i20ini();
  i21ini();
  i22ini();
  i23ini();
  i24ini();
  i25ini();
  i26ini();
  i27ini();
  i28ini();
  i29ini();
  i30ini();
  i31ini();
  i32ini();
  i33ini();
  i34ini();
  i35ini();
  i37ini();
  i38ini();
  i39ini();
  i40ini();
  i41ini();
  i42ini();
  i43ini();
  i44ini();
  i45ini();
  i46ini();
  i47ini();
  i48ini();
  i49ini();
  i50ini();
  i51ini();
  i52ini();
  i53ini();
  i54ini();
  i55ini();
  i56ini();
  i57ini();
  i59ini();
  i61ini();
  i62ini();
  i63ini();
  i64ini();
  i65ini();
  i66ini();
  i67ini();
  i68ini();
  i69ini();
  i70ini();
  i71ini();
  i72ini();
  i73ini();
  i74ini();
  i75ini();
  i76ini();
  i77ini();
  makemultab();


  a[7] = 0x200000;
  usp = 0x200000;
  ssp = 0x1f0800;
  sr = 0;

}


/*
   createstatustab
   Will translate the flags C X V N Z som the intel flag register
   X is set to the same as C since Intel doesn't have X
*/
void createstatustab(void)
{
  ULO i;
  for (i=0; i < 4096; i++)
    statustab[i]=(i&0x1)|((i&0x1)<<4)|((i&0xc0)>>4)|((i&0x800)>>10);
}


/* Make muls and mulu tables for clock calculations */

void makemultab(void)
{
  ULO i,j,k;

  for (i = 0; i < 256; i++) {
    j = 0;
    for (k = 0; k < 8; k++) if (((i>>k) & 1) == 1) j++;
    mulutab[i] = j;

    j = 0;
    for (k = 0; k < 8; k++) if ((((i>>k) & 3) == 1) || (((i>>k) & 3) == 2)) j++; 
    mulstab[i] = j;
    }
}




