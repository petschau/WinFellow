// Petter Schau 1996

#include <stdio.h>
#include <conio.h>

#include "defs.h"
#include "io.h"
#include "68.h"
#include "chip.h"
#include "mem.h"
#include "pmpro.h"
#include "menu.h"
//#include "eventid.h"
#include "disk.h"
#include "sb.h"
#include "sound.h"

extern void init_lineflagstables(void);

extern void fix_a7pointer(void);

ULO trackmo = 0;
ULO debugging;
extern ULO emuspeed;

extern ULO bytestotransfer;

extern ULO f12pressed;
extern ULO indexx,leng;
extern ULO soundon,sbio;
extern ULO norom;
extern ULO playfieldon;

extern ULO leftbutton;
extern ULO rightbutton;
extern ULO curcycle;

ULO chipmemsize,bogomemsize;
ULO enableleds;
ULO supportinterlace;
ULO linedouble;

char df0name[120],df1name[120],df2name[120],df3name[120];

ULO a7pointer;

#ifdef CPUTRACE
ULO cputracebuffer[524288];
// ints for correct comparison
int cputraceflag;
int cputracecount=0;
int cputraceptr=0;
ULO cputsr[524288];

#endif

int errorvalue = 0;

ULO breakpoint;

#ifdef LOGGING
// ******************************************************************
// CONFIGURATION DATA
// ******************************************************************




struct yesnomenu logconfigmenu;


// Log buffer
// Layout:  
// -----------
// f�rst event id
// Frame nr
// Yposisjon
// Xposisjon
// 12 evt. data longwords

ULO logbuffer[EVENTCOUNT][16];
int logfirst;
int loglast;


// Logging flags
ULO logserialtransmitbufferemptyirq = 0;
ULO logdiskdmatransferdoneirq = 0;
ULO logsoftwareirq = 0;
ULO logciaairq = 0;
ULO logcopperirq = 0;
ULO logverticalblankirq = 0;
ULO logblitterreadyirq = 0;
ULO logaudio0irq = 0;
ULO logaudio1irq = 0;
ULO logaudio2irq = 0;
ULO logaudio3irq = 0;
ULO logserialreceivebufferfullirq = 0;
ULO logdisksyncvaluerecognizedirq = 0;
ULO logciabirq = 0;
ULO logintenairq = 0;
ULO logciaatimeratimeoutirq = 0;
ULO logciaatimerbtimeoutirq = 0;
ULO logciaaeventcounterirq = 0;
ULO logciaaserialportirq = 0;
ULO logciaaparallelportirq = 0;
ULO logciabtimeratimeoutirq = 0;
ULO logciabtimerbtimeoutirq = 0;
ULO logciabeventcounterirq = 0;
ULO logciabserialportirq = 0;
ULO logciabparallelportirq = 0;
ULO logcopper = 0;
ULO logblitter = 0;
ULO logstop = 0;
ULO logbuserrorex = 0;
ULO logoddaddressex = 0;
ULO logillegalinstructionex = 0;
ULO logdivisionby0ex = 0;
ULO logchkex = 0;
ULO logtrapvex = 0;
ULO logprivilegieviolationex = 0;
ULO logtrapex = 0;
ULO logdmaconwrites = 0;
ULO logciaawrites = 0;
ULO logciabwrites = 0;
ULO logciaareads = 0;
ULO logciabreads = 0;
ULO logputmsg = 0;
ULO loggetmsg = 0;
ULO logreplymsg = 0;

// ******************************************************************
// END OF CONFIGURATION DATA
// ******************************************************************

#endif

// ******************************************************************
// MAIN SCREEN DATA
// ******************************************************************

// mainmenudata holds the data about the menu on the main screen
// -------------------------------------------------------------

struct menu mainmenudata;

// Windows on the main screen
//---------------------------

struct window mainmenu;
struct window maintitle;
struct window mainconsole;
struct window maininfo;

// ******************************************************************
// END OF MAIN SCREEN DATA
// ******************************************************************





// ******************************************************************
// CONFIGURATION SCREEN DATA
// ******************************************************************

struct window config_enterdisk_requester;
struct optionmenu config_optionmenu;

// ******************************************************************
// DEBUGGER SCREEN DATA
// ******************************************************************

// Menus for debugger
// ------------------

struct menu debugmenumain;
struct menu debugmenubreakpointrequester;

// Windows for debugger
// --------------------

struct window debugregisters;
struct window debugmenu;
struct window debuginfo;
struct window debugdisass;

// Requesters for debugger
// -----------------------

struct window debugbreakpointrequester;
struct window debugenterbreakpointrequester;

// Number fields for debugger
// --------------------------

struct numberfield debugenterbreakpointnumberfield;

// Requesters for config
// -----------------------

struct window config_enterdiskrequester;

// String fields for config
// --------------------------

struct stringfield config_enterdiskstringfield;




// ******************************************************************
// END OF DEBUGGER SCREEN DATA
// ******************************************************************


/* skiprate leses fra kommandolinja */
int skiprate = 0;
ULO frameskip = 0;

/* Legge dette inn i en h fil?? */
extern ULO frames;
extern ULO curcycle;

void setup_reset()
{
  trackmo = 0;
  pc = fetl(0xf80004);
  intena = intenar = 0;
  dmaconr = 0;
  dmacon = 0;
  reset_mousekeyboard();
}






void load_fellow_cfg(void) {
  FILE *C;
  char var[80];
  char val[256];

  strcpy(df0name,"__none__");
  strcpy(df1name,"__none__");
  strcpy(df2name,"__none__");
  strcpy(df3name,"__none__");
  chipmemsize = CHIPMEM;
  bogomemsize = BOGOMEM;
  emulate_joystick = 0;
  skiprate = 0;
  enableleds = 1;
  diskspeed = 3;
  cpuspeed = 0;
  supportinterlace = 0;

  if ((C = fopen("fellow.cfg","r")) != NULL) {
    while (!feof(C)) {
      fscanf(C,"%s %s\n",var,val);
      if (strcmp("DF0",var) == 0) strcpy(df0name,val);
      else if (strcmp("DF1",var) == 0) strcpy(df1name,val);
      else if (strcmp("DF2",var) == 0) strcpy(df2name,val);
      else if (strcmp("DF3",var) == 0) strcpy(df3name,val);
      else if (strcmp("CHIPMEM",var) == 0) chipmemsize = atoi(val);
      else if (strcmp("BOGOMEM",var) == 0) bogomemsize = atoi(val);
      else if (strcmp("JOYSTICK",var) == 0) emulate_joystick = atoi(val);
      else if (strcmp("SKIPRATE",var) == 0) skiprate = atoi(val);
      else if (strcmp("ENABLELEDS",var) == 0) enableleds = atoi(val);
      else if (strcmp("DISKSPEED",var) == 0) diskspeed = atoi(val);
      else if (strcmp("CPUSPEED",var) == 0) cpuspeed = atoi(val);
      else if (strcmp("SUPPORTINTERLACE",var) == 0) supportinterlace = atoi(val);
      }         
    fclose(C);
    chipmemsize &= 0x3c0000;
    if (chipmemsize > 0x200000) chipmemsize = 0x200000;
    if (chipmemsize == 0) chipmemsize = CHIPMEM;
    if (chipmemsize > CHIPMEM) chipmemsize = CHIPMEM;
    bogomemsize &= 0x1c0000;
    if (bogomemsize > 0x100000) bogomemsize = 0x100000;
    if (bogomemsize > BOGOMEM) chipmemsize = BOGOMEM;
    if (diskspeed > 8) diskspeed = 8;
    if (diskspeed < 1) diskspeed = 1;
    if (cpuspeed > 2) cpuspeed = 2;
  }
}

void save_fellow_cfg(void) {
  FILE *C;

  if ((C = fopen("fellow.cfg","w")) != NULL) {
    fprintf(C,"DF0 %s\n",df0name);
    fprintf(C,"DF1 %s\n",df1name);
    fprintf(C,"DF2 %s\n",df2name);
    fprintf(C,"DF3 %s\n",df3name);
    fprintf(C,"CHIPMEM %d\n",chipmemsize);
    fprintf(C,"BOGOMEM %d\n",bogomemsize);
    fprintf(C,"JOYSTICK %d\n",emulate_joystick);
    fprintf(C,"SKIPRATE %d\n",skiprate);
    fprintf(C,"ENABLELEDS %d\n",enableleds);
    fprintf(C,"DISKSPEED %d\n",diskspeed);
    fprintf(C,"CPUSPEED %d\n",cpuspeed);
    fprintf(C,"SUPPORTINTERLACE %d\n",supportinterlace);
    fclose(C);
    }           
}





#ifdef LOGGING
// ******************************************************************
// LOGGING CONFIGURATION PROCEDURES
// ******************************************************************

// Returns false when something went wrong

 
ULO loadlogconfig(void) {
  FILE *F;
  char var[80];
  ULO value;
  if ((F = fopen("log.cfg","r")) == NULL) return 0;
  while (!feof(F)) {
    fscanf(F,"%s %d\n",var,&value);
    if (strcmp("LOGSERIALTRANSMITBUFFEREMPTYIRQ",var) == 0) logserialtransmitbufferemptyirq = value;
    else if (strcmp("LOGDISKDMATRANSFERDONEIRQ",var) == 0) logdiskdmatransferdoneirq = value;
    else if (strcmp("LOGSOFTWAREIRQ",var) == 0) logsoftwareirq = value;
    else if (strcmp("LOGCIAAIRQ",var) == 0) logciaairq = value;
    else if (strcmp("LOGCOPPERIRQ",var) == 0) logcopperirq = value;
    else if (strcmp("LOGVERTICALBLANKIRQ",var) == 0) logverticalblankirq = value;
    else if (strcmp("LOGBLITTERREADYIRQ",var) == 0) logblitterreadyirq = value;
    else if (strcmp("LOGAUDIO0IRQ",var) == 0) logaudio0irq = value;
    else if (strcmp("LOGAUDIO1IRQ",var) == 0) logaudio1irq = value;
    else if (strcmp("LOGAUDIO2IRQ",var) == 0) logaudio2irq = value;
    else if (strcmp("LOGAUDIO3IRQ",var) == 0) logaudio3irq = value;
    else if (strcmp("LOGSERIALRECEIVEBUFFERFULLIRQ",var) == 0) logserialreceivebufferfullirq = value;
    else if (strcmp("LOGDISKSYNCVALUERECOGNIZEDIRQ",var) == 0) logdisksyncvaluerecognizedirq = value;
    else if (strcmp("LOGCIABIRQ",var) == 0) logciabirq = value;
    else if (strcmp("LOGINTENAIRQ",var) == 0) logintenairq = value;
    else if (strcmp("LOGCIAATIMERATIMEOUTIRQ",var) == 0) logciaatimeratimeoutirq = value;
    else if (strcmp("LOGCIAATIMERBTIMEOUTIRQ",var) == 0) logciaatimerbtimeoutirq = value;
    else if (strcmp("LOGCIAAEVENTCOUNTERIRQ",var) == 0) logciaaeventcounterirq = value;
    else if (strcmp("LOGCIAASERIALPORTIRQ",var) == 0) logciaaserialportirq = value;
    else if (strcmp("LOGCIAAPARALLELPORTIRQ",var) == 0) logciaaparallelportirq = value;
    else if (strcmp("LOGCIABTIMERATIMEOUTIRQ",var) == 0) logciabtimeratimeoutirq = value;
    else if (strcmp("LOGCIABTIMERBTIMEOUTIRQ",var) == 0) logciabtimerbtimeoutirq = value;
    else if (strcmp("LOGCIABEVENTCOUNTERIRQ",var) == 0) logciabeventcounterirq = value;
    else if (strcmp("LOGCIABSERIALPORTIRQ",var) == 0) logciabserialportirq = value;
    else if (strcmp("LOGCIABPARALLELPORTIRQ",var) == 0) logciabparallelportirq = value;
    else if (strcmp("LOGCOPPER",var) == 0) logcopper = value;
    else if (strcmp("LOGBLITTER",var) == 0) logblitter = value;
    else if (strcmp("LOGSTOP",var) == 0) logstop = value;
    else if (strcmp("LOGBUSERROREX",var) == 0) logbuserrorex = value;
    else if (strcmp("LOGODDADDRESSEX",var) == 0) logoddaddressex = value;
    else if (strcmp("LOGILLEGALINSTRUCTIONEX",var) == 0) logillegalinstructionex = value;
    else if (strcmp("LOGDIVISIONBY0EX",var) == 0) logdivisionby0ex = value;
    else if (strcmp("LOGCHKEX",var) == 0) logchkex = value;
    else if (strcmp("LOGTRAPVEX",var) == 0) logtrapvex = value;
    else if (strcmp("LOGPRIVILEGIEVIOLATIONEX",var) == 0) logprivilegieviolationex = value;
    else if (strcmp("LOGTRAPEX",var) == 0) logtrapex = value;
    else if (strcmp("LOGDMACONWRITES",var) == 0) logdmaconwrites = value;
    else if (strcmp("LOGCIAAWRITES",var) == 0) logciaawrites = value;
    else if (strcmp("LOGCIABWRITES",var) == 0) logciabwrites = value;
    else if (strcmp("LOGCIAAREADS",var) == 0) logciaareads = value;
    else if (strcmp("LOGCIABREADS",var) == 0) logciabreads = value;
    else if (strcmp("LOGPUTMSG",var) == 0) logputmsg = value;
    else if (strcmp("LOGGETMSG",var) == 0) loggetmsg = value;
    else if (strcmp("LOGREPLYMSG",var) == 0) logreplymsg = value;
   
    }
  fclose(F);
  return 1;
}    

ULO savelogconfig(void) {
  FILE *F;

  if ((F = fopen("log.cfg","w")) == NULL) return 0;
  fprintf(F,"%s %d\n","LOGSERIALTRANSMITBUFFEREMPTYIRQ",logserialtransmitbufferemptyirq);
  fprintf(F,"%s %d\n","LOGDISKDMATRANSFERDONEIRQ",logdiskdmatransferdoneirq);
  fprintf(F,"%s %d\n","LOGSOFTWAREIRQ",logsoftwareirq);
  fprintf(F,"%s %d\n","LOGCIAAIRQ",logciaairq);
  fprintf(F,"%s %d\n","LOGCOPPERIRQ",logcopperirq);
  fprintf(F,"%s %d\n","LOGVERTICALBLANKIRQ",logverticalblankirq);
  fprintf(F,"%s %d\n","LOGBLITTERREADYIRQ",logblitterreadyirq);
  fprintf(F,"%s %d\n","LOGAUDIO0IRQ",logaudio0irq);
  fprintf(F,"%s %d\n","LOGAUDIO1IRQ",logaudio1irq);
  fprintf(F,"%s %d\n","LOGAUDIO2IRQ",logaudio2irq);
  fprintf(F,"%s %d\n","LOGAUDIO3IRQ",logaudio3irq);
  fprintf(F,"%s %d\n","LOGSERIALRECEIVEBUFFERFULLIRQ",logserialreceivebufferfullirq);
  fprintf(F,"%s %d\n","LOGDISKSYNCVALUERECOGNIZEDIRQ",logdisksyncvaluerecognizedirq);
  fprintf(F,"%s %d\n","LOGCIABIRQ",logciabirq);
  fprintf(F,"%s %d\n","LOGINTENAIRQ",logintenairq);
  fprintf(F,"%s %d\n","LOGCIAATIMERATIMEOUTIRQ",logciaatimeratimeoutirq);
  fprintf(F,"%s %d\n","LOGCIAATIMERBTIMEOUTIRQ",logciaatimerbtimeoutirq);
  fprintf(F,"%s %d\n","LOGCIAAEVENTCOUNTERIRQ",logciaaeventcounterirq);
  fprintf(F,"%s %d\n","LOGCIAASERIALPORTIRQ",logciaaserialportirq);
  fprintf(F,"%s %d\n","LOGCIAAPARALLELPORTIRQ",logciaaparallelportirq);
  fprintf(F,"%s %d\n","LOGCIABTIMERATIMEOUTIRQ",logciabtimeratimeoutirq);
  fprintf(F,"%s %d\n","LOGCIABTIMERBTIMEOUTIRQ",logciabtimerbtimeoutirq);
  fprintf(F,"%s %d\n","LOGCIABEVENTCOUNTERIRQ",logciabeventcounterirq);
  fprintf(F,"%s %d\n","LOGCIABSERIALPORTIRQ",logciabserialportirq);
  fprintf(F,"%s %d\n","LOGCIABPARALLELPORTIRQ",logciabparallelportirq);
  fprintf(F,"%s %d\n","LOGCOPPER",logcopper);
  fprintf(F,"%s %d\n","LOGBLITTER",logblitter);
  fprintf(F,"%s %d\n","LOGSTOP",logstop);
  fprintf(F,"%s %d\n","LOGBUSERROREX",logbuserrorex);
  fprintf(F,"%s %d\n","LOGODDADDRESSEX",logoddaddressex);
  fprintf(F,"%s %d\n","LOGILLEGALINSTRUCTIONEX",logillegalinstructionex);
  fprintf(F,"%s %d\n","LOGDIVISIONBY0EX",logdivisionby0ex);
  fprintf(F,"%s %d\n","LOGCHKEX",logchkex);
  fprintf(F,"%s %d\n","LOGTRAPVEX",logtrapvex);
  fprintf(F,"%s %d\n","LOGPRIVILEGIEVIOLATIONEX",logprivilegieviolationex);
  fprintf(F,"%s %d\n","LOGTRAPEX",logtrapex);    
  fprintf(F,"%s %d\n","LOGDMACONWRITES",logdmaconwrites);    
  fprintf(F,"%s %d\n","LOGCIAAWRITES",logciaawrites);    
  fprintf(F,"%s %d\n","LOGCIABWRITES",logciabwrites);    
  fprintf(F,"%s %d\n","LOGCIAAREADS",logciaareads);    
  fprintf(F,"%s %d\n","LOGCIABREADS",logciabreads);    
  fprintf(F,"%s %d\n","LOGPUTMSG",logputmsg);    
  fprintf(F,"%s %d\n","LOGGETMSG",loggetmsg);    
  fprintf(F,"%s %d\n","LOGREPLYMSG",logreplymsg);    
  fclose(F);
  return 1;
}    


// init the yesno menu used in log config
// --------------------------------------
void init_logconfig_yesnomenu(void) {
  strcpy(logconfigmenu.items[0].text,"Serial transmit buffer empty interrupt (Level 1)");
  logconfigmenu.items[0].value = &logserialtransmitbufferemptyirq;
  strcpy(logconfigmenu.items[1].text,"Disk DMA transfer done interrupt (Level 1)");
  logconfigmenu.items[1].value = &logdiskdmatransferdoneirq;
  strcpy(logconfigmenu.items[2].text,"Software interrupt (Level 1)");
  logconfigmenu.items[2].value = &logsoftwareirq;
  strcpy(logconfigmenu.items[3].text,"Cia A interrupt (Level 2 - Detailed logging configuration below)");
  logconfigmenu.items[3].value = &logciaairq;
  strcpy(logconfigmenu.items[4].text,"Copper interrupt (Level 3)");
  logconfigmenu.items[4].value = &logcopperirq;
  strcpy(logconfigmenu.items[5].text,"Vertical blank interrupt (Level 3)");
  logconfigmenu.items[5].value = &logverticalblankirq;
  strcpy(logconfigmenu.items[6].text,"Blitter ready interrupt (Level 3)");
  logconfigmenu.items[6].value = &logblitterreadyirq;
  strcpy(logconfigmenu.items[7].text,"Audio channel 0 interrupt (Level 4)");
  logconfigmenu.items[7].value = &logaudio0irq;
  strcpy(logconfigmenu.items[8].text,"Audio channel 1 interrupt (Level 4)");
  logconfigmenu.items[8].value = &logaudio1irq;
  strcpy(logconfigmenu.items[9].text,"Audio channel 2 interrupt (Level 4)");
  logconfigmenu.items[9].value = &logaudio2irq;
  strcpy(logconfigmenu.items[10].text,"Audio channel 3 interrupt (Level 4)");
  logconfigmenu.items[10].value = &logaudio3irq;
  strcpy(logconfigmenu.items[11].text,"Serial receive buffer full interrupt (Level 5)");
  logconfigmenu.items[11].value = &logserialreceivebufferfullirq;
  strcpy(logconfigmenu.items[12].text,"Disk sync value recognized interrupt (Level 5)");
  logconfigmenu.items[12].value = &logdisksyncvaluerecognizedirq;
  strcpy(logconfigmenu.items[13].text,"Cia B interrupt (Level 6 - Detailed logging configuration below)");
  logconfigmenu.items[13].value = &logciabirq;
  strcpy(logconfigmenu.items[14].text,"Intena bit set in INTREQ interrupt (Level 6)");
  logconfigmenu.items[14].value = &logintenairq;
  strcpy(logconfigmenu.items[15].text,"Cia A Timer A timeout interrupt");
  logconfigmenu.items[15].value = &logciaatimeratimeoutirq;
  strcpy(logconfigmenu.items[16].text,"Cia A Timer B timeout interrupt");
  logconfigmenu.items[16].value = &logciaatimerbtimeoutirq;
  strcpy(logconfigmenu.items[17].text,"Cia A Event counter interrupt");
  logconfigmenu.items[17].value = &logciaaeventcounterirq;
  strcpy(logconfigmenu.items[18].text,"Cia A Serial port interrupt (Keyboard)");
  logconfigmenu.items[18].value = &logciaaserialportirq;
  strcpy(logconfigmenu.items[19].text,"Cia A Parallel port handshake interrupt");
  logconfigmenu.items[19].value = &logciaaparallelportirq;
  strcpy(logconfigmenu.items[20].text,"Cia B Timer A timeout interrupt");
  logconfigmenu.items[20].value = &logciabtimeratimeoutirq;
  strcpy(logconfigmenu.items[21].text,"Cia B Timer B timeout interrupt");
  logconfigmenu.items[21].value = &logciabtimerbtimeoutirq;
  strcpy(logconfigmenu.items[22].text,"Cia B Event counter interrupt");
  logconfigmenu.items[22].value = &logciabeventcounterirq;
  strcpy(logconfigmenu.items[23].text,"Cia B Serial port interrupt");
  logconfigmenu.items[23].value = &logciabserialportirq;
  strcpy(logconfigmenu.items[24].text,"Cia B Parallel port handshake interrupt");
  logconfigmenu.items[24].value = &logciabparallelportirq;
  strcpy(logconfigmenu.items[25].text,"Bus error exception");
  logconfigmenu.items[25].value = &logbuserrorex;
  strcpy(logconfigmenu.items[26].text,"Odd address exception");
  logconfigmenu.items[26].value = &logoddaddressex;
  strcpy(logconfigmenu.items[27].text,"Illegal instruction execption");
  logconfigmenu.items[27].value = &logillegalinstructionex;
  strcpy(logconfigmenu.items[28].text,"Division by Zero exception");
  logconfigmenu.items[28].value = &logdivisionby0ex;
  strcpy(logconfigmenu.items[29].text,"Chk instruction exception");
  logconfigmenu.items[29].value = &logchkex;
  strcpy(logconfigmenu.items[30].text,"Trapv instruction exception");
  logconfigmenu.items[30].value = &logtrapvex;
  strcpy(logconfigmenu.items[31].text,"Privilegie violation exception");
  logconfigmenu.items[31].value = &logprivilegieviolationex;
  strcpy(logconfigmenu.items[32].text,"Trap instruction exception");
  logconfigmenu.items[32].value = &logtrapex;
  strcpy(logconfigmenu.items[33].text,"Stop instruction");
  logconfigmenu.items[33].value = &logstop;
  strcpy(logconfigmenu.items[34].text,"Copper");
  logconfigmenu.items[34].value = &logcopper;
  strcpy(logconfigmenu.items[35].text,"Blitter");
  logconfigmenu.items[35].value = &logblitter;
  strcpy(logconfigmenu.items[36].text,"DMACON writes");
  logconfigmenu.items[36].value = &logdmaconwrites;
  strcpy(logconfigmenu.items[37].text,"CIA A writes");
  logconfigmenu.items[37].value = &logciaawrites;
  strcpy(logconfigmenu.items[38].text,"CIA B writes");
  logconfigmenu.items[38].value = &logciabwrites;
  strcpy(logconfigmenu.items[39].text,"CIA A reads");
  logconfigmenu.items[39].value = &logciaareads;
  strcpy(logconfigmenu.items[40].text,"CIA B reads");
  logconfigmenu.items[40].value = &logciabreads;
  strcpy(logconfigmenu.items[41].text,"PutMsg");
  logconfigmenu.items[41].value = &logputmsg;
  strcpy(logconfigmenu.items[42].text,"GetMsg");
  logconfigmenu.items[42].value = &loggetmsg;
  strcpy(logconfigmenu.items[43].text,"ReplyMsg");
  logconfigmenu.items[43].value = &logreplymsg;


  logconfigmenu.numberofentries = 44;
  logconfigmenu.yesnopos = 73;
  logconfigmenu.activeentry = 0;
  logconfigmenu.menuwindow = &debugdisass;
}

void print_logconfig(void) {
  clear_window(&debugdisass);
  yesnomenu_print(&logconfigmenu);
}

// Use debugdisass window to hold log config screen
// ------------------------------------------------

void setup_logconfig_window(void) {
  // Setup the yesnomenu
  init_logconfig_yesnomenu();
  print_logconfig();
};


// Printer loggen fra start til stop

// Interrupts har datastruktur:
// 0: eventid
// 1: frame
// 2: ypos
// 3: xpos
// 4: pc n�r int oppstod

void print_log(ULO start,ULO stop) {
  ULO current;
  char s[80];
  for (current = start; current < stop; current++) {
    switch(logbuffer[current%EVENTCOUNT][0]) {
      case IRQ1_0_TBE:
        sprintf(s,"F-%.8X Y-%.3X X-%.3X - Serial Transmit Buffer Empty Interrupt (PC=%.6X)",logbuffer[current%EVENTCOUNT][1],logbuffer[current%EVENTCOUNT][2],logbuffer[current%EVENTCOUNT][3],logbuffer[current%EVENTCOUNT][4]);
        break;
      case IRQ1_1_DSKBLK:
        sprintf(s,"F-%.8X Y-%.3X X-%.3X - Disk DMA Transfer Done Interrupt (PC=%.6X)",logbuffer[current%EVENTCOUNT][1],logbuffer[current%EVENTCOUNT][2],logbuffer[current%EVENTCOUNT][3],logbuffer[current%EVENTCOUNT][4]);
        break;
      case IRQ1_2_SOFT:
        sprintf(s,"F-%.8X Y-%.3X X-%.3X - Software Interrupt (PC=%.6X)",logbuffer[current%EVENTCOUNT][1],logbuffer[current%EVENTCOUNT][2],logbuffer[current%EVENTCOUNT][3],logbuffer[current%EVENTCOUNT][4]);
        break;
      case IRQ2_CIAA:
        sprintf(s,"F-%.8X Y-%.3X X-%.3X - Cia A Interrupt (PC=%.6X)",logbuffer[current%EVENTCOUNT][1],logbuffer[current%EVENTCOUNT][2],logbuffer[current%EVENTCOUNT][3],logbuffer[current%EVENTCOUNT][4]);
        break;
      case IRQ3_0_COPPER:
        sprintf(s,"F-%.8X Y-%.3X X-%.3X - Copper Interrupt (PC=%.6X)",logbuffer[current%EVENTCOUNT][1],logbuffer[current%EVENTCOUNT][2],logbuffer[current%EVENTCOUNT][3],logbuffer[current%EVENTCOUNT][4]);
        break;
      case IRQ3_1_VBL:
        sprintf(s,"F-%.8X Y-%.3X X-%.3X - Vertical Blank Interrupt (PC=%.6X)",logbuffer[current%EVENTCOUNT][1],logbuffer[current%EVENTCOUNT][2],logbuffer[current%EVENTCOUNT][3],logbuffer[current%EVENTCOUNT][4]);
        break;
      case IRQ3_2_BLIT:
        sprintf(s,"F-%.8X Y-%.3X X-%.3X - Blitter Ready Interrupt (PC=%.6X)",logbuffer[current%EVENTCOUNT][1],logbuffer[current%EVENTCOUNT][2],logbuffer[current%EVENTCOUNT][3],logbuffer[current%EVENTCOUNT][4]);
        break;
      case IRQ4_0_AUD0:
        sprintf(s,"F-%.8X Y-%.3X X-%.3X - Audio Channel 0 Interrupt (PC=%.6X)",logbuffer[current%EVENTCOUNT][1],logbuffer[current%EVENTCOUNT][2],logbuffer[current%EVENTCOUNT][3],logbuffer[current%EVENTCOUNT][4]);
        break;
      case IRQ4_1_AUD1:
        sprintf(s,"F-%.8X Y-%.3X X-%.3X - Audio Channel 1 Interrupt (PC=%.6X)",logbuffer[current%EVENTCOUNT][1],logbuffer[current%EVENTCOUNT][2],logbuffer[current%EVENTCOUNT][3],logbuffer[current%EVENTCOUNT][4]);
        break;
      case IRQ4_2_AUD2:
        sprintf(s,"F-%.8X Y-%.3X X-%.3X - Audio Channel 2 Interrupt (PC=%.6X)",logbuffer[current%EVENTCOUNT][1],logbuffer[current%EVENTCOUNT][2],logbuffer[current%EVENTCOUNT][3],logbuffer[current%EVENTCOUNT][4]);
        break;
      case IRQ4_3_AUD3:
        sprintf(s,"F-%.8X Y-%.3X X-%.3X - Audio Channel 3 Interrupt (PC=%.6X)",logbuffer[current%EVENTCOUNT][1],logbuffer[current%EVENTCOUNT][2],logbuffer[current%EVENTCOUNT][3],logbuffer[current%EVENTCOUNT][4]);
        break;
      case IRQ5_0_RBF:
        sprintf(s,"F-%.8X Y-%.3X X-%.3X - Serial Receive Buffer Full Interrupt (PC=%.6X)",logbuffer[current%EVENTCOUNT][1],logbuffer[current%EVENTCOUNT][2],logbuffer[current%EVENTCOUNT][3],logbuffer[current%EVENTCOUNT][4]);
        break;
      case IRQ5_1_DSKSYN:
        sprintf(s,"F-%.8X Y-%.3X X-%.3X - Disk Sync Value Recognized Interrupt (PC=%.6X)",logbuffer[current%EVENTCOUNT][1],logbuffer[current%EVENTCOUNT][2],logbuffer[current%EVENTCOUNT][3],logbuffer[current%EVENTCOUNT][4]);
        break;
      case IRQ6_0_CIAB:
        sprintf(s,"F-%.8X Y-%.3X X-%.3X - Cia B Interrupt (PC=%.6X)",logbuffer[current%EVENTCOUNT][1],logbuffer[current%EVENTCOUNT][2],logbuffer[current%EVENTCOUNT][3],logbuffer[current%EVENTCOUNT][4]);
        break;
      case IRQ6_1_INTENA:
        sprintf(s,"F-%.8X Y-%.3X X-%.3X - INTENA in INTREQ was set Interrupt (PC=%.6X)",logbuffer[current%EVENTCOUNT][1],logbuffer[current%EVENTCOUNT][2],logbuffer[current%EVENTCOUNT][3],logbuffer[current%EVENTCOUNT][4]);
        break;
      case IRQCIAATA:
        sprintf(s,"F-%.8X Y-%.3X X-%.3X - Cia A Timer A Timeout Interrupt (PC=%.6X)",logbuffer[current%EVENTCOUNT][1],logbuffer[current%EVENTCOUNT][2],logbuffer[current%EVENTCOUNT][3],logbuffer[current%EVENTCOUNT][4]);
        break;
      case IRQCIAATB:
        sprintf(s,"F-%.8X Y-%.3X X-%.3X - Cia A Timer B Timeout Interrupt (PC=%.6X)",logbuffer[current%EVENTCOUNT][1],logbuffer[current%EVENTCOUNT][2],logbuffer[current%EVENTCOUNT][3],logbuffer[current%EVENTCOUNT][4]);
        break;
      case IRQCIAAEVENT:
        sprintf(s,"F-%.8X Y-%.3X X-%.3X - Cia A Event counter Interrupt (PC=%.6X)",logbuffer[current%EVENTCOUNT][1],logbuffer[current%EVENTCOUNT][2],logbuffer[current%EVENTCOUNT][3],logbuffer[current%EVENTCOUNT][4]);
        break;
      case IRQCIAASP:
        sprintf(s,"F-%.8X Y-%.3X X-%.3X - Cia A Keyboard Interrupt (PC=%.6X)",logbuffer[current%EVENTCOUNT][1],logbuffer[current%EVENTCOUNT][2],logbuffer[current%EVENTCOUNT][3],logbuffer[current%EVENTCOUNT][4]);
        break;
      case IRQCIAAFLAG:
        sprintf(s,"F-%.8X Y-%.3X X-%.3X - Cia A Parallel port Interrupt (PC=%.6X)",logbuffer[current%EVENTCOUNT][1],logbuffer[current%EVENTCOUNT][2],logbuffer[current%EVENTCOUNT][3],logbuffer[current%EVENTCOUNT][4]);
        break;
      case IRQCIABTA:
        sprintf(s,"F-%.8X Y-%.3X X-%.3X - Cia B Timer A Timeout Interrupt (PC=%.6X)",logbuffer[current%EVENTCOUNT][1],logbuffer[current%EVENTCOUNT][2],logbuffer[current%EVENTCOUNT][3],logbuffer[current%EVENTCOUNT][4]);
        break;
      case IRQCIABTB:
        sprintf(s,"F-%.8X Y-%.3X X-%.3X - Cia B Timer B Timeout Interrupt (PC=%.6X)",logbuffer[current%EVENTCOUNT][1],logbuffer[current%EVENTCOUNT][2],logbuffer[current%EVENTCOUNT][3],logbuffer[current%EVENTCOUNT][4]);
        break;
      case IRQCIABEVENT:
        sprintf(s,"F-%.8X Y-%.3X X-%.3X - Cia B Event counter Interrupt (PC=%.6X)",logbuffer[current%EVENTCOUNT][1],logbuffer[current%EVENTCOUNT][2],logbuffer[current%EVENTCOUNT][3],logbuffer[current%EVENTCOUNT][4]);
        break;
      case IRQCIABSP:
        sprintf(s,"F-%.8X Y-%.3X X-%.3X - Cia B Serial Port Interrupt (PC=%.6X)",logbuffer[current%EVENTCOUNT][1],logbuffer[current%EVENTCOUNT][2],logbuffer[current%EVENTCOUNT][3],logbuffer[current%EVENTCOUNT][4]);
        break;
      case IRQCIABFLAG:
        sprintf(s,"F-%.8X Y-%.3X X-%.3X - Cia B Parallel port Interrupt (PC=%.6X)",logbuffer[current%EVENTCOUNT][1],logbuffer[current%EVENTCOUNT][2],logbuffer[current%EVENTCOUNT][3],logbuffer[current%EVENTCOUNT][4]);
        break;
      case EXBUSERROR:
        sprintf(s,"F-%.8X Y-%.3X X-%.3X - Bus Error Exception (PC=%.6X)",logbuffer[current%EVENTCOUNT][1],logbuffer[current%EVENTCOUNT][2],logbuffer[current%EVENTCOUNT][3],logbuffer[current%EVENTCOUNT][4]);
        break;
      case EXODDADDRESS:
        sprintf(s,"F-%.8X Y-%.3X X-%.3X - Odd Address Exception (PC=%.6X)",logbuffer[current%EVENTCOUNT][1],logbuffer[current%EVENTCOUNT][2],logbuffer[current%EVENTCOUNT][3],logbuffer[current%EVENTCOUNT][4]);
        break;
      case EXILLEGAL:
        sprintf(s,"F-%.8X Y-%.3X X-%.3X - Illegal Instruction Exception (PC=%.6X)",logbuffer[current%EVENTCOUNT][1],logbuffer[current%EVENTCOUNT][2],logbuffer[current%EVENTCOUNT][3],logbuffer[current%EVENTCOUNT][4]);
        break;
      case EXDIVBYZERO:
        sprintf(s,"F-%.8X Y-%.3X X-%.3X - Division by Zero Exception (PC=%.6X)",logbuffer[current%EVENTCOUNT][1],logbuffer[current%EVENTCOUNT][2],logbuffer[current%EVENTCOUNT][3],logbuffer[current%EVENTCOUNT][4]);
        break;
      case EXCHK:
        sprintf(s,"F-%.8X Y-%.3X X-%.3X - CHK Exception (PC=%.6X)",logbuffer[current%EVENTCOUNT][1],logbuffer[current%EVENTCOUNT][2],logbuffer[current%EVENTCOUNT][3],logbuffer[current%EVENTCOUNT][4]);
        break;
      case EXTRAPV:
        sprintf(s,"F-%.8X Y-%.3X X-%.3X - TRAPV Exception (PC=%.6X)",logbuffer[current%EVENTCOUNT][1],logbuffer[current%EVENTCOUNT][2],logbuffer[current%EVENTCOUNT][3],logbuffer[current%EVENTCOUNT][4]);
        break;
      case EXPRIV:
        sprintf(s,"F-%.8X Y-%.3X X-%.3X - Privilegie Violation Exception (PC=%.6X)",logbuffer[current%EVENTCOUNT][1],logbuffer[current%EVENTCOUNT][2],logbuffer[current%EVENTCOUNT][3],logbuffer[current%EVENTCOUNT][4]);
        break;
      case EXTRAP:
        sprintf(s,"F-%.8X Y-%.3X X-%.3X - TRAP Exception %d (PC=%.6X)",logbuffer[current%EVENTCOUNT][1],logbuffer[current%EVENTCOUNT][2],logbuffer[current%EVENTCOUNT][3],(logbuffer[current%EVENTCOUNT][5]-0x80)/4,logbuffer[current%EVENTCOUNT][4]);
        break;
      case EVSTOP:
        sprintf(s,"F-%.8X Y-%.3X X-%.3X - STOP instruction executed (PC=%.6X)",logbuffer[current%EVENTCOUNT][1],logbuffer[current%EVENTCOUNT][2],logbuffer[current%EVENTCOUNT][3],logbuffer[current%EVENTCOUNT][4]);
        break;
      case EVCOPPER:
        sprintf(s,"F-%.8X Y-%.3X X-%.3X - Copper instruction executed (PC=%.6X)",logbuffer[current%EVENTCOUNT][1],logbuffer[current%EVENTCOUNT][2],logbuffer[current%EVENTCOUNT][3],logbuffer[current%EVENTCOUNT][4]);
        break;
      case EVBLITTER:
        sprintf(s,"F-%.8X Y-%.3X X-%.3X - Blitter operation executed (PC=%.6X)",logbuffer[current%EVENTCOUNT][1],logbuffer[current%EVENTCOUNT][2],logbuffer[current%EVENTCOUNT][3],logbuffer[current%EVENTCOUNT][4]);
        break;
      case EVDMACONW:
        sprintf(s,"F-%.8X Y-%.3X X-%.3X - DMACON write (PC=%.6X) (Val-%4X)",logbuffer[current%EVENTCOUNT][1],logbuffer[current%EVENTCOUNT][2],logbuffer[current%EVENTCOUNT][3],logbuffer[current%EVENTCOUNT][4],logbuffer[current%EVENTCOUNT][5]);
        break;
      case EVCIAAW:
        sprintf(s,"F-%.8X Y-%.3X X-%.3X - Cia A write (PC=%.6X) (Reg-%.6X) (Val-%4X)",logbuffer[current%EVENTCOUNT][1],logbuffer[current%EVENTCOUNT][2],logbuffer[current%EVENTCOUNT][3],logbuffer[current%EVENTCOUNT][4],logbuffer[current%EVENTCOUNT][5],logbuffer[current%EVENTCOUNT][6]);
        break;
      case EVCIABW:
        sprintf(s,"F-%.8X Y-%.3X X-%.3X - Cia B write (PC=%.6X) (Reg-%.6X) (Val-%4X)",logbuffer[current%EVENTCOUNT][1],logbuffer[current%EVENTCOUNT][2],logbuffer[current%EVENTCOUNT][3],logbuffer[current%EVENTCOUNT][4],logbuffer[current%EVENTCOUNT][5],logbuffer[current%EVENTCOUNT][6]);
        break;
      case EVCIAAR:
        sprintf(s,"F-%.8X Y-%.3X X-%.3X - Cia A read (PC=%.6X) (Reg-%.6X) (Val-%4X)",logbuffer[current%EVENTCOUNT][1],logbuffer[current%EVENTCOUNT][2],logbuffer[current%EVENTCOUNT][3],logbuffer[current%EVENTCOUNT][4],logbuffer[current%EVENTCOUNT][5],logbuffer[current%EVENTCOUNT][6]);
        break;
      case EVCIABR:
        sprintf(s,"F-%.8X Y-%.3X X-%.3X - Cia B read (PC=%.6X) (Reg-%.6X) (Val-%4X)",logbuffer[current%EVENTCOUNT][1],logbuffer[current%EVENTCOUNT][2],logbuffer[current%EVENTCOUNT][3],logbuffer[current%EVENTCOUNT][4],logbuffer[current%EVENTCOUNT][5],logbuffer[current%EVENTCOUNT][6]);
        break;
      case PUTMSG:
        sprintf(s,"F-%.8X Y-%.3X X-%.3X - PutMsg (PC=%.6X) (Reg-%.6X) (Val-%4X)",logbuffer[current%EVENTCOUNT][1],logbuffer[current%EVENTCOUNT][2],logbuffer[current%EVENTCOUNT][3],logbuffer[current%EVENTCOUNT][4],logbuffer[current%EVENTCOUNT][5],logbuffer[current%EVENTCOUNT][6]);
        break;
      case GETMSG:
        sprintf(s,"F-%.8X Y-%.3X X-%.3X - GetMsg (PC=%.6X) (Reg-%.6X) (Val-%4X)",logbuffer[current%EVENTCOUNT][1],logbuffer[current%EVENTCOUNT][2],logbuffer[current%EVENTCOUNT][3],logbuffer[current%EVENTCOUNT][4],logbuffer[current%EVENTCOUNT][5],logbuffer[current%EVENTCOUNT][6]);
        break;
      case REPLYMSG:
        sprintf(s,"F-%.8X Y-%.3X X-%.3X - ReplyMsg (PC=%.6X) (Reg-%.6X) (Val-%4X)",logbuffer[current%EVENTCOUNT][1],logbuffer[current%EVENTCOUNT][2],logbuffer[current%EVENTCOUNT][3],logbuffer[current%EVENTCOUNT][4],logbuffer[current%EVENTCOUNT][5],logbuffer[current%EVENTCOUNT][6]);
        break;
      default:
        sprintf(s,"Illegal Log Event found: %d",logbuffer[current%EVENTCOUNT][0]);
        break;
      }
    plot_text_window(&debugdisass,s,0,current-start);
    }
}

void show_log(void) {
  int c,current,finished=0;
  clear_window(&debugdisass);
  if (logfirst != loglast) {
    current = logfirst;
    while (!finished) {
      clear_window(&debugdisass);
      print_log(current, ((loglast-current) > 63) ? (current+63):loglast);
      c = getch();
      if (c == 13) finished = 1;
      else if (c == 0) {
        c = getch();
        if (c == 72) {
          if (current != logfirst) current--;
          }
        else if (c == 80) {
          if (current != (loglast-1)) current++;
          }
        else if (c == 73) {  // PGUP
          if ((current-63) < logfirst) current = logfirst;
          else current -= 63;
          }
        else if (c == 81) { // PGDOWN
          if ((current+63) > (loglast-1)) current = loglast-1;
          else current += 63;
          }
        }
      }
    }
  else {
    plot_text_window(&debugdisass,"No events logged",0,0);
    }
}
    


// ******************************************************************
// END OF LOG CONFIG PROCEDURES
// ******************************************************************


#endif

// ******************************************************************
// DEBUGGER SCREEN PROCEDURES
// ******************************************************************

void show_cia_dump(void) {
  char s[80];
  ULO i = 0;
  clear_window(&debugdisass);
  plot_text_window(&debugdisass,"Cia A Timer A:",0,i++);
  plot_text_window(&debugdisass,"--------------",0,i++);
  if ((ciaacra & 1) == 1) strcpy(s,"Started, ");
  else strcpy(s,"Stopped, ");
  if ((ciaacra & 0x8) == 1) strcat(s,"One-shot mode,  ");
  else strcat(s,"Continous mode, ");
  if ((ciaacra & 0x20) == 1) strcat(s,"CNT mode, ");
  else strcat(s,"Clock mode, ");
  if ((ciaacra & 0x4) == 0) strcat(s,"Pulse to PB6, ");
  else strcat(s,"Toggle shot to PB6, ");
  if ((ciaacra & 0x2) == 1) strcat(s,"PB6 is ON");
  else strcat(s,"PB6 is OFF");
  plot_text_window(&debugdisass,s,0,i++);
  sprintf(s,"Latch=%.4X   Timer Value=%.4X   Help variable=%.8X",ciaatalatch,ciaata,ciaataleft);
  plot_text_window(&debugdisass,s,0,i++);

  i++;
  plot_text_window(&debugdisass,"Cia A Timer B:",0,i++);
  plot_text_window(&debugdisass,"--------------",0,i++);
  if ((ciaacrb & 1) == 1) strcpy(s,"Started, ");
  else strcpy(s,"Stopped, ");
  if ((ciaacrb & 0x8) == 1) strcat(s,"One-shot mode,  ");
  else strcat(s,"Continous mode, ");
  if ((ciaacrb & 0x20) == 1) strcat(s,"CNT mode");
  else strcat(s,"Clock mode");
  if ((ciaacrb & 0x40) == 1) strcat(s,", Attached to Timer A");
  if ((ciaacrb & 0x4) == 0) strcat(s,", Pulse to PB7, ");
  else strcat(s,", Toggle shot to PB7, ");
  if ((ciaacrb & 0x2) == 1) strcat(s,"PB7 is ON");
  else strcat(s,"PB7 is OFF");
  plot_text_window(&debugdisass,s,0,i++);
  sprintf(s,"Latch=%.4X   Timer Value=%.4X   Help variable=%.8X",ciaatblatch,ciaatb,ciaatbleft);
  plot_text_window(&debugdisass,s,0,i++);


  i++;
  plot_text_window(&debugdisass,"Cia B Timer A:",0,i++);
  plot_text_window(&debugdisass,"--------------",0,i++);
  if ((ciabcra & 1) == 1) strcpy(s,"Started, ");
  else strcpy(s,"Stopped, ");
  if ((ciabcra & 0x8) == 1) strcat(s,"One-shot mode,  ");
  else strcat(s,"Continous mode, ");
  if ((ciabcra & 0x20) == 1) strcat(s,"CNT mode, ");
  else strcat(s,"Clock mode, ");
  if ((ciabcra & 0x4) == 0) strcat(s,"Pulse to PB6, ");
  else strcat(s,"Toggle shot to PB6, ");
  if ((ciabcra & 0x2) == 1) strcat(s,"PB6 is ON");
  else strcat(s,"PB6 is OFF");
  plot_text_window(&debugdisass,s,0,i++);
  sprintf(s,"Latch=%.4X   Timer Value=%.4X   Help variable=%.8X",ciabtalatch,ciabta,ciabtaleft);
  plot_text_window(&debugdisass,s,0,i++);

  i++;
  plot_text_window(&debugdisass,"Cia B Timer B:",0,i++);
  plot_text_window(&debugdisass,"--------------",0,i++);
  if ((ciabcrb & 1) == 1) strcpy(s,"Started, ");
  else strcpy(s,"Stopped, ");
  if ((ciabcrb & 0x8) == 1) strcat(s,"One-shot mode,  ");
  else strcat(s,"Continous mode, ");
  if ((ciabcrb & 0x20) == 1) strcat(s,"CNT mode");
  else strcat(s,"Clock mode");
  if ((ciabcrb & 0x40) == 1) strcat(s,", Attached to Timer A");
  if ((ciabcrb & 0x4) == 0) strcat(s,", Pulse to PB7, ");
  else strcat(s,", Toggle shot to PB7, ");
  if ((ciabcrb & 0x2) == 1) strcat(s,"PB7 is ON");
  else strcat(s,"PB7 is OFF");
  plot_text_window(&debugdisass,s,0,i++);
  sprintf(s,"Latch=%.4X   Timer Value=%.4X   Help variable=%.8X",ciabtblatch,ciabtb,ciabtbleft);
  plot_text_window(&debugdisass,s,0,i++);
  i++;
  plot_text_window(&debugdisass,"Control Registers",0,i++);
  plot_text_window(&debugdisass,"-----------------",0,i++);
  sprintf(s,"CIAA CRA - %.2X  CIAA CRB - %.2X  CIAB CRA - %.2X  CIAB CRB - %.2X",ciaacra,ciaacrb,ciabcrb,ciabcrb);
  plot_text_window(&debugdisass,s,0,i++);
  sprintf(s,"CIAA ICR - %.2X  CIAA MSK - %.2X  CIAB ICR - %.2X  CIAB MSK - %.2X",ciaaicrreq,ciaaicrmsk,ciabicrreq,ciabicrmsk);
  plot_text_window(&debugdisass,s,0,i++);

  
  i++;
  plot_text_window(&debugdisass,"Cia A Event counter",0,i++);
  plot_text_window(&debugdisass,"-------------------",0,i++);
  sprintf(s,"Value=%.6X  Alarm at=%.6X  Write latch=%.6X  Read latch -%.6X",ciaaev,ciaaevalarm,ciaaevlatch,ciaaevwritelatch);
  plot_text_window(&debugdisass,s,0,i++);
  sprintf(s,"Alarm write latch=%.6X  Read latched=%1d  Write latched=%1d  Alarm latched=%1d",ciaaevalarmlatch,ciaaevlatching,ciaaevwritelatching,ciaaevalarmlatching);
  plot_text_window(&debugdisass,s,0,i++);
  i++;


  plot_text_window(&debugdisass,"Cia B Event counter",0,i++);
  plot_text_window(&debugdisass,"-------------------",0,i++);
  sprintf(s,"Value=%.6X  Alarm at=%.6X  Write latch=%.6X  Read latch -%.6X",ciabev,ciabevalarm,ciabevlatch,ciabevwritelatch);
  plot_text_window(&debugdisass,s,0,i++);
  sprintf(s,"Alarm write latch=%.6X  Read latched=%1d  Write latched=%1d  Alarm latched=%1d",ciabevalarmlatch,ciabevlatching,ciabevwritelatching,ciabevalarmlatching);
  plot_text_window(&debugdisass,s,0,i++);


  getch();
}


void show_io_dump(void) {
  char s[140];
  ULO i = 0,j;
  clear_window(&debugdisass);
  plot_text_window(&debugdisass,"Various control registers:",0,i++);
  plot_text_window(&debugdisass,"--------------------------",0,i++);

  sprintf(s,"INTENA -%.4X  INTENAR-%.4X  INTREQ -%.4X  DMACON -%.4X  DMACONR-%.4X",intena,intenar,intreq,dmacon,dmaconr);
  plot_text_window(&debugdisass,s,0,i++);
  i++;
  plot_text_window(&debugdisass,"Screen related registers and help variables:",0,i++);
  plot_text_window(&debugdisass,"--------------------------------------------",0,i++);
  sprintf(s,"DIWXLEFT-%.3X  DIWXRIGHT-%.3X  DIWYTOP    -%.3X  DIWYBOTTOM      -%.3X",diwxleft,diwxright,diwytop,diwybottom);
  plot_text_window(&debugdisass,s,0,i++);
  sprintf(s,"DDFSTRT -%.3X  DDFSTOP  -%.3X  DDFstartpos-%.3d  DDFnumberofwords-%.3d",ddfstrt,ddfstop,DDFstartpos,DDFnumberofwords);
  plot_text_window(&debugdisass,s,0,i++);
  sprintf(s,"DIWSTRT -%.4X DIWSTOP  -%.4X DIWfirstvisiblepos-%.3d  DIWlastvisiblepos-%.3d",diwstrt,diwstop,DIWfirstvisiblepos,DIWlastvisiblepos);
  plot_text_window(&debugdisass,s,0,i++);
  sprintf(s,"BPL1PT-%.6X  BPL2PT-%.6X  BPL3PT-%.6X  BPL4PT-%.6X  BPL5PT-%.6X",bpl1pt,bpl2pt,bpl3pt,bpl4pt,bpl5pt);
  plot_text_window(&debugdisass,s,0,i++);
  sprintf(s,"BPL6PT-%.6X BPLCON0-%.4X  BPLCON1-%.4X BPLCON2-%.4X BPL1MOD-%.4X BPL2MOD-%.4X",bpl6pt,bplcon0,bplcon1,bplcon2,bpl1mod,bpl2mod);
  plot_text_window(&debugdisass,s,0,i++);
  sprintf(s,"DECODEROUTINE:%s DRAW:%s DRAWROUTINE:%s",(decoderoutineptr == (ULO) decodelo1) ? "decodelo1" : (decoderoutineptr == (ULO) decodelo2) ? "decodelo2" : (decoderoutineptr == (ULO) decodelo3) ? "decodelo3" : (decoderoutineptr == (ULO) decodelo4) ? "decodelo4" :(decoderoutineptr == (ULO) decodelo5) ? "decodelo5" :(decoderoutineptr == (ULO) decodelo6) ? "decodelo6" :(decoderoutineptr == (ULO) decodehi1) ? "decodehi1" :(decoderoutineptr == (ULO) decodehi2) ? "decodehi2" :(decoderoutineptr == (ULO) decodehi3) ? "decodehi3" : (decoderoutineptr == (ULO) decodehi4) ? "decodehi4" :
                                                      (decoderoutineptr == (ULO) decodeduallo2) ? "decodeduallo2" : (decoderoutineptr == (ULO) decodeduallo3) ? "decodeduallo3" : (decoderoutineptr == (ULO) decodeduallo4org) ? "decodeduallo4" : (decoderoutineptr == (ULO) decodeduallo5) ? "decodeduallo5" :(decoderoutineptr == (ULO) decodeduallo6) ? "decodeduallo6" :(decoderoutineptr == (ULO) decodedualhi2) ? "decodedualhi2" :
                                                      (decoderoutineptr == (ULO) decodedualhi3) ? "decodedualhi3" : (decoderoutineptr == (ULO) decodedualhi4) ? "decodedualhi4" : "Unknown",
                     (drawptr == (ULO) drawbgline) ? "drawbgline" : (drawptr == (ULO) drawddfline) ? "drawddfline" : "Unknown",
                     (drawroutineptr == (ULO) drawlores) ? "drawlores" : (drawroutineptr == (ULO) drawhires) ? "drawhires" : (drawroutineptr == (ULO) drawham) ? "drawham" : (drawroutineptr == (ULO) drawdualhires) ? "drawdualhires" : (drawroutineptr == (ULO) drawduallores) ? "drawduallores" : "Unknown");
  plot_text_window(&debugdisass,s,0,i++);
  sprintf(s,"PLAYFIELDON-%d",playfieldon);
  plot_text_window(&debugdisass,s,0,i++);


  i++;
  plot_text_window(&debugdisass,"Copper registers",0,i++);
  plot_text_window(&debugdisass,"----------------",0,i++);
  sprintf(s,"COP1LC-%.6X  COP2LC-%.6X  COPCON-%.4X  CURCOPPTR-%.6X NXTCOPACCESS-%.5X",cop1lc,cop2lc,copcon,curcopptr,nxtcopaccess);
  plot_text_window(&debugdisass,s,0,i++);
  i++;
  plot_text_window(&debugdisass,"Color registers",0,i++);
  plot_text_window(&debugdisass,"---------------",0,i++);
  sprintf(s,"COLOR00-%.8X  COLOR01-%.8X  COLOR02-%.8X COLOR03-%.8X",shadcol[0],shadcol[1],shadcol[2],shadcol[3]);
  plot_text_window(&debugdisass,s,0,i++);
  sprintf(s,"COLOR04-%.8X  COLOR05-%.8X  COLOR06-%.8X COLOR07-%.8X",shadcol[4],shadcol[5],shadcol[6],shadcol[7]);
  plot_text_window(&debugdisass,s,0,i++);
  sprintf(s,"COLOR08-%.8X  COLOR09-%.8X  COLOR0A-%.8X COLOR0B-%.8X",shadcol[8],shadcol[9],shadcol[10],shadcol[11]);
  plot_text_window(&debugdisass,s,0,i++);
  sprintf(s,"COLOR0C-%.8X  COLOR0D-%.8X  COLOR0E-%.8X COLOR0F-%.8X",shadcol[12],shadcol[13],shadcol[14],shadcol[15]);
  plot_text_window(&debugdisass,s,0,i++);
  sprintf(s,"COLOR10-%.8X  COLOR11-%.8X  COLOR12-%.8X COLOR13-%.8X",shadcol[16],shadcol[17],shadcol[18],shadcol[19]);
  plot_text_window(&debugdisass,s,0,i++);
  sprintf(s,"COLOR14-%.8X  COLOR15-%.8X  COLOR16-%.8X COLOR17-%.8X",shadcol[20],shadcol[21],shadcol[22],shadcol[23]);
  plot_text_window(&debugdisass,s,0,i++);
  sprintf(s,"COLOR18-%.8X  COLOR19-%.8X  COLOR1A-%.8X COLOR1B-%.8X",shadcol[24],shadcol[25],shadcol[26],shadcol[27]);
  plot_text_window(&debugdisass,s,0,i++);
  sprintf(s,"COLOR1C-%.8X  COLOR1D-%.8X  COLOR1E-%.8X COLOR1F-%.8X",shadcol[28],shadcol[29],shadcol[30],shadcol[31]);
  plot_text_window(&debugdisass,s,0,i++);
  i++;
  plot_text_window(&debugdisass,"Disk drive 0    Disk drive 1    Disk drive 2    Disk drive 3",0,i++);
  plot_text_window(&debugdisass,"------------    ------------    ------------    ------------",0,i++);
  sprintf(s,                    "Sel: %.1d          Sel: %.1d          Sel: %.1d          Sel: %.1d",sel[0],sel[1],sel[2],sel[3]);
  plot_text_window(&debugdisass,s,0,i++);
  sprintf(s,                    "Track: %.2d       Track: %.2d       Track: %.2d       Track: %.2d",track[0],track[1],track[2],track[3]);
  plot_text_window(&debugdisass,s,0,i++);
  sprintf(s,                    "Inserted: %1d     Inserted: %1d     Inserted: %1d     Inserted: %1d",inserted[0],inserted[1],inserted[2],inserted[3]);
  plot_text_window(&debugdisass,s,0,i++);
  sprintf(s,                    "Active: %1d       Active: %1d       Active: %1d       Active: %1d",active[0],active[1],active[2],active[3]);
  plot_text_window(&debugdisass,s,0,i++);
  sprintf(s,                    "Side: %1d         Side: %1d         Side: %1d         Side: %1d",side[0],side[1],side[2],side[3]);
  plot_text_window(&debugdisass,s,0,i++);
  sprintf(s,                    "Dir: %1d          Dir: %1d          Dir: %1d          Dir: %1d",dir[0],dir[1],dir[2],dir[3]);
  plot_text_window(&debugdisass,s,0,i++);
  sprintf(s,                    "Motor: %1d        Motor: %1d        Motor: %1d        Motor: %1d",motor[0],motor[1],motor[2],motor[3]);
  plot_text_window(&debugdisass,s,0,i++);
  sprintf(s,"DSKPT - %.6X  DSKLEN - %.4X   DSKSYNC - %.4X  DISKDMAINPROGRESS - %1d",dskpt,dsklen,dsksync,diskdmainprogress);
  plot_text_window(&debugdisass,s,0,i++);
  sprintf(s,"DISKDMAEN - %1d LINESLEFT-%d INDEXX-%d LENG-%d BTS2T-%d",diskdmaen,diskdmalinesleft,indexx,leng,bytestotransfer);
  plot_text_window(&debugdisass,s,0,i++);
  i++;
  sprintf(s,"AUD0PT-%.6X AUD0LEN-%.8X AUD0PER-%.8X AUD0VOL-%.2X AUD0LENW-%.4X",audpt[0],audlen[0],audper[0],audvol[0],audlenw[0]); 
  plot_text_window(&debugdisass,s,0,i++);
  sprintf(s,"STATE0-%.1X AUD0PTW-%.8X AUD0LENW-%.8X AUD0COUNTER-%.8X",audstate[0],audptw[0],audlenw[0],audpercounter[0]); 
  plot_text_window(&debugdisass,s,0,i++);
  i++;
  sprintf(s,"AUD1PT-%.6X AUD1LEN-%.8X AUD1PER-%.8X AUD1VOL-%.2X AUD1LENW-%.4X",audpt[1],audlen[1],audper[1],audvol[1],audlenw[1]); 
  plot_text_window(&debugdisass,s,0,i++);
  sprintf(s,"STATE1-%.1X AUD1PTW-%.8X AUD1LENW-%.8X AUD1COUNTER-%.8X",audstate[1],audptw[1],audlenw[1],audpercounter[1]); 
  plot_text_window(&debugdisass,s,0,i++);
  i++;
  sprintf(s,"AUD2PT-%.6X AUD2LEN-%.8X AUD2PER-%.8X AUD2VOL-%.2X AUD2LENW-%.4X",audpt[2],audlen[2],audper[2],audvol[2],audlenw[2]); 
  plot_text_window(&debugdisass,s,0,i++);
  sprintf(s,"STATE2-%.1X AUD2PTW-%.8X AUD2LENW-%.8X AUD2COUNTER-%.8X",audstate[2],audptw[2],audlenw[2],audpercounter[2]); 
  plot_text_window(&debugdisass,s,0,i++);
  i++;
  sprintf(s,"A3PT-%.6X A3LEN-%.8X A3PER-%.8X A3VOL-%.2X A3LENW-%.4X",audpt[3],audlen[3],audper[3],audvol[3],audlenw[3]); 
  plot_text_window(&debugdisass,s,0,i++);
  sprintf(s,"STATE3-%.1X AUD3PTW-%.8X AUD3LENW-%.8X AUD3COUNTER-%.8X",audstate[3],audptw[3],audlenw[3],audpercounter[3]); 
  plot_text_window(&debugdisass,s,0,i++);



  sprintf(s,"DMAFLAT-%.8X DMAPAGE-%d DMAPTR-%.8X SBIRQ-%d soundon-%d play-%d edit-%d",dmaflataddr,dmapage,auddmaptr,sbirqflag,soundon,playbuffer,editbuffer);
  plot_text_window(&debugdisass,s,0,i++);
  i++;
  sprintf(s,"BLTCON-%.8X FWM-%.4X LWM-%.4X BLTAPT-%.6X BLTBPT-%.6X ",bltcon,bltafwm,bltalwm,bltapt,bltbpt);
  plot_text_window(&debugdisass,s,0,i++);
  sprintf(s,"BLTCPT-%.6X BLTDPT-%.6X BLTAMOD-%.8X BLTBMOD-%.8X",bltcpt,bltdpt,bltamod,bltbmod);
  plot_text_window(&debugdisass,s,0,i++);
  sprintf(s,"BLTCMOD-%.8X BLTDMOD-%.8X BLTADAT-%.8X BLTBDAT-%.8X",bltcmod,bltdmod,bltadat,bltbdat);
  plot_text_window(&debugdisass,s,0,i++);
  sprintf(s,"BLTCDAT-%.8X LINELENGTH-%d LINECOUNT-%d LINENUM-%d",bltcdat,linelength,linecount,linenum);
  plot_text_window(&debugdisass,s,0,i++);
  sprintf(s,"BLITEND-%X BLITTERSTATUS-%d BLTPRI-%d",blitend,blitterstatus,(dmaconr & 0x400) == 0x400);
  plot_text_window(&debugdisass,s,0,i++);

  plot_text_window(&debuginfo," Copperlist:",0,3);
  plot_text_window(&debuginfo," -----------",0,4);

  for (j = 0; j < 55; j++) {
    sprintf(s," %.8X,%.8X",fetl((curcopptr+(j*8))&0x1ffffe),fetl((curcopptr+4+(j*8))&0x1ffffe));
    plot_text_window(&debuginfo,s,0,j+5);
    }
  getch();

}

// Print disassembler from PC location on debugger screen
// ----------------------------------------------------

void print_debug_disass(void)
{
  ULO y,mpc,opco;
  union { ULO lo; ULO (*fun)(); } yeah;
  clear_window(&debugdisass);
  mpc = pc;
  for (y = 0; y <= (debugdisass.y2-debugdisass.y1); y++) {
    opco = fetw(mpc);
    yeah.lo = t[opco][1];
    mpc = yeah.fun(mpc,opco,y);
    }
}

// Prints the requester to select different breakpoint options
// -----------------------------------------------------------

void print_debug_breakpoint_requester(void) {
  clear_window(&debugbreakpointrequester);
  print_window_borders(&debugbreakpointrequester);
  menu_print(&debugmenubreakpointrequester);
}

// Prints the requester to enter breakpoint address
// -----------------------------------------------------------

void print_debug_enter_breakpoint_requester(void) {
  clear_window(&debugenterbreakpointrequester);
  print_window_borders(&debugenterbreakpointrequester);
  plot_text_window(&debugenterbreakpointrequester,"Enter breakpoint address (Hex):",0,1);
}

// Print register information on debugger screen
// ---------------------------------------------

void print_debug_registers(void)
{
  char st[80];
  clear_window(&debugregisters);
  sprintf(st,"D0:%.8X %.8X %.8X %.8X %.8X %.8X %.8X %.8X:D7",d[0],d[1],d[2],d[3],d[4],d[5],d[6],d[7]);
  plot_text_window(&debugregisters,st,0,0);
  sprintf(st,"A0:%.8X %.8X %.8X %.8X %.8X %.8X %.8X %.8X:A7",a[0],a[1],a[2],a[3],a[4],a[5],a[6],a[7]);
  plot_text_window(&debugregisters,st,0,1);
  if ((sr & 0x2000) == 0x2000)
    sprintf(st,"PC:%.8X USP:%.8X SSP:%.8X SR:%.4X IRQ-LEVEL %1d SUPERVISOR MODE",pc,usp,a[7],sr,(sr & 0x700)>>8);
  else
    sprintf(st,"PC:%.8X USP:%.8X SSP:%.8X SR:%.4X IRQ-LEVEL %1d USER MODE",pc,a[7],ssp,sr,(sr & 0x700)>>8);
  plot_text_window(&debugregisters,st,0,2);
}

// Draws borders for the debugger screen
// -------------------------------------
void draw_debugger_screen_borders() {
  int i;
  // Top line
  plot_char(0x1f,0,0,0xefff,0x9);  // Top left corner
  plot_char(0x1b,78,0,0xefff,0x9);
  plot_char(0x1e,99,0,0xefff,0x9); // Top right corner
  for (i=1; i < 78; i++) plot_char(0x15,i,0,0xefff,0x9);
  for (i=79; i < 99; i++) plot_char(0x15,i,0,0xefff,0x9);
  
  // Left line
  plot_char(0x18,0,6,0xefff,0x9);  
  plot_char(0x18,0,10,0xefff,0x9);  
  plot_char(0x1c,0,74,0xefff,0x9);  // Bottom left corner

  for (i=1; i < 6; i++) plot_char(0x16,0,i,0xefff,0x9);
  for (i=7; i < 10; i++) plot_char(0x16,0,i,0xefff,0x9);
  for (i=11; i < 74; i++) plot_char(0x16,0,i,0xefff,0x9);

  // Bottom line
  plot_char(0x19,78,74,0xefff,0x9);
  plot_char(0x1d,99,74,0xefff,0x9); // Bottom right corner
  for (i=1; i < 78; i++) plot_char(0x15,i,74,0xefff,0x9);
  for (i=79; i < 99; i++) plot_char(0x15,i,74,0xefff,0x9);

  // Right line
  plot_char(0x1a,99,10,0xefff,0x9);  
  for (i=1; i < 10; i++) plot_char(0x16,99,i,0xefff,0x9);
  for (i=11; i < 74; i++) plot_char(0x16,99,i,0xefff,0x9);

  // Middle line
  plot_char(0x1a,78,6,0xefff,0x9);  
  plot_char(0x1a,78,10,0xefff,0x9);  
  plot_char(0x17,78,10,0xefff,0x9);  
  for (i=1; i < 6; i++) plot_char(0x16,78,i,0xefff,0x9);
  for (i=7; i < 10; i++) plot_char(0x16,78,i,0xefff,0x9);
  for (i=11; i < 74; i++) plot_char(0x16,78,i,0xefff,0x9);

  // Three horisontal lines
  for (i=1; i < 78; i++) plot_char(0x15,i,6,0xefff,0x9);
  for (i=1; i < 78; i++) plot_char(0x15,i,10,0xefff,0x9);
  for (i=79; i < 99; i++) plot_char(0x15,i,10,0xefff,0x9);
}

void init_debug_menu_main(void) {
  strcpy(debugmenumain.entrytext[0],"    EXECUTE NEXT    ");
  strcpy(debugmenumain.entrytext[1],"  RUN THROUGH LOOP  ");
  strcpy(debugmenumain.entrytext[2],"RUN UNTIL BREAKPOINT");
  strcpy(debugmenumain.entrytext[3],"    MEMORY DUMP     ");
  strcpy(debugmenumain.entrytext[4]," CIA REGISTER DUMP  ");
  strcpy(debugmenumain.entrytext[5],"  IO REGISTER DUMP  ");
  strcpy(debugmenumain.entrytext[6]," BACK TO MAIN MENU  ");
#ifdef LOGGING
  strcpy(debugmenumain.entrytext[7]," CONFIGURE LOGGING  ");
  strcpy(debugmenumain.entrytext[8],"      VIEW LOG      ");
  debugmenumain.numberofentries = 9;
#else
  debugmenumain.numberofentries = 7;
#endif
  debugmenumain.activeentry = 0;
  debugmenumain.menuwindow = &debugmenu;
}

void init_debug_menu_breakpoint_requester(void) {
  strcpy(debugmenubreakpointrequester.entrytext[0],"RUN UNTIL BREAKPOINT");
  strcpy(debugmenubreakpointrequester.entrytext[1]," UNTIL LINE 312 ");
  strcpy(debugmenubreakpointrequester.entrytext[2]," BACK TO DEBUG MENU ");
#ifdef LOGGING
  strcpy(debugmenubreakpointrequester.entrytext[3]," UNTIL LOGGED EVENT ");
  debugmenubreakpointrequester.numberofentries = 4;
#else
  debugmenubreakpointrequester.numberofentries = 3;
#endif

  debugmenubreakpointrequester.activeentry = 0;
  debugmenubreakpointrequester.menuwindow = &debugbreakpointrequester;
}

extern ULO useprefetch,cpuprefetchaddr1,cpuprefetchaddr2;
extern UWO cpuprefetch1[],cpuprefetch2[];

void print_debug_info() {
  char s[80];
  int i=0;
  clear_window(&debuginfo);
  sprintf(s,"FRAME-%d",frames);
  plot_text_window(&debuginfo,s,0,i++);
  sprintf(s,"Current cycle-%X",curcycle);
  plot_text_window(&debuginfo,s,0,i++);
  sprintf(s,"YPOS-%.3X  XPOS-%.3X",ypos,xpos);
  plot_text_window(&debuginfo,s,0,i++);
  i++;
  sprintf(s,"USEPRE-%d",useprefetch);
  plot_text_window(&debuginfo,s,0,i++);
  sprintf(s,"CPUADR1-%X",cpuprefetchaddr1);
  plot_text_window(&debuginfo,s,0,i++);
  sprintf(s,"%.4X%.4X%.4X%.4X",cpuprefetch1[0],cpuprefetch1[1],cpuprefetch1[2],cpuprefetch1[3]);
  plot_text_window(&debuginfo,s,0,i++);
  sprintf(s,"%.4X%.4X%.4X%.4X",cpuprefetch1[4],cpuprefetch1[5],cpuprefetch1[6],cpuprefetch1[7]);
  plot_text_window(&debuginfo,s,0,i++);

  sprintf(s,"CPUADR2-%X",cpuprefetchaddr2);
  plot_text_window(&debuginfo,s,0,i++);
  sprintf(s,"%.4X%.4X%.4X%.4X",cpuprefetch2[0],cpuprefetch2[1],cpuprefetch2[2],cpuprefetch2[3]);
  plot_text_window(&debuginfo,s,0,i++);
  sprintf(s,"%.4X%.4X%.4X%.4X",cpuprefetch2[4],cpuprefetch2[5],cpuprefetch2[6],cpuprefetch2[7]);
  plot_text_window(&debuginfo,s,0,i++);


}

void print_debug_screen() {
  menu_print(&debugmenumain);
  print_title();
  print_debug_registers();
  print_debug_disass();
  print_debug_info();
}

// Init debugger breakpoint requester sets up a requester window
// draws the borders and menu
void init_debug_breakpoint_requester(void) {

#ifdef LOGGING
  init_window(&debugbreakpointrequester,40,36,59,39,0xec00,0xefff);
#else
  init_window(&debugbreakpointrequester,40,36,59,38,0xec00,0xefff);
#endif

  init_debug_menu_breakpoint_requester();
  print_debug_breakpoint_requester();
}

// Init debugger screen sets up different window structs, and draws the
// borders and title and menu and info
void init_debugger_screen(void) {
  // Draw borders
  draw_debugger_screen_borders();
  init_window(&debugregisters,1,7,77,9,0xefff,0x9);
  clear_window(&debugregisters);
  init_window(&maintitle,1,1,77,5,0xefff,0x9);
  clear_window(&maintitle);
  init_window(&debugmenu,79,1,98,9,0xefff,0x9);
  clear_window(&debugmenu);
  init_window(&debuginfo,79,11,98,73,0xefff,0x9);
  clear_window(&debuginfo);
  init_window(&debugdisass,1,11,77,73,0xefff,0x9);
  clear_window(&debugdisass);
  init_debug_menu_main();
  print_debug_screen();

  print_debug_info();

}

void memory_dump() {
  ULO s,i;
  char x[80];
  ULO mdend = 0,keyz;
  clear_window(&debugdisass);

  s=0x00000;
  while (!mdend) {

    for (i=0; i < 63; i++) {
      sprintf(x,"%.6X %.8X%.8X %.8X%.8X %.8X%.8X %.8X%.8X",s+i*32,fetl(s+i*32+0),fetl(s+i*32+4),fetl(s+i*32+8),fetl(s+i*32+12),fetl(s+i*32+16),fetl(s+i*32+20),fetl(s+i*32+24),fetl(s+i*32+28));
      plot_text_window(&debugdisass,x,0,i);
      } 

    while (!kbhit()) {};
    keyz = getch();
    if (keyz == 13) mdend = 1;
    else if (keyz == 0) {
        keyz = getch();
        if (keyz == 71) {
          s = (s-0x10000)&0xffffff;
          }
        else if (keyz == 79) {
          s = (s+0x10000)&0xffffff;
          }
        else if (keyz == 72) {
          s = (s-32)&0xffffff;
          }
        else if (keyz == 80) {
          s = (s+32)&0xffffff;
          }
        else if (keyz == 73) {  // PGUP
          s = (s-2016)&0xffffff;
          }
        else if (keyz == 81) { // PGDOWN
          s = (s+2016)&0xffffff;
          }
        }
      }
}


void init_debug_enter_breakpoint_requester(void) {
  init_window(&debugenterbreakpointrequester,30,36,70,38,0xefff,0xec00);
}

void init_debug_enter_breakpoint_number_field(void) {
  init_number_field(&debugenterbreakpointnumberfield,&debugenterbreakpointrequester,breakpoint,33,1);
}

#ifdef LOGGING
void debug_run_until_logged_event(void) {
  ULO t = loglast;
  int hey;

  outp(0x3d4,9);
  hey = inp(0x3d5);
  outp(0x3d4,9);
  outp(0x3d5,(hey&0xe0)|1);
    //init_mousekeyboard();
  f12pressed = 0;
  debugging = 1;
  while (t == loglast) {
    next_instruction();
    }
    //restore_mousekeyboard();
        outp(0x3d4,9);
        hey = inp(0x3d5);
        outp(0x3d4,9);
        outp(0x3d5,(hey&0xe0));
}
#endif

void debug_run_until_line_312(void) {
  int hey;

  debugging = 1;
  outp(0x3d4,9);
  hey = inp(0x3d5);
  outp(0x3d4,9);
  outp(0x3d5,(hey&0xe0)|1);
  f12pressed = 0;
    init_mousekeyboard();
  while ((ypos != 312) && !f12pressed) {
    next_instruction();
    }
        outp(0x3d4,9);
        hey = inp(0x3d5);
        outp(0x3d4,9);
        outp(0x3d5,(hey&0xe0));
    restore_mousekeyboard();
}
void debug_run_until_breakpoint(void) {
  int hey;

  debugging = 1;
  outp(0x3d4,9);
  hey = inp(0x3d5);
  outp(0x3d4,9);
  outp(0x3d5,(hey&0xe0)|1);
  f12pressed = 0;
    init_mousekeyboard();
  while (pc != breakpoint && !f12pressed) {
    next_instruction();
    }
        outp(0x3d4,9);
        hey = inp(0x3d5);
        outp(0x3d4,9);
        outp(0x3d5,(hey&0xe0));
    restore_mousekeyboard();
}

void debugger(void) {
  int c,temp,finished = 0;  
  union { ULO lo; ULO (*fun)(); } yeah;

  while (!finished) {
    switch (menu_select(&debugmenumain)) {
      case 0: // EXECUTE NEXT
        debugging = 1;
        next_instruction();
        print_debug_screen();
        break;
      case 1: // RUN THROUGH LOOP
        debugging = 1;
        temp = fetw(pc);
        yeah.lo = t[temp][1];
        temp = yeah.fun(pc,temp,0);
        while (pc != temp) {
          next_instruction();
          }
        print_debug_screen();
        break;
      case 2: // EXECUTE UNTIL BREAKPOINT
        init_debug_breakpoint_requester();
        print_debug_breakpoint_requester();
        switch(menu_select(&debugmenubreakpointrequester)) {
          case 0:
            print_debug_screen();
            init_debug_enter_breakpoint_requester();
            print_debug_enter_breakpoint_requester();
            init_debug_enter_breakpoint_number_field();
            enter_number(&debugenterbreakpointnumberfield);
            breakpoint = debugenterbreakpointnumberfield.value;
            print_debug_screen();
            debug_run_until_breakpoint();
            break;
          case 1: // RUN UNTIL LINE 0
            debug_run_until_line_312();
            break;
          case 2:  // BACK TO DEBUG MENU
            break;
#ifdef LOGGING
          case 3:  // RUN UNTIL LOGGED EVENT
            debug_run_until_logged_event();
            break;
#endif
          }
        print_debug_screen();
        break;
      case 3: // MEMORY DUMP
        memory_dump();
        print_debug_screen();
        break;
      case 4: // CIA REGISTER DUMP
        show_cia_dump();
        print_debug_screen();
        break;
      case 5: // IO REGISTER DUMP
        show_io_dump();
        print_debug_screen();
        break;
      case 6: // BACK TO MAIN MENU
        finished = 1;
        break;
#ifdef LOGGING
      case 7: // CONFIGURE LOGGING
        setup_logconfig_window();
        yesnomenu_select(&logconfigmenu);
        print_debug_screen();
        break;
      case 8: // VIEW LOG
        show_log();
        print_debug_screen();
        break;
#endif
      }
    }
}



// ***********************************************************
// Configuration stuff
// ***********************************************************



// Prints the requester to enter diskname
// -----------------------------------------------------------

void config_print_enterdisk_requester(void) {
  init_window(&config_enterdisk_requester,5,38,75,44,0xefff,0x4);
  clear_window(&config_enterdiskrequester);
  
  print_window_borders(&config_enterdisk_requester);
  plot_text_window(&config_enterdisk_requester,"Enter filename of diskimage:",0,1);
}


void init_config_optionmenu() {
  char tmpstr[40];
  int i;
  // Setup items

  strcpy(config_optionmenu.items[0].text,"Diskimage in DF0:");
  config_optionmenu.items[0].stringvalue = df0name;
  config_optionmenu.items[0].type = 1;

  strcpy(config_optionmenu.items[1].text,"Diskimage in DF1:");
  config_optionmenu.items[1].stringvalue = df1name;
  config_optionmenu.items[1].type = 1;

  strcpy(config_optionmenu.items[2].text,"Diskimage in DF2:");
  config_optionmenu.items[2].stringvalue = df2name;
  config_optionmenu.items[2].type = 1;

  strcpy(config_optionmenu.items[3].text,"Diskimage in DF3:");
  config_optionmenu.items[3].stringvalue = df3name;
  config_optionmenu.items[3].type = 1;

  strcpy(config_optionmenu.items[4].text,"Chipmemory size:");
  config_optionmenu.items[4].intvalue = &chipmemsize;
  config_optionmenu.items[4].type = 0;

  for (i=0; i < 8; i++) {
    sprintf(tmpstr,"%dk",(i+1)*256);
    strcpy(config_optionmenu.items[4].options.optiontext[i],tmpstr);
    config_optionmenu.items[4].options.optionvalues[i] = (i+1)*0x40000;
    if (chipmemsize == ((i+1)*0x40000)) config_optionmenu.items[4].options.activeoption = i;
  }

  config_optionmenu.items[4].options.numberofentries = 8;


  strcpy(config_optionmenu.items[5].text,"Bogomemory size:");
  config_optionmenu.items[5].intvalue = &bogomemsize;
  config_optionmenu.items[5].type = 0;

  for (i=0; i < 5; i++) {
    sprintf(tmpstr,"%dk",i*256);
    strcpy(config_optionmenu.items[5].options.optiontext[i],tmpstr);
    config_optionmenu.items[5].options.optionvalues[i] = i*0x40000;
    if (bogomemsize == (i*0x40000)) config_optionmenu.items[5].options.activeoption = i;
  }

  config_optionmenu.items[5].options.numberofentries = 5;


  strcpy(config_optionmenu.items[6].text,"Emulate joystick:");
  config_optionmenu.items[6].intvalue = &emulate_joystick;
  config_optionmenu.items[6].type = 0;

  strcpy(config_optionmenu.items[6].options.optiontext[0],"YES");
  config_optionmenu.items[6].options.optionvalues[0] = 1;
  if (emulate_joystick == 1) config_optionmenu.items[6].options.activeoption = 0;

  strcpy(config_optionmenu.items[6].options.optiontext[1],"NO");
  config_optionmenu.items[6].options.optionvalues[1] = 0;
  if (emulate_joystick == 0) config_optionmenu.items[6].options.activeoption = 1;

  config_optionmenu.items[6].options.numberofentries = 2;


  strcpy(config_optionmenu.items[7].text,"Skipframe ratio:");
  config_optionmenu.items[7].intvalue = &skiprate;
  config_optionmenu.items[7].type = 0;

  for (i=0; i < 25; i++) {
    sprintf(tmpstr,"1/%d",i+1);
    strcpy(config_optionmenu.items[7].options.optiontext[i],tmpstr);
    config_optionmenu.items[7].options.optionvalues[i] = i;
    if (skiprate == i) config_optionmenu.items[7].options.activeoption = i;
  }

  config_optionmenu.items[7].options.numberofentries = 25;

  strcpy(config_optionmenu.items[8].text,"Enable Leds:");
  config_optionmenu.items[8].intvalue = &enableleds;
  config_optionmenu.items[8].type = 0;

  strcpy(config_optionmenu.items[8].options.optiontext[0],"YES");
  config_optionmenu.items[8].options.optionvalues[0] = 1;
  if (enableleds == 1) config_optionmenu.items[8].options.activeoption = 0;

  strcpy(config_optionmenu.items[8].options.optiontext[1],"NO");
  config_optionmenu.items[8].options.optionvalues[1] = 0;
  if (enableleds == 0) config_optionmenu.items[8].options.activeoption = 1;

  config_optionmenu.items[8].options.numberofentries = 2;

  strcpy(config_optionmenu.items[9].text,"Diskspeed:");
  config_optionmenu.items[9].intvalue = &diskspeed;
  config_optionmenu.items[9].type = 0;

  for (i=0; i < 8; i++) {
    sprintf(tmpstr,"%dX",(i == 0) ? 1: (i==1) ? 2: (i==2) ? 4: (i==3) ? 8: (i==4) ? 16: (i==5) ? 32:(i==6) ? 64:128);
    strcpy(config_optionmenu.items[9].options.optiontext[i],tmpstr);
    config_optionmenu.items[9].options.optionvalues[i] = (i+1);
    if (diskspeed == (i+1)) config_optionmenu.items[9].options.activeoption = i;
    }

  config_optionmenu.items[9].options.numberofentries = 8;

  strcpy(config_optionmenu.items[10].text,"Cpuspeed:");
  config_optionmenu.items[10].intvalue = &cpuspeed;
  config_optionmenu.items[10].type = 0;

  for (i=0; i < 3; i++) {
    sprintf(tmpstr,"%dX",(i == 0) ? 1: (i == 1) ? 2: 4);
    strcpy(config_optionmenu.items[10].options.optiontext[i],tmpstr);
    config_optionmenu.items[10].options.optionvalues[i] = i;
    if (cpuspeed == i) config_optionmenu.items[10].options.activeoption = i;
    }

  config_optionmenu.items[10].options.numberofentries = 3;

  strcpy(config_optionmenu.items[11].text,"Support interlace:");
  config_optionmenu.items[11].intvalue = &supportinterlace;
  config_optionmenu.items[11].type = 0;

  strcpy(config_optionmenu.items[11].options.optiontext[0],"YES");
  config_optionmenu.items[11].options.optionvalues[0] = 1;
  if (supportinterlace == 1) config_optionmenu.items[11].options.activeoption = 0;

  strcpy(config_optionmenu.items[11].options.optiontext[1],"NO");
  config_optionmenu.items[11].options.optionvalues[1] = 0;
  if (supportinterlace == 0) config_optionmenu.items[11].options.activeoption = 1;

  config_optionmenu.items[11].options.numberofentries = 2;

  config_optionmenu.numberofentries = 12;
  config_optionmenu.optionpos = 30;
  config_optionmenu.activeentry = 0;
  config_optionmenu.menuwindow = &mainconsole;
}

void init_configuration_screen(void) {

  // Use main console
  clear_window(&mainconsole);

  // Set up the optionmenu data structure
  init_config_optionmenu();
  
  // Print our optionmenu
  optionmenu_print(&config_optionmenu);
}

void configuration() {
  char disknames[4][120];

  strcpy(disknames[0],df0name);
  strcpy(disknames[1],df1name);
  strcpy(disknames[2],df2name);
  strcpy(disknames[3],df3name);


  // Do selctions
  
  optionmenu_select(&config_optionmenu);

  save_fellow_cfg();
  if (strcmp(disknames[0],df0name) != 0) {
    insert_diskimage(df0name,0);
  }
  if (strcmp(disknames[1],df1name) != 0) {
    insert_diskimage(df1name,1);
  }
  if (strcmp(disknames[2],df2name) != 0) {
    insert_diskimage(df2name,2);
  }
  if (strcmp(disknames[3],df3name) != 0) {
    insert_diskimage(df3name,3);
  }
}


// Draws borders for the main screen
// ---------------------------------
void draw_main_screen_borders() {
  int i;
  // Top line
  plot_char(0x1f,0,0,0xefff,0x9);  // Top left corner
  plot_char(0x1b,78,0,0xefff,0x9);
  plot_char(0x1e,99,0,0xefff,0x9); // Top right corner
  for (i=1; i < 78; i++) plot_char(0x15,i,0,0xefff,0x9);
  for (i=79; i < 99; i++) plot_char(0x15,i,0,0xefff,0x9);
  
  // Left line
  plot_char(0x18,0,6,0xefff,0x9);  
  plot_char(0x1c,0,74,0xefff,0x9);  // Bottom left corner
  for (i=1; i < 6; i++) plot_char(0x16,0,i,0xefff,0x9);
  for (i=7; i < 74; i++) plot_char(0x16,0,i,0xefff,0x9);

  // Bottom line
  plot_char(0x19,78,74,0xefff,0x9);
  plot_char(0x1d,99,74,0xefff,0x9); // Bottom right corner
  for (i=1; i < 78; i++) plot_char(0x15,i,74,0xefff,0x9);
  for (i=79; i < 99; i++) plot_char(0x15,i,74,0xefff,0x9);

  // Right line
  plot_char(0x1a,99,10,0xefff,0x9);  
  for (i=1; i < 10; i++) plot_char(0x16,99,i,0xefff,0x9);
  for (i=11; i < 74; i++) plot_char(0x16,99,i,0xefff,0x9);

  // Middle line
  plot_char(0x1a,78,6,0xefff,0x9);  
  plot_char(0x18,78,10,0xefff,0x9);  
  for (i=1; i < 6; i++) plot_char(0x16,78,i,0xefff,0x9);
  for (i=7; i < 10; i++) plot_char(0x16,78,i,0xefff,0x9);
  for (i=11; i < 74; i++) plot_char(0x16,78,i,0xefff,0x9);

  // Two horisontal lines
  for (i=1; i < 78; i++) plot_char(0x15,i,6,0xefff,0x9);
  for (i=79; i < 99; i++) plot_char(0x15,i,10,0xefff,0x9);
}

void init_main_menu(void) {
  strcpy(mainmenudata.entrytext[0],"        RUN         ");
  strcpy(mainmenudata.entrytext[1],"      DEBUGGER      ");
  strcpy(mainmenudata.entrytext[2],"    CONFIGURATION   ");
/*  strcpy(mainmenudata.entrytext[3]," RESET TO KICKSTART ");
  strcpy(mainmenudata.entrytext[4],"  RESET TO TRACKMO  ");
*/
  strcpy(mainmenudata.entrytext[3],"        QUIT        ");

#ifdef CPUTRACE
  strcpy(mainmenudata.entrytext[6],"    CPU TRACE ON    ");
  strcpy(mainmenudata.entrytext[7],"    CPU TRACE OFF   ");
  strcpy(mainmenudata.entrytext[8],"   SHOW CPU TRACE   ");
  mainmenudata.numberofentries = 9;
#else
  mainmenudata.numberofentries = 4;
#endif

  mainmenudata.activeentry = 0;
  mainmenudata.menuwindow = &mainmenu;
}

void print_disks(void) {
  char s[120];

  plot_text_window(&mainconsole,"                 ",60,10);
  plot_text_window(&mainconsole,"                 ",60,11);
  plot_text_window(&mainconsole,"                 ",60,12);
  plot_text_window(&mainconsole,"                 ",60,13);
  sprintf(s,"DF0: %s",df0name);
  plot_text_window(&mainconsole,s,1,10);
  if (disknotfound[0]) {
    plot_text_window(&mainconsole,"  File not found ",60,10);
  }
  sprintf(s,"DF1: %s",df1name);
  plot_text_window(&mainconsole,s,1,11);
  if (disknotfound[1]) 
    plot_text_window(&mainconsole,"  File not found ",60,11);
  sprintf(s,"DF2: %s",df2name);
  plot_text_window(&mainconsole,s,1,12);
  if (disknotfound[2]) 
    plot_text_window(&mainconsole,"  File not found ",60,12);
  sprintf(s,"DF3: %s",df3name);
  plot_text_window(&mainconsole,s,1,13);
  if (disknotfound[3]) 
    plot_text_window(&mainconsole,"  File not found ",60,13);
}


// Init main screen sets up different window structs, and draws the borders
// and title and menu and info
void init_main_screen(void) {
  // Draw borders
  draw_main_screen_borders();
  init_window(&mainconsole,1,7,77,73,0xefff,0x9);
  clear_window(&mainconsole);
  init_window(&maintitle,1,1,77,5,0xefff,0x9);
  clear_window(&maintitle);
  init_window(&mainmenu,79,1,98,9,0xefff,0x9);
  clear_window(&mainmenu);
  init_window(&maininfo,79,11,98,73,0xefff,0x9);
  clear_window(&maininfo);
  init_main_menu();
  menu_print(&mainmenudata);
  print_title();
  print_disks();


}

void print_title(void) {
  plot_text_window(&maintitle,"Fellow V0.1",0,1);
  plot_text_window(&maintitle,"(C) Petter Schau 1997",0,3);
}

void run_forever(void) {
  int hey;
  debugging = 0;
  clear(0,74);
  if (!supportinterlace) {
    outp(0x3d4,9);
    hey = inp(0x3d5);
    outp(0x3d4,9);
    outp(0x3d5,(hey&0xe0)|1);
    inp (sbio+0xf);
  }
  init_mousekeyboard();
  next_instruction();
  restore_mousekeyboard();

  if (!supportinterlace) {
          outp(0x3d4,9);
          hey = inp(0x3d5);
          outp(0x3d4,9);
          outp(0x3d5,(hey&0xe0));
          }
          return;

}

void setup_trackmo(void) {   
    trackmo = 1;
    a[1] = 0x140000;
    pc = 0x8000c;
    intena = intenar = 0xc020;
    wril(0x1a0000,0x60);
    wril(0x1a0000,0x64);
    wril(0x1a0000,0x68);
    wril(0x1a0000,0x6c);
    wril(0x1a0000,0x70);
    wril(0x1a0000,0x74);
    wril(0x1a0000,0x78);
    wril(0x1a0000,0x7c);        // Might lose some ints here.....
    wril(0x33fc3fff,0x1a0000);  // move #$3fff,$dff09c
    wril(0x00dff09c,0x1a0004);  
    wril(0x4e730000,0x1a0008);  // rte
    copy_bootsector();
    reset_mousekeyboard();
 }

#ifdef CPUTRACE
void cputraceoff(void)
{
  cputraceflag = 0;
  //cputraceptr = 0;
  //cputracecount = 0;
}

void cputraceon(void)
{
  cputraceflag = 1;
  cputraceptr = 0;
  cputracecount = 0;
}


// Print disassembler from cputrace
// ----------------------------------------------------

void showcputrace(void)
{
  char s[20],strr[80];
  ULO y,mpc,opco;
  int tracepostop;
  union { ULO lo; ULO (*fun)(); } yeah;
  ULO keyz;
  int cputend = 0,traceend;

  
  if (cputraceptr == 0) {
    clear_window(&debugdisass);
    plot_text_window(&debugdisass,"No cpu trace available",0,0);
    getch();
    return;
    }

  // Start of trace
  tracepostop = 0;
  if (cputracecount >= 524288) cputracecount = 524288;

  while (!cputend) {
    clear_window(&debugdisass);
    clear_window(&debuginfo);
    plot_text_window(&debuginfo,"Trace position:",0,0);
    sprintf(s,"%d",tracepostop);
    plot_text_window(&debuginfo,s,0,1);
    plot_text_window(&debuginfo,"Trace length:",0,2);
    sprintf(s,"%d",cputracecount);
    plot_text_window(&debuginfo,s,0,3);

    for (y = 0; y <= (debugdisass.y2-debugdisass.y1); y++) {
      if ((tracepostop+y) <= cputracecount) {
        mpc = cputracebuffer[(cputraceptr+tracepostop+y) & 0x7ffff];
        opco = fetw(mpc);
        yeah.lo = t[opco][1];
        yeah.fun(mpc,opco,y);
        sprintf(strr,"%4X",cputsr[(cputraceptr+tracepostop+y) & 0x7ffff]);
        plot_text_window(&debugdisass,strr,66,y);
        }
      }

    while (!kbhit()) {};
    keyz = getch();
    if (keyz == 13) cputend = 1;
    else if (keyz == 0) {
        keyz = getch();
        if (keyz == 71) {
          tracepostop = 0;
          }
        else if (keyz == 79) {
          tracepostop = cputracecount;
          }
        else if (keyz == 72) {
          if (tracepostop > 0) tracepostop--; 
          }
        else if (keyz == 80) {
          if (tracepostop < cputracecount)
            tracepostop++;
          }
        else if (keyz == 73) {  // PGUP
          if ((tracepostop-63) < 0) tracepostop = 0;
          else tracepostop -= 63;
          }
        else if (keyz == 81) { // PGDOWN
          if ((tracepostop+63) > cputracecount)
            tracepostop = cputracecount;
          else tracepostop += 63;
          }
        else if (keyz == 82) {  // PGUP
          if ((tracepostop-1000) < 0) tracepostop = 0;
          else tracepostop -= 1000;
          }
        else if (keyz == 83) { // PGDOWN
          if ((tracepostop+1000) > cputracecount)
            tracepostop = cputracecount;
          else tracepostop += 1000;
          }
        }
      }


}
#endif

extern ULO keybufferconsumepos;
extern ULO keybufferproducepos;
extern UBY keybuffer[];

FILE *LOG;


UBY emuspeedstring[20];

void print_emuspeed(void) {
  sprintf(emuspeedstring,"%3d.%2.2d",emuspeed/100,emuspeed % 100);
  plot_text(emuspeedstring,60,0,0x7fff,0);
}


void main(int argc,char *argv[])
{
  FILE *romtst;
  int tast,finished = 0,i;
  int currenty=0;  // For use when printing status messages in console
  LOG = fopen("fellow.log","w");


  if (argc > 5) {
    printf("Usage:\nfellow [-r skiprate] [-s]\nskiprate: 0 means no skipped frames(default)\n-s enable sound\n");
    exit(1);
    }
  skiprate = 0;
  soundon = 0;
  emulate_joystick = 0;
  if (argc > 1) {
    i = 1;
    while (i < argc) {
      if (strcmp(argv[i],"-s") == 0) {
        i++;
        soundon = 1;
        }
      else {
        printf("Usage:\nfellow [-s]\n-s enables sound\n");
        exit(1);
       }
      }
    }

    if ((romtst = fopen("rom","r")) == NULL) {
      fprintf(LOG,"Need kickstart image in a file called 'rom'.\n");
      printf("Need kickstart image in a file called 'rom'.\n");
      fclose(LOG);
      exit(1);
      }
    fclose(romtst);  

    load_fellow_cfg();

  // Init different components
  // -------------------------
  // Screen
  //--------------------------
  if (soundon == 1) {
    sbinit();
    soundinit();
    }
  if (screeninit() == FALSE) {
    fprintf(LOG,"Failed to initialize Video system, STOP!\n");
    printf("Failed to initialize Video system, STOP!\n");
    fclose(LOG);
    exit(1);
  }  
  else {
    // Screen ready, init_main_screen
    init_main_screen();

#ifdef LOGGING
    // Load logging configuration
    if (loadlogconfig() == 0) plot_text_window(&mainconsole,"Failed to read logging configuration file, using default values.",0,currenty++);
#endif

    // Now initialize memory component
    if (meminit() == 0) {
      plot_text_window(&mainconsole,"Unsuccessful initialization of Memory emulation module, shutting down",0,currenty++);
      }
    else {
      plot_text_window(&mainconsole,"Memory emulation module initialized",0,currenty++);
      cpuinit();
      plot_text_window(&mainconsole,"CPU emulation module initialized",0,currenty++);
      chipinit();
      plot_text_window(&mainconsole,"Custom chip emulation module initialized",0,currenty++);
      diskinit();
      plot_text_window(&mainconsole,"Disk emulation module initialized",0,currenty++);

    fix_a7pointer();

      print_disks();

#ifdef CPUTRACE
    cputraceoff();
#endif


    if (norom == 0) setup_reset();
    else setup_trackmo();
    while (!finished) {
      switch (menu_select(&mainmenudata)) {
        case 0: // RUN
          init_lineflagstables();
          run_forever();
          debugging = 0;
          init_main_screen();
          if (errorvalue == 1) {
            plot_text_window(&mainconsole,"FATAL ERROR, I'M DEAD!!!!",0,0);
            plot_text_window(&mainconsole,"Could not process exception, stack pointer is odd.",0,1);
           }
          break;
        case 1: // DEBUGGER
          init_debugger_screen();
          debugger();
          init_main_screen();
          break;
        case 2: // CONFIGURATION
          init_configuration_screen();
	  configuration();
          init_main_screen();
          break;
/*        case 3: // RESET to kickstart
          setup_reset();
          break;
        case 4: // RESET for trackmos
          setup_trackmo();
          break;
*/
        case 3: // QUIT
          finished = 1;
          break;
#ifdef CPUTRACE
        case 6: // CPU TRACE ON
          cputraceon();
          break;
        case 7: // CPU TRACE OFF
          cputraceoff();
          break;
        case 8:  // SHOW CPU TRACE
          init_debugger_screen();
          showcputrace();
          init_main_screen();
          break;
#endif
        }
      }

#ifdef LOGGING
     // Save logging configuration
     savelogconfig();
#endif

     if (soundon == 1) sbclose();
     if (screenclose() == FALSE) {
       plot_text_window(&mainconsole,"Failed to close down Video system",0,40);
       }
     }
   }
  fclose(LOG);
}


