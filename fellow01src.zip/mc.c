#include <stdio.h>
#include "defs.h"
#include "ac.h"
#include "io.h"
#include "chip.h"

extern ULO blitterused;
extern ULO nxtcopaccess;
ULO norom;

extern FILE *LOG;

extern ULO interruptflag;
extern ULO interruptadress;
extern ULO interruptlevel;
extern ULO cpustopflag;

extern ULO chipmemsize,bogomemsize;

extern ULO eventcount;

extern void decodelo1();
extern void drawlores();
extern update_new_bpdmaline();
extern void drawddfline();
extern void fillbginfrontlores();
extern void fillbgbehindlores();


extern ULO eventlog[16384];
extern ULO eventptr;

/* AD hoc */
extern ULO frames;
extern ULO drawptr;



ULO screenmode;
ULO decoderoutineptr;
ULO drawroutineptr;
extern void drawbgline();

extern ULO rid();
extern ULO rciaapra();
extern void wciaapra();
extern ULO rciaaprb();
extern void wciaaprb();
extern ULO rciaaddra();
extern void wciaaddra();
extern ULO rciaaddrb();
extern void wciaaddrb();
extern ULO rciaasp();
extern void wciaasp();
extern ULO rciaatalo();
extern void wciaatalo();
extern ULO rciaatahi();
extern void wciaatahi();
extern ULO rciaatblo();
extern void wciaatblo();
extern ULO rciaatbhi();
extern void wciaatbhi();
extern ULO rciaaevlo();
extern ULO rciaaevmi();
extern ULO rciaaevhi();
extern void wciaaevlo();
extern void wciaaevmi();
extern void wciaaevhi();
extern ULO rciaaicr();
extern void wciaaicr();
extern ULO rciaacra();
extern void wciaacra();
extern ULO rciaacrb();
extern void wciaacrb();
extern ULO rcianothing();
extern void wcianothing();
extern ULO rciabpra();
extern void wciabpra();
extern ULO rciabprb();
extern void wciabprb();
extern ULO rciabddra();
extern void wciabddra();
extern ULO rciabddrb();
extern void wciabddrb();
extern ULO rciabsp();
extern void wciabsp();
extern ULO rciabtalo();
extern void wciabtalo();
extern ULO rciabtahi();
extern void wciabtahi();
extern ULO rciabtblo();
extern void wciabtblo();
extern ULO rciabtbhi();
extern void wciabtbhi();
extern ULO rciabevlo();
extern ULO rciabevmi();
extern ULO rciabevhi();
extern void wciabevlo();
extern void wciabevmi();
extern void wciabevhi();
extern ULO rciabicr();
extern void wciabicr();
extern ULO rciabcra();
extern void wciabcra();
extern ULO rciabcrb();
extern void wciabcrb();



extern ULO rdmaconr();
extern ULO rvposr();
extern ULO rvhposr();
extern ULO rjoy0dat();
extern ULO rjoy1dat();
extern ULO rpot0dat();
extern ULO rpot1dat();
extern ULO rpotgor();
extern ULO rdskbytr();
extern ULO rintenar();
extern ULO rintreqr();
extern ULO rdefault();
extern void wdskpth();
extern void wdskptl();
extern void wdsklen();
extern void wcopcon();
extern void wbltcon0();
extern void wbltcon1();
extern void wbltafwm();
extern void wbltalwm();
extern void wbltcpth();
extern void wbltcptl();
extern void wbltbpth();
extern void wbltbptl();
extern void wbltapth();
extern void wbltaptl();
extern void wbltdpth();
extern void wbltdptl();
extern void wbltsize();
extern void wbltcmod();
extern void wbltbmod();
extern void wbltamod();
extern void wbltdmod();
extern void wbltcdat();
extern void wbltbdat();
extern void wbltadat();
extern void wdsksync();
extern void wcop1lch();
extern void wcop1lcl();
extern void wcop2lch();
extern void wcop2lcl();
extern void wcopjmp1();
extern void wcopjmp2();
extern void wdiwstrt();
extern void wdiwstop();
extern void wddfstrt();
extern void wddfstop();
extern void wdmacon();
extern void wintena();
extern void wintreq();
extern void wadcon();
extern void waud0pth();
extern void waud0ptl();
extern void waud0vol();
extern void waud0len();
extern void waud0per();
extern void waud1pth();
extern void waud1ptl();
extern void waud1vol();
extern void waud1len();
extern void waud1per();
extern void waud2pth();
extern void waud2ptl();
extern void waud2vol();
extern void waud2len();
extern void waud2per();
extern void waud3pth();
extern void waud3ptl();
extern void waud3vol();
extern void waud3len();
extern void waud3per();
extern void wbpl1ptl();
extern void wbpl1pth();
extern void wbpl1ptl();
extern void wbpl2pth();
extern void wbpl2ptl();
extern void wbpl3pth();
extern void wbpl3ptl();
extern void wbpl4pth();
extern void wbpl4ptl();
extern void wbpl5pth();
extern void wbpl5ptl();
extern void wbpl6pth();
extern void wbpl6ptl();
extern void wbplcon0();
extern void wbplcon1();
extern void wbplcon2();
extern void wbpl1mod();
extern void wbpl2mod();
extern void wspr0pth();
extern void wspr0ptl();
extern void wspr1pth();
extern void wspr1ptl();
extern void wspr2pth();
extern void wspr2ptl();
extern void wspr3pth();
extern void wspr3ptl();
extern void wspr4pth();
extern void wspr4ptl();
extern void wspr5pth();
extern void wspr5ptl();
extern void wspr6pth();
extern void wspr6ptl();
extern void wspr7pth();
extern void wspr7ptl();
extern void wcolor();
extern void wdefault();


/* Declare functions in this file */

ULO meminit(void);
void dumpioblock(void);
void hexdump(ULO wher);

/* Table of register read/write functions */

regreadfunc ioread[256] = {rdefault,rdmaconr,rvposr,rvhposr,
                           rdefault,rjoy0dat,rjoy1dat,rdefault,
                           rdefault,rpot0dat,rpot1dat,rpotgor,
                           rdefault,rdskbytr,rintenar,rintreqr,
                           rdefault,rdefault,rdefault,rdefault,
                           rdefault,rdefault,rdefault,rdefault,
                           rdefault,rdefault,rdefault,rdefault,
                           rdefault,rdefault,rdefault,rdefault,
                           rdefault,rdefault,rdefault,rdefault,
                           rdefault,rdefault,rdefault,rdefault,
                           rdefault,rdefault,rdefault,rdefault,
                           rdefault,rdefault,rdefault,rdefault,
                           rdefault,rdefault,rdefault,rdefault,
                           rdefault,rdefault,rdefault,rdefault,
                           rdefault,rdefault,rdefault,rdefault,
                           rdefault,rdefault,rdefault,rdefault,
                           rdefault,rdefault,rdefault,rdefault,
                           rdefault,rdefault,rdefault,rdefault,
                           rdefault,rdefault,rdefault,rdefault,
                           rdefault,rdefault,rdefault,rdefault,
                           rdefault,rdefault,rdefault,rdefault,
                           rdefault,rdefault,rdefault,rdefault,
                           rdefault,rdefault,rdefault,rdefault,
                           rdefault,rdefault,rdefault,rdefault,
                           rdefault,rdefault,rdefault,rdefault,
                           rdefault,rdefault,rdefault,rdefault,
                           rdefault,rdefault,rdefault,rdefault,
                           rdefault,rdefault,rdefault,rdefault,
                           rdefault,rdefault,rdefault,rdefault,
                           rdefault,rdefault,rdefault,rdefault,
                           rdefault,rdefault,rdefault,rdefault,
                           rdefault,rdefault,rdefault,rdefault,
                           rdefault,rdefault,rdefault,rdefault,
                           rdefault,rdefault,rdefault,rdefault,
                           rdefault,rdefault,rdefault,rdefault,
                           rdefault,rdefault,rdefault,rdefault,
                           rdefault,rdefault,rdefault,rdefault,
                           rdefault,rdefault,rdefault,rdefault,
                           rdefault,rdefault,rdefault,rdefault,
                           rdefault,rdefault,rdefault,rdefault,
                           rdefault,rdefault,rdefault,rdefault,
                           rdefault,rdefault,rdefault,rdefault,
                           rdefault,rdefault,rdefault,rdefault,
                           rdefault,rdefault,rdefault,rdefault,
                           rdefault,rdefault,rdefault,rdefault,
                           rdefault,rdefault,rdefault,rdefault,
                           rdefault,rdefault,rdefault,rdefault,
                           rdefault,rdefault,rdefault,rdefault,
                           rdefault,rdefault,rdefault,rdefault,
                           rdefault,rdefault,rdefault,rdefault,
                           rdefault,rdefault,rdefault,rdefault,
                           rdefault,rdefault,rdefault,rdefault,
                           rdefault,rdefault,rdefault,rdefault,
                           rdefault,rdefault,rdefault,rdefault,
                           rdefault,rdefault,rdefault,rdefault,
                           rdefault,rdefault,rdefault,rdefault,
                           rdefault,rdefault,rdefault,rdefault,
                           rdefault,rdefault,rdefault,rdefault,
                           rdefault,rdefault,rdefault,rdefault,
                           rdefault,rdefault,rdefault,rdefault,
                           rdefault,rdefault,rdefault,rdefault,
                           rdefault,rdefault,rdefault,rdefault,
                           rdefault,rdefault,rdefault,rdefault,
                           rdefault,rdefault,rdefault,rdefault};

regwritefunc iowrite[256]={wdefault,wdefault,wdefault,wdefault,
                           wdefault,wdefault,wdefault,wdefault,
                           wdefault,wdefault,wdefault,wdefault,
                           wdefault,wdefault,wdefault,wdefault,
                           wdskpth,wdskptl,wdsklen,wdefault,
                           wdefault,wdefault,wdefault,wcopcon,
                           wdefault,wdefault,wdefault,wdefault,
                           wdefault,wdefault,wdefault,wdefault,
                           wbltcon0,wbltcon1,wbltafwm,wbltalwm,
                           wbltcpth,wbltcptl,wbltbpth,wbltbptl,
                           wbltapth,wbltaptl,wbltdpth,wbltdptl,
                           wbltsize,wdefault,wdefault,wdefault,
                           wbltcmod,wbltbmod,wbltamod,wbltdmod,
                           wdefault,wdefault,wdefault,wdefault,
                           wbltcdat,wbltbdat,wbltadat,wdefault,
                           wdefault,wdefault,wdefault,wdsksync,
                           wcop1lch,wcop1lcl,wcop2lch,wcop2lcl,
                           wcopjmp1,wcopjmp2,wdefault,wdiwstrt,
                           wdiwstop,wddfstrt,wddfstop,wdmacon,
                           wdefault,wintena,wintreq,wadcon,
                           waud0pth,waud0ptl,waud0len,waud0per,
                           waud0vol,wdefault,wdefault,wdefault,
                           waud1pth,waud1ptl,waud1len,waud1per,
                           waud1vol,wdefault,wdefault,wdefault,
                           waud2pth,waud2ptl,waud2len,waud2per,
                           waud2vol,wdefault,wdefault,wdefault,
                           waud3pth,waud3ptl,waud3len,waud3per,
                           waud3vol,wdefault,wdefault,wdefault,
                           wbpl1pth,wbpl1ptl,wbpl2pth,wbpl2ptl,
                           wbpl3pth,wbpl3ptl,wbpl4pth,wbpl4ptl,
                           wbpl5pth,wbpl5ptl,wbpl6pth,wbpl6ptl,
                           wdefault,wdefault,wdefault,wdefault,
                           wbplcon0,wbplcon1,wbplcon2,wdefault,
                           wbpl1mod,wbpl2mod,wdefault,wdefault,
                           wdefault,wdefault,wdefault,wdefault,
                           wdefault,wdefault,wdefault,wdefault,
                           wspr0pth,wspr0ptl,wspr1pth,wspr1ptl,
                           wspr2pth,wspr2ptl,wspr3pth,wspr3ptl,
                           wspr4pth,wspr4ptl,wspr5pth,wspr5ptl,
                           wspr6pth,wspr6ptl,wspr7pth,wspr7ptl,
                           wdefault,wdefault,wdefault,wdefault,
                           wdefault,wdefault,wdefault,wdefault,
                           wdefault,wdefault,wdefault,wdefault,
                           wdefault,wdefault,wdefault,wdefault,
                           wdefault,wdefault,wdefault,wdefault,
                           wdefault,wdefault,wdefault,wdefault,
                           wdefault,wdefault,wdefault,wdefault,
                           wdefault,wdefault,wdefault,wdefault,
                           wcolor,wcolor,wcolor,wcolor,
                           wcolor,wcolor,wcolor,wcolor,
                           wcolor,wcolor,wcolor,wcolor,
                           wcolor,wcolor,wcolor,wcolor,
                           wcolor,wcolor,wcolor,wcolor,
                           wcolor,wcolor,wcolor,wcolor,
                           wcolor,wcolor,wcolor,wcolor,
                           wcolor,wcolor,wcolor,wcolor,
                           wdefault,wdefault,wdefault,wdefault,
                           wdefault,wdefault,wdefault,wdefault,
                           wdefault,wdefault,wdefault,wdefault,
                           wdefault,wdefault,wdefault,wdefault,
                           wdefault,wdefault,wdefault,wdefault,
                           wdefault,wdefault,wdefault,wdefault,
                           wdefault,wdefault,wdefault,wdefault,
                           wdefault,wdefault,wdefault,wdefault};


/* Table of CIA read/write functions */

ciareadfunc ciaaread[16] = {rciaapra,rciaaprb,rciaaddra,rciaaddrb,rciaatalo,
                            rciaatahi,rciaatblo,rciaatbhi,rciaaevlo,
                            rciaaevmi,rciaaevhi,rcianothing,rciaasp,rciaaicr,
                            rciaacra,rciaacrb};
ciareadfunc ciabread[16] = {rciabpra,rciabprb,rciabddra,rciabddrb,rciabtalo,
                            rciabtahi,rciabtblo,rciabtbhi,rciabevlo,
                            rciabevmi,rciabevhi,rcianothing,rciabsp,rciabicr,
                            rciabcra,rciabcrb};
ciawritefunc ciaawrite[16]={wciaapra,wciaaprb,wciaaddra,wciaaddrb,wciaatalo,
                            wciaatahi,wciaatblo,wciaatbhi,wciaaevlo,
                            wciaaevmi,wciaaevhi,wcianothing,wciaasp,wciaaicr,
                            wciaacra,wciaacrb};
ciawritefunc ciabwrite[16]={wciabpra,wciabprb,wciabddra,wciabddrb,wciabtalo,
                            wciabtahi,wciabtblo,wciabtbhi,wciabevlo,
                            wciabevmi,wciabevhi,wcianothing,wciabsp,wciabicr,
                            wciabcra,wciabcrb};

/* Data for the CIAs */

ULO ciaeventtime;

ULO led;
ULO ciaata;
ULO ciaatb;               
ULO ciaatalatch;
ULO ciaatblatch;          
ULO ciaataleft;
ULO ciaatbleft;
ULO ciaaicrreq;
ULO ciaaicrmsk;           
ULO ciaaevalarm;          
ULO ciaaevlatch;               
ULO ciaaevlatching;
ULO ciaaevwritelatch;               
ULO ciaaevwritelatching;               
ULO ciaaevalarmlatch;
ULO ciaaevalarmlatching;

ULO ciaaev;
ULO ciaacra;              
ULO ciaacrb;              
ULO ciaapra = 0xff;
ULO ciaaprb;              
ULO ciaaddra;             
ULO ciaaddrb;             
ULO ciaasp;               

ULO ciabta;               
ULO ciabtb;               
ULO ciabtalatch;          
ULO ciabtblatch;          
ULO ciabtaleft;
ULO ciabtbleft;
ULO ciabicrreq;           
ULO ciabicrmsk;           
ULO ciabevalarm;
ULO ciabevlatch;               
ULO ciabevlatching;               
ULO ciabevwritelatch;
ULO ciabevwritelatching;               
ULO ciabevalarmlatch;
ULO ciabevalarmlatching;
ULO ciabev;               
ULO ciabcra;              
ULO ciabcrb;              
ULO ciabpra = 0xff;
ULO ciabprb;              
ULO ciabddra;             
ULO ciabddrb;             
ULO ciabsp;               

/* Disk registers */

ULO dsklen,dsksync,dskpt,adcon;

/* Different variables used by the decode routines to scroll bitplanes */

ULO evenscroll,evenhiscroll,oddscroll,oddhiscroll;

/* Variables that correspond to various registers */

ULO dmaconr,dmacon;
ULO intenar,intena,intreq;
ULO potgor,pot0dat,pot1dat,joy0dat,joy1dat;

/* Screen related registers */

ULO bpl1pt,bpl2pt,bpl3pt,bpl4pt,bpl5pt,bpl6pt;

ULO lof,xpos,ypos,diwxleft,diwxright,diwytop,diwybottom,ddfstrt,
    ddfstop,
    bplcon0,bplcon1,bplcon2,bpl1mod,bpl2mod,diwstrt,diwstop;

/* Helpers for the screen emulation */

ULO screenptr,lineflags[314];

// Global line specific data

ULO DDFstartpos,DDFnumberofwords,DIWfirstvisiblepos,DIWlastvisiblepos;
ULO DIWfirstposonline,DIWlastposonline;

// Data for the current line

ULO LINEposition;

/* Copper registers */

ULO copcon,cop1lc,cop2lc;

/* Blitter registers */

ULO bltcon,bltafwm,bltalwm,bltapt,bltbpt,bltcpt,bltdpt,bltamod,
    bltbmod,bltcmod,bltdmod,bltadat,bltbdat,bltcdat,blitteraccess=FALSE,
    linenum,linecount,linelength,bltdesc,blitterdmawaiting,
    blitterstatus,blitend,bltadatoff,bltbdatoff,bltadattmp,bltbdattmp,
    bltcdattmp,bltminterm;

/* Sprite registers */
ULO sprpt[8],sprx[8],spry[8],sprly[8],spratt[8];
ULO spritestate[8];
ULO sprite16col[8];
UWO sprdat[8][2];


/****************************************************************************
 MEMORY RELATED DATA
 ****************************************************************************/
 
/* Memory arrays ++ because of a fucked up compiler */
/* Should make these allocated dynamicly later */

UBY cmem[CHIPMEM+32];
UBY fmem[FASTMEM+32];
UBY bmem[BOGOMEM+32];
UBY kmem[KICKMEM+32];

/* ------------------- */
/* DEFINE LOOKUPTABLES */
/* ------------------- */
/* Table of fetch-functions using 256K banks */
/* Byte/word/long read */

readfunc readbyte[64];
readfunc readword[64];
readfunc readlong[64];

/* Table of write-functions using 256K banks */
/* Byte/word/long read */

writefunc writebyte[64];
writefunc writeword[64];
writefunc writelong[64];

/****************************************************************************
 MEMORY RELATED FUNCTIONS
 ****************************************************************************/
/* Functions implemented in ma.asm */

/* TOP LEVEL INTERFACE */
extern ULO fetb(amigaadress ea);
extern ULO fetw(amigaadress ea);
extern ULO fetl(amigaadress ea);
extern void wrib(ULO data, amigaadress ea);
extern void wriw(ULO data, amigaadress ea);
extern void wril(ULO data, amigaadress ea);

/* CHIP RAM INTERFACE */
extern ULO readchipbyte(amigaadress ea);
extern ULO readchipword(amigaadress ea);
extern ULO readchiplong(amigaadress ea);
extern void writechipbyte(ULO data, amigaadress ea);
extern void writechipword(ULO data, amigaadress ea);
extern void writechiplong(ULO data, amigaadress ea);

/* FAST RAM INTERFACE */
extern ULO readfastbyte(amigaadress ea);
extern ULO readfastword(amigaadress ea);
extern ULO readfastlong(amigaadress ea);
extern void writefastbyte(ULO data, amigaadress ea);
extern void writefastword(ULO data, amigaadress ea);
extern void writefastlong(ULO data, amigaadress ea);

/* BOGO RAM INTERFACE */
extern ULO readbogobyte(amigaadress ea);
extern ULO readbogoword(amigaadress ea);
extern ULO readbogolong(amigaadress ea);
extern void writebogobyte(ULO data, amigaadress ea);
extern void writebogoword(ULO data, amigaadress ea);
extern void writebogolong(ULO data, amigaadress ea);

/* KICK ROM INTERFACE */
extern ULO readkickbyte(amigaadress ea);
extern ULO readkickword(amigaadress ea);
extern ULO readkicklong(amigaadress ea);
extern void writekickbyte(ULO data, amigaadress ea);
extern void writekickword(ULO data, amigaadress ea);
extern void writekicklong(ULO data, amigaadress ea);

/* IO REGISTER INTERFACE */
extern ULO readregisterbyte(amigaadress ea);
extern ULO readregisterword(amigaadress ea);
extern ULO readregisterlong(amigaadress ea);
extern void writeregisterbyte(ULO data, amigaadress ea);
extern void writeregisterword(ULO data, amigaadress ea);
extern void writeregisterlong(ULO data, amigaadress ea);

/* CIA INTERFACE */
extern ULO readciabyte(amigaadress ea);
extern ULO readciaword(amigaadress ea);
extern ULO readcialong(amigaadress ea);
extern void writeciabyte(ULO data, amigaadress ea);
extern void writeciaword(ULO data, amigaadress ea);
extern void writecialong(ULO data, amigaadress ea);

/* NOT AVAILABLE INTERFACE */
extern ULO readnotavailablebyte(amigaadress ea);
extern ULO readnotavailableword(amigaadress ea);
extern ULO readnotavailablelong(amigaadress ea);
extern void writenotavailablebyte(ULO data, amigaadress ea);
extern void writenotavailableword(ULO data, amigaadress ea);
extern void writenotavailablelong(ULO data, amigaadress ea);

extern void oddwrite(ULO data,amigaadress ea);
extern ULO oddread(amigaadress ea);




/* Translation tables for colors */

ULO colortab[4096];
ULO shadcol[64];

/* Some useful functions */

void setNAjumptable(ULO m)
{
    readbyte[m] = readnotavailablebyte;
    readword[m] = readnotavailableword;
    readlong[m] = readnotavailablelong;
    writebyte[m] = writenotavailablebyte;
    writeword[m] = writenotavailableword;
    writelong[m] = writenotavailablelong;
}


// The memory module holds all registers (IO and CIA) and
// handles all memory banks.  Loads kickstart from file.
// Meminit initializes these to default values
// Returns true or false when done
// ======================================================

ULO meminit(void)
{
  FILE *F;
  char hei[120];
  int k,j;
  ULO m,n;
  int strt,c;
  ULO returnvalue = 1;


/* Init cia registers */
  ciaaev = 0;
  ciaaevlatch = 0;
  ciaaevlatching = 0;
  ciaaevalarm = 0;
  ciaaevalarmlatch = 0;
  ciaaevalarmlatching = 0;
  ciaaevwritelatch = 0;
  ciaaevwritelatching = 0;
  ciabev = 0;
  ciabevlatch = 0;
  ciabevlatching = 0;
  ciabevalarm = 0;
  ciabevalarmlatch = 0;
  ciabevalarmlatching = 0;
  ciabevwritelatch = 0;
  ciabevwritelatching = 0;

  ciaataleft = -1;
  ciaatbleft = -1;
  ciaata = 0xffff; // Just for safety, don't know if its necesary
  ciaatb = 0xffff;
  ciaatalatch = 0xffff;
  ciaatblatch = 0xffff;

  ciabtaleft = -1;
  ciabtbleft = -1;
  ciabta = 0xffff; // Just for safety, don't know if its necesary
  ciabtb = 0xffff;
  ciabtalatch = 0xffff;
  ciabtblatch = 0xffff;



// Initialize Screen Registers
  lof = 0x8000;       // Always long frame, or maybe not...
  bpl1mod = 0;
  bpl2mod = 0;
  diwxleft = 0;
  diwxright = 0; 
  diwytop = 0;   
  diwybottom = 0;

/* Initialize the helpers for screenemulation */
/* Assume no bitplanes on */

  screenptr = (ULO) framebuffer + 9632 + (scanlineadd*6); // 16 blank pixels to the left and 12 lines down
  drawptr = (ULO) drawbgline;      /* Should be something else */
  decoderoutineptr = (ULO) decodelo1;
  drawroutineptr = (ULO) drawlores;


  DDFstartpos = 0;
  DDFnumberofwords = 0;
  DIWfirstvisiblepos = 256;
  DIWlastvisiblepos = 256;
  DIWfirstposonline = 88;

  // Clear the speedup table for blank lines.
  for (m=0; m < 314; m++) lineflags[m] = -1;

  blitend = blitterstatus = 0;

// Initialize various registers
  potgor = 0xffff;   // To avoid detection of pressed right mouse button
  dmaconr = 0x01ff;

// Copper registers
  curcopptr = 0;
  nxtcopaccess = 6;

/* Initialize the jumptables */
/* Chipmem first */

  if (chipmemsize > 0x200000) n = 0x200000>>18;
  else n = chipmemsize>>18;
  for (m = 0; m < n; m++) {
    readbyte[m] = readchipbyte;
    readword[m] = readchipword;
    readlong[m] = readchiplong;
    writebyte[m] = writechipbyte;
    writeword[m] = writechipword;
    writelong[m] = writechiplong;
    }

/* Then the area between chip mem and fastmem */

  for (m = n; m < 0x200000>>18; m++) setNAjumptable(m);

/* Then Fastmem */

  if (FASTMEM > 0x800000) n = 0xa00000>>18;
  else n = (0x200000+FASTMEM)>>18;
  for (m = 0x200000>>18; m < n; m++) {
    readbyte[m] = readfastbyte;
    readword[m] = readfastword;
    readlong[m] = readfastlong;
    writebyte[m] = writefastbyte;
    writeword[m] = writefastword;
    writelong[m] = writefastlong;
    }

/* Then the area between fastmem and ciamem */

  for (m = n; m < 0xa00000>>18; m++) setNAjumptable(m);

/* Cia memory */

  for (m = 0xa00000>>18; m < (0xc00000>>18); m++) {
    readbyte[m] = readciabyte;
    readword[m] = readciaword;
    readlong[m] = readcialong;
    writebyte[m] = writeciabyte;
    writeword[m] = writeciaword;
    writelong[m] = writecialong;
    }

/* Then Bogomem */

  if (bogomemsize > 0x1c0000) n = 0xdc0000>>18;
  else n = (0xc00000+bogomemsize)>>18;
  for (m = 0xc00000>>18; m < n; m++) {
    readbyte[m] = readbogobyte;
    readword[m] = readbogoword;
    readlong[m] = readbogolong;
    writebyte[m] = writebogobyte;
    writeword[m] = writebogoword;
    writelong[m] = writebogolong;
    }

/* Register mem */

  for (m = n; m < 0xe00000>>18; m++) {
    readbyte[m] = readregisterbyte;
    readword[m] = readregisterword;
    readlong[m] = readregisterlong;
    writebyte[m] = writeregisterbyte;
    writeword[m] = writeregisterword;
    writelong[m] = writeregisterlong;
    }

/* Then the area between regmem and rom */

  for (m = 0xe00000>>18; m < 0xf80000>>18; m++) setNAjumptable(m);

/* Kick (rom) mem */

  for (m = 0xf80000>>18; m < 0x1000000>>18; m++) {
    readbyte[m] = readkickbyte;
    readword[m] = readkickword;
    readlong[m] = readkicklong;
    writebyte[m] = writenotavailablebyte;
    writeword[m] = writenotavailableword;
    writelong[m] = writenotavailablelong;
    }


/* Create color translation table */
  for (k=0; k<4096;k++) {
    colortab[k] = ((k & 0xf)<<1) | ((k & 0xf0)<<2) | ((k & 0xf00)<<3);
    colortab[k] = colortab[k]<<16 | colortab[k];
    }

/* Zero the shadow color registers */
  for (k=0; k<64; k++) shadcol[k] = 0;

  decoderoutineptr = (ULO) decodelo1;
  decoderoutineptr = (ULO) drawlores;
/* Load rom from file */

  if ((F = fopen("rom","rb")) == NULL) {
    fprintf(LOG,"Couldn't find rom");
    norom = 1;
    }
  else {
    fread(kmem,1,262144*2,F);
    norom = 0;
   }

  bltminterm = 0;

  ciaeventtime = -1;
  return returnvalue;
}

