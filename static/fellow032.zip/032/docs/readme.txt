This archive contains Fellow V0.3.2:
------------------------------------

Always read the documentation.


Changes in V0.3.2:
------------------

-Major cpu-emulation bug fixed. It caused some strange behaviour
 in the commands "list" and "dir" when using the "all" parameter.
 This is also what made the WB harddisk installation hang.

-VESA code tests more on return values. It could end up using a NULL 
 pointer for the framebuffer, which instantly erased all conventional 
 dos-memory. It can be one of the reasons for some of the "instant reset"
 reports. I'm curious if this fix has any positive effects.

-Minor cpu-emulation bug that appeared in V0.3.1 fixed. It affected
 ABCD numbers and caused some games to count scores wrong.

-Mouse emulation now responds to a request to reset the counters.
 Affected some mouse-driven selection lists where you could only
 access the top or bottom entry.

-Implemented Blitter zero bit in Blitter.  A couple of other changes
 in the blitter behaviour were also done.  Among other things it
 helps demos that uses a combined cpu/blitter clearing algorithm.

-Added handling of blitter finish disable bit in copper emulation.

-"Expansion cards" are now also reset after a GURU so hardfiles
 boot and fastmem does not disappear after the GURU meditation.

-Various other changes and bugfixes in cpu and cia emulation.

-Italian translation of the documentation by Roberto Gasparrini.

-Correct handling of sprites on HAM-screens now implemented.



 

