FellowHD Version 1.0

Copyrights
This program are freeware as long as none one take monny for it.
If you will include it on a Freeware or Shareware DISK or CD-ROM you must 
a write perimintion  for it.
Copyrights by Magnus Olsen 1998.
   
What is this program good for ?
If you want make a hard file to Fellow. You can use this program.

How to use it
It is not so hard to use it. 
You type : 
Fellowhd.exe (the hardfile name) (how big the hard file will be in Mb)

example :
In the DOS prompt type:
FellowHD.exe AmigaHD 50 (enter)
It will creat a File call AmigaHD.ADF and this file are also 50 Mb Big

System Req.
CPU :  386 or higher
Opreation System MS-DOS 5.0 or higher

Buggs:
I can not find a bugg in this version.
    