/*=========================================*/
/* Fellow Amiga Emulator                   */
/* Data and functions that run the GUI     */
/* (C) 1997-1998 Petter Schau              */
/*           and Roman Doljesi             */
/*           and Rainer Sinsch             */
/*=========================================*/

#include <stdio.h>
#include <string.h>
#include "defs.h"
#include "fellow.h"
#include "gui.h"
#include "floppy.h"
#include "memory.h"
#include "sound.h"
#include "graphem.h"
#include "inout.h"
#include "68000.h"
#include "68030.h"
#include "joymouse.h"
#include "cianew.h"
#include "fhfile.h"
#include "sblast.h"
#include "wav.h"
#include "draw.h"
#include "bus.h"
#include "copper.h"
#include "keyboard.h"
#include "blit.h"
#include "various.h"
#include "filesys.h"

#ifdef USE_GUI


/* TODO: Sometime, make separate file "debugger.c"  */

void fguiConfigMenuInit(void);
void fguiConfigMenuRun(void);
void fguiTopMenuInit(void);
void fguiTopMenuRun(void);
void fguiUtilMenuInit(void);
void fguiUtilMenuRun(void);
void fguiFilesystemMenuInit(void);
void fguiFilesystemMenuRun(void);
void fguiDebugMenuInit(void);
void fguiDebugMenuRun(void);
void fguiMODRipper(void);
void fguiGameCheats(void);
void fguiADFCreate(void);
void fguiHDFCreate(void);
void fguiAbout(void);
ULO fguiFloppyUnitsPrint(ULO ystart);
ULO fguiFHFileUnitsPrint(ULO ystart);
ULO fguiUAEUnitsPrint(ULO ystart);
ULO fguiKickstartInfoPrint(ULO ystart);
void fguiDiskNamePrint(STR *str, ULO drv);
void fguiFellowRun(void);

/* Print addresses for a number of labels */

/*#define ALIGN_CHECK*/


#ifdef DEBUGBUILD

#include "eventid.h"

#endif


/*=============*/
/* The windows */
/*=============*/

struct gui_window fgui_wrequester, fgui_wfullscreen, fgui_wheader,
		  fgui_wconsole, fgui_wmenu;


/*===================*/
/* IO registers menu */
/*===================*/

struct gui_menu fgui_debugiomenu;

char *fgui_debugiomenu_entries[] = {"Floppy","Sound","Copper","Sprites",
                                    "Screen","Events",NULL};

UBY fgui_debugiomenu_shortcuts[] = {0,0,0,1,2,0};


/*====================*/
/* Breakpoint submenu */
/*====================*/

struct gui_menu fgui_debugbreakmenu;

char *fgui_debugbreakmenu_entries[] = {"Set Breakpnt","To Line 312",
#ifdef DEBUGBUILD
                                  "Until Event",
#endif
                                  NULL};

UBY fgui_debugbreakmenu_shortcuts[] = {0,0
#ifdef DEBUGBUILD
                                  ,0
#endif                                  
};


/*====================*/
/* Floppy option-menu */
/*====================*/

struct gui_optionmenu fgui_floppy_optionmenu;

char *fgui_floppy_topheader = {"Floppy-disk emulation options:"};

char *fgui_floppy_headers[10] = {"Disk-image in DF0:","Disk-image in DF1:",
                               "Disk-image in DF2:","Disk-image in DF3:",
                               "Drive 0 status:",   "Drive 1 status:",
                               "Drive 2 status:",   "Drive 3 status:",
                               "Disk-DMA speed:", NULL};

UBY fgui_floppy_shortcuts[9] = {16,16,16,16,0,1,2,3,0};

UBY fgui_floppy_actions[9] = {GUI_FILEREQ_ADF,GUI_FILEREQ_ADF,GUI_FILEREQ_ADF,
			       GUI_FILEREQ_ADF,GUI_VALUELIST,GUI_VALUELIST,
			       GUI_VALUELIST,GUI_VALUELIST,GUI_VALUELIST,
			     };

const void *fgui_floppy_vars[9] = {floppy[0].imagename,
				    floppy[1].imagename,
                                    floppy[2].imagename,
				    floppy[3].imagename,
                                    &floppy[0].enabled,
                                    &floppy[1].enabled,
                                    &floppy[2].enabled,
                                    &floppy[3].enabled,
                                    &floppy_fast};

/* Option texts for disk menu */

char *fgui_floppy_enabled_text[3] = {"Enabled ",
				     "Disabled",
				     NULL};
char *fgui_floppy_fast_text[3] = {"Original",
				  "Fast    ",
				  NULL};

/* Option values for disk menu */

ULO fgui_floppy_enabled_vals[2] = {TRUE, FALSE};
ULO fgui_floppy_fast_vals[2] = {FALSE, TRUE};

char **fgui_floppy_texts[9] = {NULL,NULL,NULL,NULL,fgui_floppy_enabled_text,
                                fgui_floppy_enabled_text,
                                fgui_floppy_enabled_text,
                                fgui_floppy_enabled_text,
                                fgui_floppy_fast_text};

void *fgui_floppy_vals[9] = {NULL,NULL,NULL,NULL,fgui_floppy_enabled_vals,
                              fgui_floppy_enabled_vals,
                              fgui_floppy_enabled_vals,
                              fgui_floppy_enabled_vals,
                              fgui_floppy_fast_vals};


void fguiOptionmenuFloppyInit(void) {
  guiOptionmenuInit(&fgui_floppy_optionmenu,
		     fgui_floppy_topheader,
		     fgui_floppy_headers,
		     fgui_floppy_actions,
		     fgui_floppy_vars,
		     fgui_floppy_texts,
		     fgui_floppy_vals,
		     &fgui_wconsole,
		     fgui_floppy_shortcuts);
}

/*====================*/
/* Screen option-menu */
/*====================*/

struct gui_optionmenu fgui_screen_optionmenu;

char *fgui_screen_topheader = {"Screen-emulation configuration:"};

char *fgui_screen_headers[6] = {"Resolution:",
                                "Frame-skip ratio:",
                                "Maximum frame-rate:",
                                "Flicker-free interlace:",
                                "Y Scaling:",NULL};

UBY fgui_screen_shortcuts[6] = {0,0,0,1,0};

UBY fgui_screen_actions[5] = {GUI_VALUELIST,GUI_VALUELIST,GUI_VALUELIST,
                              GUI_VALUELIST,GUI_VALUELIST};

const void *fgui_screen_vars[5] = {&config_graphics_mode,
                                   &config_graphics_skiprate,
                                   &config_graphics_maxfps,
                                   &config_graphics_flickerfree,
                                   &config_graphics_scaley};

/* Option texts for screen menu */

char *fgui_screen_resolution_text[15];

char *fgui_screen_resolution_text_template[15] = {"800x600 hi-color   ",
                                                 "320x200 hi-color   ",
                                                 "320x240 hi-color   ",
                                                 "640x480 hi-color   ",
                                                 "640x400 hi-color   ",
                                                 "640x350 hi-color   ",
                                                 "320x200 8-bit color",
                                                 "320x240 8-bit color",
                                                 "320x400 8-bit color",
                                                 "320x480 8-bit color",
                                                 "400x300 8-bit color",
                                                 "320x400 hi-color",
                                                 "320x480 hi-color",
                                                 "400x300 hi-color",NULL};

char *fgui_screen_frameskip_text[26] = {"1/1 ","1/2 ","1/3 ","1/4 ",
                                        "1/5 ","1/6 ","1/7 ","1/8 ",
                                        "1/9 ","1/10","1/11","1/12",
                                        "1/13","1/14","1/15","1/16",
                                        "1/17","1/18","1/19","1/20",
                                        "1/21","1/22","1/23","1/24",
                                        "1/25",NULL};

char *fgui_screen_maxframerate_text[4] = {"Unlimited             ",
                                          "50 hz                 ",
                                          "Use sync from VGA-card",
                                          NULL};

char *fgui_screen_interlace_text[3] = {"No ","Yes",NULL};

char *fgui_screen_scaley_text[] = {"No scaling                ",
				   "Hardware VGA Line Doubling",
				   "Insert blank lines        ",
				   NULL};

/* Option values for screen menu */

ULO fgui_screen_resolution_vals[15];
ULO fgui_screen_frameskip_vals[25] = {0,1,2,3,4,5,6,7,8,9,10,11,12,13,
                                      14,15,16,17,18,19,20,21,22,23,24};

ULO fgui_screen_maxframerate_vals[3] = {0,1,2};

ULO fgui_screen_interlace_vals[2] = {0,1};
ULO fgui_screen_scaley_vals[3] = {0, 1, 2};

char **fgui_screen_texts[6] = {fgui_screen_resolution_text,
                               fgui_screen_frameskip_text,
                               fgui_screen_maxframerate_text,
                               fgui_screen_interlace_text,
                               fgui_screen_scaley_text};

void *fgui_screen_vals[6] = {fgui_screen_resolution_vals,
                             fgui_screen_frameskip_vals,
                             fgui_screen_maxframerate_vals,
                             fgui_screen_interlace_vals,
                             fgui_screen_scaley_vals};

void fguiOptionmenuScreenInit(void) {
  int i, j = 0;

  for (i = 0; i < NROFMODES; i++) {
    if (config_graphics_modeavailable[i]) {
      fgui_screen_resolution_text[j] = fgui_screen_resolution_text_template[i];
      fgui_screen_resolution_vals[j] = i;
      j++;
    }
    fgui_screen_resolution_text[j] = NULL;
  }
  guiOptionmenuInit(&fgui_screen_optionmenu,fgui_screen_topheader,
		     fgui_screen_headers,fgui_screen_actions,fgui_screen_vars,
		     fgui_screen_texts,fgui_screen_vals,&fgui_wconsole,
		     fgui_screen_shortcuts);
}

/*====================*/
/* Memory option-menu */
/*====================*/

struct gui_optionmenu fgui_memory_optionmenu;

char *fgui_memory_topheader = {"Memory configuration (Changes force reset):"};

char *fgui_memory_headers[] = {"Chip-memory:",
			       "Fast-memory:",
			       "Slow-memory:",
			       "Kickstart-image file:",
			       "Encryption key-file:",
			       "Memory-space size:",
			       NULL};

UBY fgui_memory_shortcuts[] = {0, 0, 0, 0,
			       1,
			       0};

UBY fgui_memory_actions[] = {GUI_VALUELIST,
			     GUI_VALUELIST,
			     GUI_VALUELIST,
			     GUI_FILEREQ_ROM,
			     GUI_FILEREQ_KEY,
			     GUI_VALUELIST};

const void *fgui_memory_vars[] = {&config_memory_chipsize,
				  &config_memory_fastsize,
				  &config_memory_bogosize,
				  config_memory_kickname,
				  config_memory_keyname,
				  &config_memory_space_32bit};

/* Option texts for memory menu */

char *fgui_memory_chip_text[9] = {"256 k ", "512 k ", "768 k ", "1024 k",
                                  "1280 k", "1536 k", "1792 k", "2048 k",
                                  NULL};

char *fgui_memory_fast_text[6] = {"0 MB", "1 MB", "2 MB", "4 MB", "8 MB",
				  NULL};

char *fgui_memory_bogo_text[9] = {"0 k   ", "256 k ", "512 k ", "768 k ",
                                  "1024 k", "1280 k", "1536 k", "1792 k",
				  NULL};

char *fgui_memory_space_text[3] = {"24 Bit", "32 Bit", NULL};

/* Option values for memory menu */

ULO fgui_memory_chip_vals[8] = { 0x40000,  0x80000,  0xc0000, 0x100000,
                                0x140000, 0x180000, 0x1c0000, 0x200000};

ULO fgui_memory_fast_vals[5] = {0, 0x100000, 0x200000, 0x400000, 0x800000};

ULO fgui_memory_bogo_vals[8] = {       0,  0x40000,  0x80000,  0xc0000,
				0x100000, 0x140000, 0x180000, 0x1c0000};

ULO fgui_memory_space_vals[2] = {FALSE, TRUE};

STR **fgui_memory_texts[] = {fgui_memory_chip_text,
			     fgui_memory_fast_text,
			     fgui_memory_bogo_text,
			     NULL,
			     NULL,
			     fgui_memory_space_text};

void *fgui_memory_vals[] = {fgui_memory_chip_vals,
			    fgui_memory_fast_vals,
			    fgui_memory_bogo_vals,
			    NULL,
			    NULL,
			    fgui_memory_space_vals
};

void fguiOptionmenuMemoryInit(void) {
  guiOptionmenuInit(&fgui_memory_optionmenu,
		     fgui_memory_topheader,
		     fgui_memory_headers,
		     fgui_memory_actions,
		     fgui_memory_vars,
		     fgui_memory_texts,
		     fgui_memory_vals,
		     &fgui_wconsole,
		     fgui_memory_shortcuts);
}


/*===================*/
/* Sound option-menu */
/*===================*/

struct gui_optionmenu fgui_sound_optionmenu;

STR *fgui_sound_topheader = {"Sound configuration:"};

STR *fgui_sound_topheader_nosound = {"No supported sound card was found."};

STR *fgui_sound_headers[] = {"Sound-emulation:",
#ifdef SOUNDDRV_MIDAS
			     "Internal mixing rate:",
			     "Internal mixing channels:",
			     "Internal mixing bits:",
#else
			     "Output rate:",
			     "Output channels:",
			     "Output bits:",
#endif
			     "Low-Pass Filter:",
			     "Sound-buffer depth (in ms):",
			     "Send sound output to WAV-file:",
			     NULL};

#ifdef SOUNDDRV_MIDAS
UBY fgui_sound_shortcuts[] = {0, 16, 16, 16, 9, 0, 21};
#else
UBY fgui_sound_shortcuts[] = {0, 7, 7, 7, 9, 0, 21};
#endif

UBY fgui_sound_actions[] = {GUI_VALUELIST, GUI_VALUELIST, GUI_VALUELIST,
			    GUI_VALUELIST, GUI_VALUELIST, GUI_VALUELIST,
                            GUI_VALUELIST};
UBY fgui_sound_actionsnosound[] = {GUI_VALUELIST};

const void *fgui_sound_vars[] = {&sound_mode,
				 &sound_rate,
				 &sound_channels,
				 &sound_bits,
				 &sound_filter,
                                 &sound_buffer_depth,
                                 &sound_wav_dump};

STR *fgui_sound_headers_nosound[] = {"Sound-emulation:",
				     "Low-Pass Filter:",
				     "Send sound output to WAV-file:",
				     NULL};

const void *fgui_sound_vars_nosound[] = {&sound_mode,
                                         &sound_filter,
                                         &sound_wav_dump};

UBY fgui_sound_actions_nosound[] = {GUI_VALUELIST, GUI_VALUELIST,
				    GUI_VALUELIST};

/* Option texts for sound menu */

STR *fgui_sound_soundemu_text[] = {"No sound                 ",
				   "Normal                   ",
				   "Emulated, no sound output",
				   NULL};

ULO fgui_sound_soundemu_vals[] = {0, 1, 3};

STR *fgui_sound_soundemunosound_text[] = {"No sound                 ",
					  "Emulated, no sound output",
					  NULL};

ULO fgui_sound_soundemunosound_vals[] = {0, 3};

STR *fgui_sound_rate_text[] = {"15650",
			       "22050",
			       "31300",
			       "44100",
			       NULL};

STR *fgui_sound_channels_text[] = {"Mono  ",
				   "Stereo",
				   NULL};

STR *fgui_sound_bits_text[] = {"8 bits ",
			       "16 bits",
			       NULL};

STR *fgui_sound_filter_text[] = {"Original",
				 "Always  ",
				 "Never   ",
				 NULL};

STR *fgui_sound_depth_text[] = {"20 ","40 ","60 ","80 ","100","120","140",
				"160","180", NULL};

STR *fgui_sound_wav_text[] = {"Disabled",
			      "Enabled ",
			      NULL};

ULO fgui_sound_rate_vals[] = {SOUND_15650, SOUND_22050,
			      SOUND_31300, SOUND_44100};
ULO fgui_sound_channels_vals[] = {SOUND_MONO, SOUND_STEREO};
ULO fgui_sound_bits_vals[] = {SOUND_8BITS, SOUND_16BITS};
ULO fgui_sound_filter_vals[] = {0, 1, 2};
ULO fgui_sound_depth_vals[] = { 1, 2,  3,  4,  5,  6,  7, 8, 9};
ULO fgui_sound_wav_vals[] = {FALSE, TRUE};

STR **fgui_sound_texts[] = {fgui_sound_soundemu_text,
			    fgui_sound_rate_text,
			    fgui_sound_channels_text,
			    fgui_sound_bits_text,
			    fgui_sound_filter_text,
			    fgui_sound_depth_text,
			    fgui_sound_wav_text,
			    NULL};

void *fgui_sound_vals[] = {fgui_sound_soundemu_vals,
			   fgui_sound_rate_vals,
			   fgui_sound_channels_vals,
			   fgui_sound_bits_vals,
			   fgui_sound_filter_vals,
			   fgui_sound_depth_vals,
			   fgui_sound_wav_vals,
			   NULL};

STR **fgui_sound_texts_nosound[] = {fgui_sound_soundemunosound_text,
				    fgui_sound_filter_text,
				    fgui_sound_wav_text,
				    NULL};
void *fgui_sound_vals_nosound[] = {fgui_sound_soundemunosound_vals,
				   fgui_sound_filter_vals,
				   fgui_sound_wav_vals,
				   NULL};

void fguiOptionmenuSoundInit(void) {
  if (sound_device_found) {
    guiOptionmenuInit(&fgui_sound_optionmenu, fgui_sound_topheader,
		       fgui_sound_headers, fgui_sound_actions,
		       fgui_sound_vars, fgui_sound_texts, fgui_sound_vals,
		       &fgui_wconsole, fgui_sound_shortcuts);
  }
  else {
    guiOptionmenuInit(&fgui_sound_optionmenu, fgui_sound_topheader_nosound,
		       fgui_sound_headers_nosound, fgui_sound_actions_nosound,
		       fgui_sound_vars_nosound, fgui_sound_texts_nosound,
		       fgui_sound_vals_nosound, &fgui_wconsole,
		       fgui_sound_shortcuts);
  }
}


/*=====================*/
/* Cpu option-menu     */
/*=====================*/

struct gui_optionmenu fgui_cpu_optionmenu;

STR *fgui_cpu_topheader = {"CPU and Blitter configuration:"};

STR *fgui_cpu_headers[] = {"Virtual CPU instruction-set:",
			   "Virtual CPU speed:",
			   "Virtual Blitter speed:",
			   "Long blits:",
			   NULL};

UBY fgui_cpu_shortcuts[4] = {8, 12, 8, 0};

UBY fgui_cpu_actions[4] = {GUI_VALUELIST, GUI_VALUELIST,
                           GUI_VALUELIST, GUI_VALUELIST};

const void *fgui_cpu_vars[4] = {&config_cpu_type,
                                &config_cpu_speed,
                                &blit_fast,
                                &blit_long};

/* Option texts for cpu menu */

STR *fgui_cpu_type_text[] = {"M68000",
			     "M68010",
			     "M68020",
			     "M68030",
			     NULL};

STR *fgui_cpu_speed_text[] = {"3.5 MHZ M68000",
			      "7 MHZ M68000  ",
			      "14 MHZ M68000 ",
			      "28 MHZ M68000 ",
			      NULL};

STR *fgui_cpu_bltspeed_text[] = {"Normal OCS speed",
				 "Finish instantly",
				 NULL};

STR *fgui_cpu_bltlong_text[] = {"Disabled (OCS Blitter)",
				"Enabled (ECS Blitter) ",
				NULL};

/* Option values for cpu menu */

ULO fgui_cpu_type_vals[] = {0, 1, 2, 3};

ULO fgui_cpu_speed_vals[] = {0, 1, 2, 3};

ULO fgui_cpu_bltspeed_vals[] = {FALSE, TRUE};
ULO fgui_cpu_bltlong_vals[] = {FALSE, TRUE};

STR **fgui_cpu_texts[] = {fgui_cpu_type_text,
			  fgui_cpu_speed_text,
			  fgui_cpu_bltspeed_text,
			  fgui_cpu_bltlong_text,
			  NULL};

void *fgui_cpu_vals[] = {fgui_cpu_type_vals,
			 fgui_cpu_speed_vals,
			 fgui_cpu_bltspeed_vals,
			 fgui_cpu_bltlong_vals,
			 NULL};

void fguiOptionmenuCPUInit(void) {
  guiOptionmenuInit(&fgui_cpu_optionmenu,
		     fgui_cpu_topheader,
		     fgui_cpu_headers,
		     fgui_cpu_actions,
		     fgui_cpu_vars,
		     fgui_cpu_texts,
		     fgui_cpu_vals,
		     &fgui_wconsole,
		     fgui_cpu_shortcuts);
}

/*=========================*/
/* Various option-menu     */
/*=========================*/

struct gui_optionmenu fgui_various_optionmenu;

char *fgui_various_topheader = {"Various configuration:"};


char *fgui_various_headers[8] = {"Joystick Port 1:","Joystick Port 2:",
                                 "Power,Floppy LEDs:","Keyboard LED order:",
                                 "Performance displayed on-screen:",
                                 "Menu position saving on exit:",
                                 "Automatic Run after commands:",NULL};

UBY fgui_various_shortcuts[7] = {14,14,0,0,1,0,0};

UBY fgui_various_actions[7] = {GUI_VALUELIST,GUI_VALUELIST,GUI_VALUELIST,
                               GUI_VALUELIST,GUI_VALUELIST,GUI_VALUELIST,
                               GUI_VALUELIST};
 
const void *fgui_various_vars[7] = {&config_joy[0],
                                    &config_joy[1],
                                    &config_enableleds,
                                    &kbdleds,
                                    &config_printspeed,
                                    &config_store_mpos,
                                    &config_autorun};

/* Option texts for various menu */

char *fgui_various_joya_text[6];
char *fgui_various_joyb_text[6];
char *fgui_various_joy_text_tmp[6] = {"Disabled                             ",
                                      "Joystick replacement, arrowkeys/RCTRL",
                                      "Joystick replacement, rdfg/LCTRL     ",
                                      "Analog Joystick                      ",
                                      NULL,
                                      "Mouse                                "};

/* Led meter values must be filled in runtime */

char *fgui_various_led_text[12] = {"Disabled                          ",
                                   "On screen                         ",
                                   "Keyboard (DF0, DF1, DF2)          ",
                                   "Keyboard (Power, DF0, DF1)        ",
                                   "Keyboard (Power, DF0+DF1, DF2+DF3)",
                                   "Led Meter on LPT1                 ",
                                   "Led Meter on LPT1 (mirrored)      ",
                                   "Led Meter on LPT2                 ",
                                   "Led Meter on LPT2 (mirrored)      ",
                                   "Led Meter on LPT3                 ",
                                   "Led Meter on LPT3 (mirrored)      ",
                                   NULL};
 char *fgui_various_order_text[7] = {"Num / Caps / Scroll",
                                    "Num / Scroll / Caps",
                                    "Caps / Num / Scroll",
                                    "Caps / Scroll / Num",
                                    "Scroll / Caps / Num",
                                    "Scroll / Num / Caps",NULL};

char *fgui_various_speed_text[3] = {"No ","Yes",NULL};
char *fgui_various_mpos_text[3] = {"No ","Yes",NULL};

char *fgui_various_arun_text[5] = {"None         ","Alt-N        ",
                                   "Reset        ","Alt-N & Reset",NULL};

/* Option values for various menu */

ULO fgui_various_joya_vals[5];
ULO fgui_various_joyb_vals[5];
ULO fgui_various_led_vals[11] = {0,1,0x81,0x82,0x83,0x41,0x51,0x42,0x52,0x43,0x53};
ULO fgui_various_order_vals[6] = {0,1,2,3,4,5};
ULO fgui_various_speed_vals[2] = {0,1};
ULO fgui_various_mpos_vals[2] = {0,1};
ULO fgui_various_arun_vals[4] = {0,1,2,3};

char **fgui_various_texts[8] = {fgui_various_joya_text,fgui_various_joyb_text,
                                fgui_various_led_text,fgui_various_order_text,
                                fgui_various_speed_text,fgui_various_mpos_text,
                                fgui_various_arun_text,NULL};
void *fgui_various_vals[8] = {fgui_various_joya_vals,fgui_various_joyb_vals,
                              fgui_various_led_vals,fgui_various_order_vals,
                              fgui_various_speed_vals,fgui_various_mpos_vals,
                              fgui_various_arun_vals,NULL};

void fguiOptionmenuVariousInit(void) {
  ULO i, j;
  UWO *lptcfg;

  j = 0;
  for (i = 0; i < 6; i++) {
    if ((i < 3) || (i == 3 && config_analogjoystickfound) || (i != 4)) {
      fgui_various_joya_text[j] = fgui_various_joy_text_tmp[i];
      fgui_various_joya_vals[j] = i;
      fgui_various_joyb_text[j] = fgui_various_joy_text_tmp[i];
      fgui_various_joyb_vals[j] = i;
      j++;
    }
  }
  fgui_various_joya_text[j] = NULL;
  fgui_various_joyb_text[j] = NULL;
  lptcfg = (UWO *) 0x410;
  fgui_various_led_text[5 + ((lptcfg[0] >> 14) * 2)] = NULL;
  guiOptionmenuInit(&fgui_various_optionmenu, fgui_various_topheader,
		    fgui_various_headers, fgui_various_actions,
		    fgui_various_vars, fgui_various_texts,
		    fgui_various_vals, &fgui_wconsole, fgui_various_shortcuts);
}

/*=====================*/
/* hfile option-menu   */
/*=====================*/

struct gui_optionmenu fgui_hfile_optionmenu;

char *fgui_hfile_topheader = {"Hardfile configuration (Changes cause reset):"};

char *fgui_hfile_headers[FHFILE_MAX_DEVICES + 2] = {"fhfile.device state:"};

UBY fgui_hfile_shortcuts[FHFILE_MAX_DEVICES + 1] = {0};

UBY fgui_hfile_actions[FHFILE_MAX_DEVICES + 1] = {GUI_VALUELIST};

void *fgui_hfile_vars[FHFILE_MAX_DEVICES + 1] = {&config_fhfile_enabled};

/* Option texts for hfile menu */

char *fgui_hfile_enabled_text[3] = {"Disabled","Enabled ",NULL};

/* Option values for hfile menu */

ULO fgui_hfile_enabled_vals[2] = {0,1};

char **fgui_hfile_texts[3] = {fgui_hfile_enabled_text,NULL,NULL};

void *fgui_hfile_vals[3] = {fgui_hfile_enabled_vals, NULL,NULL};

void fguiOptionmenuHFileInit(void) {
  int i;
  char *temps;
  
  for (i = 0; i < FHFILE_MAX_DEVICES; i++) {
    temps = (char *) malloc(20);
    sprintf(temps, "FELLOW%d hardfile:", i);
    fgui_hfile_headers[i + 1] = temps;   
    fgui_hfile_shortcuts[i + 1] = 6;
    fgui_hfile_actions[i + 1] = GUI_FILEREQ_HDF;
    fgui_hfile_vars[i + 1] = config_fhfile_name[i];
  }
  fgui_hfile_headers[FHFILE_MAX_DEVICES + 1] = NULL;
  
  guiOptionmenuInit(&fgui_hfile_optionmenu, fgui_hfile_topheader,
		    fgui_hfile_headers, fgui_hfile_actions, fgui_hfile_vars,
		    fgui_hfile_texts, fgui_hfile_vals, &fgui_wconsole,
		    fgui_hfile_shortcuts);
}


/*==================================*/
/* Event logging configuration menu */
/*==================================*/

#ifdef DEBUGBUILD

struct gui_optionmenu fgui_evlog_optionmenu;

char *fgui_evlog_topheader = NULL;

char *fgui_evlog_headers[] = {"Serial TBE irq (Level 1):",
                              "Disk DMA done irq (Level 1):",
                              "Software irq (Level 1):",
                              "Cia A irq (Level 2):",
                              "Copper irq (Level 3):",
                              "Vertical Blank irq (Level 3):",
                              "Blitter irq (Level 3):",
                              "Audio irq (Level 4):",
                              "Serial RBF irq (Level 5):",
                              "Disk Sync found irq (Level 5):",
                              "Cia B irq (Level 6):",
                              "Bus error exception:",
                              "Odd address exception:",
                              "Illegal instruction exception:",
                              "Division by zero exception:",
                              "Privilegie violation exception:",
                              "Trap exception:",
                              "STOP instruction:",
			      "F-Line",
                              NULL};

UBY fgui_evlog_shortcuts[] = {0,0,1,8,2,0,0,0,1,1,7,1,13,1,7,23,0,16,0};

UBY fgui_evlog_actions[] = {GUI_VALUELIST,GUI_VALUELIST,GUI_VALUELIST,
                            GUI_VALUELIST,GUI_VALUELIST,GUI_VALUELIST,
                            GUI_VALUELIST,GUI_VALUELIST,GUI_VALUELIST,
                            GUI_VALUELIST,GUI_VALUELIST,GUI_VALUELIST,
                            GUI_VALUELIST,GUI_VALUELIST,GUI_VALUELIST,
                            GUI_VALUELIST,GUI_VALUELIST,GUI_VALUELIST,
                            GUI_VALUELIST};
                            
const void *fgui_evlog_vars[] = {&logserialtransmitbufferemptyirq,
                                 &logdiskdmatransferdoneirq,
                                 &logsoftwareirq,
                                 &logciaairq,
                                 &logcopperirq,
                                 &logverticalblankirq,
                                 &logblitterreadyirq,
                                 &logaudioirq,
                                 &logserialreceivebufferfullirq,
                                 &logdisksyncvaluerecognizedirq,
                                 &logciabirq,
                                 &logbuserrorex,
                                 &logoddaddressex,
                                 &logillegalinstructionex,
                                 &logdivisionby0ex,
                                 &logprivilegieviolationex,
                                 &logtrapex,
                                 &logstop,
                                 &logfline};

/* Option texts for evlog menu */

char *fgui_evlog_all_text[3] = {"Logged    ","Not Logged",NULL};

/* Option values for evlog menu */

ULO fgui_evlog_all_vals[2] = {TRUE,FALSE};

char **fgui_evlog_texts[] = {fgui_evlog_all_text,
                             fgui_evlog_all_text,
                             fgui_evlog_all_text,
                             fgui_evlog_all_text,
                             fgui_evlog_all_text,
                             fgui_evlog_all_text,
                             fgui_evlog_all_text,
                             fgui_evlog_all_text,
                             fgui_evlog_all_text,
                             fgui_evlog_all_text,
                             fgui_evlog_all_text,
                             fgui_evlog_all_text,
                             fgui_evlog_all_text,
                             fgui_evlog_all_text,
                             fgui_evlog_all_text,
                             fgui_evlog_all_text,
                             fgui_evlog_all_text,
                             fgui_evlog_all_text,
                             fgui_evlog_all_text,
                             NULL};

void *fgui_evlog_vals[] = {fgui_evlog_all_vals,
                           fgui_evlog_all_vals,
                           fgui_evlog_all_vals,
                           fgui_evlog_all_vals,
                           fgui_evlog_all_vals,
                           fgui_evlog_all_vals,
                           fgui_evlog_all_vals,
                           fgui_evlog_all_vals,
                           fgui_evlog_all_vals,
                           fgui_evlog_all_vals,
                           fgui_evlog_all_vals,
                           fgui_evlog_all_vals,
                           fgui_evlog_all_vals,
                           fgui_evlog_all_vals,
                           fgui_evlog_all_vals,
                           fgui_evlog_all_vals,
                           fgui_evlog_all_vals,
                           fgui_evlog_all_vals,
                           fgui_evlog_all_vals,
                           NULL};

void fguiOptionmenuEvlogInit(void) {
  guiOptionmenuInit(&fgui_evlog_optionmenu, fgui_evlog_topheader,
		    fgui_evlog_headers, fgui_evlog_actions, fgui_evlog_vars,
		    fgui_evlog_texts, fgui_evlog_vals, &fgui_wconsole,
		    fgui_evlog_shortcuts);
}

#endif

/*====================*/
/* The top level menu */
/*====================*/

struct gui_menu fgui_topmenu;

STR *fgui_topmenu_entries[] = {"Start",
                               "Configuration",
                               "Utilities",
                               "Hard Reset",
                               "Debugger",
                               "About",
                               "Quit",
                               NULL};
                               
UBY fgui_topmenu_shortcuts[] = {0, 0, 0, 5, 0, 0, 0};

void fguiTopMenuInit(void) {
  guiMenuInit(&fgui_topmenu,
               fgui_topmenu_entries,
               0,
               &fgui_wmenu,
               fgui_topmenu_shortcuts);
}

void fguiTopMenuRun(void) {
  BOOLE ended = FALSE;

  if (cmdnogui) {
    cmdnogui = FALSE;
    fguiFellowRun();
    if (cmdf12exit)
      return;
    else {
      guiScreenSetup();
      fguiWindowsInit();
      fguiTopMenuScreenPrintPlain(TRUE);
      fguiMenuInit();
      fguiOptionmenuInit();
      guiWindowClear(&fgui_wconsole, FALSE);
    }
  }

  while (!ended && !gui_exitflag) {
    fguiMenuWindowResize(&fgui_topmenu);
    fguiTopMenuScreenPrint(FALSE);
    switch (guiMenuSelect(&fgui_topmenu, TRUE)) {
      case 0: /* Run */
	if (config_memory_nokick)
          fguiRequester("", "You must select a Kickstart ROM image first", "");
	else {
	  fguiFellowRun();
	  if (cmdf12exit)
	    return;
	}
        break;
      case 1: /* Configuration */
        fguiConfigMenuRun();
        break;
      case 2: /* Utilities */
        fguiUtilMenuRun();
	break;
      case 3: /* Hard Reset  */
        fellow_hardreset();
        if (config_autorun & 2)
	  fguiFellowRun();
        break;
      case 4: /* Debugger */
	if (config_memory_nokick)
          fguiRequester("", "You must select a Kickstart ROM image first", "");
	else
	  fguiDebugMenuRun();
        break;
      case 5: /* About */
	fguiAbout();
	break;
      case 6: /* Quit */
	ended = TRUE;
	break;
      }
    }
  guiWindowClear(fgui_topmenu.w,FALSE);
}


/*==========================*/
/* Print plain screen setup */
/*==========================*/

void fguiTopMenuScreenPrintPlain(BOOLE clearflag) {
  if (clearflag)
    guiWindowClear(&fgui_wfullscreen, TRUE);
  guiWindowBorderPlot(&fgui_wfullscreen);
  guiWindowBorderPlot(&fgui_wheader);
  guiWindowBorderPlot(&fgui_wconsole);
  fguiVersionPrint();
}


/*=========================*/
/* Draw screen for TopMenu */
/*=========================*/

void fguiTopMenuScreenPrint(BOOLE clearflag) {
  ULO ycurrent;

  if (clearflag)
    guiWindowClear(&fgui_wfullscreen, TRUE);
  guiWindowBorderPlot(&fgui_wfullscreen);
  guiWindowBorderPlot(&fgui_wheader);
  guiWindowBorderPlot(&fgui_wconsole);
  guiWindowBorderPlot(&fgui_wmenu);
  fguiVersionPrint();
  ycurrent = fguiFloppyUnitsPrint(1);
  ycurrent = fguiFHFileUnitsPrint(ycurrent + 1);
  ycurrent = fguiUAEUnitsPrint(ycurrent + 1);
  fguiKickstartInfoPrint(18);
}

/*========================*/
/* Configuration sub-menu */
/*========================*/

struct gui_menu fgui_configmenu;

STR *fgui_configmenu_entries[] = {"Disk-images",
                                  "Filesystems",
                                  "Screen",
                                  "Memory",
                                  "Sound",
                                  "CPU & Blitter",
                                  "Hardfile",
                                  "Various",
                                  NULL};

UBY fgui_configmenu_shortcuts[8] = {0, 0, 0, 0, 1, 0, 0, 0};

void fguiConfigMenuInit(void) {
  guiMenuInit(&fgui_configmenu,
               fgui_configmenu_entries,
               0,
               &fgui_wmenu,
               fgui_configmenu_shortcuts);
}

void fguiConfigMenuRun(void) {
  ULO i;
  BOOLE ended = FALSE;
  static char disknames[4][256];  /* Remember old disk-image names */
  static char romname[2][256];       /* Remember old Kickstart name */
  static char hdnames[FHFILE_MAX_DEVICES][256];/* Remember old HDF names */
  ULO chips, bogos, fasts;                     /* Remember old memory sizes */
  ULO vmode;                                   /* Remember old videomode */
  ULO hardfileenabled;                         /* Remember HDF enabled state */
  BOOLE doreset = FALSE;
  ULO cputype = config_cpu_type;
  ULO scaley = config_graphics_scaley;
  BOOLE oldmemspacesize = config_memory_space_32bit;
  
  for (i = 0; i < 4; i++) 
    strcpy(disknames[i], floppy[i].imagename);
  for (i = 0; i < FHFILE_MAX_DEVICES; i++) 
    strcpy(hdnames[i], config_fhfile_name[i]);
  strcpy(romname, config_memory_kickname);
  hardfileenabled = config_fhfile_enabled;
  chips = config_memory_chipsize;
  bogos = config_memory_bogosize;
  fasts = config_memory_fastsize;
  vmode = config_graphics_mode;
  guiWindowClear(fgui_configmenu.w, FALSE);
  while (!ended && !gui_exitflag) {
    fguiMenuWindowResize(&fgui_configmenu);
    fguiTopMenuScreenPrint(FALSE);
    i = guiMenuSelect(&fgui_configmenu, FALSE);
    switch (i) {
      case 0: /* Disk-images */
	guiOptionmenuRun(&fgui_floppy_optionmenu);
	break;
      case 1: /* Filesystems */
        fguiFilesystemMenuRun();
	guiWindowClear(&fgui_wconsole, FALSE);
        break;
      case 2: /* Screen */
	guiOptionmenuRun(&fgui_screen_optionmenu);
	break;
      case 3: /* Memory */
	guiOptionmenuRun(&fgui_memory_optionmenu);
	break;
      case 4: /* Sound  */
	guiOptionmenuRun(&fgui_sound_optionmenu);
	break;
      case 5: /* Cpu  */
	guiOptionmenuRun(&fgui_cpu_optionmenu);
	break;
      case 6: /* Hardfile */
	guiOptionmenuRun(&fgui_hfile_optionmenu);
	break;
      case 7: /* Various */
	guiOptionmenuRun(&fgui_various_optionmenu);
	break;
      case GUI_MENU_LEVEL_UP: /* ESC */
	ended = TRUE;
	break;
    }
  }
  
  save_fellow_cfg();

  if (config_enableleds & 0x40) {
    UWO *lptcfg = (UWO *) 0x406;
    ledlpt = lptcfg[config_enableleds & 3]; /* get LPT port from BIOS area */
  };

  /* Insert changed diskimages */

  ended = FALSE;
  for (i = 0; i < 4; i++) {
    if (strcmp(disknames[i], floppy[i].imagename) != 0) {
      if (!ended) {
        guiWindowClear(&fgui_wconsole, TRUE);
        guiWindowBorderPlot(&fgui_wconsole);
	ended = TRUE;
      }
      fguiDiskNamePrint(floppy[i].imagename, i);
      floppyImageInsert(floppy[i].imagename, i);
    }
  }

  /* If the hardfile config was changed, demand reset */

  for (i = 0; i < FHFILE_MAX_DEVICES; i++) 
    if (strcmp(hdnames[i], config_fhfile_name[i]) != 0)
      doreset = TRUE;
      
  /* If videomode was changed, or scale, flag recalculation of screen parm */

  if (vmode != config_graphics_mode || scaley != config_graphics_scaley)
    gmodefirsttime[config_graphics_mode] = TRUE;

  /* If kickstart was changed, demand reset */

  if ((strcmp(romname, config_memory_kickname) != 0))
    doreset = TRUE;

  /* If memory sizes changed, demand reset */

  if (config_memory_chipsize != chips ||
      config_memory_bogosize != bogos ||
      config_memory_fastsize != fasts)
    doreset = TRUE;
  
  /* If memory space size changed, demand reset */

  if (oldmemspacesize != config_memory_space_32bit)
    doreset = TRUE;

  /* Reinitialize sound */

  soundModeInit();

  /* If cpu-type changed, demand reset */

  if (cputype != config_cpu_type) {
    cpuinit();
    doreset = TRUE;
  }

  /* Reset if requested */

  if (doreset)
    fellow_hardreset();

  guiWindowClear(&fgui_wconsole, FALSE);
}


/*==================*/
/* Debugger support */
/*==================*/


/*==========================================================*/
/* Prints a list of instructions starting at the current PC */
/*==========================================================*/

void fguiDebugInstructionsPrint(void) {
  ULO y, mpc, opco;
  union { ULO lo; ULO (*fun)(); } yeah;
  STR s[80];
  
  mpc = get_pc(pc);
  for (y = 1; y <= (fgui_wconsole.y2 - fgui_wconsole.y1 - 1); y++) {
    opco = fetw(mpc);
    yeah.lo = cpu_dis_tab[opco];
    mpc = yeah.fun(mpc,opco,s);
    guiWindowTextPlot(&fgui_wconsole, s, 1, y);
  }
}


/*=====================================================================*/
/* Prints frame, beam position and prefetch word in upper right corner */
/*=====================================================================*/

void fguiDebugFrameposPrint(void) {
  STR s[30];

  sprintf(s, "Frame: %d", frames);
  guiWindowTextPlot(&fgui_wconsole, s, 65, 1);
  sprintf(s, "Xpos:  %d", xpos);
  guiWindowTextPlot(&fgui_wconsole, s, 65, 2);
  sprintf(s, "Ypos:  %d", ypos);
  guiWindowTextPlot(&fgui_wconsole, s, 65, 3);
#ifdef PREFETCH
  sprintf(s, "PFW:   %.4X", prefetch_word);
  guiWindowTextPlot(&fgui_wconsole, s, 65, 4);
#endif
}


/*================*/
/* Memory browser */
/*================*/

void fguiDebugMemoryBrowse(void) {
  STR st[80];
  ULO i, s, keyz, j, padd = 608, k;
  BOOLE ended = FALSE, ascii = FALSE;

  s = 0;
  guiWindowClear(&fgui_wconsole, TRUE);
  guiWindowBorderPlot(&fgui_wconsole);  
  while (!ended & !gui_exitflag) {    
    for (i = 0; i < 19; i++) 
      if (ascii) {
	sprintf(st, "%.6X %.8X%.8X %.8X%.8X ", (s + i*16) & 0xffffff,
		fetl(s + i*16 + 0),
		fetl(s + i*16 + 4),
		fetl(s + i*16 + 8),
		fetl(s + i*16 + 12));
	guiWindowTextPlot(&fgui_wconsole, st, 2, i + 1);
	for (j = 0; j < 16; j++) {
          k = fetb(s + i*16 + j) & 0xff;
          if (k < 32)
            st[j] = '.';
          else
            st[j] = k;
	}
	st[16] = '\0';
	guiWindowTextPlot(&fgui_wconsole, st, 44, i + 1);
      }
      else {
	sprintf(st, "%.6X %.8X%.8X %.8X%.8X %.8X%.8X %.8X%.8X",
                (s + i*32) & 0xffffff, fetl(s + i*32), fetl(s + i*32 + 4),
                fetl(s + i*32 + 8), fetl(s + i*32 + 12), fetl(s + i*32 + 16),
                fetl(s + i*32 + 20), fetl(s + i*32 + 24), fetl(s + i*32 + 28));
	guiWindowTextPlot(&fgui_wconsole, st, 2, i + 1);
      }
    
    keyz = getch();
    if (keyz == 27)
      ended = TRUE;
    else if (keyz == 'a') {
      padd = 304;
      ascii = TRUE;
      guiWindowClear(&fgui_wconsole, FALSE);
    }
    else if (keyz == 'h') {
      padd = 608;
      ascii = FALSE;
      guiWindowClear(&fgui_wconsole, FALSE);
    }
    else if (keyz == 0) {
      keyz = getch();
      if (keyz == 71) {
        s = (s - 0x10000) & 0xffffff;
      }
      else if (keyz == 79) {
        s = (s + 0x10000) & 0xffffff;
      }
      else if (keyz == 72) {
        s = (s - 32) & 0xffffff;
      }
      else if (keyz == 80) {
        s = (s + 32) & 0xffffff;
      }
      else if (keyz == 73) {  /* PGUP */
        s = (s - padd) & 0xffffff;
      }
      else if (keyz == 81) { /* PGDOWN */
        s = (s + padd) & 0xffffff;
      }
    }
  }
}


/*==================================*/
/* Print the state of the CIA chips */
/*==================================*/

void fguiDebugCIAStatePrint(void) {
  STR s[80];
  ULO y = 1, i;

  guiWindowClear(&fgui_wconsole, TRUE);
  guiWindowBorderPlot(&fgui_wconsole);
  intena &= 0xffdf;
  intenar &= 0xffdf;
  
  for (i = 0; i < 2; i++) {
    sprintf(s, "Cia %s Registers:", (i == 0) ? "A" : "B");
    guiWindowTextPlot(&fgui_wconsole, s, 1, y++);
    sprintf(s, "CRA-%.2X CRB-%.2X IREQ-%.2X IMSK-%.2X SP-%.2X", cia_cra[i],
            cia_crb[i], cia_icrreq[i], cia_icrmsk[i], cia_sp[i]);
    guiWindowTextPlot(&fgui_wconsole, s, 1, y++);
    sprintf(s, "EV-%.8X ALARM-%.8X", cia_ev[i], cia_evalarm[i]);
    guiWindowTextPlot(&fgui_wconsole, s, 1, y++);
    sprintf(s, "TA-%.4X TAHELP-%.8X TB-%.4X TBHELP-%.8X", cia_ta[i],
            cia_taleft[i], cia_tb[i], cia_tbleft[i]);
    guiWindowTextPlot(&fgui_wconsole, s, 1, y++);
    sprintf(s, "TALATCH-%.4X TBLATCH-%.4X", cia_talatch[i], cia_tblatch[i]);
    guiWindowTextPlot(&fgui_wconsole, s, 1, y++);
    if (cia_cra[i] & 1)
      guiWindowTextPlot(&fgui_wconsole, "Timer A started", 1, y);
    else 
      guiWindowTextPlot(&fgui_wconsole, "Timer A stopped", 1, y);
    if (cia_cra[i] & 8)
      guiWindowTextPlot(&fgui_wconsole, "One-shot mode", 25, y++);
    else 
      guiWindowTextPlot(&fgui_wconsole, "Continuous", 25, y++);
    if (cia_crb[i] & 1)
      guiWindowTextPlot(&fgui_wconsole, "Timer B started", 1, y);
    else 
      guiWindowTextPlot(&fgui_wconsole, "Timer B stopped", 1 ,y);
    if (cia_crb[i] & 8)
      guiWindowTextPlot(&fgui_wconsole, "One-shot mode", 25, y++);
    else 
      guiWindowTextPlot(&fgui_wconsole, "Continuous", 25, y++);
    y++;
    }
  getch();
}


/*========================================*/
/* Print the state of the sound emulation */
/*========================================*/

void fguiDebugSoundStatePrint(void) {
  STR s[80];
  ULO y = 1, i;

  guiWindowClear(&fgui_wconsole, TRUE);
  guiWindowBorderPlot(&fgui_wconsole);

#ifdef ALIGN_CHECK
  sprintf(s, "A0: %X A1: %X A2: %X A3: %X A5: %X", audiostate0, audiostate1, audiostate2, audiostate3, audiostate5);
  guiWindowTextPlot(&fgui_wconsole, s, 1, y++);
#endif
  for (i = 0; i < 4; i++) {
    sprintf(s, "Ch%i State: %d Lenw: %d Len: %d per: %d Pcnt: %X Vol: %d", i,
            (audstate[i] == audiostate0) ? 0 :
            (audstate[i] == audiostate1) ? 1 :
            (audstate[i] == audiostate2) ? 2 :
            (audstate[i] == audiostate3) ? 3 :
            (audstate[i] == audiostate5) ? 5 : -1, audlenw[i], audlen[i],
	    audper[i], audpercounter[i], audvol[i]);
    guiWindowTextPlot(&fgui_wconsole, s, 1, y++);
  }
  sprintf(s, "dmacon: %X", dmacon);
  guiWindowTextPlot(&fgui_wconsole, s, 1, y++);
  getch();
}


/*=========================================*/
/* Print the state of the floppy emulation */
/*=========================================*/

void fguiDebugFloppyStatePrint(void) {
  STR s[80];
  ULO y = 1, i;

  guiWindowClear(&fgui_wconsole, TRUE);
  guiWindowBorderPlot(&fgui_wconsole);
  
  for (i = 0; i < 4; i++) {
    sprintf(s, "DF%d:", i);
    guiWindowTextPlot(&fgui_wconsole, s, 1, y++);
    sprintf(s, "Track-%d Sel-%d Motor-%d Side-%d WP-%d Cached-%s", floppy[i].track, floppy[i].sel, floppy[i].motor, floppy[i].side,  floppy[i].writeprot, floppy[i].cached ? "No " : "Yes");
    guiWindowTextPlot(&fgui_wconsole, s, 1, y++);
    y++;
  }  
  sprintf(s, "Dskpt-%.6X dsklen-%.4X dsksync-%.4X", dskpt, dsklen, dsksync);
  guiWindowTextPlot(&fgui_wconsole, s, 1, y++);
  if (floppy_DMA_started)
    guiWindowTextPlot(&fgui_wconsole, "Disk DMA running", 1, y++);
  else
    guiWindowTextPlot(&fgui_wconsole, "Disk DMA stopped", 1, y++);

  guiWindowTextPlot(&fgui_wconsole, "Transfer settings:", 1, y++);
  sprintf(s, "Drive: %d  Wordsleft: %d  Wait: %d  Dst: %X", floppy_DMA.drive,
	  floppy_DMA.wordsleft, floppy_DMA.wait, floppy_DMA.dst);
  guiWindowTextPlot(&fgui_wconsole, s, 1, y++);
  
  
#ifdef ALIGN_CHECK
  sprintf(s, "Busloop: %X  eol: %X copemu: %X", checkadr, end_of_line, copemu);
  guiWindowTextPlot(&fgui_wconsole, s, 1, 1 + y++);
  sprintf(s, "68000strt:%X busstrt:%X copperstrt:%X memorystrt:%X", m68000start, busstart, copperstart, memorystart);
  guiWindowTextPlot(&fgui_wconsole, s, 1, 1 + y++);
  sprintf(s, "sndstrt:%X sbstrt:%X blitstrt:%X", soundstart, sblaststart, blitstart);
  guiWindowTextPlot(&fgui_wconsole, s, 1, 1 + y++);
  sprintf(s, "drawstrt:%X graphemstrt:%X",drawstart,graphemstart);
  guiWindowTextPlot(&fgui_wconsole, s, 1, 1 + y++);
#endif
  getch();
}


/*===============================*/
/* Print the state of the copper */
/*===============================*/

void fguiDebugCopperStatePrint(void) {
  STR s[80];
  ULO y = 1, i, list1 = (cop1lc & 0xfffffe), list2 = (cop2lc & 0xfffffe),
      atpc = (curcopptr & 0xfffffe); /* Make sure debug doesn't trap odd ex */

  guiWindowClear(&fgui_wconsole, TRUE);
  guiWindowBorderPlot(&fgui_wconsole);
  sprintf(s, "Cop1lc-%.6X Cop2lc-%.6X Copcon-%d Copper PC - %.6X", cop1lc, cop2lc, copcon, curcopptr);
  guiWindowTextPlot(&fgui_wconsole, s, 1, y++);
  sprintf(s, "Next cycle - %d  Y - %d  X - %d", nxtcopaccess, (nxtcopaccess != -1) ? (nxtcopaccess/228) : 0, (nxtcopaccess != -1) ? (nxtcopaccess % 228) : 0);
  guiWindowTextPlot(&fgui_wconsole, s, 1, y++);
  guiWindowTextPlot(&fgui_wconsole,"List 1:        List 2:        At PC:",1,y++);
  for (i = 0; i < 16; i++) {
    sprintf(s, "$%.4X, $%.4X   $%.4X, $%.4X   $%.4X, $%.4X", fetw(list1), fetw(list1 + 2), fetw(list2), fetw(list2 + 2), fetw(atpc), fetw(atpc + 2));
    guiWindowTextPlot(&fgui_wconsole, s, 1, y++);
    list1 += 4;
    list2 += 4;
    atpc += 4;
    }
  getch();
}


/*================================*/
/* Print the state of the sprites */
/*================================*/

void fguiDebugSpritesStatePrint(void) {
  STR s[80];
  ULO y = 1, i;

  guiWindowClear(&fgui_wconsole, TRUE);
  guiWindowBorderPlot(&fgui_wconsole);
  sprintf(s, "Spr0pt-%.6X Spr1pt-%.6X Spr2pt-%.6X Spr3pt - %.6X", sprpt[0], sprpt[1], sprpt[2], sprpt[3]);
  guiWindowTextPlot(&fgui_wconsole, s, 1, y++);
  sprintf(s, "Spr4pt-%.6X Spr5pt-%.6X Spr6pt-%.6X Spr7pt - %.6X", sprpt[4], sprpt[5], sprpt[6], sprpt[7]);
  guiWindowTextPlot(&fgui_wconsole, s, 1, y++);
  sprintf(s, "SpriteDDFkill-%X", spriteddfkill);
  guiWindowTextPlot(&fgui_wconsole, s, 1, y++);
  for (i = 0; i < 8; i++) {
    sprintf(s, "Spr%dX-%d Spr%dStartY-%d Spr%dStopY-%d Spr%dAttached-%d Spr%dstate-%d", i, sprx[i], i, spry[i], i, sprly[i], i, spratt[i], i, spritestate[i]);
    guiWindowTextPlot(&fgui_wconsole, s, 1, y++);
    }
  getch();
}


/*===============================*/
/* Print the state of the screen */
/*===============================*/

void fguiDebugScreenStatePrint(void) {
  STR s[80];
  ULO y = 1;

  guiWindowClear(&fgui_wconsole, TRUE);
  guiWindowBorderPlot(&fgui_wconsole);
  sprintf(s,
          "clipleftx-%.3d   cliprightx-%.3d         cliptop-%.3d           clipbot-%d",
          clipleftx,
          cliprightx,
          cliptop,
          clipbot);
  guiWindowTextPlot(&fgui_wconsole, s, 1, y++);
  sprintf(s,
          "DDFStartpos-%.3d DIWfirstvisiblepos-%.3d DIWlastvisiblepos-%.3d",
          DDFstartpos, DIWfirstvisiblepos, DIWlastvisiblepos);
  guiWindowTextPlot(&fgui_wconsole, s, 1, y++);
  sprintf(s,
          "diwxleft-%.3d    diwxright-%.3d          diwytop-%.3d           diwybot-%.3d",
          diwxleft, diwxright, diwytop, diwybottom);
  guiWindowTextPlot(&fgui_wconsole, s, 1, y++);
  sprintf(s,
          "ddfstrt-%.3d     ddfstop-%.3d",
          ddfstrt, ddfstop);
  guiWindowTextPlot(&fgui_wconsole, s, 1, y++);
  sprintf(s,
          "oddscroll-%.3d   oddhiscroll-%.3d        evenscroll-%.3d        evenhiscroll-%.3d",
          oddscroll, oddhiscroll, evenscroll, evenhiscroll);
  guiWindowTextPlot(&fgui_wconsole,s, 1, y++);
  sprintf(s,
          "intena-%.4X     intreq-%.4X",
          intena, intreq);
  guiWindowTextPlot(&fgui_wconsole, s, 1, y++);
  getch();
}


/*===============================================*/
/* Print the event queue and the state of events */
/*===============================================*/

void fguiDebugEventsPrint(void) {
  STR s[80];
  ULO y = 1;

  guiWindowClear(&fgui_wconsole, TRUE);
  guiWindowBorderPlot(&fgui_wconsole);
  sprintf(s, "Next Cpu      - %d", cpu_next);
  guiWindowTextPlot(&fgui_wconsole, s, 1, y++);
  sprintf(s, "Next Copper   - %d", nxtcopaccess);
  guiWindowTextPlot(&fgui_wconsole, s, 1, y++);
  sprintf(s, "Next EOL      - %d", eol_next);
  guiWindowTextPlot(&fgui_wconsole, s, 1, y++);
  sprintf(s, "Next Blitter  - %d", blitend);
  guiWindowTextPlot(&fgui_wconsole, s, 1, y++);
  sprintf(s, "Next IRQ      - %d", irq_next);
  guiWindowTextPlot(&fgui_wconsole, s, 1, y++);
  sprintf(s, "Next EOF      - %d", eof_next);
  guiWindowTextPlot(&fgui_wconsole, s, 1, y++);
  sprintf(s, "Lvl2 - %d", lvl2_next);
  guiWindowTextPlot(&fgui_wconsole, s, 1, y++);
  sprintf(s, "Lvl3 - %d", lvl3_next);
  guiWindowTextPlot(&fgui_wconsole, s, 1, y++);
  sprintf(s, "Lvl4 - %d", lvl4_next);
  guiWindowTextPlot(&fgui_wconsole, s, 1, y++);
  sprintf(s, "Lvl5 - %d", lvl5_next);
  guiWindowTextPlot(&fgui_wconsole, s, 1, y++);
  sprintf(s, "Lvl6 - %d", lvl6_next);
  guiWindowTextPlot(&fgui_wconsole, s, 1, y++);  
  getch();
}

#ifdef DEBUGBUILD

/*========================================
   Irq and Exception logging data-layout:
        
        0: eventid
        1: frame
        2: ypos
        3: xpos
        4: pc when irq happened
  ========================================*/


/*=======================================*/
/* Print one screenful of event log data */
/*=======================================*/

void fguiDebugEventLogPrint(ULO start, ULO stop) {
  ULO current, i, j;
  STR s[80];
  
  for (current = start; current < stop; current++) {
    switch(logbuffer[current % EVENTCOUNT][0]) {
      case IRQ1_0_TBE:
        sprintf(s, "F-%.8X Y-%.3X X-%.3X - Serial Transmit Buffer Empty Interrupt (PC=%.6X)", logbuffer[current % EVENTCOUNT][1], logbuffer[current % EVENTCOUNT][2], logbuffer[current % EVENTCOUNT][3], logbuffer[current % EVENTCOUNT][4]);
	break;
      case IRQ1_1_DSKBLK:
        sprintf(s, "F-%.8X Y-%.3X X-%.3X - Disk DMA Transfer Done Interrupt (PC=%.6X)", logbuffer[current % EVENTCOUNT][1], logbuffer[current % EVENTCOUNT][2], logbuffer[current % EVENTCOUNT][3], logbuffer[current % EVENTCOUNT][4]);
	break;
      case IRQ1_2_SOFT:
        sprintf(s, "F-%.8X Y-%.3X X-%.3X - Software Interrupt (PC=%.6X)", logbuffer[current % EVENTCOUNT][1], logbuffer[current % EVENTCOUNT][2], logbuffer[current % EVENTCOUNT][3], logbuffer[current % EVENTCOUNT][4]);
	break;
      case IRQ2_CIAA:
        sprintf(s, "F-%.8X Y-%.3X X-%.3X - Cia A Interrupt (PC=%.6X)", logbuffer[current % EVENTCOUNT][1], logbuffer[current % EVENTCOUNT][2], logbuffer[current % EVENTCOUNT][3], logbuffer[current % EVENTCOUNT][4]);
	break;
      case IRQ3_0_COPPER:
        sprintf(s, "F-%.8X Y-%.3X X-%.3X - Copper Interrupt (PC=%.6X)", logbuffer[current % EVENTCOUNT][1], logbuffer[current % EVENTCOUNT][2], logbuffer[current % EVENTCOUNT][3], logbuffer[current % EVENTCOUNT][4]);
	break;
      case IRQ3_1_VBL:
        sprintf(s, "F-%.8X Y-%.3X X-%.3X - Vertical Blank Interrupt (PC=%.6X)", logbuffer[current % EVENTCOUNT][1], logbuffer[current % EVENTCOUNT][2], logbuffer[current % EVENTCOUNT][3], logbuffer[current % EVENTCOUNT][4]);
	break;
      case IRQ3_2_BLIT:
        sprintf(s, "F-%.8X Y-%.3X X-%.3X - Blitter Ready Interrupt (PC=%.6X)", logbuffer[current % EVENTCOUNT][1], logbuffer[current % EVENTCOUNT][2], logbuffer[current % EVENTCOUNT][3], logbuffer[current % EVENTCOUNT][4]);
	break;
      case IRQ4_AUD:
        sprintf(s, "F-%.8X Y-%.3X X-%.3X - Audio Channel 0 Interrupt (PC=%.6X)", logbuffer[current % EVENTCOUNT][1], logbuffer[current % EVENTCOUNT][2], logbuffer[current % EVENTCOUNT][3], logbuffer[current % EVENTCOUNT][4]);
	break;
      case IRQ5_0_RBF:
        sprintf(s, "F-%.8X Y-%.3X X-%.3X - Serial Receive Buffer Full Interrupt (PC=%.6X)", logbuffer[current % EVENTCOUNT][1], logbuffer[current % EVENTCOUNT][2], logbuffer[current % EVENTCOUNT][3], logbuffer[current % EVENTCOUNT][4]);
	break;
      case IRQ5_1_DSKSYN:
        sprintf(s, "F-%.8X Y-%.3X X-%.3X - Disk Sync Value Recognized Interrupt (PC=%.6X)", logbuffer[current % EVENTCOUNT][1], logbuffer[current % EVENTCOUNT][2], logbuffer[current % EVENTCOUNT][3], logbuffer[current % EVENTCOUNT][4]);
	break;
      case IRQ6_0_CIAB:
        sprintf(s, "F-%.8X Y-%.3X X-%.3X - Cia B Interrupt (PC=%.6X)", logbuffer[current % EVENTCOUNT][1], logbuffer[current % EVENTCOUNT][2], logbuffer[current % EVENTCOUNT][3], logbuffer[current % EVENTCOUNT][4]);
	break;
      case EXBUSERROR:
        sprintf(s, "F-%.8X Y-%.3X X-%.3X - Bus Error Exception (PC=%.6X)", logbuffer[current % EVENTCOUNT][1], logbuffer[current % EVENTCOUNT][2], logbuffer[current % EVENTCOUNT][3], logbuffer[current % EVENTCOUNT][4]);
	break;
      case EXODDADDRESS:
        sprintf(s, "F-%.8X Y-%.3X X-%.3X - Odd Address Exception (PC=%.6X)", logbuffer[current % EVENTCOUNT][1], logbuffer[current % EVENTCOUNT][2], logbuffer[current % EVENTCOUNT][3], logbuffer[current % EVENTCOUNT][4]);
	break;
      case EXILLEGAL:
        sprintf(s, "F-%.8X Y-%.3X X-%.3X - Illegal Instruction Exception (PC=%.6X)", logbuffer[current % EVENTCOUNT][1], logbuffer[current % EVENTCOUNT][2], logbuffer[current % EVENTCOUNT][3], logbuffer[current % EVENTCOUNT][4]);
	break;
      case EXDIVBYZERO:
        sprintf(s, "F-%.8X Y-%.3X X-%.3X - Division by Zero Exception (PC=%.6X)", logbuffer[current % EVENTCOUNT][1], logbuffer[current % EVENTCOUNT][2], logbuffer[current % EVENTCOUNT][3], logbuffer[current % EVENTCOUNT][4]);
	break;
      case EXPRIV:
        sprintf(s, "F-%.8X Y-%.3X X-%.3X - Privilegie Violation Exception (PC=%.6X)", logbuffer[current % EVENTCOUNT][1], logbuffer[current % EVENTCOUNT][2], logbuffer[current % EVENTCOUNT][3], logbuffer[current % EVENTCOUNT][4]);
	break;
      case EXTRAP:
        sprintf(s, "F-%.8X Y-%.3X X-%.3X - TRAP Exception %d (PC=%.6X)", logbuffer[current % EVENTCOUNT][1], logbuffer[current % EVENTCOUNT][2], logbuffer[current % EVENTCOUNT][3],(logbuffer[current % EVENTCOUNT][5]-0x80)/4,logbuffer[current % EVENTCOUNT][4]);
	break;
      case EVSTOP:
        sprintf(s, "F-%.8X Y-%.3X X-%.3X - STOP instruction executed (PC=%.6X)", logbuffer[current % EVENTCOUNT][1], logbuffer[current % EVENTCOUNT][2], logbuffer[current % EVENTCOUNT][3], logbuffer[current % EVENTCOUNT][4]);
	break;
      case EXFLINE:
        sprintf(s,
		"F-%.8X Y-%.3X X-%.3X - F-Line Exception (PC=%.6X)",
		logbuffer[current % EVENTCOUNT][1],
		logbuffer[current % EVENTCOUNT][2],
		logbuffer[current % EVENTCOUNT][3],
		logbuffer[current % EVENTCOUNT][4]);
	break;
      default:
        sprintf(s, "Unknown Log Event (bug!) found: %d", logbuffer[current % EVENTCOUNT][0]);
	break;
    }
    guiWindowTextPlot(&fgui_wconsole, s, 1, 1 + current - start);
    guiSpacesToEOL(&fgui_wconsole, s, 1 + current - start);
  }
}


/*======================*/
/* Browse the event log */
/*======================*/

void fguiDebugEventLogBrowse(void) {
  ULO c, current, wheight = fgui_wconsole.y2 - fgui_wconsole.y1 - 1;
  BOOLE finished = FALSE;

  guiWindowClear(&fgui_wconsole, TRUE);
  guiWindowBorderPlot(&fgui_wconsole);
  if (logfirst != loglast) {
    current = logfirst;
    while (!finished) {
      fguiDebugEventLogPrint(current, ((loglast - current) > wheight) ? (current + wheight) : loglast);
      c = getch();
      if (c == 27)
        finished = TRUE;
      else if (c == 0) {
	c = getch();
	if (c == 72) {
          if (current != logfirst)
            current--;
	}
	else if (c == 80) {
          if (current != (loglast - 1))
            current++;
	}
	else if (c == 73) {  /* PGUP */
          if ((current - wheight) < logfirst)
            current = logfirst;
          else
            current -= wheight;
	}
	else if (c == 81) { /* PGDOWN */
          if ((current + wheight) > (loglast - 1))
            current = loglast - 1;
          else
            current += wheight;
	}
      }
    }
  }
  else {
    guiWindowTextPlot(&fgui_wconsole, "No events logged", 1, 1);
    getch();
  }
}


/*====================*/
/* Toggle CPU history */
/*====================*/

void fguiDebugCPUTraceOff(void) {
  cputraceflag = FALSE;
}

void fguiDebugCPUTraceOn(void) {
  cputraceflag = TRUE;
  cputraceptr = 0;
  cputracecount = 0;
}


/*====================*/
/* CPU history browse */
/*====================*/

#ifdef PC_PTR
ULO debugCPUTraceGetPC(ULO p, ULO pos) {return p - cputracebase[pos];};
#else
ULO debugCPUTraceGetPC(ULO p, ULO pos) {return p;};
#endif

void fguiDebugCPUTraceBrowse(void) {
  STR s[20], strr[80];
  ULO y, mpc, opco;
  ULO tracepostop;
  union { ULO lo; ULO (*fun)(); } disfunc;
  ULO keyz;
  BOOLE cputend = FALSE;
  
  guiWindowClear(&fgui_wconsole, FALSE);
  guiWindowBorderPlot(&fgui_wconsole);
  
  if (cputraceptr == 0) {
    guiWindowTextPlot(&fgui_wconsole, "No CPU trace available", 1, 1);
    getch();
    return;
  }
  
  tracepostop = 0;
  if (cputracecount >= 524288)
    cputracecount = 524288;
  
  while (!cputend) {
    for (y = 0; y < (fgui_wconsole.y2 - fgui_wconsole.y1 - 1); y++) {
      if ((tracepostop + y) < cputracecount) {
        if (cputracecount == 524288)
          mpc = debugCPUTraceGetPC(cputracebuffer[(cputraceptr + tracepostop + y) & 0x7ffff], (cputraceptr + tracepostop + y) & 0x7ffff);
        else
          mpc = debugCPUTraceGetPC(cputracebuffer[(tracepostop + y) & 0x7ffff], (cputraceptr + tracepostop + y) & 0x7ffff);
	opco = fetw(mpc);
        disfunc.lo = cpu_dis_tab[opco];
        disfunc.fun(mpc, opco, strr);
	guiWindowTextPlot(&fgui_wconsole, strr, 1, y + 1);
        guiSpacesToEOL(&fgui_wconsole, strr, y + 1);
      }
      else {
	strr[0] = 0;
        guiSpacesToEOL(&fgui_wconsole, strr, y + 1);
      }
      if (y == 2) {
        guiWindowTextPlot(&fgui_wconsole, "Trace position:", 58, 1);
	sprintf(s, "%d", tracepostop);
	guiWindowTextPlot(&fgui_wconsole, s, 73, 1);
	guiWindowTextPlot(&fgui_wconsole, "Trace length:", 58, 2);
	sprintf(s, "%d", cputracecount);
	guiWindowTextPlot(&fgui_wconsole, s, 73, 2);
      }
    }
    while (!kbhit()) {};
    keyz = getch();
    if (keyz == 27) cputend = TRUE;
    else if (keyz == 0) {
      keyz = getch();
      if (keyz == 71) {
	tracepostop = 0;
      }
      else if (keyz == 79) {
	tracepostop = cputracecount;
      }
      else if (keyz == 72) {
	if (tracepostop > 0) tracepostop--; 
      }
      else if (keyz == 80) {
	if (tracepostop < cputracecount)
	  tracepostop++;
      }
      else if (keyz == 73) {  /* PGUP */
        if ((tracepostop - 19) < 0) tracepostop = 0;
	else tracepostop -= 19;
      }
      else if (keyz == 81) { /* PGDOWN */
        if ((tracepostop + 19) > cputracecount)
	  tracepostop = cputracecount;
	else tracepostop += 19;
      }
      else if (keyz == 82) {  
        if ((tracepostop - 1000) < 0) tracepostop = 0;
	else tracepostop -= 1000;
      }
      else if (keyz == 83) { 
        if ((tracepostop + 1000) > cputracecount)
	  tracepostop = cputracecount;
	else tracepostop += 1000;
      }
    }
  }
}

/*===========================*/
/* Print CPU history to file */
/*===========================*/

void fguiDebugCPUTraceToFile(void) {
  STR strr[80];
  ULO y, mpc, opco;
  ULO tracepostop;
  union { ULO lo; ULO (*fun)(); } disfunc;
  ULO cputend = FALSE;
  FILE *F;

  if ((F = fopen("mytrace.cpu", "w")) != NULL) {  
    tracepostop = 0;
    if (cputracecount >= 524288) cputracecount = 524288;
    for (y = 0; y < cputracecount; y++) {
      if ((tracepostop + y) < cputracecount) {
	if (cputracecount == 524288)
          mpc = debugCPUTraceGetPC(cputracebuffer[(cputraceptr + tracepostop + y) & 0x7ffff], (cputraceptr + tracepostop + y) & 0x7ffff);
        else
          mpc = debugCPUTraceGetPC(cputracebuffer[(tracepostop + y) & 0x7ffff], (cputraceptr + tracepostop + y) & 0x7ffff);
	opco = fetw(mpc);
        disfunc.lo = cpu_dis_tab[opco];
        disfunc.fun(mpc, opco, strr);
	fprintf(F, "%s\n", strr);
      }
    }
    fclose(F);    
  }
}

#endif


/*======================================*/
/* Print the state of the CPU registers */
/*======================================*/

void fguiDebugCPURegistersPrint(void) {
  STR st[80];

  guiWindowClear(&fgui_wheader, FALSE);
  sprintf(st, "D0:%.8X %.8X %.8X %.8X %.8X %.8X %.8X %.8X:D7", d[0], d[1], d[2], d[3], d[4], d[5], d[6], d[7]);
  guiWindowTextPlot(&fgui_wheader, st, 1, 1);
  sprintf(st, "A0:%.8X %.8X %.8X %.8X %.8X %.8X %.8X %.8X:A7", a[0], a[1], a[2], a[3], a[4], a[5], a[6], a[7]);
  guiWindowTextPlot(&fgui_wheader, st, 1, 2);
  if ((sr & 0x2000) == 0x2000)
    sprintf(st, "PC:%.8X USP:%.8X SSP:%.8X SR:%.4X IRQ-LEVEL %1d SUPERVISOR MODE", get_pc(pc), usp, a[7], sr, (sr & 0x700)>>8);
  else
    sprintf(st, "PC:%.8X USP:%.8X SSP:%.8X SR:%.4X IRQ-LEVEL %1d USER MODE", get_pc(pc), a[7], ssp, sr, (sr & 0x700)>>8);
  guiWindowTextPlot(&fgui_wheader, st, 1, 3);
  if (config_cpu_type > 0) {
    sprintf(st, "VBR: %.8X CACR: %.8X MSP: %.8X", vbr, cacr, msp);
    guiWindowTextPlot(&fgui_wheader, st, 1, 4);
  }    
}


/*===========================================*/
/* Show collected timer values for profiling */
/*===========================================*/

#ifdef TSC_PROFILING
void fguiDebugTSCPrint(void) {
  STR s[80];
  ULO y = 1;

  guiWindowClear(&fgui_wconsole, FALSE);
  guiWindowBorderPlot(&fgui_wconsole);
  sprintf(s, "Drawbgline800: %.8X%.8X  Times: %d  Avg: %d", (ULO)(drawbgline800_tsc>>32), (ULO)(drawbgline800_tsc&0xffffffff), drawbgline800_tsctimes, (drawbgline800_tsctimes != 0) ? (drawbgline800_tsc/drawbgline800_tsctimes) : 0);
  guiWindowTextPlot(&fgui_wconsole, s, 2, y++);
  sprintf(s, "Drawbgline800mmx: %.8X%.8X  Times: %d  Avg: %d", (ULO)(drawbgline800mmx_tsc>>32), (ULO)(drawbgline800mmx_tsc&0xffffffff), drawbgline800mmx_tsctimes,  (drawbgline800mmx_tsctimes != 0) ? (drawbgline800mmx_tsc/drawbgline800mmx_tsctimes) : 0);
  guiWindowTextPlot(&fgui_wconsole, s, 2, y++);
  sprintf(s, "Drawbgline800notdrawn: %.8X%.8X  Times: %d  Avg: %d", (ULO)(drawbgline800notdrawn_tsc>>32), (ULO)(drawbgline800notdrawn_tsc&0xffffffff), drawbgline800notdrawn_tsctimes, (drawbgline800notdrawn_tsctimes != 0) ? (drawbgline800notdrawn_tsc/drawbgline800notdrawn_tsctimes) : 0);
  guiWindowTextPlot(&fgui_wconsole, s, 2, y++);
  sprintf(s, "Drawlores800: %.8X%.8X  Times: %d  Avg: %d", (ULO)(drawlores800_tsc>>32), (ULO)(drawlores800_tsc&0xffffffff), drawlores800_tsctimes, (drawlores800_tsctimes != 0) ? (drawlores800_tsc/drawlores800_tsctimes) : 0);
  guiWindowTextPlot(&fgui_wconsole, s, 2, y++);
  sprintf(s, "Drawlores800mmx: %.8X%.8X  Times: %d  Avg: %d", (ULO)(drawlores800mmx_tsc>>32), (ULO)(drawlores800mmx_tsc&0xffffffff), drawlores800mmx_tsctimes, (drawlores800mmx_tsctimes != 0) ? (drawlores800mmx_tsc/drawlores800mmx_tsctimes) : 0);
  guiWindowTextPlot(&fgui_wconsole, s, 2, y++);
  sprintf(s, "Drawhires800: %.8X%.8X  Times: %d  Avg: %d", (ULO)(drawhires800_tsc>>32), (ULO)(drawhires800_tsc&0xffffffff), drawhires800_tsctimes, (drawhires800_tsctimes != 0) ? (drawhires800_tsc/drawhires800_tsctimes) : 0);
  guiWindowTextPlot(&fgui_wconsole, s, 2, y++);
  sprintf(s, "Drawhires800mmx: %.8X%.8X  Times: %d  Avg: %d", (ULO)(drawhires800mmx_tsc>>32), (ULO)(drawhires800mmx_tsc&0xffffffff), drawhires800mmx_tsctimes, (drawhires800mmx_tsctimes != 0) ? (drawhires800mmx_tsc/drawhires800mmx_tsctimes) : 0);
  guiWindowTextPlot(&fgui_wconsole, s, 2, y++);

  sprintf(s,"Drawbgline800wmmx %X dbgloopmmx %X dbgnodrawmmx %X",drawbgline800wmmx,dbgloopmmx,dbgnodrawmmx);
  guiWindowTextPlot(&fgui_wconsole,s,2,y++);
  sprintf(s,"Drawlores800wmmx %X dlloopmmx %X docoppers %X",drawlores800wmmx,dlloopmmx,docoppers);
  guiWindowTextPlot(&fgui_wconsole,s,2,y++);
  getch();
}
#endif


/*==========================*/
/* Draw the debugger screen */
/*==========================*/

void fguiDebugScreenPrint(BOOLE clearflag, BOOLE drawborderflag) {
  if (clearflag) {
    guiWindowClear(&fgui_wheader, drawborderflag);
    guiWindowClear(&fgui_wconsole, drawborderflag);
  }
  if (drawborderflag) {
    guiWindowBorderPlot(&fgui_wfullscreen);
    guiWindowBorderPlot(&fgui_wheader);
    guiWindowBorderPlot(&fgui_wconsole);
  }
  guiWindowBorderPlot(&fgui_wmenu);
  fguiDebugCPURegistersPrint();
  fguiDebugInstructionsPrint();
  fguiDebugFrameposPrint();
}


/*===========================*/
/* The debug breakpoint menu */
/*===========================*/

struct gui_numberfield fgui_debugbreak_numberfield;
struct gui_numberfield fgui_debugline_numberfield;
struct gui_numberfield fgui_wavcap_numberfield;
static ULO fgui_debug_breakpoint = 0;
static ULO fgui_wavcap_seconds = 0;
static ULO fgui_debug_lineno = 0;

ULO fguiDebugBreakpointGet(void) {
  guiWindowClear(&fgui_wrequester,FALSE);
  guiWindowBorderPlot(&fgui_wrequester);
  guiWindowTextPlot(&fgui_wrequester, "Breakpoint Address:",2,3);
  guiFieldNumberEnter(&fgui_debugbreak_numberfield);
  fgui_debug_breakpoint = fgui_debugbreak_numberfield.value;
  return fgui_debug_breakpoint;
}

ULO fguiDebugLinenumberGet(void) {
  guiWindowClear(&fgui_wrequester,FALSE);
  guiWindowBorderPlot(&fgui_wrequester);
  guiWindowTextPlot(&fgui_wrequester, "Line Number:",2,3);
  guiFieldNumberEnter(&fgui_debugline_numberfield);
  fgui_debug_lineno = fgui_debugline_numberfield.value;
  return fgui_debug_lineno;
}

void fguiDebugBreakMenuInit(void) {
  guiMenuInit(&fgui_debugbreakmenu,
	       fgui_debugbreakmenu_entries,
	       0,
	       &fgui_wmenu,
	       fgui_debugbreakmenu_shortcuts);
  guiFieldNumberInit(&fgui_debugbreak_numberfield,
		     &fgui_wrequester,
		     fgui_debug_breakpoint,
		     30, 3, TRUE);
  guiFieldNumberInit(&fgui_wavcap_numberfield,
		     &fgui_wrequester,
		     fgui_wavcap_seconds,
		     30, 3, FALSE);
  guiFieldNumberInit(&fgui_debugline_numberfield,
		     &fgui_wrequester,
		     fgui_debug_lineno,
		     30, 3, FALSE);
}

void fguiDebugBreakMenuRun(void) {
  BOOLE ended = FALSE;

  while (!ended) {
    fguiMenuWindowResize(&fgui_debugbreakmenu);
    fguiDebugScreenPrint(TRUE, TRUE);
    switch (guiMenuSelect(&fgui_debugbreakmenu, FALSE)) {
      case 0: /* Enter breakpoint */
        fellow_run_until_breakpoint(fguiDebugBreakpointGet());
	guiScreenSetup();
	ended = TRUE;
	break;
      case 1: /* Until Line */
        fellow_run_until_line(fguiDebugLinenumberGet());
	ended = TRUE;
	break;
#ifdef DEBUGBUILD
      case 2: /* Until Event */
	fellow_run_until_event();
	ended = TRUE;
	break;
#endif
      case GUI_MENU_LEVEL_UP:
	ended = TRUE;
	break;
    }
  }
}

/*===========================*/
/* The debug ioregister menu */
/*===========================*/

void fguiDebugIOMenuInit(void) {
  guiMenuInit(&fgui_debugiomenu,
               fgui_debugiomenu_entries,
               0,
               &fgui_wmenu,
               fgui_debugiomenu_shortcuts);
}

void fguiDebugIOMenuRun(void) {
  BOOLE ended = FALSE;
  
  fguiMenuWindowResize(&fgui_debugiomenu);
  while (!ended) {
    fguiDebugScreenPrint(TRUE, TRUE);
    switch (guiMenuSelect(&fgui_debugiomenu, FALSE)) {
      case 0: /* Floppy */
        fguiDebugFloppyStatePrint();
	break;
      case 1: /* Sound */
        fguiDebugSoundStatePrint();
	break;
      case 2: /* Copper */
        fguiDebugCopperStatePrint();
	break;
      case 3: /* Sprites */
        fguiDebugSpritesStatePrint();
	break;
      case 4: /* Screen */
        fguiDebugScreenStatePrint();
	break;
      case 5: /* Events */
        fguiDebugEventsPrint();
	break;
      case GUI_MENU_LEVEL_UP:
	ended = TRUE;
	break;
    }
  }
}


/*===============*/
/* Debugger Menu */
/*===============*/

struct gui_menu fgui_debugmenu;

STR *fgui_debugmenu_entries[] = {"Step",
                                 "Step Over",
                                 "Breakpoint",
                                 "Memory",
                                 "Cia",
                                 "IO",
#ifdef DEBUGBUILD
                                 "Trace on",
                                 "Trace off",
                                 "Show Trace",
                                 "Trace to file",
                                 "Evlog Config",
                                 "Show Evlog",
#endif
#ifdef TSC_PROFILING
                                 "TSC_Profile",
#endif
                                 NULL};
UBY fgui_debugmenu_shortcuts[] = {0, 1, 0, 0, 0, 0
#ifdef DEBUGBUILD
                                  , 1, 2, 1, 4, 1, 2, 3
#endif                                  
};

void fguiDebugMenuInit(void) {
  guiMenuInit(&fgui_debugmenu,
               fgui_debugmenu_entries,
               0,
               &fgui_wmenu,
               fgui_debugmenu_shortcuts);
}

void fguiDebugMenuRun(void) {
  BOOLE ended = FALSE;
  BOOLE printborder = FALSE;
  
  if (debug_screentables_not_set) {
    setup_emu_videomode(); /* Debug will crash if not run once */
    guiScreenSetup();
  }
  fguiMenuWindowResize(&fgui_debugmenu);
  fguiDebugScreenPrint(TRUE, TRUE);
  do {
    switch (guiMenuSelect(&fgui_debugmenu, FALSE)) {
      case 0: /* Step */
	fellow_step();
	break;
      case 1: /* Step over */
	fellow_step_over();
	break;
      case 2: /* Breakpoint */
        fguiDebugBreakMenuRun();
	printborder = TRUE;
	break;
      case 3: /* Memory  */
        fguiDebugMemoryBrowse();
	break;
      case 4: /* Cia*/
        fguiDebugCIAStatePrint();
	break;
      case 5: /* IO */
        fguiDebugIOMenuRun();
	break;
#ifdef DEBUGBUILD
      case 6: /* Cputrace on */
        fguiDebugCPUTraceOn();
	break;
      case 7: /* Cputrace off */
        fguiDebugCPUTraceOff();
	break;
      case 8: /* Show cputrace */
        fguiDebugCPUTraceBrowse();
	break;
      case 9: /* Print trace to file */
        fguiDebugCPUTraceToFile();
	break;
      case 10: /* Event log config */
	guiOptionmenuRun(&fgui_evlog_optionmenu);
	break;
      case 11: /* Show Event log */
        fguiDebugEventLogBrowse();
	break;
#endif
#ifdef TSC_PROFILING
      case 12:
        fguiDebugTSCPrint();
	break;
#endif
      case GUI_MENU_LEVEL_UP:
	ended = TRUE;
	break;
    }
    fguiMenuWindowResize(&fgui_debugmenu);
    if (!ended) {
      fguiDebugScreenPrint(TRUE, printborder);
      printborder = FALSE;
    }
  } while (!ended && !gui_exitflag);
  guiWindowClear(&fgui_wfullscreen, FALSE);
}



/*=================*/
/* Filesystem menu */
/*=================*/

struct gui_menu fgui_filesystemmenu;
STR *fgui_filesystemmenu_entries[] = {"Add VFS filesystem",
				      "Add readonly VFS",
				      "Add normal filesystem",
				      "Add readonly normal",
				      "Remove Filesystem",
                                      NULL};

UBY fgui_filesystemmenu_shortcuts[] = {4, 4, 4, 5, 2};
struct gui_textfield fgui_filesystemtextfield;
struct gui_numberfield fgui_filesystemnumberfield;
struct gui_window fgui_wfilesystem;

void fguiFilesystemMenuInit(void) {
  guiMenuInit(&fgui_filesystemmenu,
               fgui_filesystemmenu_entries,
               0,
               &fgui_wmenu,
               fgui_filesystemmenu_shortcuts);
}

void fguiFilesystemMenuScreenPrint(void) {
  guiWindowClear(&fgui_wconsole, FALSE);
  guiWindowBorderPlot(&fgui_wconsole);
  guiWindowBorderPlot(&fgui_wmenu);
  fguiUAEUnitsPrint(2);
}

BOOLE fguiFilesystemAdd(BOOLE readonly, BOOLE vfsmodule) {
  STR volumename[40], rootdirectory[80];
  ULO mangle;

  guiFieldTextInit(&fgui_filesystemtextfield, &fgui_wrequester, "", 2, 4, 40);
  guiWindowClear(&fgui_wrequester, FALSE);
  guiWindowBorderPlot(&fgui_wrequester);
  guiWindowTextPlot(&fgui_wrequester, "Enter volume name:", 2, 2);
  if (!guiFieldTextEnter(&fgui_filesystemtextfield))
    return FALSE;
  strcpy(volumename, fgui_filesystemtextfield.value);
  guiFieldTextInit(&fgui_filesystemtextfield, &fgui_wrequester, "", 2, 4, 75);
  guiWindowClear(&fgui_wrequester, FALSE);
  guiWindowBorderPlot(&fgui_wrequester);
  guiWindowTextPlot(&fgui_wrequester, "Enter volume root directory:", 2, 2);
  if (!guiFieldTextEnter(&fgui_filesystemtextfield))
    return FALSE;
  strcpy(rootdirectory, fgui_filesystemtextfield.value);
  if (vfsmodule) {
    guiFieldNumberInit(&fgui_filesystemnumberfield, &fgui_wrequester, 8, 2, 4,
		       FALSE);
    guiWindowClear(&fgui_wrequester, FALSE);
    guiWindowBorderPlot(&fgui_wrequester);
    guiWindowTextPlot(&fgui_wrequester, "Enter filename mangle size:", 2,
			 2);
    if (!guiFieldNumberEnter(&fgui_filesystemnumberfield))
      return FALSE;
    mangle = fgui_filesystemnumberfield.value;
    if (mangle < 1 || mangle > 8) mangle = 8;
  }
  add_filesys_unit(volumename, rootdirectory, readonly, 0, 0, 0, vfsmodule,
		   mangle);
  return TRUE;
}

BOOLE fguiFilesystemRemove(void) {
  STR *volnames[20];
  ULO devnos[20];
  struct gui_menu m;
  ULO volumes = getNumUnits(), i, width = 0, sel;
  BOOLE must_reset = FALSE;

  if (volumes > 0) {
    for (i = 0; i < volumes; i++) {
      volnames[i] = getVolName(i);
      devnos[i] = i;
      if (width < strlen(volnames[i]))
	width = strlen(volnames[i]);
    }
    volnames[volumes] = NULL;
    guiWindowInit(&fgui_wfilesystem, 40 - (width/2), 42 + (width/2),
		   12 - (volumes/2), 13 + ((volumes + 1)/2), BGCOL, TXTCOL,
		   SHORTCUTCOL, REVERSECOL, 0);
    guiMenuInit(&m, volnames, 0, &fgui_wfilesystem, NULL);
    guiWindowClear(&fgui_wfilesystem, FALSE);
    guiWindowBorderPlot(&fgui_wfilesystem);
    sel = guiMenuSelect(&m, FALSE);
    if (sel != GUI_MENU_LEVEL_UP) {
      kill_filesys_unit(devnos[sel]);
      must_reset = TRUE;
    }
  }
  return must_reset;
}
    
void fguiFilesystemMenuRun(void) {
  BOOLE ended;
  BOOLE must_reset = FALSE;

  ended = FALSE;
  while (!ended) {
    fguiMenuWindowResize(&fgui_filesystemmenu);
    fguiFilesystemMenuScreenPrint();
    switch (guiMenuSelect(&fgui_filesystemmenu, FALSE)) {
      case 0: /* Add VFS Filesystem */ 
	must_reset |= fguiFilesystemAdd(FALSE, TRUE);
        break;
      case 1: /* Add readonly VFS Filesystem */ 
	must_reset |= fguiFilesystemAdd(TRUE, TRUE);
        break;
      case 2: /* Add Normal Filesystem */ 
	must_reset |= fguiFilesystemAdd(FALSE, FALSE);
        break;
      case 3: /* Add readonly Normal Filesystem */ 
	must_reset |= fguiFilesystemAdd(TRUE, FALSE);
        break;
      case 4: /* Remove Filesystem */ 
	must_reset |= fguiFilesystemRemove();
        break;
      case GUI_MENU_LEVEL_UP:
        ended = TRUE;
        break;
    }
  }
  if (must_reset)
    fellow_hardreset();
}


/*================*/
/* Utilities menu */
/*================*/

struct gui_menu fgui_utilmenu;
STR *fgui_utilmenu_entries[] = {"MOD Ripper",
                                NULL};

UBY fgui_utilmenu_shortcuts[] = {0};

void fguiUtilMenuInit(void) {
  guiMenuInit(&fgui_utilmenu,
               fgui_utilmenu_entries,
               0,
               &fgui_wmenu,
               fgui_utilmenu_shortcuts);
}

void fguiUtilMenuRun(void) {
  BOOLE ended;

  ended = FALSE;
  while (!ended) {
    fguiMenuWindowResize(&fgui_utilmenu);
    fguiTopMenuScreenPrint(TRUE);
    switch (guiMenuSelect(&fgui_utilmenu, FALSE)) {
      case 0: /* MOD Ripper */ 
	fguiMODRipper();
        break;
      case GUI_MENU_LEVEL_UP:
        ended = TRUE;
        break;
    }
  }
}


/*====================================*/
/* 3 line requester for error reports */
/*====================================*/

void fguiRequester(STR *s1, STR *s2, STR *s3) {
  LON p;
  
  guiWindowClear(&fgui_wrequester, TRUE);
  guiWindowBorderPlot(&fgui_wrequester);
  p = 35 - (strlen(s1)/2);
  if (p < 1)
    p = 1;
  guiWindowTextPlot(&fgui_wrequester,s1, p, 1);
  p = 35 - (strlen(s2)/2);
  if (p < 1)
    p = 1;
  guiWindowTextPlot(&fgui_wrequester,s2, p, 3);
  p = 35 - (strlen(s3)/2);
  if (p < 1)
    p = 1;
  guiWindowTextPlot(&fgui_wrequester,s3, p, 5);
  getch();
  guiWindowClear(&fgui_wrequester, TRUE);
}


/*==================================*/
/* The version and copyright notice */
/*==================================*/

void fguiVersionPrint(void) {
  guiWindowTextPlot(&fgui_wheader,"Fellow V0.3.5",2,1);
#ifdef PREFETCH  
  guiWindowTextPlot(&fgui_wheader,"(M68k Prefetch)",64,1);
#endif
  guiWindowTextPlot(&fgui_wheader,"Copyright (C) 2000 Petter Schau, Roman Dolejsi, David Voracek, Rainer Sinsch",2,3);
}


/*===================================================*/
/* Prints a list of the currently loaded disk-images */
/*===================================================*/

ULO fguiFloppyUnitsPrint(ULO ystart) {
  ULO i, j;
  STR st[256];
  
  guiWindowTextPlot(&fgui_wconsole, "Disk-images:", 2, ystart);
  guiWindowTextPlot(&fgui_wconsole, "------------", 2, ystart + 1);
  j = 2;  
  for (i = 0; i < 4; i++) {
    sprintf(st, "DF%d:", i);
    guiWindowTextPlot(&fgui_wconsole, st, 2, ystart + j);
    guiWindowTextPlot(&fgui_wconsole, floppy[i].imagename, 7,
			 ystart + j);
    if (floppy[i].enabled) {
      switch (floppy[i].imagestatus) {
	case FLOPPY_STATUS_NORMAL_OK:
	  sprintf(st, "%d track ADF", floppy[i].tracks);
	  guiWindowTextPlot(&fgui_wconsole, st, 50, ystart + j);
	  break;
	case FLOPPY_STATUS_EXTENDED_OK:
	  guiWindowTextPlot(&fgui_wconsole, "Extended ADF", 50,
			       ystart + j);
	  break;
	case FLOPPY_STATUS_ERROR:
	  switch (floppy[i].imageerror) {
	    case FLOPPY_ERROR_EXISTS_NOT:
	      guiWindowTextPlot(&fgui_wconsole, "File not found error", 50,
				   ystart + j);
	      break;
	    case FLOPPY_ERROR_COMPRESS:
	      guiWindowTextPlot(&fgui_wconsole, "Uncompress error", 50,
				   ystart + j);
	      break;
	    case FLOPPY_ERROR_SIZE:
	      guiWindowTextPlot(&fgui_wconsole, "Wrong size error", 50,
				   ystart + j);
	      break;
	    case FLOPPY_ERROR_COMPRESS_NOTMP:
	      guiWindowTextPlot(&fgui_wconsole, "TMP/TEMP undefined error", 50,
				   ystart + j);
	      break;
	    case FLOPPY_ERROR_COMPRESS_TMPFILEOPEN:
	      guiWindowTextPlot(&fgui_wconsole, "TMP file access error", 50,
				   ystart + j);
	      break;
	    case FLOPPY_ERROR_FILE:
	      guiWindowTextPlot(&fgui_wconsole, "File access error", 50,
				   ystart + j);
	      break;
	    case FLOPPY_ERROR_EXTENDED:
	      guiWindowTextPlot(&fgui_wconsole, "Extended ADF:Unsupported", 50,
				   ystart + j);
	      break;
	  }
	  break;
	case FLOPPY_STATUS_NONE:
	  guiWindowTextPlot(&fgui_wconsole, "None inserted", 50,
			       ystart + j);
	  break;
      }
    }
    else
      guiWindowTextPlot(&fgui_wconsole, "Disabled", 50, ystart + j);
    j++;
  } 
  return ystart + 6;
}


/*========================================================*/
/* Prints a list of the currently active hardfile-devices */
/*========================================================*/

ULO fguiFHFileUnitsPrint(ULO ystart) {
  ULO i, j;
  STR st[256];
  BOOLE first;
  
  first = TRUE;
  j = 0;
  for (i = 0; i < FHFILE_MAX_DEVICES; i++) {
    if (config_fhfile_status[i] != FHFILE_NONE) {
      if (first) {
	first = FALSE;
	guiWindowTextPlot(&fgui_wconsole, "Hardfiles:", 2, ystart + j++);
	guiWindowTextPlot(&fgui_wconsole, "----------", 2, ystart + j++);
      }	
      sprintf(st, "FELLOW%d: ", i);
      guiWindowTextPlot(&fgui_wconsole, st, 2, ystart + j);
      guiWindowTextPlot(&fgui_wconsole, config_fhfile_name[i], 11,
			   ystart + j);
      if (config_fhfile_enabled) {
	if (config_memory_romversion < 36) 
	  guiWindowTextPlot(&fgui_wconsole, "Disabled, use Kickstart >= 2",
			       50, ystart + j);
	else {
	  switch (config_fhfile_status[i]) {
	    case FHFILE_ADF:
	      sprintf(st, "ADF           ");
	      break;
	    case FHFILE_HDF:
	      sprintf(st, "%d MB Hardfile", fhfile_size[i] / 0x100000);
	      break;
	    default:
	      sprintf(st, "BUG!          ");
	      break;
	  }
	  guiWindowTextPlot(&fgui_wconsole, st, 50, ystart + j);
	}
      }
      else
	guiWindowTextPlot(&fgui_wconsole, "Disabled     ", 50, ystart + j);
      j++;
    }
  }
  return ystart + j;
}  


/*===================================================*/
/* Prints a list of the currently active UAE-devices */
/*===================================================*/

ULO fguiUAEUnitsPrint(ULO ystart) {
  ULO i, j;
  STR st[256];
  BOOLE first;
  
  first = TRUE;
  j = 0;
  for (i = 0; i < getNumUnits(); i++) {
    if (first) {
      first = FALSE;
      guiWindowTextPlot(&fgui_wconsole, "Virtual Filesystems:", 2,
			   ystart + j++);
      guiWindowTextPlot(&fgui_wconsole, "--------------------", 2,
			   ystart + j++);
    }	
    sprintf(st, "%s: ", getVolName(i));
    guiWindowTextPlot(&fgui_wconsole, st, 2, ystart + j);
    sprintf(st, "%s (%s R%s)", getRootDir(i), (getVFSModule(i)) ? "VFS" : "",
	    (getReadOnly(i)) ? "" : "W");
    guiWindowTextPlot(&fgui_wconsole, st, 20, ystart + j);
    j++;
  }
  return ystart + j;
}  


/*==================================================*/
/* Prints info about the currently loaded Kickstart */
/*==================================================*/

ULO fguiKickstartInfoPrint(ULO ystart) {
  if (!config_memory_nokick)
    guiWindowTextPlot(&fgui_wconsole, kickstart_idstring, 2, ystart + 1);
  else {
    guiWindowTextPlot(&fgui_wconsole,
	    "No Kickstart loaded                                          ",
			 2, ystart);
  }
  return ystart + 2;
}


/*=============================================*/
/* Print diskname while inserting a disk-image */
/*=============================================*/

void fguiDiskNamePrint(STR *str, ULO drv) {
  STR s[80];
  STR s2[80];
  LON i;
  STR strw[80];

  if(strcmpi(floppy[drv].imagename, "__None__" ) ) {
    strw[0] = 0; s[0] = 0;
    if( strlen( str ) > ( 78 - 25 ) ) {
      strcat( strw, "..." );
      strcat( strw, &str[ strlen( str ) - ( 78 - 25 - 3 ) ] );
    } else strcpy( strw, str );
    sprintf( s2, "Inserting %s into drive Df%i", strw, drv );
    i = ( 78 - strlen( s2 ) ) / 2;
    while( i-- > 0 ) strcat( s, " " );
    strcat( s2, s );
    strcat( s, s2 );
    guiWindowTextPlot( &fgui_wconsole, s, 1, 10 );
  };
}


/*====================*/
/* MOD Ripper Control */
/*====================*/

// Module-Rip Functions
int mods_found;   // no. of mods found
void save_mem(char *name,int start, int end)
// Saves mem from address start to address end in file *name
{
  int i;
  FILE *modfile;

  if ((modfile = fopen(name, "w+b")) == NULL) return;
  for (i=start;i<=end;i++) fputc(cmem[i],modfile);
  fclose(modfile);
}

void scan(char *searchstring, int channels)
{
  int i,j;
  char file_name[14];   // File name for the module-file
  char dummy_string[80];
  char module_name[34]; // Name of the module
  char c;
  int start;            // address where the module starts
  int end;              // address where the module ends
  int sample_size;      // no. of all sample-data used in bytes
  int pattern_size;     // no. of all pattern-data used in bytes
  int song_length;      // how many patterns does the song play?
  int max_pattern;      // highest pattern used
  BOOLE played;
#ifdef SOUNDDRV_MIDAS
	     MIDASmodule module;
	     MIDASmodulePlayHandle playHandle;
#endif
			     
  for (i=0;i<=config_memory_chipsize;i++)
      if ((cmem[i+0] == searchstring[0]) && (cmem[i+1] == searchstring[1])
       && (cmem[i+2] == searchstring[2]) && (cmem[i+3] == searchstring[3]))
      // Searchstring found, now calc size
      {
        start = i-0x438;
        // Get SampleSize
        sample_size = 0;
        for (j=0;j<=30;j++) sample_size+=
            (256*cmem[start+0x2a+j*0x1e]+cmem[start+0x2b+j*0x1e])*2;

        song_length = cmem[start+0x3b6];
        // Scan for max. ammount of patterns
        max_pattern = 0;
        for (j=0;j<=song_length;j++)
            if (max_pattern < cmem[start+0x3b8+j]) max_pattern = cmem[start+0x3b8+j];

        pattern_size = (max_pattern+1)*64*4*channels;
        end = start+sample_size+pattern_size+0x43b;
                
        if ((end <= config_memory_chipsize) && (end-start < 1000000)) {
           // Get module name
           for (j=0;j<20;j++) module_name[j]= cmem[start+j];
           module_name[20] = 0;
           // Clear-Screen
           for (j=2;j<=15;j++) guiWindowTextPlot(&fgui_wconsole, "                                                                          ",1,j);
           // Set filename for the module-file
           if (strlen(module_name) > 2) {
              for (j=0;j<=strlen(module_name),j<=7;j++) file_name[j] = toupper(module_name[j]);
              file_name[j] = 0;  
              strcat(file_name,".MOD");
           }
           else sprintf(file_name,"MOD%d.MOD",mods_found++);

           sprintf(dummy_string,"Module found at $%X",start);
           guiWindowTextPlot(&fgui_wconsole, dummy_string,1,3);
           sprintf(dummy_string,"Module name: %s",module_name);
           guiWindowTextPlot(&fgui_wconsole, dummy_string,1,4);
           sprintf(dummy_string,"Module size: %d Bytes",end-start);
           guiWindowTextPlot(&fgui_wconsole, dummy_string,1,5);
           sprintf(dummy_string,"Patterns used: %d",max_pattern);
           guiWindowTextPlot(&fgui_wconsole, dummy_string,1,7);
           sprintf(dummy_string,"Save module as %s (Y/N)? P - Play",file_name);
           guiWindowTextPlot(&fgui_wconsole, dummy_string,1,11);

	   played = FALSE;
           do {
	     c = toupper(getch());
#ifdef SOUNDDRV_MIDAS
	      if (c == 'P' && !played) {
		played = TRUE;
		save_mem("tmp.mod", start, end);
		MIDASstartup();
		MIDASinit();
		MIDASstartBackgroundPlay(0);
		module = MIDASloadModule("tmp.mod");
		playHandle = MIDASplayModule(module, TRUE);
	      }
#endif
           } while ((c != 'Y') && (c != 'N'));
#ifdef SOUNDDRV_MIDAS
	   if (played) {
	     played = FALSE;
	     MIDASstopModule(playHandle);
	     MIDASfreeModule(module);
	     MIDASclose();
	     system("del tmp.mod");
	   }
#endif
           if (c == 'Y') {save_mem(file_name,start,end); guiWindowTextPlot(&fgui_wconsole, "YES: Saving... OK.",37,11);}
           else guiWindowTextPlot(&fgui_wconsole, "NO",37,11);
           }
      }
}
void MODrip(void)
// Scans for the mod-signature
{
  guiWindowTextPlot(&fgui_wconsole, "Scanning chip-mem: [      ]", 1, 1);
  mods_found = 0;
  scan("M.K.",4); guiWindowTextPlot(&fgui_wconsole, ".", 21,1);
  scan("4CHN",4); guiWindowTextPlot(&fgui_wconsole, ".", 22,1);
  scan("6CHN",6); guiWindowTextPlot(&fgui_wconsole, ".", 23,1);
  scan("8CHN",8); guiWindowTextPlot(&fgui_wconsole, ".", 24,1);
  scan("FLT4",4); guiWindowTextPlot(&fgui_wconsole, ".", 25,1);
  scan("FLT8",8); guiWindowTextPlot(&fgui_wconsole, ".", 26,1);
  guiWindowTextPlot(&fgui_wconsole, "No more modules found...",1,15);
  getch();

}

void fguiMODRipper(void) {
  fguiTopMenuScreenPrintPlain(TRUE);
  MODrip();
  guiWindowClear(&fgui_wconsole, FALSE);
}


/*====================*/
/* Game Cheat Control */
/*====================*/

void fguiGameCheats(void) {
  fguiTopMenuScreenPrintPlain(TRUE);

  getch();
}

/*=======*/
/* About */
/*=======*/

void fguiAbout(void) {
  fguiTopMenuScreenPrintPlain(TRUE);
  guiWindowTextPlot(&fgui_wconsole, "Fellow Amiga Emulator V0.3.5", 24, 1);
  guiWindowTextPlot(&fgui_wconsole, "1996-2000 Petter Schau and contributors", 17, 2);
  guiWindowTextPlot(&fgui_wconsole, "This program is now released under the GNU Public License.", 7, 4);
  guiWindowTextPlot(&fgui_wconsole, "Some libraries listed below were used that are not GPL.", 10, 5);  
  guiWindowTextPlot(&fgui_wconsole, "The Fellow Amiga Emulator was programmed by:", 17, 7);
  guiWindowTextPlot(&fgui_wconsole, "--------------------------------------------", 17, 8);
  guiWindowTextPlot(&fgui_wconsole, "Petter Schau", 30, 9);
  guiWindowTextPlot(&fgui_wconsole, "Roman Dolejsi", 30, 10);
  guiWindowTextPlot(&fgui_wconsole, "David Voracek", 30, 11);
  guiWindowTextPlot(&fgui_wconsole, "Rainer Sinsch", 30, 12);
  guiWindowTextPlot(&fgui_wconsole, "(MORE)", 73, 19);
  getch();
  guiWindowClear(&fgui_wconsole, FALSE);  
  guiWindowTextPlot(&fgui_wconsole, "External sources used:", 24, 2);
  guiWindowTextPlot(&fgui_wconsole, "----------------------", 24, 3);
  guiWindowTextPlot(&fgui_wconsole, "zlib - Copyright (C) 1995-1996 Jean-loup Gailly and Mark Adler", 2, 5);
  guiWindowTextPlot(&fgui_wconsole, "Some code adapted from the Scitech SDK - Copyright (C) 1994 SciTech Software", 2, 7);
  guiWindowTextPlot(&fgui_wconsole, "DOS-Extender: PMODE/W is Copyright (c) 1994-1997, Charles Scheffold", 2, 11);
  guiWindowTextPlot(&fgui_wconsole, "and Thomas Pytel. All rights reserved.", 16, 12);
  guiWindowTextPlot(&fgui_wconsole, "UAE virtual filesystem - Copyright 1998 Bernd Schmidt and contributors.", 2, 14);
  getch();
  guiWindowClear(&fgui_wconsole, FALSE);
}


/*====================*/
/* Create ADF and HDF */
/*====================*/

void fguiADFCreate(void) {
  static STR filename[80];
  static STR command[128];
  STR *suff;
  
  guiFieldTextInit(&fgui_filesystemtextfield, &fgui_wrequester, "", 2, 4, 70);
  guiWindowClear(&fgui_wrequester, FALSE);
  guiWindowBorderPlot(&fgui_wrequester);
  guiWindowTextPlot(&fgui_wrequester, "Enter disk-image name:", 2, 2);
  guiFieldTextEnter(&fgui_filesystemtextfield);
  strcpy(filename, fgui_filesystemtextfield.value);
  suff = strchr(filename, '.');
  if (suff != NULL) suff[0] = '\0';
  guiWindowClear(&fgui_wrequester, FALSE);
  sprintf(command, "Creating disk-image: %s", filename);
  guiWindowTextPlot(&fgui_wrequester, command, 35 - (strlen(command) / 2),
		       3);
  sprintf(command, "makeadf %s 1 -quiet", filename);
  if (system(command) != 0) {
    guiWindowClear(&fgui_wrequester, FALSE);
    guiWindowTextPlot(&fgui_wrequester, "Disk-image creation failed!", 27, 2);
    getch();
  }  
}


void fguiHDFCreate(void) {
  static STR filename[80];
  static STR command[128];
  ULO hdsize;
  
  guiFieldTextInit(&fgui_filesystemtextfield, &fgui_wrequester, "", 2, 4, 70);
  guiWindowClear(&fgui_wrequester, FALSE);
  guiWindowBorderPlot(&fgui_wrequester);
  guiWindowTextPlot(&fgui_wrequester, "Enter hardfile-name:", 2, 2);
  guiFieldTextEnter(&fgui_filesystemtextfield);
  strcpy(filename, fgui_filesystemtextfield.value);
  guiFieldNumberInit(&fgui_filesystemnumberfield, &fgui_wrequester, 0, 2, 4,
		     FALSE);
  guiWindowClear(&fgui_wrequester, FALSE);
  guiWindowBorderPlot(&fgui_wrequester);
  guiWindowTextPlot(&fgui_wrequester, "Enter hardfile-size:", 2,
		       2);
  guiFieldNumberEnter(&fgui_filesystemnumberfield);
  hdsize = fgui_filesystemnumberfield.value;
  if (hdsize < 1) hdsize = 1;
  guiWindowClear(&fgui_wrequester, FALSE);
  sprintf(command, "Creating %d MB hardfile: %s", hdsize, filename);
  guiWindowTextPlot(&fgui_wrequester, command, 40 - (strlen(command) / 2),
		       3);
  sprintf(command, "fellowHD %s %d", filename, hdsize);
  printf("%s\n", command);
  if (system(command) != 0) {
    guiWindowClear(&fgui_wrequester, FALSE);
    guiWindowTextPlot(&fgui_wrequester, "Hardfile creation failed!", 27, 2);
    getch();
  }  
}


/*===============*/
/* Run emulation */
/*===============*/

void fguiFellowRun(void) {
  ULO i;
  BOOLE more = TRUE;
  static STR tmpimgname[256];

  for (i = 0; i < 4; i++)
    insert_dfX[i] = 0;
  while (more) {
#ifdef WITH_OS_KEYBOARD
    home_pressed = FALSE;
    end_pressed = FALSE;
#endif
    fellow_run();
    more = FALSE;
    guiScreenSetup();
    guiWindowClear(&fgui_wfullscreen,TRUE);
    fellowRuntimeErrorCheck();
    for (i = 0; i < 4; i++) 
      if (insert_dfX[i] == 1) { 
        strcpy(tmpimgname, floppy[i].imagename);
        guiWindowBorderPlot(&fgui_wfullscreen);
        dt_selectfile(&fgui_wfullscreen, "ADF", floppy[i].imagename);
        more = TRUE;
        insert_dfX[i] = 0;
        if (strcmp(tmpimgname, floppy[i].imagename)) { 
          guiWindowClear( &fgui_wfullscreen, TRUE);
          guiWindowBorderPlot( &fgui_wfullscreen);
          fguiDiskNamePrint(floppy[i].imagename, i);
          floppyImageInsert(floppy[i].imagename, i);
          }
        }
      else if (insert_dfX[i] == 2) { 
        strcpy(floppy[i].imagename,"__None__");
        more = TRUE;
        insert_dfX[i] = 0;
        floppyImageInsert(floppy[i].imagename, i);
        }
   }
}

/*==================*/
/* Init all windows */
/*==================*/

void fguiWindowsInit(void) {
  guiWindowInit(&fgui_wfullscreen, 1, 80, 1, 25, BGCOL, TXTCOL, SHORTCUTCOL,
		REVERSECOL, 0);
  guiWindowInit(&fgui_wrequester, 5, 76, 10, 16, BGCOL, TXTCOL, SHORTCUTCOL,
		REVERSECOL, 0);
  guiWindowInit(&fgui_wheader, 1, 80, 1, 5, BGCOL, TXTCOL, SHORTCUTCOL,
		REVERSECOL, 0);
  guiWindowInit(&fgui_wconsole, 1, 80, 5, 25, BGCOL, TXTCOL, SHORTCUTCOL,
		REVERSECOL, TOPLEFT | TOPRIGHT);
  guiWindowInit(&fgui_wmenu, 66, 80, 18, 25, BGCOL, TXTCOL, SHORTCUTCOL,
		REVERSECOL, TOPRIGHT | BOTLEFT);
}

void fguiMenuWindowResize(struct gui_menu *m) {
  guiWindowClear(&fgui_wmenu, TRUE);
  fgui_wmenu.y1 = 24 - guiMenuEntryCount(m);
  fgui_wmenu.x1 = 80 - guiMenuEntryWidth(m);
}


/*===================*/
/* Set up menusystem */
/*===================*/

void fguiMenuInit(void) {
  fguiTopMenuInit();
  fguiConfigMenuInit();
  fguiDebugMenuInit();
  fguiDebugBreakMenuInit();
  fguiDebugIOMenuInit();
  fguiUtilMenuInit();
  fguiFileSystemMenuInit();
}

void fguiOptionmenuInit(void) {
  fguiOptionmenuFloppyInit();
  fguiOptionmenuScreenInit();
  fguiOptionmenuMemoryInit();
  fguiOptionmenuSoundInit();
  fguiOptionmenuCPUInit();
  fguiOptionmenuHFileInit();
  fguiOptionmenuVariousInit();
#ifdef DEBUGBUILD
  fguiOptionmenuEvlogInit();
#endif
}


/*===========================================*/
/* Start GUI, when exited, the emulator ends */
/*===========================================*/

void fguiEnterPre(void) {
  if (!cmdnogui) {
    guiScreenSetup();
    fguiWindowsInit();
    fguiTopMenuScreenPrintPlain(TRUE);
  }
}

void fguiEnter(void) {
  if (!cmdnogui) {
    fguiMenuInit();
    fguiOptionmenuInit();
    guiWindowClear(&fgui_wconsole, FALSE);
  }
  fellow_hardreset();  
  fguiTopMenuRun();
  if (!cmdnogui)
    guiScreenClose();
}

#endif  /* USE_GUI */
