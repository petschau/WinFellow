/*=======================*/
/* Fellow Amiga Emulator */
/* Virtual timer device  */
/* (C) 1998 Petter Schau */ 
/*=======================*/


#include "defs.h"


typedef struct {
  timerStartCallback start;
  timerStopCallback stop;
} timer_device;


#define TIMER_DEVICES_MAX 4

ULO timer_ticks;
ULO timer_device_count;
ULO timer_device_current;
timer_device timer_devs[4];


/*============*/
/* Timer tick */
/*============*/

void timerTick(void) {
  timer_tick++;
}


/*====================*/
/* Poll timer counter */
/*====================*/

ULO timerPoll(void) {
  return timer_ticks;
}


/*==========================*/
/* Start a timer at hz rate */
/*==========================*/

void timerStart(ULO hz) {
  timer_ticks = 0;
}  


/*============*/
/* Stop timer */
/*============*/

void timerStop(void) {
}


/*=======================*/
/* Register timer device */
/*=======================*/

void timerRegister(timer_device *td) {
  timer_devs[timer_device_count] = td;
  timer_device_count++;
}


/*======================*/
/* Timer device startup */
/*======================*/

void timerStartup(void) {
}


/*=======================*/
/* Timer device shutdown */
/*=======================*/

void timerShutdown(void) {
}








