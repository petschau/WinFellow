/*============================*/
/* Fellow Amiga Emulator      */
/* Hardfile device            */
/* (C) 1997-1998 Petter Schau */
/*============================*/

#include <stdio.h>
#include <sys/types.h>
#include <sys/stat.h>


#include "defs.h"
#include "fellow.h"
#include "memory.h"
#include "inout.h"
#include "68000.h"
#include "led.h"

/*====================*/
/* fhfile.device      */
/*====================*/


/*===================================*/
/* Fixed locations in fhfile_rom:    */
/* ------------------------------    */
/* offset 4088 - max number of units */
/* offset 4092 - configdev pointer   */
/*===================================*/


/*===================================================================*/
/* The hardfile device is at least in spirit based on ideas found in */
/* the sources below:                                                */
/* - The device driver source found on Fish 39                       */
/*   and other early Fish-disks                                      */
/* - UAE was useful for test and compare when the device was written */
/*   and didn't work                                                 */
/*===================================================================*/


ULO fhfile_tracks[FHFILE_MAX_DEVICES];
ULO fhfile_size[FHFILE_MAX_DEVICES];
FILE *fhfile_hardfile[FHFILE_MAX_DEVICES];
BOOLE config_fhfile_writeprot[FHFILE_MAX_DEVICES];
STR config_fhfile_name[FHFILE_MAX_DEVICES][256];
ULO config_fhfile_status[FHFILE_MAX_DEVICES];
BOOLE fhfile_first_time_init = TRUE;

ULO fhfile_romstart;
ULO fhfile_bootcode;
ULO fhfile_configdev;

#define FHFILE_ROMSIZE 8192
#define FHFILE_ROMMASK 0x1fff

UBY fhfile_rom[FHFILE_ROMSIZE];
ULO config_fhfile_enabled = TRUE;
ULO config_fhfile_init = 0;



/*===================*/
/* Set HD led symbol */
/*===================*/

void fhfileLed(BOOLE state) {
  if (state) {
    if (config_enableleds & 0x40 || config_enableleds < 0x10) {
      ledbyte |= (config_enableleds & 0x10) ? 0x4 : 0x20;
      if (config_enableleds < 0x10)
	drawledhdscr();
      else
	drawledlpt();
    }
  }
  else {
    if (config_enableleds & 0x40 || config_enableleds < 0x10 ) {
      ledbyte &= (config_enableleds & 0x10) ? 0xfb : 0xdf;
      if( config_enableleds < 0x10 ) drawledhdscr();
      else drawledlpt();
    }
  }
}


/*======================================================*/
/* fhfile_diag                                          */
/*                                                      */
/* Pointer to our configdev struct is stored in $f40ffc */
/* For later use when filling out the bootnode          */
/*======================================================*/

void fhfileDiag(void) {
  fhfile_configdev = a[3];
  dmem[4092] = fhfile_configdev>>24;
  dmem[4093] = fhfile_configdev>>16;
  dmem[4094] = fhfile_configdev>>8;
  dmem[4095] = fhfile_configdev;
  dmem[4088] = FHFILE_MAX_DEVICES>>24;
  dmem[4089] = FHFILE_MAX_DEVICES>>16;
  dmem[4090] = FHFILE_MAX_DEVICES>>8;
  dmem[4091] = FHFILE_MAX_DEVICES;
}


/*=============*/
/* fhfile_open */
/*=============*/

void fhfileOpen(void) {
  if (d[0] < FHFILE_MAX_DEVICES) {         /* Only 1 unit now */
    wrib(7, a[1] + 8);                     /* ln_type (NT_REPLYMSG) */
    wrib(0, a[1] + 31);                    /* io_error */
    wril(d[0], a[1] + 24);                 /* io_unit */
    wril(fetl(a[6] + 32) + 1, a[6] + 32);  /* LIB_OPENCNT */
    d[0] = 0;                              /* ? */
  }
  else {
    wril(-1, a[1] + 20);            
    wrib(-1, a[1] + 31);                   /* io_error */
    d[0] = -1;                             /* ? */
  }
}


/*==============*/
/* fhfile_close */
/*==============*/

void fhfileClose(void) {
  wril(fetl(a[6] + 32) - 1, a[6] + 32);    /* LIB_OPENCNT */
  d[0] = 0;                                /* ? */
}


/*================*/
/* fhfile_expunge */
/*================*/

void fhfileExpunge(void) {
  d[0] = 0;                                /* ? */
}


/*=============*/
/* fhfile_null */
/*=============*/

void fhfileNull(void) {};


/*==================*/
/* BeginIO Commands */
/*==================*/

void fhfileIgnore(ULO unit) {
  wril(0, a[1] + 32);
  d[0] = 0;
}

static void fhfileGetnumberoftracks(ULO unit) {
  wril(fhfile_tracks[unit], a[1] + 32);
}

static void fhfileGetdrivetype(ULO unit) {
  wril(1, a[1] + 32);
}

static void fhfileWriteprot(ULO unit) {
  wril(config_fhfile_writeprot[unit], a[1] + 32);
}

static LON fhfileRead(ULO unit) {
  ULO dest = fetl(a[1] + 40), offset = fetl(a[1] + 44),
      length = fetl(a[1] + 36);
  
  if ((offset + length) > fhfile_size[unit])
    return -3;
  fhfileLed(TRUE);
  fseek(fhfile_hardfile[unit], offset, SEEK_SET);
  fread(address_to_ptr(dest), 1, length, fhfile_hardfile[unit]);
  wril(length, a[1] + 32);
  fhfileLed(FALSE);
  return 0;
}

static LON fhfileWrite(ULO unit) {
  ULO dest = fetl(a[1] + 40), offset = fetl(a[1] + 44),
      length = fetl(a[1] + 36);

  if (config_fhfile_writeprot[unit] || ((offset + length) > fhfile_size[unit]))
    return -3;
  fhfileLed(TRUE);
  fseek(fhfile_hardfile[unit], offset, SEEK_SET);
  fwrite(address_to_ptr(dest),1, length, fhfile_hardfile[unit]);
  wril(length, a[1] + 32);
  fhfileLed(FALSE);
  return 0;
}


/*==========================*/
/* fhfile_beginio           */
/*==========================*/

void fhfileBeginio(void) {
  LON error = 0;
  ULO unit = fetl(a[1] + 24);

  switch (fetw(a[1] + 28)) {
    case 2:
      error = fhfileRead(unit);
      break;
    case 3:
    case 11:
      error = fhfileWrite(unit);
      break;
    case 18:
      fhfileGetdrivetype(unit);
      break;
    case 19:
      fhfileGetnumberoftracks(unit);
      break;
    case 15:
      fhfileWriteprot(unit);
      break;
    case 4:
    case 5:
    case 9:
    case 10:
    case 12:
    case 13:
    case 14:
    case 20:
    case 21:
      fhfileIgnore(unit);
      break;
    default:
      error = -3;
      d[0] = 0;
      break;
  }
  wrib(5, a[1] + 8);      /* ln_type */
  wrib(error, a[1] + 31); /* ln_error */
}


/*==========================*/
/* fhfile_abortio           */
/*==========================*/

void fhfileAbortio(void) {
  d[0] = -3;
}


/*=================================================*/
/* fhfile_do                                       */
/* The M68000 stubs entered in the device tables   */
/* write a longword to $f40000, which is forwarded */
/* by the memory system to this procedure.         */
/* Hardfile commands are issued by 0x0001XXXX      */
/*=================================================*/

void fhfileDo(ULO data) {
  switch (data & 0xffff) {
    case 1:
      fhfileDiag();
      break;
    case 2:
      fhfileOpen();
      break;
    case 3:
      fhfileClose();
      break;
    case 4:
      fhfileExpunge();
      break;
    case 5:
      fhfileNull();
      break;
    case 6:
      fhfileBeginio();
      break;
    case 7:
      fhfileAbortio();
      break;
    default:
      break;
  }
}


/*=============================================================*/
/* Open hardfile, and record some of its vital characteristics */
/*=============================================================*/

void fhfileOpenInit(void) {
  ULO size, i;
  struct stat mystat;

  for (i = 0; i < FHFILE_MAX_DEVICES; i++) {
    if (fhfile_hardfile[i])
      fclose(fhfile_hardfile[i]);
    fhfile_hardfile[i] = NULL;
    config_fhfile_status[i] = FHFILE_NONE;
    stat(config_fhfile_name[i], &mystat);
    config_fhfile_writeprot[i] = !(mystat.st_mode & S_IWUSR);
    size = mystat.st_size;
    if ((fhfile_hardfile[i] = fopen(config_fhfile_name[i],
				 (config_fhfile_writeprot[i]) ? "rb" : "r+b"))
	!= NULL) {
      if (size < (32*512)) {
	fclose(fhfile_hardfile[i]);
	fhfile_hardfile[i] = NULL;
	config_fhfile_status[i] = FHFILE_NONE;
      }
      else if (size == 901120) { /* Assume it is ADF */
	fhfile_tracks[i] = 160;
	fhfile_size[i] = size;
        config_fhfile_status[i] = FHFILE_ADF;
      }
      else {
	fhfile_tracks[i] = size/(32*512);
        fhfile_size[i] = fhfile_tracks[i]*32*512;
	config_fhfile_status[i] = FHFILE_HDF;
      }
    }
  }
}


/*=============================================*/
/* Hardfile ROM access routines, and card init */
/*=============================================*/

/*=============================*/
/* Read stubs for hardfile rom */
/*=============================*/

#pragma aux fhfileByteRead parm [ecx] value [edx];
ULO fhfileByteRead(ULO address) {
  return fhfile_rom[address & FHFILE_ROMMASK];
}

#pragma aux fhfileWordRead parm [ecx] value [edx];
ULO fhfileWordRead(ULO address) {
  return (fhfile_rom[address & FHFILE_ROMMASK] << 8) |
         fhfile_rom[(address & FHFILE_ROMMASK) + 1];
}
#pragma aux fhfileLongRead parm [ecx] value [edx];
ULO fhfileLongRead(ULO address) {
  return (fhfile_rom[(address & FHFILE_ROMMASK)] << 24) |
         (fhfile_rom[(address & FHFILE_ROMMASK) + 1] << 16) |
         (fhfile_rom[(address & FHFILE_ROMMASK) + 2] << 8) |
         fhfile_rom[(address & FHFILE_ROMMASK) + 3];
}


/*==============================*/
/* Write stubs for hardfile rom */
/*==============================*/

#pragma aux fhfileByteWrite parm [ecx] [edx];
void fhfileByteWrite(ULO address, ULO data) {
}

#pragma aux fhfileWordWrite parm [ecx] [edx];
void fhfileWordWrite(ULO address, ULO data) {
}

#pragma aux fhfileLongWrite parm [ecx] [edx];
void fhfileLongWrite(ULO address, ULO data) {
}


/*================================================================*/
/* fhfile_card_init                                               */
/* We want a configDev struct.  AmigaDOS won't give us one unless */
/* we pretend to be a expansion card.                             */
/*================================================================*/

void fhfileCardInit(void) {
  ULO i;

  addlog("FHFILE: Card Init\n");
  memoryEmemSet(0, 0xd1);
  memoryEmemSet(8, 0xc0);
  memoryEmemSet(4, 2);
  memoryEmemSet(0x10, 2011>>8);
  memoryEmemSet(0x14, 2011 & 0xf);
  memoryEmemSet(0x18, 0);
  memoryEmemSet(0x1c, 0);
  memoryEmemSet(0x20, 0);
  memoryEmemSet(0x24, 1);
  memoryEmemSet(0x28, 0x10);
  memoryEmemSet(0x2c, 0);
  memoryEmemSet(0x40, 0);
  memcpy(emem + 0x1000, fhfile_rom + 0x1000, 0xa0);
}


/*====================================================*/
/* fhfile_card_map                                    */
/* Our rom must be remapped to the location specified */
/* by Amiga OS                                        */
/*====================================================*/

void fhfileCardMap(ULO mapping) {
  ULO bank;

  addlog("FHFILE: Card Map\n");
  fhfile_romstart = (mapping<<8) & 0xff0000;
  bank = fhfile_romstart>>16;
  memoryBankSet(fhfileByteRead, fhfileWordRead, fhfileLongRead,
		fhfileByteWrite, fhfileWordWrite, fhfileLongWrite,
		fhfile_rom, bank, bank, FALSE);
}


/*=================================================*/
/* Make a dosdevice packet about the device layout */
/*=================================================*/

void fhfileMKDosdevPacketInit(ULO devno, ULO unitnameptr, ULO devnameptr) {
  if (fhfile_hardfile[devno]) {
    dsetl(devno);                   /* Flag to initcode */
    dsetl(unitnameptr);             /*  0 Device driver name "FELLOWX" */
    dsetl(devnameptr);              /*  4 Device name "fhfile.device" */
    dsetl(devno);                   /*  8 Unit # */
    dsetl(0);                       /* 12 OpenDevice flags */
    dsetl(16);                      /* 16 Environment size */
    dsetl(128);                     /* 20 Longwords in a block */
    dsetl(0);                       /* 24 sector origin (unused) */
    dsetl(1);                       /* 28 Heads */
    dsetl(1);                       /* 32 Sectors per logical block (unused) */
    if (config_fhfile_status[devno] == FHFILE_ADF) {
      dsetl(11);                    /* 36 Sectors per track */
      dsetl(2);                     /* 40 Reserved blocks, min. 1 */
    }
    else {
      dsetl(32);                    /* 36 Sectors per track */
      dsetl(1);                     /* 40 Reserved blocks, min. 1 */
    }
    dsetl(0);                       /* 44 mdn_prefac - Unused */
    dsetl(0);                       /* 48 Interleave */
    dsetl(0);                       /* 52 Lower cylinder */
    dsetl(fhfile_tracks[devno] - 1);/* 56 Upper cylinder */
    dsetl(0);                       /* 60 Number of buffers */
    dsetl(0);                       /* 64 Type of memory for buffers */
    dsetl(0x7fffffff);              /* 68 Largest transfer */
    dsetl(~1);                      /* 72 Add mask */
    dsetl(-1);                      /* 76 Boot priority */
    dsetl(0x444f5300);              /* 80 DOS file handler name */
    dsetl(0);
  }
  if (devno == (FHFILE_MAX_DEVICES - 1))
    dsetl(-1);
}


/*===========================================================*/
/* fhfile_setup                                              */
/* This will set up the device structures and stubs          */
/* Can be called at every reset, but really only needed once */
/*===========================================================*/

void fhfileSetup(void) {
  ULO devicename, idstr;
  ULO romtagstart;
  ULO initstruct, functable, datatable;
  ULO fhfile_t_init = 0;
  ULO fhfile_t_open = 0;
  ULO fhfile_t_close = 0;
  ULO fhfile_t_expunge = 0;
  ULO fhfile_t_null = 0;
  ULO fhfile_t_beginio = 0;
  ULO fhfile_t_abortio = 0;
  ULO unitnames[FHFILE_MAX_DEVICES];
  ULO doslibname;
  STR tmpunitname[32];
  ULO i;

  if (fhfile_first_time_init) {
    fhfile_first_time_init = FALSE;
    for (i = 0; i < FHFILE_MAX_DEVICES; i++) {
      config_fhfile_status[i] = FHFILE_NONE;
      fhfile_hardfile[i] = NULL;
    }
  }  
  if (config_fhfile_enabled && (config_memory_romversion >= 36)) {
    fhfileOpenInit();

    if (fhfile_hardfile == NULL)
      return;

    dmem_setcounter(0);

    /* Device-name and ID string */

    devicename = dmem_getcounter();
    dsets("fhfile.device");
    idstr = dmem_getcounter();
    dsets("Fellow Hardfile device V2");

    /* Device name as seen in Amiga DOS */

    for (i = 0; i < FHFILE_MAX_DEVICES; i++) {
      unitnames[i] = dmem_getcounter();
      sprintf(tmpunitname, "FELLOW%d", i);
      dsets(tmpunitname);
    }
      
    /* dos.library name */

    doslibname = dmem_getcounter();
    dsets("dos.library");
    
    /* fhfile.open */

    fhfile_t_open = dmem_getcounter();
    dsetw(0x23fc);
    dsetl(0x00010002); dsetl(0xf40000);     /* move.l #$00010002,$f40000 */
    dsetw(0x4e75);                          /* rts */

    /* fhfile.close */

    fhfile_t_close = dmem_getcounter();
    dsetw(0x23fc);
    dsetl(0x00010003); dsetl(0xf40000);     /* move.l #$00010003,$f40000 */
    dsetw(0x4e75);                          /* rts */

    /* fhfile.expunge */

    fhfile_t_expunge = dmem_getcounter();
    dsetw(0x23fc);
    dsetl(0x00010004); dsetl(0xf40000);     /* move.l #$00010004,$f40000 */
    dsetw(0x4e75);                          /* rts */

    /* fhfile.null */

    fhfile_t_null = dmem_getcounter();
    dsetw(0x23fc);
    dsetl(0x00010005); dsetl(0xf40000);     /* move.l #$00010005,$f40000 */
    dsetw(0x4e75);                          /* rts */

    /* fhfile.beginio */

    fhfile_t_beginio = dmem_getcounter();
    dsetw(0x23fc);
    dsetl(0x00010006); dsetl(0xf40000);     /* move.l #$00010006,$f40000 */
    dsetl(0x48e78002);                      /* movem.l d0/a6,-(a7) */
    dsetl(0x08290000); dsetw(0x001e);       /* btst   #$0,30(a1)   */
    dsetw(0x6608);                          /* bne    (to rts)     */
    dsetl(0x2c780004);                      /* move.l $4.w,a6      */
    dsetl(0x4eaefe86);                      /* jsr    -378(a6)     */
    dsetl(0x4cdf4001);                      /* movem.l (a7)+,d0/a6 */
    dsetw(0x4e75);                          /* rts */

    /* fhfile.abortio */

    fhfile_t_abortio = dmem_getcounter();
    dsetw(0x23fc);
    dsetl(0x00010007); dsetl(0xf40000);     /* move.l #$00010007,$f40000 */
    dsetw(0x4e75);                          /* rts */

    /* Func-table */

    functable = dmem_getcounter();
    dsetl(fhfile_t_open);
    dsetl(fhfile_t_close);
    dsetl(fhfile_t_expunge);
    dsetl(fhfile_t_null);
    dsetl(fhfile_t_beginio);
    dsetl(fhfile_t_abortio);
    dsetl(0xffffffff);

    /* Data-table */

    datatable = dmem_getcounter();
    dsetw(0xE000);          /* INITBYTE */
    dsetw(0x0008);          /* LN_TYPE */
    dsetw(0x0300);          /* NT_DEVICE */
    dsetw(0xC000);          /* INITLONG */
    dsetw(0x000A);          /* LN_NAME */
    dsetl(devicename);
    dsetw(0xE000);          /* INITBYTE */
    dsetw(0x000E);          /* LIB_FLAGS */
    dsetw(0x0600);          /* LIBF_SUMUSED+LIBF_CHANGED */
    dsetw(0xD000);          /* INITWORD */
    dsetw(0x0014);          /* LIB_VERSION */
    dsetw(0x0002);
    dsetw(0xD000);          /* INITWORD */
    dsetw(0x0016);          /* LIB_REVISION */
    dsetw(0x0000);
    dsetw(0xC000);          /* INITLONG */
    dsetw(0x0018);          /* LIB_IDSTRING */
    dsetl(idstr);
    dsetl(0);               /* END */

    /* bootcode */

    fhfile_bootcode = dmem_getcounter();
    dsetw(0x227c); dsetl(doslibname);      /* move.l #doslibname,a1 */
    dsetl(0x4eaeffa0);                     /* jsr    -96(a6) */
    dsetw(0x2040);                         /* move.l d0,a0 */
    dsetl(0x20280016);                     /* move.l 22(a0),d0 */
    dsetw(0x2040);                         /* move.l d0,a0 */
    dsetw(0x4e90);                         /* jsr    (a0) */
    dsetw(0x4e75);                         /* rts */
    
    /* fhfile.init */

    fhfile_t_init = dmem_getcounter();

    dsetb(0x48); dsetb(0xE7);
    dsetb(0xFF); dsetb(0xFE);
    dsetb(0x2C); dsetb(0x78);
    dsetb(0x00); dsetb(0x04);
    dsetb(0x43); dsetb(0xFA);
    dsetb(0x00); dsetb(0xA6);
    dsetb(0x4E); dsetb(0xAE);
    dsetb(0xFE); dsetb(0x68);
    dsetb(0x28); dsetb(0x40);
    dsetb(0x41); dsetb(0xFA);
    dsetb(0x00); dsetb(0xAE);
    dsetb(0x2E); dsetb(0x08);
    dsetb(0x20); dsetb(0x47);
    dsetb(0x4A); dsetb(0x90);
    dsetb(0x6B); dsetb(0x00);
    dsetb(0x00); dsetb(0x82);
    dsetb(0x58); dsetb(0x87);
    dsetb(0x20); dsetb(0x3C);
    dsetb(0x00); dsetb(0x00);
    dsetb(0x00); dsetb(0x58);
    dsetb(0x72); dsetb(0x01);
    dsetb(0x2C); dsetb(0x78);
    dsetb(0x00); dsetb(0x04);
    dsetb(0x4E); dsetb(0xAE);
    dsetb(0xFF); dsetb(0x3A);
    dsetb(0x2A); dsetb(0x40);
    dsetb(0x20); dsetb(0x47);
    dsetb(0x70); dsetb(0x54);
    dsetb(0x2B); dsetb(0xB0);
    dsetb(0x08); dsetb(0x00);
    dsetb(0x08); dsetb(0x00);
    dsetb(0x59); dsetb(0x80);
    dsetb(0x64); dsetb(0xF6);
    dsetb(0x20); dsetb(0x4D);
    dsetb(0x4E); dsetb(0xAC);
    dsetb(0xFF); dsetb(0x70);
    dsetb(0x26); dsetb(0x40);
    dsetb(0x70); dsetb(0x00);
    dsetb(0x27); dsetb(0x40);
    dsetb(0x00); dsetb(0x08);
    dsetb(0x27); dsetb(0x40);
    dsetb(0x00); dsetb(0x10);
    dsetb(0x27); dsetb(0x40);
    dsetb(0x00); dsetb(0x20);
    dsetb(0x2C); dsetb(0x78);
    dsetb(0x00); dsetb(0x04);
    dsetb(0x70); dsetb(0x14);
    dsetb(0x72); dsetb(0x00);
    dsetb(0x4E); dsetb(0xAE);
    dsetb(0xFF); dsetb(0x3A);
    dsetb(0x22); dsetb(0x47);
    dsetb(0x2C); dsetb(0x29);
    dsetb(0xFF); dsetb(0xFC);
    dsetb(0x22); dsetb(0x40);
    dsetb(0x70); dsetb(0x00);
    dsetb(0x22); dsetb(0x80);
    dsetb(0x23); dsetb(0x40);
    dsetb(0x00); dsetb(0x04);
    dsetb(0x33); dsetb(0x40);
    dsetb(0x00); dsetb(0x0E);
    dsetb(0x33); dsetb(0x7C);
    dsetb(0x10); dsetb(0xFF);
    dsetb(0x00); dsetb(0x08);
    dsetb(0x9D); dsetb(0x69);
    dsetb(0x00); dsetb(0x08);
    dsetb(0x23); dsetb(0x79);
    dsetb(0x00); dsetb(0xF4);
    dsetb(0x0F); dsetb(0xFC);
    dsetb(0x00); dsetb(0x0A);
    dsetb(0x23); dsetb(0x4B);
    dsetb(0x00); dsetb(0x10);
    dsetb(0x41); dsetb(0xEC);
    dsetb(0x00); dsetb(0x4A);
    dsetb(0x4E); dsetb(0xAE);
    dsetb(0xFE); dsetb(0xF2);
    dsetb(0x06); dsetb(0x87);
    dsetb(0x00); dsetb(0x00);
    dsetb(0x00); dsetb(0x58);
    dsetb(0x60); dsetb(0x00);
    dsetb(0xFF); dsetb(0x7A);
    dsetb(0x2C); dsetb(0x78);
    dsetb(0x00); dsetb(0x04);
    dsetb(0x22); dsetb(0x4C);
    dsetb(0x4E); dsetb(0xAE);
    dsetb(0xFE); dsetb(0x62);
    dsetb(0x4C); dsetb(0xDF);
    dsetb(0x7F); dsetb(0xFF);
    dsetb(0x4E); dsetb(0x75);
    dsetb(0x65); dsetb(0x78);
    dsetb(0x70); dsetb(0x61);
    dsetb(0x6E); dsetb(0x73);
    dsetb(0x69); dsetb(0x6F);
    dsetb(0x6E); dsetb(0x2E);
    dsetb(0x6C); dsetb(0x69);
    dsetb(0x62); dsetb(0x72);
    dsetb(0x61); dsetb(0x72);
    dsetb(0x79); dsetb(0x00);



    /* The mkdosdev packets */

    for (i = 0; i < FHFILE_MAX_DEVICES; i++)
      fhfileMKDosdevPacketInit(i, unitnames[i], devicename);

    /* Init-struct */

    initstruct = dmem_getcounter();
    dsetl(0x100);                   /* Data-space size, min LIB_SIZE */
    dsetl(functable);               /* Function-table */
    dsetl(datatable);               /* Data-table */
    dsetl(fhfile_t_init);           /* Init-routine */

    /* RomTag structure */

    romtagstart = dmem_getcounter();
    dsetw(0x4afc);                  /* Start of structure */
    dsetl(romtagstart);             /* Pointer to start of structure */
    dsetl(romtagstart+26);          /* Pointer to end of code */
    dsetb(0x81);                    /* Flags, AUTOINIT+COLDSTART */
    dsetb(0x1);                     /* Version */
    dsetb(3);                       /* DEVICE */
    dsetb(0);                       /* Priority */
    dsetl(devicename);              /* Pointer to name (used in opendev)*/
    dsetl(idstr);                   /* ID string */
    dsetl(initstruct);              /* Init_struct */

    /* Clear hardfile rom */

    memset(fhfile_rom, 0, FHFILE_ROMSIZE);

    /* Struct DiagArea */
  
    fhfile_rom[0x1000] = 0x90; /* da_Config */
    fhfile_rom[0x1001] = 0;    /* da_Flags */
    fhfile_rom[0x1002] = 0;    /* da_Size */
    fhfile_rom[0x1003] = 0x96;
    fhfile_rom[0x1004] = 0;    /* da_DiagPoint */
    fhfile_rom[0x1005] = 0x80;
    fhfile_rom[0x1006] = 0;    /* da_BootPoint */
    fhfile_rom[0x1007] = 0x90;
    fhfile_rom[0x1008] = 0;    /* da_Name */
    fhfile_rom[0x1009] = 0;
    fhfile_rom[0x100a] = 0;    /* da_Reserved01 */
    fhfile_rom[0x100b] = 0;
    fhfile_rom[0x100c] = 0;    /* da_Reserved02 */
    fhfile_rom[0x100d] = 0;
    
    fhfile_rom[0x1080] = 0x23; /* DiagPoint */
    fhfile_rom[0x1081] = 0xfc; /* move.l #$00010001,$f40000 */
    fhfile_rom[0x1082] = 0x00;
    fhfile_rom[0x1083] = 0x01;
    fhfile_rom[0x1084] = 0x00;
    fhfile_rom[0x1085] = 0x01;
    fhfile_rom[0x1086] = 0x00;
    fhfile_rom[0x1087] = 0xf4;
    fhfile_rom[0x1088] = 0x00;
    fhfile_rom[0x1089] = 0x00;
    fhfile_rom[0x108a] = 0x4e; /* rts */
    fhfile_rom[0x108b] = 0x75;

    fhfile_rom[0x1090] = 0x4e; /* BootPoint */
    fhfile_rom[0x1091] = 0xf9; /* JMP fhfile_bootcode */
    fhfile_rom[0x1092] = fhfile_bootcode>>24;
    fhfile_rom[0x1093] = fhfile_bootcode>>16;
    fhfile_rom[0x1094] = fhfile_bootcode>>8;
    fhfile_rom[0x1095] = fhfile_bootcode;

    /* NULLIFY pointer to configdev */
    
    dmem[4092] = 0;
    dmem[4093] = 0;
    dmem[4094] = 0;
    dmem[4095] = 0;
    
    memoryEmemCardAdd(fhfileCardInit, fhfileCardMap);
  }
  else
    dmem_clear();
}



