/*================================*/
/* Fellow Amiga Emulator          */
/* Soundblaster specific routines */
/* (C) 1996-1998 Petter Schau     */
/*================================*/


#include <stdio.h>
#include <dos.h>
#include <stdlib.h>
#include <conio.h>
#include "defs.h"
#include "sound.h"
#include "memory.h"
#include "keyboard.h"
#include "draw.h"
#include "sblasta.h"            /* Symbols defined in sblasta.asm */
#include "inout.h"

#ifdef WITH_OS_SOUND

BOOLE config_sb_forceV1;          /* Force using soundblaster V1 code */
ULO actualrate;


/*=====================================*/
/* Soundblaster hardware configuration */
/*=====================================*/

LON sb_io;
LON sb_irq;
LON sb_dma8;
LON sb_dma16;
LON sb_dspmajor;
LON sb_dspminor;


/*=============================================*/
/* Run-time information about current playback */
/*=============================================*/

typedef void (*sbPlayFunc)(void);
UBY *sb_PB_buffer;           /* Location to put next sample */
UBY *sb_PB_buffers[2];       /* Buffers for play and edit */
BOOLE sb_PB_16bits;          /* 16-bit playback */
BOOLE sb_PB_stereo;          /* Stereo playback */
BOOLE sb_PB_DMA_single;      /* Single cycle or auto init DMA */
ULO sb_PB_edit;              /* Current edit buffer */			       
ULO sb_PB_play;              /* Current play buffer */
volatile BOOLE sb_PB_IRQ;    /* IRQ has occured flag */
ULO sb_PB_playcmd16;         /* Command byte for DSP V4 */
ULO sb_PB_playmode16;        /* Mode byte for DSP V4 */
ULO sb_PB_playlength;        /* Number of samples - 1 */
ULO sb_PB_timeconstant;      /* Time-constant for current playback */
ULO sb_PB_rate;              /* Actual output sample rate */
ULO sb_PB_DMA_length;        /* Length fed to DMA controller */
UBY *sb_PB_DMA_buffer[2];    /* Address used to program DMA */
ULO sb_PB_DMA_page[2];       /* Page number for each buffer */
ULO sb_PB_DMA_channel;       /* DMA Channel used for playback */
BOOLE sb_PB_DMA_16bits;      /* DMA Channel is 16 bits wide */
sbPlayFunc sb_PB_playFunc;   /* Routine to play sound */
BOOLE sb_PB_waiting;

/*======================================*/
/* Information about previous IRQ setup */
/*======================================*/

void (__interrupt __far *sb_IRQ_vector_old)();
ULO sb_IRQ_mask1_old;  
ULO sb_IRQ_mask2_old;


/*========================*/
/* DMA buffer information */
/*========================*/

UBY *dmaflataddr;   /* 64K aligned pointer we use for buffers */
ULO dmapage;        /* Page number for the 64K aligned memory */
ULO dmaselector;    /* Selector for allocated memory, used when freeing it */


/*====================================*/
/* Various lookup tables for SB setup */
/*====================================*/

/* Playcmd for DSP V4 [BITS] */ 

ULO sb_playcmd16tab[2] = {0xc6, 0xb6};

/* Playmode for DSP V4 [CHANNELS][BITS] */

ULO sb_playmode16tab[2][2] = {0x00, 0x10, 0x20, 0x30};

/* SB Real rate, opposed to requested rate [RATE] */

ULO sb_realratetab[4] = {15650, 21739, 31300, 43478};

/* Rates:  192 = 15625 hz (Mono on V1,2,3,4  Stereo on V4) */
/*         210 = 21739 hz (Mono on V1,2,3,4  Stereo on V4) */
/*         224 = 31250 hz (Mono on V2.01,3,4  Stereo on V4) */
/*         233 = 43478 hz (Mono on V2.01,3,4  Stereo on V4) */
/*         224 = 15625 hz (Stereo on V3)                    */
/*         233 = 21739 hz (Stereo on V3)                    */

/* 45454 is possible on some cards, but not all, so it is   */
/* not used anymore                                         */

/* SB Timeconstant for DSP != V3 [RATE] */

ULO sb_timeconstantV1tab[4] = {192, 210, 224, 233};

/* SB Timeconstant for DSP V3 (PRO) [CHANNELS][RATE] */

ULO sb_timeconstantV3tab[2][4] = {192, 210, 224, 233, /* Mono */
	                          224, 233,   0,   0  /* Stereo */};


/*================================================*/
/* Callbacks to add samples to the dma-buffer     */
/* C-implementation of original assembly routines */
/*================================================*/

#ifdef SOUND_C

void sb8BitMonoSampleAdd(ULO samples) {
  ULO i;

  for (i = 0; i < samples; i++)
    *(sb_PB_buffer + i) = ((left[i] + right[i])>>8) + 0x80;
  sb_PB_buffer += samples;
}

void sb8BitStereoSampleAdd(ULO samples) {
  ULO i;

  for (i = 0; i < samples; i++) {
    *(sb_PB_buffer + i) = (left[i]>>8) + 0x80;
    *(sb_PB_buffer + i + 1) = (right[i]>>8) + 0x80;
    }
  sb_PB_buffer += samples*2;
}

void sb16BitMonoSampleAdd(ULO samples) {
  ULO i;

  for (i = 0; i < samples; i++)
    *(((WOR *) sb_PB_buffer) + i) = left[i] + right[i];
  sb_PB_buffer += samples*2;
}

void sb16BitStereoSampleAdd(ULO samples) {
  ULO i;

  for (i = 0; i < samples; i++) {
    *(((WOR *) sb_PB_buffer) + 2*i) = left[i];
    *(((WOR *) sb_PB_buffer) + 2*i + 2) = right[i];
    }
  sb_PB_buffer += samples*4;
}

#endif


/*===========*/
/* DMA setup */
/*===========*/


/*---------------*/
/* DMA-registers */
/*---------------*/

#define SINGLE_MASK_8           0xa
#define SINGLE_MASK_16          0xd4
#define CLEAR_BYTEPTR_8         0xc
#define CLEAR_BYTEPTR_16        0xd8
#define SET_MODE_8              0xb
#define SET_MODE_16             0xd6
#define SET_PAGENR_CH0          0x87
#define SET_PAGENR_CH1          0x83
#define SET_PAGENR_CH2          0x81
#define SET_PAGENR_CH3          0x82
#define SET_PAGENR_CH4          0x8f
#define SET_PAGENR_CH5          0x8b
#define SET_PAGENR_CH6          0x89
#define SET_PAGENR_CH7          0x8a

ULO dmapagetab[8] = {SET_PAGENR_CH0, SET_PAGENR_CH1,
		     SET_PAGENR_CH2, SET_PAGENR_CH3,
		     SET_PAGENR_CH4, SET_PAGENR_CH5,
		     SET_PAGENR_CH6, SET_PAGENR_CH7};


/*-----------*/
/* DMA-modes */
/*-----------*/

#define DMA_MODE_READ           0x8
#define DMA_MODE_AUTOINIT       0x10
#define DMA_MODE_SINGLE         0x40


/*=====================*/
/* Mask single channel */
/*=====================*/

#define dmaChannelMask(ch) outp((ch < 4) ? SINGLE_MASK_8 : SINGLE_MASK_16, ch | 4);


/*========================*/
/* Clear byte ptr         */
/* (any value will clear) */
/*========================*/

#define dmaBytePtrClear(ch) outp((ch < 4) ? CLEAR_BYTEPTR_8 : CLEAR_BYTEPTR_16, 0);


/*==============*/
/* Set dma-mode */
/*==============*/

#define dmaModeSet(ch) outp((ch<4)?SET_MODE_8:SET_MODE_16,(ch&3) | DMA_MODE_READ | ((sb_PB_DMA_single) ? DMA_MODE_SINGLE : DMA_MODE_AUTOINIT));


/*=================*/
/* Set page number */
/*=================*/

#define dmaPageNrSet(ch) outp(dmapagetab[ch], sb_PB_DMA_page[sb_PB_play]);


/*=============*/
/* Set address */
/*=============*/

#define dmaAddressSet(ch) {\
  ULO cmd = (ch < 4) ? (ch<<1) : (0xc0 | ((ch & 3)<<2));\
  outp(cmd, ((ULO) sb_PB_DMA_buffer[sb_PB_play]) & 0xFF);\
  outp(cmd, ((ULO) sb_PB_DMA_buffer[sb_PB_play])>>8);\
}


/*============*/
/* Set length */
/*============*/

#define dmaLengthSet(ch) {\
  ULO cmd = (ch < 4) ? ((ch<<1) | 1) : (0xc2 | ((ch & 3)<<2));\
  outp(cmd, sb_PB_DMA_length & 0xff);\
  outp(cmd, sb_PB_DMA_length>>8);\
}


/*========================*/
/* Un-Mask single channel */
/*========================*/

#define dmaChannelUnmask(ch) outp((ch < 4) ? SINGLE_MASK_8 : SINGLE_MASK_16, ch & 3);


/*=======================*/
/* Set up a DMA transfer */
/*=======================*/

#define dmaTransferInit(void) {\
  dmaChannelMask(sb_PB_DMA_channel);\
  dmaBytePtrClear(sb_PB_DMA_channel);\
  dmaModeSet(sb_PB_DMA_channel);\
  dmaPageNrSet(sb_PB_DMA_channel);\
  dmaAddressSet(sb_PB_DMA_channel);\
  dmaLengthSet(sb_PB_DMA_channel);\
  dmaChannelUnmask(sb_PB_DMA_channel);\
}


/*==================*/
/* SB SPECIFIC CODE */
/*==================*/


/*==============*/
/* SB Registers */
/*==============*/

#define SB_MIXER_REG            4
#define SB_MIXER_DATA           5
#define SB_DSP_RESET            6
#define SB_DSP_READ_DATA        0xa
#define SB_DSP_WRITE            0xc
#define SB_DSP_DATA_AVAILABLE   0xe
#define SB_DSP_IRQ_ACK_8        0xe
#define SB_DSP_IRQ_ACK_16       0xf


/*==============*/
/* DSP commands */
/*==============*/

#define DSP_SET_TIMECONSTANT    0x40   /* ALL */
#define DSP_ENABLE_SPEAKER      0xd1   /* ALL */
#define DSP_DISABLE_SPEAKER     0xd3   /* ALL */
#define DSP_SET_DMA_BLOCK_SIZE  0x48   /* V2, V2.01, V3, V4 */
#define DSP_AUTO_HI_DMA_DAC     0x90   /* V2.01, V3 */
#define DSP_SINGLE_HI_DMA_DAC   0x91   /* V2.01, V3 */
#define DSP_DMA_DAC             0x14   /* ALL */
#define DSP_VERSION             0xe1   /* ALL */
#define DSP_HALT_8              0xd0   /* ALL */
#define DSP_CONTINUE_8          0xd4   /* ALL */
#define DSP_HALT_16             0xd5   /* V4 */
#define DSP_CONTINUE_16         0xd6   /* V4 */
#define DSP_AUTO_LO_DMA_DAC     0x1c   /* V2, V2.01, V3, V4 */
#define DSP_AUTO_EXIT_8         0xda   /* V2, V2.01, V3, V4 */
#define DSP_AUTO_EXIT_16        0xd9   /* V4 */


/*================*/
/* Mixer commands */
/*================*/

#define MIXER_OUTPUT_STEREO_SELECT      0xe


/*==================*/
/* Read DSP command */
/*==================*/

static ULO sbCMDRead(void) {
  while (!(inp(sb_io + SB_DSP_DATA_AVAILABLE) & 0x80));
  return inp(sb_io + SB_DSP_READ_DATA);
}


/*===================*/
/* Write DSP command */
/*===================*/

static void sbCMDWrite(UBY val) {
  while ((inp(sb_io + SB_DSP_WRITE) & 0x80));
  outp(sb_io + SB_DSP_WRITE, val);
}


/*====================*/
/* Read Mixer command */
/*====================*/

static ULO sbMixerRead(ULO reg) {
  outp(sb_io + SB_MIXER_REG, reg);
  return inp(sb_io + SB_MIXER_DATA);
}


/*=====================*/
/* Write Mixer command */
/*=====================*/

static void sbMixerWrite(ULO reg, ULO val) {
  outp(sb_io + SB_MIXER_REG, reg);
  outp(sb_io + SB_MIXER_DATA, val);
}


/*================*/
/* Speaker output */
/*================*/

static void sbSpeakerEnable(void) {
  sbCMDWrite(DSP_ENABLE_SPEAKER);        
}

static void sbSpeakerDisable(void) {
  sbCMDWrite(DSP_DISABLE_SPEAKER);        
}


/*================================================================*/
/* Pause DMA, common for all DSP, both auto-init and single-cycle */
/*================================================================*/

static __inline void sbDMAHalt(void) {
  if (sb_PB_DMA_16bits)
    sbCMDWrite(DSP_HALT_16);
  else
    sbCMDWrite(DSP_HALT_8);
}


/*===================================================================*/
/* Continue DMA, common for all DSP, both auto-init and single-cycle */
/*===================================================================*/

static __inline void sbDMAContinue(void) {
  if (sb_PB_DMA_16bits)
    sbCMDWrite(DSP_CONTINUE_16);
  else
    sbCMDWrite(DSP_CONTINUE_8);
}


/*====================*/
/* Exit Auto-init DMA */
/*====================*/

static __inline void sbDMAAutoExit(void) {
  if (sb_PB_DMA_16bits)
    sbCMDWrite(DSP_AUTO_EXIT_16);
  else
    sbCMDWrite(DSP_AUTO_EXIT_8);
}


/*=================*/
/* Acknowledge IRQ */
/*=================*/

static __inline void sbIRQAcknowledge(void) {
  if (sb_PB_16bits)
    inp(sb_io + SB_DSP_IRQ_ACK_16);    /* Clear SB-irq source */
  else
    inp(sb_io + SB_DSP_IRQ_ACK_8);
}


/*====================*/
/* Play on SB V1      */
/* Using single cycle */
/*====================*/

static void sbPlayV1(void) {
  sbCMDWrite(DSP_DMA_DAC);                 /* Start low-speed DMA */
  sbCMDWrite(sb_PB_playlength & 0xff);     /* DMA size */
  sbCMDWrite(sb_PB_playlength>>8);
}


/*========================*/
/* Play on SB PRO and V2  */
/* Using lospeed autoinit */
/* and hispeed single     */
/*========================*/

static void sbPlayPRO(void) {
  if (sb_PB_stereo || ((!sb_PB_stereo) && (sb_PB_rate > 23000))) {
    sbCMDWrite(DSP_SET_DMA_BLOCK_SIZE);
    sbCMDWrite(sb_PB_playlength & 0xff);
    sbCMDWrite(sb_PB_playlength>>8);
    sbCMDWrite(DSP_SINGLE_HI_DMA_DAC);     
  }
  else
    sbPlayV1();
}


/*================*/
/* Play on SB 16  */
/* Using autoinit */
/*================*/

static void sbPlay16(void) {
  sbCMDWrite(sb_PB_playcmd16);  
  sbCMDWrite(sb_PB_playmode16);
  sbCMDWrite(sb_PB_playlength & 0xff);
  sbCMDWrite(sb_PB_playlength>>8);
}


/*========================*/
/* Start playing a buffer */
/*========================*/

static void sbStartPlayingBuffer(void) {
  dmaTransferInit(); 
  (*sb_PB_playFunc)();
}


/*=================================*/
/* Free DOS-memory used for buffer */
/*=================================*/

static void sbBufferFree (void) {
  static union REGS reg;
  reg.x.eax = 0x0101;
  reg.x.edx = dmaselector;
  int386(0x31, &reg, &reg);
}


/*=====================================*/
/* Allocate DOS-memory used for buffer */
/*=====================================*/

static BOOLE sbBufferAllocate(ULO size) {
  UBY *addr;
  static union REGS reg;

  reg.x.eax = 0x0100;                        /* DPMI Mem. Allocation */
  reg.x.ebx = ((size*2) + 15)>>4;            /* # of paragraphs to alloc. */
  int386(0x31, &reg, &reg);            
  dmaflataddr = NULL;
  if (reg.x.cflag)
    return FALSE;                            /* error alloc. mem. */
  dmaselector = reg.x.edx;                   /* get the base selector */
  addr = (UBY *) ((reg.x.eax & 0xFFFF)<<4);  /* get the real segment adress */
  if ((((ULO)addr)>>16) != ((((ULO)addr) + size - 1)>>16))
    addr = (UBY *) (((ULO) addr + size) & 0xffff0000);
  dmaflataddr = addr;                        /* get the 20 bit real adress */
  dmapage = ((ULO) dmaflataddr)>>16;
  return TRUE;
}


/*=========================*/
/* Clear the sound-buffers */
/*=========================*/

static void sbBufferClear(void) {
  if (dmaflataddr)
    memset(dmaflataddr, (sound_bits == SOUND_8BITS) ? 128 : 0, 65536);
}


/*===========*/
/* Reset DSP */
/*===========*/

static int sbDSPReset(void) {
  outp(sb_io + SB_DSP_RESET, 1);   /* write 1 to reset port */
  delay(100);
  outp(sb_io + SB_DSP_RESET, 0);   /* write 0 to reset port */
  delay(100);
  return !(inp(sb_io + SB_DSP_READ_DATA) == 0xaa); 
}


/*=============*/
/* Irq handler */
/*=============*/

void __interrupt __far sbIRQHandler() {
  sb_PB_IRQ = TRUE;
  if (!sb_PB_waiting && !sb_PB_DMA_single)
    sbDMAHalt();
  sbIRQAcknowledge();
  if (sb_PB_waiting && sb_PB_DMA_single)
    sbStartPlayingBuffer();
#ifdef WITH_OS_TIMER
  timerFPSCalculate();
#endif
  if (sb_irq > 7)
    outp(0xA0, 0x20);                  /* Clear PIC */
  outp(0x20, 0x20);
}


/*==============================================*/
/* Initialize the irq-vector and enable the irq */
/*==============================================*/

void sbIRQInit(void) {
  lock_region((void near *) sbIRQHandler, 1024);
#ifdef WITH_OS_TIMER
  lock_region(&fps, sizeof(fps));
#endif
  lock_region(&frames, sizeof(frames));
  lock_region(&xpos, sizeof(xpos));
  lock_region(&ypos, sizeof(ypos));
  lock_region(&sb_PB_IRQ, sizeof(sb_PB_IRQ));
  lock_region(&sb_PB_16bits, sizeof(sb_PB_16bits));
  lock_region(&sb_io, sizeof(sb_io));
  if (sb_irq < 8) {
    sb_IRQ_vector_old = _dos_getvect(sb_irq + 8);
    _dos_setvect(sb_irq + 8, sbIRQHandler);
    sb_IRQ_mask1_old = inp(0x21) & (1<<sb_irq);
    outp(0x21, (inp(0x21) & ~(1<<sb_irq)));
    }
  else {
    sb_IRQ_vector_old = _dos_getvect(sb_irq + 0x68);
    _dos_setvect(sb_irq + 0x68, sbIRQHandler);
    sb_IRQ_mask2_old = inp(0xa1) & (1<<(sb_irq - 8));
    outp(0xa1, (inp(0xa1) & ~(1<<(sb_irq - 8))));
    }
}


/*==========================================*/
/* Set old irq-vector, and set old irq-mask */
/*==========================================*/

void sbIRQRestore(void) {
  if (sb_irq < 8) {
    if (sb_IRQ_mask1_old)
      outp(0x21, (inp(0x21) | sb_IRQ_mask1_old));
    _dos_setvect(sb_irq + 8, sb_IRQ_vector_old);
    }
  else {
    if (sb_IRQ_mask2_old)
      outp(0xa1, (inp(0xa1) | sb_IRQ_mask2_old));
    _dos_setvect(sb_irq + 0x68, sb_IRQ_vector_old);
    }
  unlock_region((void near *)sbIRQHandler, 1024);
#ifdef WITH_OS_TIMER
  unlock_region(&fps, sizeof(fps));
#endif
  unlock_region(&frames, sizeof(frames));
  unlock_region(&xpos, sizeof(xpos));
  unlock_region(&ypos, sizeof(ypos));
  unlock_region(&sb_PB_IRQ, sizeof(sb_PB_IRQ));
  unlock_region(&sb_PB_16bits, sizeof(sb_PB_16bits));
  unlock_region(&sb_io, sizeof(sb_io));
}


/*=======================================================*/
/* Return value of 'tmp' setting, or -1 if it is missing */
/*=======================================================*/

static LON sbBLASTERScan(STR tmp, STR *env) {
  STR cpy[5];
  ULO i = 0, retval;

  while (*(env + i) != 0 && toupper(*(env + i)) != toupper(tmp))
    i++;
  if (*(env+i) == 0)
    retval = -1;
  else {
    env += i + 1; i = 0;
    while ( *(env+i) != 0 && *(env+i) != ' ' ) {
      cpy[i] = *(env+i);
      i++;
      }
    cpy[i] = 0;
    retval = atoi(cpy);
    }
  return retval;
}


/*==========================*/
/* Return TRUE if all is OK */
/*==========================*/

static BOOLE sbBLASTERExamine(void) {
  STR *envvar;
  STR trans[20], o[80];
  BOOLE retval;

  if ((envvar = getenv("BLASTER")) != NULL) {
    sb_io = sbBLASTERScan('A', envvar);
    sb_irq = sbBLASTERScan('I', envvar);
    sb_dma8 = sbBLASTERScan('D', envvar);
    sb_dma16 = sbBLASTERScan('H', envvar);
    sprintf(trans,"%d\n", sb_io);
    sscanf(trans,"%X\n", &sb_io);

    addlog("SB: Result of BLASTER search:\n");
    sprintf(o,"SB: sbio = %X\n", sb_io);
    addlog(o);
    sprintf(o,"SB: sbirq = %d\n", sb_irq);
    addlog(o);
    sprintf(o,"SB: sbdma8 = %d\n", sb_dma8);
    addlog(o);
    sprintf(o,"SB: sbdma16 = %d\n", sb_dma16);
    addlog(o);

    if (sb_io == -1 || sb_irq == -1 || sb_dma8 == -1) {
      addlog("SB: ERROR - Vital information missing in BLASTER variable\n");
      addlog("SB: ERROR - Playback disabled\n");
      retval = FALSE;
    }
    else
      retval = TRUE;
  }
  else
    retval = FALSE;          /* No BLASTER env-var at all */
  return retval;
}


ULO playstartedf;
ULO playstartedx;
ULO playstartedy;
ULO playfirsttime = TRUE;


/*===================================*/
/* Test irq, switch buffers and play */
/*===================================*/

static void sbPlay(void) {
  sb_PB_edit = (sb_PB_edit + 1) & 1;
  sb_PB_play = (sb_PB_play + 1) & 1;
  if ((sb_PB_edit == 0) || sb_PB_DMA_single)
    sb_PB_buffer = sb_PB_buffers[sb_PB_edit];
  if (playfirsttime) {
    playstartedf = frames;
    playstartedx = xpos;
    playstartedy = ypos;
    playfirsttime = FALSE;
  }
  sbStartPlayingBuffer();
  sb_PB_IRQ = FALSE;
  sb_PB_waiting = FALSE;
}

#pragma aux sbCriticalStart = "cli";
#pragma aux sbCriticalEnd = "sti";


void sbTestAndPlay(void) {
  sbCriticalStart();
  if (!sb_PB_IRQ) {          /* IRQ has not happened, yet */
    sb_PB_waiting = TRUE;    /* Tell IRQ that data is ready */
    sbCriticalEnd();
    while (!f12pressed && !sb_PB_IRQ);  /* Now just wait for IRQ (synch) */
    sb_PB_waiting = FALSE;
  }
  else { /* IRQ has already happened, must restart DMA */
    sbCriticalEnd();
    if (sb_PB_DMA_single)
      sbStartPlayingBuffer();
    else
      sbDMAContinue();
  }
  sb_PB_IRQ = FALSE;
  sb_PB_edit = (sb_PB_edit + 1) & 1;
  sb_PB_play = (sb_PB_play + 1) & 1;
  if ((sb_PB_edit == 0) || sb_PB_DMA_single)
    sb_PB_buffer = sb_PB_buffers[sb_PB_edit];
}


/*=======================================================*/
/* Set up a sound-mode                                   */
/*                                                       */
/* For internal use                                      */
/*=======================================================*/

void sbModeSet(void) {
  ULO bufferlength;
  
  sb_PB_stereo = sound_channels;                      /* Stereo flag */
  sb_PB_16bits = sound_bits;                          /* 16bits flag */
  sb_PB_edit = 0;                                     /* Buffer to edit */
  sb_PB_play = 1;                                     /* Buffer to play */
  sb_PB_IRQ = FALSE;                                  /* No IRQ, yet */
  sb_PB_rate = sb_realratetab[sound_rate];            /* Real output rate */
  bufferlength = (sb_PB_rate/50)*sound_buffer_depth;  /* Base length */
  bufferlength *= (sb_PB_stereo + 1);                 /* Stereo adjust */
  bufferlength *= (sb_PB_16bits + 1);                 /* 16 bit adjust */
  sb_PB_buffers[0] = dmaflataddr;                     /* Set edit and play */
  sb_PB_buffers[1] = dmaflataddr + bufferlength;      /* buffers.          */
  if (sb_dspmajor >= 4) {
    sb_PB_playFunc = sbPlay16;
    sb_PB_DMA_single = FALSE;
    sb_PB_timeconstant = sb_timeconstantV1tab[sound_rate];
  }
  else if (sb_dspmajor == 1) {
    sb_PB_playFunc = sbPlayV1;
    sb_PB_DMA_single = TRUE; /* V1 has no auto-init mode */
    sb_PB_timeconstant = sb_timeconstantV1tab[sound_rate];
  }
  else {
    sb_PB_playFunc = sbPlayPRO;
    /*    sb_PB_DMA_single = sb_PB_stereo ||
		       ((!sb_PB_stereo) && (sb_PB_rate >= 23000));*/
    sb_PB_DMA_single = TRUE;
    sb_PB_timeconstant = sb_timeconstantV3tab[sb_PB_stereo][sound_rate];
  }
  if (sb_PB_DMA_single)
    sb_PB_buffers[1] += 256;
  sb_PB_buffer = sb_PB_buffers[0];                    /* Set current bufptr */
  if (sb_PB_16bits) {                                 /* Select DMA channel */
    if (sb_dma16 >= 4)
      sb_PB_DMA_channel = sb_dma16;
    else
      sb_PB_DMA_channel = sb_dma8;
  }
  else
    sb_PB_DMA_channel = sb_dma8;
  sb_PB_DMA_16bits = (sb_PB_DMA_channel >= 4);        /* DMA channel size */  
  sb_PB_DMA_page[0] = sb_PB_DMA_page[1] = dmapage;    /* DMA page */
  sb_PB_DMA_length = ((bufferlength*(!sb_PB_DMA_single + 1))>>sb_PB_DMA_16bits) - 1; /* DMA length */
  sb_PB_playlength = (bufferlength>>sb_PB_DMA_16bits) - 1;
  sb_PB_DMA_buffer[0] =
    (UBY*) ((((ULO) sb_PB_buffers[0])>>sb_PB_DMA_16bits) & 0xffff);
  sb_PB_DMA_buffer[1] =
    (UBY*) ((((ULO) sb_PB_buffers[1])>>sb_PB_DMA_16bits) & 0xffff);
  sb_PB_playcmd16 = sb_playcmd16tab[sb_PB_16bits];
  sb_PB_playmode16 = sb_playmode16tab[sb_PB_stereo][sb_PB_16bits];
  sbSpeakerEnable();
  sbCMDWrite(DSP_SET_TIMECONSTANT);
  sbCMDWrite(sb_PB_timeconstant);
  if (sb_dspmajor == 3) {
    if (sb_PB_stereo)
      sbMixerWrite(MIXER_OUTPUT_STEREO_SELECT,
		   sbMixerRead(MIXER_OUTPUT_STEREO_SELECT) | 0x2);
    else
      sbMixerWrite(MIXER_OUTPUT_STEREO_SELECT,
		   sbMixerRead(MIXER_OUTPUT_STEREO_SELECT) & 0xfd);
    }
}


/*=======================================================*/
/* Set up a sound-mode                                   */
/*                                                       */
/* For external use                                      */
/*=======================================================*/

ULO sbModeSetup(void) {
  return sb_realratetab[sound_rate];
}


/*======================================*/
/* Called before emulation is started   */
/*======================================*/

void sbEmulationStarting(void) {
  sbBufferClear();
  sbDSPReset();
  sbModeSet();
  sb_PB_waiting = FALSE;
  sbPlay();
}


/*===================================*/
/* Called after emulation is stopped */
/*===================================*/

void sbEmulationStopping(void) {
  if (sb_PB_DMA_single)
    sbDSPReset();
  else
    sbDMAAutoExit();
  sbSpeakerDisable();
}


/*==========================================================*/
/* Install various callbacks in the central sound-emulation */
/*==========================================================*/

static void sbCallbacksInit(sound_device *sd) {
  sd->bufferPlayCallback= sbTestAndPlay;
  sd->emulationStartingCallback = sbEmulationStarting;
  sd->emulationStoppingCallback = sbEmulationStopping;
  sd->sampleAddCallback[SOUND_8BITS][SOUND_MONO] = sb8BitMonoSampleAdd;
  sd->sampleAddCallback[SOUND_8BITS][SOUND_STEREO] = sb8BitStereoSampleAdd;
  sd->sampleAddCallback[SOUND_16BITS][SOUND_MONO] = sb16BitMonoSampleAdd;
  sd->sampleAddCallback[SOUND_16BITS][SOUND_STEREO]=sb16BitStereoSampleAdd;
  sd->modeSetCallback = sbModeSetup;
}


/*=================*/
/* Get DSP version */
/*=================*/

static void sbDSPID(sound_device *sd) {
  STR s[80];
  if (!config_sb_forceV1) {
    sbCMDWrite(DSP_VERSION);
    sb_dspmajor = sbCMDRead();
    sb_dspminor = sbCMDRead();
  }
  else {
    sb_dspmajor = 1;
    sb_dspminor = 0;
  }

  if (sb_dspmajor == 1 ||
      (sb_dspmajor == 2 && sb_dspminor == 0)) {
    sprintf(s, "SB: Soundblaster V1 or V2.0, (Actual V%d.%d)\n", sb_dspmajor, sb_dspminor);
    addlog(s);
    addlog("Capabilities: Mono, 8 bits, Max rate = 22050, single-cycle DMA\n");
    sd->found = TRUE;
    sd->channels[SOUND_MONO] = TRUE;
    sd->channels[SOUND_STEREO] = FALSE;
    sd->bits[SOUND_8BITS] = TRUE;
    sd->bits[SOUND_16BITS] = FALSE;
    sd->rates_max[SOUND_8BITS][SOUND_MONO] = SOUND_22050;
  }
  else if (sb_dspmajor == 2 && sb_dspminor > 0) {
    sprintf(s, "SB: Soundblaster V2.01 (Actual V%d.%d)\n", sb_dspmajor, sb_dspminor);
    addlog(s);
    addlog("Capabilities: Mono, 8 bits, Max rate = 44100, single-cycle DMA\n");
    sd->found = TRUE;
    sd->channels[SOUND_MONO] = TRUE;
    sd->channels[SOUND_STEREO] = FALSE;
    sd->bits[SOUND_8BITS] = TRUE;
    sd->bits[SOUND_16BITS] = FALSE;
    sd->rates_max[SOUND_8BITS][SOUND_MONO] = SOUND_44100;
  }
  else if (sb_dspmajor == 3) {
    sprintf(s, "SB: Soundblaster V3.X (Actual V%d.%d)\n", sb_dspmajor, sb_dspminor);
    addlog(s);
    addlog("Capabilities: Mono/Stereo, 8 bits,\n"
	   "              Max rate = 44100(Mono), 22050(Stereo),\n"
	   "              Single-cycle/Auto-init DMA\n");
    sd->found = TRUE;
    sd->channels[SOUND_MONO] = TRUE;
    sd->channels[SOUND_STEREO] = TRUE;
    sd->bits[SOUND_8BITS] = TRUE;
    sd->bits[SOUND_16BITS] = FALSE;
    sd->rates_max[SOUND_8BITS][SOUND_MONO] = SOUND_44100;
    sd->rates_max[SOUND_8BITS][SOUND_STEREO] = SOUND_22050;
  }
  else if (sb_dspmajor >= 4) {
    sprintf(s, "SB: Soundblaster V4.X (Actual V%d.%d)\n", sb_dspmajor, sb_dspminor);
    addlog(s);
    addlog("Capabilities: Mono/Stereo, 8/16 bits,\n"
	   "              Max rate = 44100\n"
	   "              Single-cycle/Auto-init DMA\n");
    sd->found = TRUE;
    sd->channels[SOUND_MONO] = TRUE;
    sd->channels[SOUND_STEREO] = TRUE;
    sd->bits[SOUND_8BITS] = TRUE;
    sd->bits[SOUND_16BITS] = TRUE;
    sd->rates_max[SOUND_8BITS][SOUND_MONO] = SOUND_44100;
    sd->rates_max[SOUND_8BITS][SOUND_STEREO] = SOUND_44100;
    sd->rates_max[SOUND_16BITS][SOUND_MONO] = SOUND_44100;
    sd->rates_max[SOUND_16BITS][SOUND_STEREO] = SOUND_44100;
  }
}


/*==========================*/
/* Top level initialization */
/*==========================*/

void sbStartup(sound_device *sd) {
  dmaflataddr = NULL;
  if (!sbBLASTERExamine()) {
    addlog("SB: Error in, or no BLASTER variable, sound off\n");
    sd->found = FALSE;
    return;
    }
  if (sbDSPReset()) {
    addlog("SB: Didn't find DSP\n");
    sd->found = FALSE;
    return;
    }
  sbDSPID(sd);
  if (!sbBufferAllocate(65536)) {
    addlog("SB: Error while allocating DMA buffer");
    sd->found = FALSE;
    return;
    }
  sbBufferClear();
  sbIRQInit();
  sbSpeakerEnable();
  sbCallbacksInit(sd);
}

void sbShutdown(void) {
  sbDSPReset();
  sbIRQrestore();
  sbBufferFree();
}

#endif
