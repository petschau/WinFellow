/*===========================*/
/* Fellow Emulator           */
/* Petter Schau 1997/1998    */
/* Keyboard DOS driver       */
/*===========================*/

#include <dos.h>
#include "defs.h"
#include "fellow.h"
#include "led.h"
#include "keycodes.h"
#include "keyboard.h"
#include "joymouse.h"


/*==========================================*/
/* Symbolic PC keycodes                     */
/* Scancodes are converted to these symbols */
/* Symbols refer to a norwegian keyboard    */
/* The names do not mean much though.       */
/*==========================================*/

#define PC_NONE         0
#define PC_ESCAPE       1
#define PC_F1           2
#define PC_F2           3
#define PC_F3           4
#define PC_F4           5
#define PC_F5           6
#define PC_F6           7
#define PC_F7           8
#define PC_F8           9
#define PC_F9           10
#define PC_F10          11
#define PC_F11          12
#define PC_F12          13
#define PC_PRINT_SCREEN 14
#define PC_SCROLL_LOCK  15
#define PC_PAUSE        16
#define PC_OR           17
#define PC_1            18
#define PC_2            19
#define PC_3            20
#define PC_4            21
#define PC_5            22
#define PC_6            23
#define PC_7            24
#define PC_8            25
#define PC_9            26
#define PC_0            27
#define PC_PLUS         28
#define PC_BACKSLASH    29
#define PC_BACKSPACE    30
#define PC_TAB          31
#define PC_Q            32
#define PC_W            33
#define PC_E            34
#define PC_R            35
#define PC_T            36
#define PC_Y            37
#define PC_U            38
#define PC_I            39
#define PC_O            40
#define PC_P            41
#define PC_AA           42
#define PC_UMLAUT       43
#define PC_RETURN       44
#define PC_CAPS_LOCK    45
#define PC_A            46
#define PC_S            47
#define PC_D            48
#define PC_F            49
#define PC_G            50
#define PC_H            51
#define PC_J            52
#define PC_K            53
#define PC_L            54
#define PC_OE           55
#define PC_AE           56
#define PC_SMALL_SLASH  57
#define PC_LEFT_SHIFT   58
#define PC_LESS_THAN    59
#define PC_Z            60
#define PC_X            61
#define PC_C            62
#define PC_V            63
#define PC_B            64
#define PC_N            65
#define PC_M            66
#define PC_COMMA        67
#define PC_DOT          68
#define PC_MINUS        69
#define PC_RIGHT_SHIFT  70
#define PC_LEFT_CTRL    71
#define PC_LEFT_ALT     72
#define PC_SPACE        73
#define PC_RIGHT_ALT    74
#define PC_RIGHT_CTRL   75
#define PC_INSERT       76
#define PC_HOME         77
#define PC_PAGE_UP      78
#define PC_DELETE       79
#define PC_END          80
#define PC_PAGE_DOWN    81
#define PC_UP           82
#define PC_LEFT         83
#define PC_DOWN         84
#define PC_RIGHT        85
#define PC_NUM_LOCK     86
#define PC_PAD_DIVIDE   87
#define PC_PAD_MULTIPLY 88
#define PC_PAD_PLUS     89
#define PC_PAD_MINUS    90
#define PC_PAD_RETURN   91
#define PC_PAD_DOT      92
#define PC_PAD_0        93
#define PC_PAD_1        94
#define PC_PAD_2        95
#define PC_PAD_3        96
#define PC_PAD_4        97
#define PC_PAD_5        98
#define PC_PAD_6        99
#define PC_PAD_7        100
#define PC_PAD_8        101
#define PC_PAD_9        102
#define PC_LEFT_WIN     103
#define PC_RIGHT_WIN    104
#define PC_MENU         105


/*===========================================================================*/
/* PC Key Names                                                              */
/* National keyboards have different print on the keys, the table below will */
/* be wrong outside Norway and Denmark....                                   */
/* If anyone decides to make their own national table, duplicate the table   */
/* below and change the corresponding text. Don't bother with the symbols    */
/* though.                                                                   */
/*===========================================================================*/

/*==============*/
/* Norway       */
/*==============*/

const char *kbdDOS_keynames_no[106] = {
  "No Key",          /* PC_NONE */
  "Escape",          /* PC_ESCAPE */
  "F1",              /* PC_F1 */
  "F2",              /* PC_F2 */
  "F3",              /* PC_F3 */
  "F4",              /* PC_F4 */
  "F5",              /* PC_F5 */
  "F6",              /* PC_F6 */
  "F7",              /* PC_F7 */
  "F8",              /* PC_F8 */
  "F9",              /* PC_F9 */
  "F10",             /* PC_F10 */
  "F11",             /* PC_F11 */
  "F12",             /* PC_F12 */
  "Print Screen",    /* PC_PRINT_SCREEN */
  "Scroll Lock",     /* PC_SCROLL_LOCK */
  "Pause",           /* PC_PAUSE */
  "|",               /* PC_OR */
  "1",               /* PC_1 */
  "2",               /* PC_2 */
  "3",               /* PC_3 */
  "4",               /* PC_4 */
  "5",               /* PC_5 */
  "6",               /* PC_6 */
  "7",               /* PC_7 */
  "8",               /* PC_8 */
  "9",               /* PC_9 */
  "0",               /* PC_0 */
  "+",               /* PC_PLUS */
  "\\",              /* PC_BACKSLASH */
  "Backspace",       /* PC_BACKSPACE  */
  "Tab",             /* PC_TAB */
  "Q",               /* PC_Q */
  "W",               /* PC_W */
  "E",               /* PC_E */
  "R",               /* PC_R */
  "T",               /* PC_T */
  "Y",               /* PC_Y */
  "U",               /* PC_U */
  "I",               /* PC_I */
  "O",               /* PC_O */
  "P",               /* PC_P */
  "AA",              /* PC_AA */
  "�",               /* PC_UMLAUT */
  "Return",          /* PC_RETURN */
  "Caps Lock",       /* PC_CAPS_LOCK */
  "A",               /* PC_A */
  "S",               /* PC_S */
  "D",               /* PC_D */
  "F",               /* PC_F */
  "G",               /* PC_G */
  "H",               /* PC_H */
  "J",               /* PC_J */
  "K",               /* PC_K */
  "L",               /* PC_L */
  "OE",              /* PC_OE */
  "AE",              /* PC_AE */
  "'",               /* PC_SMALL_SLASH */
  "Left Shift",      /* PC_LEFT_SHIFT */
  "<",               /* PC_LESS_THAN */
  "Z",               /* PC_Z */
  "X",               /* PC_X */
  "C",               /* PC_C */
  "V",               /* PC_V */
  "B",               /* PC_B */
  "N",               /* PC_N */
  "M",               /* PC_M */
  ",",               /* PC_COMMA */
  ".",               /* PC_DOT */
  "-",               /* PC_MINUS */
  "Right Shift",     /* PC_RIGHT_SHIFT */
  "Left Ctrl",       /* PC_LEFT_CTRL */
  "Left Alt",        /* PC_LEFT_ALT */
  "Space",           /* PC_SPACE */
  "Right Alt",       /* PC_RIGHT_ALT */
  "Right Ctrl",      /* PC_RIGHT_CTRL */
  "Insert",          /* PC_INSERT */
  "Home",            /* PC_HOME */
  "Page Up",         /* PC_PAGE_UP */
  "Delete",          /* PC_DELETE */
  "End",             /* PC_END */
  "Page Down",       /* PC_PAGE_DOWN */
  "Up",              /* PC_UP */
  "Left",            /* PC_LEFT */
  "Down",            /* PC_DOWN */
  "Right",           /* PC_RIGHT */
  "Num Lock",        /* PC_NUM_LOCK */
  "Keypad /",        /* PC_PAD_DIVIDE */
  "Keypad *",        /* PC_PAD_MULTIPLY */
  "Keypad +",        /* PC_PAD_PLUS */
  "Keypad -",        /* PC_PAD_MINUS */
  "Keypad Return",   /* PC_PAD_RETURN */
  "Keypad .",        /* PC_PAD_DOT */
  "Keypad 0",        /* PC_PAD_0 */
  "Keypad 1",        /* PC_PAD_1 */
  "Keypad 2",        /* PC_PAD_2 */
  "Keypad 3",        /* PC_PAD_3 */
  "Keypad 4",        /* PC_PAD_4 */
  "Keypad 5",        /* PC_PAD_5 */
  "Keypad 6",        /* PC_PAD_6 */
  "Keypad 7",        /* PC_PAD_7 */
  "Keypad 8",        /* PC_PAD_8 */
  "Keypad 9",        /* PC_PAD_9 */
  "Left Windows",    /* PC_LEFT_WIN */
  "Right Windows",   /* PC_RIGHT_WIN */
  "Menu"             /* PC_MENU */
};


/*=============================================*/
/* Translation table, scancode to symbol value */
/* No prefix first, then E0 prefix             */
/*=============================================*/

UBY kbdDOS_xlat_no[2][128] = {
  PC_NONE,        PC_ESCAPE,      PC_1,           PC_2,            /* 0  -  F */
  PC_3,           PC_4,           PC_5,           PC_6,
  PC_7,           PC_8,           PC_9,           PC_0,
  PC_PLUS,        PC_BACKSLASH,   PC_BACKSPACE,   PC_TAB,
  PC_Q,           PC_W,           PC_E,           PC_R,            /* 10 - 1F */
  PC_T,           PC_Y,           PC_U,           PC_I,
  PC_O,           PC_P,           PC_AA,          PC_UMLAUT,
  PC_RETURN,      PC_LEFT_CTRL,   PC_A,           PC_S,
  PC_D,           PC_F,           PC_G,           PC_H,            /* 20 - 2F */
  PC_J,           PC_K,           PC_L,           PC_OE,
  PC_AE,          PC_OR,        PC_LEFT_SHIFT,  PC_SMALL_SLASH,
  PC_Z,           PC_X,           PC_C,           PC_V,
  PC_B,           PC_N,           PC_M,           PC_COMMA,        /* 30 - 3F */
  PC_DOT,         PC_MINUS,       PC_RIGHT_SHIFT, PC_PAD_MULTIPLY,
  PC_LEFT_ALT,    PC_SPACE,       PC_CAPS_LOCK,   PC_F1,
  PC_F2,          PC_F3,          PC_F4,          PC_F5,
  PC_F6,          PC_F7,          PC_F8,          PC_F9,           /* 40 - 4F */
  PC_F10,         PC_NUM_LOCK,    PC_SCROLL_LOCK, PC_PAD_7,
  PC_PAD_8,       PC_PAD_9,       PC_PAD_MINUS,   PC_PAD_4,
  PC_PAD_5,       PC_PAD_6,       PC_PAD_PLUS,    PC_PAD_1,
  PC_PAD_2,       PC_PAD_3,       PC_PAD_0,       PC_PAD_DOT,      /* 50 - 5F */
  PC_NONE,        PC_NONE,        PC_LESS_THAN,   PC_F11,
  PC_F12,         PC_NONE,        PC_NONE,        PC_NONE,
  PC_NONE,        PC_NONE,        PC_NONE,        PC_NONE,
  PC_NONE,        PC_NONE,        PC_NONE,        PC_NONE,         /* 60 - 6F */
  PC_NONE,        PC_NONE,        PC_NONE,        PC_NONE,
  PC_NONE,        PC_NONE,        PC_NONE,        PC_NONE,
  PC_NONE,        PC_NONE,        PC_NONE,        PC_NONE,
  PC_NONE,        PC_NONE,        PC_NONE,        PC_NONE,         /* 70 - 7F */
  PC_NONE,        PC_NONE,        PC_NONE,        PC_NONE,
  PC_NONE,        PC_NONE,        PC_NONE,        PC_NONE,
  PC_NONE,        PC_NONE,        PC_NONE,        PC_NONE,

  PC_NONE,        PC_NONE,        PC_NONE,        PC_NONE,         /* 00 - 0F */
  PC_NONE,        PC_NONE,        PC_NONE,        PC_NONE,
  PC_NONE,        PC_NONE,        PC_NONE,        PC_NONE,
  PC_NONE,        PC_NONE,        PC_NONE,        PC_NONE,
  PC_NONE,        PC_NONE,        PC_NONE,        PC_NONE,         /* 10 - 1F */
  PC_NONE,        PC_NONE,        PC_NONE,        PC_NONE,
  PC_NONE,        PC_NONE,        PC_NONE,        PC_NONE,
  PC_PAD_RETURN,  PC_RIGHT_CTRL,  PC_NONE,        PC_NONE,
  PC_NONE,        PC_NONE,        PC_NONE,        PC_NONE,         /* 20 - 2F */
  PC_NONE,        PC_NONE,        PC_NONE,        PC_NONE,
  PC_NONE,        PC_NONE,        PC_NONE,        PC_NONE,
  PC_NONE,        PC_NONE,        PC_NONE,        PC_NONE,
  PC_NONE,        PC_NONE,        PC_NONE,        PC_NONE,         /* 30 - 3F */
  PC_NONE,        PC_PAD_DIVIDE,  PC_NONE,        PC_PRINT_SCREEN,
  PC_RIGHT_ALT,   PC_NONE,        PC_NONE,        PC_NONE,
  PC_NONE,        PC_NONE,        PC_NONE,        PC_NONE,
  PC_NONE,        PC_NONE,        PC_NONE,        PC_NONE,         /* 40 - 4F */
  PC_NONE,        PC_NONE,        PC_NONE,        PC_HOME,
  PC_UP,          PC_PAGE_UP,     PC_NONE,        PC_LEFT,
  PC_NONE,        PC_RIGHT,       PC_NONE,        PC_END,
  PC_DOWN,        PC_PAGE_DOWN,   PC_INSERT,      PC_DELETE,       /* 50 - 5F */
  PC_NONE,        PC_NONE,        PC_NONE,        PC_NONE,
  PC_NONE,        PC_NONE,        PC_NONE,        PC_LEFT_WIN,
  PC_RIGHT_WIN,   PC_MENU,        PC_NONE,        PC_NONE,
  PC_NONE,        PC_NONE,        PC_NONE,        PC_NONE,         /* 60 - 6F */
  PC_NONE,        PC_NONE,        PC_NONE,        PC_NONE,
  PC_NONE,        PC_NONE,        PC_NONE,        PC_NONE,
  PC_NONE,        PC_NONE,        PC_NONE,        PC_NONE,
  PC_NONE,        PC_NONE,        PC_NONE,        PC_NONE,         /* 70 - 7F */
  PC_NONE,        PC_NONE,        PC_NONE,        PC_NONE,
  PC_NONE,        PC_NONE,        PC_NONE,        PC_NONE,
  PC_NONE,        PC_NONE,        PC_NONE,        PC_NONE};


/*==================================================*/
/* This figure shows the symolic name for each key. */
/* Based on a Norwegian 102 key keyboard.           */
/*==================================================*/

/*=================================================================================================================================================================================================================================================================*/
/* ------------          ---------------------------------------------     ---------------------------------------------    ---------------------------------------------     ----------------------------------                                                   */
/* |  ESCAPE  |          |    F1    |    F2    |    F3    |    F4    |     |    F5    |    F6    |    F7    |    F8    |    |    F9    |    F10   |    F11   |    F12   |     |  PRINT_  |  SCROLL_ |  PAUSE   |                                                   */
/* |          |          |          |          |          |          |     |          |          |          |          |    |          |          |          |          |     |  SCREEN  |   LOCK   |          |                                                   */
/* |    01    |          |    3B    |    3C    |    3D    |    3E    |     |    3F    |    40    |    41    |    42    |    |    43    |    44    |    57    |    58    |     |  E0 37   |    46    | E1 1D 45 |                                                   */
/* ------------          ---------------------------------------------     ---------------------------------------------    ---------------------------------------------     ----------------------------------                                                   */
/*                                                                                                                                                                                                                                                                 */
/* ----------------------------------------------------------------------------------------------------------------------------------------------------------------------     ----------------------------------     --------------------------------------------- */
/* |    OR    |    1     |    2     |    3     |    4     |    5     |    6     |    7     |    8     |    9     |    0     |   PLUS   | BACKSLASH|     BACKSPACE       |     |  INSERT  |   HOME   | PAGE_UP  |     | NUM_LOCK |   PAD_   |   PAD_   |   PAD_   | */
/* |          |          |          |          |          |          |          |          |          |          |          |          |          |                     |     |          |          |          |     |          |  DIVIDE  | MULTIPLY |  MINUS   | */
/* |    29    |    02    |    03    |    04    |    05    |    06    |    07    |    08    |    09    |    0A    |    0B    |    0C    |    0D    |         0E          |     |  E0 52   |  E0 47   |  E0 49   |     |    45    |  E0 35   |    37    |    4A    | */
/* ----------------------------------------------------------------------------------------------------------------------------------------------------------------------     ----------------------------------     --------------------------------------------- */
/* |      TAB      |    Q     |    W     |    E     |    R     |    T     |    Y     |    U     |    I     |    O     |    P     |    AA    |  UMLAUT  |     RETURN     |     |  DELETE  |   END    |PAGE_DOWN |     |  PAD_7   |  PAD_8   |  PAD_9   | PAD_PLUS | */
/* |               |          |          |          |          |          |          |          |          |          |          |          |          |                |     |          |          |          |     |          |          |          |          | */
/* |      0F       |    10    |    11    |    12    |    13    |    14    |    15    |    16    |    17    |    18    |    19    |    1A    |    1B    |       1C       |     |  E0 53   |  E0 4F   |  E0 51   |     |    47    |    48    |    49    |    4E    | */
/* -------------------------------------------------------------------------------------------------------------------------------------------------------              |     ----------------------------------     ---------------------------------|          | */
/* |    CAPS_LOCK    |    A     |    S     |    D     |    F     |    G     |    H     |    J     |    K     |    L     |    OE    |    AE    |  SMALL_  |              |                                            |  PAD_4   |  PAD_5   |  PAD_6   |          | */
/* |                 |          |          |          |          |          |          |          |          |          |          |          |  SLASH   |              |                                            |          |          |          |          | */
/* |       3A        |    1E    |    1F    |    20    |    21    |    22    |    23    |    24    |    25    |    26    |    27    |    28    |    2B    |              |                                            |    4B    |    4C    |    4D    |          | */
/* ----------------------------------------------------------------------------------------------------------------------------------------------------------------------                                            --------------------------------------------- */
/* | LEFT_SHIFT |   LESS_  |    Z     |    X     |    C     |    V     |    B     |    N     |    M     |  COMMA   |   DOT    |  MINUS   |        RIGHT_SHIFT           |                                            |  PAD_1   |  PAD_2   |  PAD_3   |PAD_RETURN| */
/* |            |   THAN   |          |          |          |          |          |          |          |          |          |          |                              |                                            |          |          |          |          | */
/* |    2A      |    56    |    2C    |    2D    |    2E    |    2F    |    30    |    31    |    32    |    33    |    34    |    35    |            36                |                                            |    4F    |    50    |    51    |  E0 1C   | */
/* ----------------------------------------------------------------------------------------------------------------------------------------------------------------------                                            ---------------------------------|          | */
/* |  LEFT_CTRL    |          |   LEFT_ALT    |                              SPACE                                       |  RIGHT_ALT    |            |   RIGHT_CTRL    |                                            |        PAD_0        | PAD_DOT  |          | */
/* |               |          |               |                                                                          |               |            |                 |                                            |                     |          |          | */
/* |     1D        |          |      38       |                                39                                        |    E0 38      |            |     E0 1D       |                                            |         52          |    53    |          | */
/* -----------------          ------------------------------------------------------------------------------------------------------------            -------------------                                            --------------------------------------------- */
/*=================================================================================================================================================================================================================================================================*/

/*==================================================*/
/* This figure shows the symolic name for each key. */
/* Based on a Norwegian Amiga 500 keyboard.         */
/*==================================================*/
/*=================================================================================================================================================================================================================================================================*/
/* ------------          --------------------------------------------------------     --------------------------------------------------------                                                   */
/* |  ESCAPE  |          |    F1    |    F2    |    F3    |    F4    |    F5    |     |    F6    |    F7    |    F8    |    F9    |    F10   |                                                   */
/* |          |          |          |          |          |          |          |     |          |          |          |          |          |                                                         */
/* |    01    |          |    3B    |    3C    |    3D    |    3E    |    3F    |     |    40    |    41    |    42    |    43    |    44    |                                                  */
/* ------------          --------------------------------------------------------     --------------------------------------------------------                                 */
/*                                                                                                                                                                                                                                                                 */
/* ----------------------------------------------------------------------------------------------------------------------------------------------------------------------     ----------------------------------     --------------------------------------------- */
/* |  SMALL_  |    1     |    2     |    3     |    4     |    5     |    6     |    7     |    8     |    9     |    0     |   PLUS   |  SMALL_  |BACKSLASH |BACKSPACE |     |    DELETE      |     HELP      |     |PAD_LEFT_ |PAD_RIGHT_|   PAD_   |   PAD_   | */
/* |BACKSLASH |          |          |          |          |          |          |          |          |          |          |          |  SLASH   |          |          |     |                |               |     |  SQUARE  |  SQUARE  |  DIVIDE  | MULTIPLY | */
/* |          |          |          |          |          |          |          |          |          |          |          |          |          |          |          |     |                |               |     |          |          |          |          | */
/* ----------------------------------------------------------------------------------------------------------------------------------------------------------------------     ----------------------------------     --------------------------------------------- */
/* |      TAB      |    Q     |    W     |    E     |    R     |    T     |    Y     |    U     |    I     |    O     |    P     |    AA    |  UMLAUT  |     RETURN     |                                            |  PAD_7   |  PAD_8   |  PAD_9   |PAD_MINUS | */
/* |               |          |          |          |          |          |          |          |          |          |          |          |          |                |                                            |          |          |          |          | */
/* |      0F       |          |          |          |          |          |          |          |          |          |          |          |          |                |                                            |          |          |          |          | */
/* -------------------------------------------------------------------------------------------------------------------------------------------------------              |                                            --------------------------------------------- */
/* |  CTRL   | CAPS_ |    A     |    S     |    D     |    F     |    G     |    H     |    J     |    K     |    L     |    OE    |    AE    |  SMALL_  |              |                                            |  PAD_4   |  PAD_5   |  PAD_6   | PAD_PLUS | */
/* |         | LOCK  |          |          |          |          |          |          |          |          |          |          |          |  SLASH2  |              |                                            |          |          |          |          | */
/* |         |       |          |          |          |          |          |          |          |          |          |          |          |          |              |                                            |          |          |          |          | */
/* ----------------------------------------------------------------------------------------------------------------------------------------------------------------------                                            --------------------------------------------- */
/* | LEFT_SHIFT |   LESS_  |    Z     |    X     |    C     |    V     |    B     |    N     |    M     |  COMMA   |   DOT    |  MINUS   |        RIGHT_SHIFT           |                                            |  PAD_1   |  PAD_2   |  PAD_3   |PAD_RETURN| */
/* |            |   THAN   |          |          |          |          |          |          |          |          |          |          |                              |                                            |          |          |          |          | */
/* |            |          |          |          |          |          |          |          |          |          |          |          |                              |                                            |          |          |          |          | */
/* ----------------------------------------------------------------------------------------------------------------------------------------------------------------------                                            ---------------------------------|          | */
/* |  LEFT_ALT     |   LEFT_AMIGA  |                                         SPACE                                                    |  RIGHT_AMIGA  |   RIGHT_ALT     |                                            |        PAD_0        | PAD_DOT  |          | */
/* |               |               |                                                                                                  |               |                 |                                            |                     |          |          | */
/* |               |               |                                                                                                  |               |                 |                                            |                     |          |          | */
/* ----------------------------------------------------------------------------------------------------------------------------------------------------------------------                                            --------------------------------------------- */
/*=================================================================================================================================================================================================================================================================*/

/*===============================================================*/
/* Map symbolic PC key to Amiga scancode.                        */
/*                                                               */
/* Missing key issue: on the top row on Amiga there is an extra  */
/* key compared to a PC keyboard.(The one closest to backspace.) */
/*===============================================================*/

/* Special mappings:
   -----------------

  - "Extra key on top Amiga row" closest to backspace mapped to PC "F11"
  - Amiga "CTRL" mapped to PC "Left CTRL" and PC "Right CTRL"
  - Amiga "Left Amiga" mapped to PC "Page Down"
  - Amiga "Right Amiga" mapped to PC "Right Amiga"
  - "Extra key on keypad with subprint Scr.Lock" mapped to PC Scroll Lock.

*/

UBY kbdDOS_xlat_amiga_no[106] = {
 AMIGA_NONE,            /* PC_NONE */
 AMIGA_ESCAPE,          /* PC_ESCAPE */
 AMIGA_F1,              /* PC_F1 */
 AMIGA_F2,              /* PC_F2 */
 AMIGA_F3,              /* PC_F3 */
 AMIGA_F4,              /* PC_F4 */
 AMIGA_F5,              /* PC_F5 */
 AMIGA_F6,              /* PC_F6 */
 AMIGA_F7,              /* PC_F7 */
 AMIGA_F8,              /* PC_F8 */
 AMIGA_F9,              /* PC_F9 */
 AMIGA_F10,             /* PC_F10 */
 AMIGA_BACKSLASH,       /* PC_F11 */
 AMIGA_NONE,            /* PC_F12 */
 AMIGA_NONE,            /* PC_PRINT_SCREEN */
 AMIGA_PAD_RIGHT_SQUARE,/* PC_SCROLL_LOCK */
 AMIGA_NONE,            /* PC_PAUSE */
 AMIGA_SMALL_BACKSLASH, /* PC_OR */
 AMIGA_1,               /* PC_1 */
 AMIGA_2,               /* PC_2 */
 AMIGA_3,               /* PC_3 */
 AMIGA_4,               /* PC_4 */
 AMIGA_5,               /* PC_5 */
 AMIGA_6,               /* PC_6 */
 AMIGA_7,               /* PC_7 */
 AMIGA_8,               /* PC_8 */
 AMIGA_9,               /* PC_9 */
 AMIGA_0,               /* PC_0 */
 AMIGA_PLUS,            /* PC_PLUS */
 AMIGA_SMALL_SLASH,     /* PC_BACKSLASH */
 AMIGA_BACKSPACE,       /* PC_BACKSPACE */
 AMIGA_TAB,             /* PC_TAB */
 AMIGA_Q,               /* PC_Q */
 AMIGA_W,               /* PC_W */
 AMIGA_E,               /* PC_E */
 AMIGA_R,               /* PC_R */
 AMIGA_T,               /* PC_T */
 AMIGA_Y,               /* PC_Y */
 AMIGA_U,               /* PC_U */
 AMIGA_I,               /* PC_I */
 AMIGA_O,               /* PC_O */
 AMIGA_P,               /* PC_P */
 AMIGA_AA,              /* PC_AA */
 AMIGA_UMLAUT,          /* PC_UMLAUT */
 AMIGA_RETURN,          /* PC_RETURN */
 AMIGA_CAPS_LOCK,       /* PC_CAPS_LOCK */
 AMIGA_A,               /* PC_A */
 AMIGA_S,               /* PC_S */
 AMIGA_D,               /* PC_D */
 AMIGA_F,               /* PC_F */
 AMIGA_G,               /* PC_G */
 AMIGA_H,               /* PC_H */
 AMIGA_J,               /* PC_J */
 AMIGA_K,               /* PC_K */
 AMIGA_L,               /* PC_L */
 AMIGA_OE,              /* PC_OE */
 AMIGA_AE,              /* PC_AE */
 AMIGA_SMALL_SLASH2,    /* PC_SMALL_SLASH */
 AMIGA_LEFT_SHIFT,      /* PC_LEFT_SHIFT */
 AMIGA_LESS_THAN,       /* PC_LESS_THAN */
 AMIGA_Z,               /* PC_Z */
 AMIGA_X,               /* PC_X */
 AMIGA_C,               /* PC_C */
 AMIGA_V,               /* PC_V */
 AMIGA_B,               /* PC_B */
 AMIGA_N,               /* PC_N */
 AMIGA_M,               /* PC_M */
 AMIGA_COMMA,           /* PC_COMMA */
 AMIGA_DOT,             /* PC_DOT */
 AMIGA_MINUS,           /* PC_MINUS */
 AMIGA_RIGHT_SHIFT,     /* PC_RIGHT_SHIFT */
 AMIGA_CTRL,            /* PC_LEFT_CTRL */
 AMIGA_LEFT_ALT,        /* PC_LEFT_ALT */
 AMIGA_SPACE,           /* PC_SPACE */
 AMIGA_RIGHT_ALT,       /* PC_RIGHT_ALT */
 AMIGA_CTRL,            /* PC_RIGHT_CTRL */
 AMIGA_HELP,            /* PC_INSERT */
 AMIGA_NONE,            /* PC_HOME */
 AMIGA_RIGHT_AMIGA,     /* PC_PAGE_UP */
 AMIGA_DELETE,          /* PC_DELETE */
 AMIGA_NONE,            /* PC_END */
 AMIGA_LEFT_AMIGA,      /* PC_PAGE_DOWN */
 AMIGA_UP,              /* PC_UP */
 AMIGA_LEFT,            /* PC_LEFT */
 AMIGA_DOWN,            /* PC_DOWN */
 AMIGA_RIGHT,           /* PC_RIGHT */
 AMIGA_PAD_LEFT_SQUARE, /* PC_NUM_LOCK */
 AMIGA_PAD_DIVIDE,      /* PC_PAD_DIVIDE */
 AMIGA_PAD_MULTIPLY,    /* PC_PAD_MULTIPLY */
 AMIGA_PAD_PLUS,        /* PC_PAD_PLUS */
 AMIGA_PAD_MINUS,       /* PC_PAD_MINUS */
 AMIGA_PAD_RETURN,      /* PC_PAD_RETURN */
 AMIGA_PAD_DOT,         /* PC_PAD_DOT */
 AMIGA_PAD_0,           /* PC_PAD_0 */
 AMIGA_PAD_1,           /* PC_PAD_1 */
 AMIGA_PAD_2,           /* PC_PAD_2 */
 AMIGA_PAD_3,           /* PC_PAD_3 */
 AMIGA_PAD_4,           /* PC_PAD_4 */
 AMIGA_PAD_5,           /* PC_PAD_5 */
 AMIGA_PAD_6,           /* PC_PAD_6 */
 AMIGA_PAD_7,           /* PC_PAD_7 */
 AMIGA_PAD_8,           /* PC_PAD_8 */
 AMIGA_PAD_9,           /* PC_PAD_9 */
 AMIGA_NONE,            /* PC_LEFT_WIN */
 AMIGA_NONE,            /* PC_RIGHT_WIN */
 AMIGA_NONE};           /* PC_MENU */


/*=========================*/
/* Old keyboard irq vector */
/*=========================*/

void (__interrupt __far *kbdDOS_irq_org_vector)();
BOOLE kbdDOS_irq_installed;
BOOLE kbdDOS_pages_locked;


/*=======================*/
/* State of the keyboard */
/*=======================*/

BOOLE kbdDOS_e0;
BOOLE kbdDOS_home;
BOOLE kbdDOS_end;
BOOLE kbdDOS_lctrl;
BOOLE kbdDOS_page_up;
BOOLE kbdDOS_page_down;
BOOLE kbdDOS_caps_lock;
volatile BOOLE kbdDOS_ack;
volatile BOOLE kbdDOS_nack;
ULO kbdDOS_pause;
volatile ULO kbdDOS_lastscancode;

/*========================*/
/* Joystick configuration */
/*========================*/

ULO kbdDOS_joy_up[2];
ULO kbdDOS_joy_down[2];
ULO kbdDOS_joy_left[2];
ULO kbdDOS_joy_right[2];
ULO kbdDOS_joy_fire[2][2];
ULO kbdDOS_capture_key;
volatile BOOLE kbdDOS_capture_done;


/*============*/
/* Led status */
/*============*/

ULO kbdDOS_led_status, kbdDOS_led_original;
ULO kbdDOS_led_mask[3] = {0xfffffffe, 0xfffffffd, 0xfffffffb};


/*==============================*/
/* Record state of special keys */
/*==============================*/

BOOLE kbdDOSSpecialKeysTest(ULO pckey, BOOLE pressed) {
  BOOLE result;

  result = TRUE;
  switch (pckey) {
    case PC_HOME:       kbdDOS_home = pressed;
                        break;
    case PC_END:        kbdDOS_end = pressed;
                        break;
    case PC_PAGE_UP:    kbdDOS_page_up = pressed;
                        break;
    case PC_PAGE_DOWN:  kbdDOS_page_down = pressed;
                        break;
    case PC_LEFT_CTRL:  kbdDOS_lctrl = pressed;
                        break;
    default:            result = FALSE;
                        break;
  }
  return result;
}


/*========================================*/
/* Keyboard Joystick replacement handling */
/*========================================*/

void kbdDOSJoystickSet(ULO joynr, ULO direction, ULO key) {
  if (joynr < 2) {
    switch (direction) {
      case KBD_JOY_UP:     kbdDOS_joy_up[joynr] = key;
  			   break;
      case KBD_JOY_DOWN:   kbdDOS_joy_down[joynr] = key;
			   break;
      case KBD_JOY_LEFT:   kbdDOS_joy_left[joynr] = key;
			   break;
      case KBD_JOY_RIGHT:  kbdDOS_joy_right[joynr] = key;
			   break;
      case KBD_JOY_FIRE_0: kbdDOS_joy_fire[joynr][0] = key;
			   break;
      case KBD_JOY_FIRE_1: kbdDOS_joy_fire[joynr][1] = key;
			   break;
    }
  }
}

ULO kbdDOSCapture(void) {
  ULO lastscan = 0;
  UBY bigarray[4096];
  ULO counter = 0;
  int i;

  kbdDOS_capture_key = PC_NONE;
  kbdDOS_capture_done = FALSE;
  kbdDOSIrqInstallCapture();
  while (!kbdDOS_capture_done) {
    if (lastscan != kbdDOS_lastscancode) {
      lastscan = kbdDOS_lastscancode;
      bigarray[counter++] = lastscan;
    }
  }    
  for (i = 0; i < counter; i++)
    printf("Scancode %X\n", bigarray[i]);
  kbdDOSIrqUnInstallCapture();
  return kbdDOS_capture_key;
}

ULO kbdDOSJoystickGet(ULO joynr, ULO direction) {
  if (joynr < 2) {
    switch (direction) {
      case KBD_JOY_UP:     return kbdDOS_joy_up[joynr];
      case KBD_JOY_DOWN:   return kbdDOS_joy_down[joynr];
      case KBD_JOY_LEFT:   return kbdDOS_joy_left[joynr];
      case KBD_JOY_RIGHT:  return kbdDOS_joy_right[joynr];
      case KBD_JOY_FIRE_0: return kbdDOS_joy_fire[joynr][0];
      case KBD_JOY_FIRE_1: return kbdDOS_joy_fire[joynr][1];
    }
  }
  return 0;
}

char *kbdDOSGetString(ULO key, char *description) {
  return strcpy(description, kbdDOS_keynames_no[key]);
}

BOOLE kbdDOSJoystickTest(ULO pckey, BOOLE pressed) {
  BOOLE result;
  ULO i;

  result = FALSE;
  if (joy_config[0] == JOY_KBD_REPLACEMENT_0 || joy_config[0] == JOY_KBD_REPLACEMENT_1) {
    i = (joy_config[0] == JOY_KBD_REPLACEMENT_0) ? 0 : 1;
    if (pressed) {
      if (pckey == kbdDOS_joy_down[i]) {
        kbdQueueAdd(KBD_EVENT_JOY_0_SET_DOWN);
        result = TRUE;
      }
      else if (pckey == kbdDOS_joy_up[i]) {
        kbdQueueAdd(KBD_EVENT_JOY_0_SET_UP);
        result = TRUE;
      }
      else if (pckey == kbdDOS_joy_left[i]) {
        kbdQueueAdd(KBD_EVENT_JOY_0_SET_LEFT);
        result = TRUE;
      }
      else if (pckey == kbdDOS_joy_right[i]) {
        kbdQueueAdd(KBD_EVENT_JOY_0_SET_RIGHT);
        result = TRUE;
      }
      else if (pckey == kbdDOS_joy_fire[i][0]) {
        kbdQueueAdd(KBD_EVENT_JOY_0_SET_FIRE_0);
        result = TRUE;
      }
      else if (pckey == kbdDOS_joy_fire[i][1]) {
        kbdQueueAdd(KBD_EVENT_JOY_0_SET_FIRE_1);
        result = TRUE;
      }
    }
    else {
      if (pckey == kbdDOS_joy_down[i]) {
        kbdQueueAdd(KBD_EVENT_JOY_0_RELEASE_DOWN);
        result = TRUE;
      }
      else if (pckey == kbdDOS_joy_up[i]) {
        kbdQueueAdd(KBD_EVENT_JOY_0_RELEASE_UP);
        result = TRUE;
      }
      else if (pckey == kbdDOS_joy_left[i]) {
        kbdQueueAdd(KBD_EVENT_JOY_0_RELEASE_LEFT);
        result = TRUE;
      }
      else if (pckey == kbdDOS_joy_right[i]) {
        kbdQueueAdd(KBD_EVENT_JOY_0_RELEASE_RIGHT);
        result = TRUE;
      }
      else if (pckey == kbdDOS_joy_fire[i][0]) {
        kbdQueueAdd(KBD_EVENT_JOY_0_RELEASE_FIRE_0);
        result = TRUE;
      }
      else if (pckey == kbdDOS_joy_fire[i][1]) {
        kbdQueueAdd(KBD_EVENT_JOY_0_RELEASE_FIRE_1);
        result = TRUE;
      }
    }
  }
  if (joy_config[1] == JOY_KBD_REPLACEMENT_0 || joy_config[1] == JOY_KBD_REPLACEMENT_1) {
    i = (joy_config[1] == JOY_KBD_REPLACEMENT_0) ? 0 : 1;
    if (pressed) {
      if (pckey == kbdDOS_joy_down[1]) {
        kbdQueueAdd(KBD_EVENT_JOY_1_SET_DOWN);
        result = TRUE;
      }
      else if (pckey == kbdDOS_joy_up[1]) {
        kbdQueueAdd(KBD_EVENT_JOY_1_SET_UP);
        result = TRUE;
      }
      else if (pckey == kbdDOS_joy_left[1]) {
        kbdQueueAdd(KBD_EVENT_JOY_1_SET_LEFT);
        result = TRUE;
      }
      else if (pckey == kbdDOS_joy_right[1]) {
        kbdQueueAdd(KBD_EVENT_JOY_1_SET_RIGHT);
        result = TRUE;
      }
      else if (pckey == kbdDOS_joy_fire[i][0]) {
        kbdQueueAdd(KBD_EVENT_JOY_1_SET_FIRE_0);
        result = TRUE;
      }
      else if (pckey == kbdDOS_joy_fire[i][1]) {
        kbdQueueAdd(KBD_EVENT_JOY_1_SET_FIRE_1);
        result = TRUE;
      }
    }
    else {
      if (pckey == kbdDOS_joy_down[1]) {
        kbdQueueAdd(KBD_EVENT_JOY_1_RELEASE_DOWN);
        result = TRUE;
      }
      else if (pckey == kbdDOS_joy_up[1]) {
        kbdQueueAdd(KBD_EVENT_JOY_1_RELEASE_UP);
        result = TRUE;
      }
      else if (pckey == kbdDOS_joy_left[1]) {
        kbdQueueAdd(KBD_EVENT_JOY_1_RELEASE_LEFT);
        result = TRUE;
      }
      else if (pckey == kbdDOS_joy_right[1]) {
        kbdQueueAdd(KBD_EVENT_JOY_1_RELEASE_RIGHT);
        result = TRUE;
      }
      else if (pckey == kbdDOS_joy_fire[i][0]) {
        kbdQueueAdd(KBD_EVENT_JOY_1_RELEASE_FIRE_0);
        result = TRUE;
      }
      else if (pckey == kbdDOS_joy_fire[i][1]) {
        kbdQueueAdd(KBD_EVENT_JOY_1_RELEASE_FIRE_1);
        result = TRUE;
      }
    }
  }
  return result;
}


/*===============*/
/* Detect events */
/*===============*/

BOOLE kbdDOSEventTest(ULO pckey, BOOLE pressed) {
  ULO event;
  BOOLE result;

  event = KBD_EVENT_NONE;
  if (kbdDOS_home && !pressed) {
    switch (pckey) {
      case PC_F1:        event = KBD_EVENT_ADF_INSERT_0;
                         break;
      case PC_F2:        event = KBD_EVENT_ADF_INSERT_1;
                         break;
      case PC_F3:        event = KBD_EVENT_ADF_INSERT_2;
                         break;
      case PC_F4:        event = KBD_EVENT_ADF_INSERT_3;
                         break;
      case PC_F5:        event = KBD_EVENT_DUMP_SCREEN;
                         break;
      case PC_PAGE_UP:   event = KBD_EVENT_RESOLUTION_PREV;
                         break;
      case PC_PAGE_DOWN: event = KBD_EVENT_RESOLUTION_NEXT;
                         break;
      case PC_PAD_4:     event = KBD_EVENT_PAN_LEFT;
                         break;
      case PC_PAD_6:     event = KBD_EVENT_PAN_RIGHT;
                         break;
      case PC_PAD_8:     event = KBD_EVENT_PAN_UP;
                         break;
      case PC_PAD_2:     event = KBD_EVENT_PAN_DOWN;
                         break;
    }
  }
  if (kbdDOS_end && !pressed && (event == KBD_EVENT_NONE)) {
    switch (pckey) {
      case PC_F1:        event = KBD_EVENT_ADF_EJECT_0;
                         break;
      case PC_F2:        event = KBD_EVENT_ADF_EJECT_1;
                         break;
      case PC_F3:        event = KBD_EVENT_ADF_EJECT_2;
                         break;
      case PC_F4:        event = KBD_EVENT_ADF_EJECT_3;
                         break;
      case PC_PAGE_UP:   event = KBD_EVENT_YSCALE_PREV;
                         break;
      case PC_PAGE_DOWN: event = KBD_EVENT_YSCALE_NEXT;
                         break;
    }
  }
  if (!pressed && (event == KBD_EVENT_NONE))
    if (pckey == PC_F12) event = KBD_EVENT_EXIT;
  result = (event != KBD_EVENT_NONE);
  if (result) kbdQueueAdd(event);
  return result;
}


/*=================*/
/* Event detection */
/*=================*/

BOOLE kbdDOSEventDetect(ULO pckey, BOOLE pressed) {
  BOOLE result;

  result = FALSE;
  if (!(result = kbdDOSSpecialKeysTest(pckey, pressed)))
    if (!(result = kbdDOSJoystickTest(pckey, pressed)))
      result = kbdDOSEventTest(pckey, pressed);
  if (!result) if (kbdDOS_lctrl && kbdDOS_page_up && kbdDOS_page_down)
      kbdQueueAdd(KBD_EVENT_RESET);
  return result;
}


/*============================*/
/* Keyboard interrupt handler */
/*============================*/

void __interrupt __far kbdDOSIrqHandler() {
  ULO scancoderaw, scancode, pckey, amigakey;
  BOOLE pressed;

  pckey = PC_NONE;
  scancoderaw = inp(0x60);
  scancode = scancoderaw & 0x7f;
  pressed = !(scancoderaw & 0x80);
  kbdDOS_ack = (scancode == 0xfa);
  kbdDOS_nack = (scancode == 0xfe);
  
  /* Translate scancode to symbolic PC key */
  
  if (scancoderaw == 0xe0) kbdDOS_e0 = TRUE;
  else if (kbdDOS_pause > 0) {
    switch (kbdDOS_pause) {
      case 1:  if (scancoderaw == 0x1d) kbdDOS_pause++;
 	       else kbdDOS_pause = 0;
	       break;
      case 2:  if (scancoderaw == 0x45) kbdDOS_pause++;
	       else kbdDOS_pause = 0;
	       break;
      case 3:  if (scancoderaw == 0xe1) kbdDOS_pause++;
	       else kbdDOS_pause = 0;
	       break;
      case 4:  if (scancoderaw == 0x9d) kbdDOS_pause++;
	       else kbdDOS_pause = 0;
	       break;
      case 5:  if (scancoderaw == 0xc5) pckey = PC_PAUSE;
      default: kbdDOS_pause = 0;
    }
  }
  else if (scancoderaw == 0xe1) kbdDOS_pause++;
  else {
    pckey = kbdDOS_xlat_no[kbdDOS_e0][scancode];
    kbdDOS_e0 = FALSE;
  }

  /* Process symbolic PC key */
  
  if (pckey != PC_NONE)
    if (kbdDOSEventDetect(pckey, pressed)) pckey = PC_NONE;
  
  /* Translate to Amiga scancode */

  if (pckey != PC_NONE) {
  amigakey = kbdDOS_xlat_amiga_no[pckey];
  if (!pressed) amigakey |= 0x80;
    kbdQueueAdd(amigakey);
  }
  outp(0x20,0x20);
}


/*==================================*/
/* Handler that captures a keypress */
/*==================================*/

void __interrupt __far kbdDOSIrqHandlerCapture() {
  ULO scancoderaw, scancode, pckey;
  BOOLE pressed;

  pckey = PC_NONE;
  scancoderaw = inp(0x60);
  kbdDOS_lastscancode = scancoderaw;
  scancode = scancoderaw & 0x7f;
  pressed = !(scancoderaw & 0x80);

  /* Translate scancode to symbolic PC key */
  
  if (scancoderaw == 0xe0) kbdDOS_e0 = TRUE;
  else if (kbdDOS_pause > 0) {
    switch (kbdDOS_pause) {
      case 1:  if (scancoderaw == 0x1d) kbdDOS_pause++;
 	       else kbdDOS_pause = 0;
	       break;
      case 2:  if (scancoderaw == 0x45) kbdDOS_pause++;
	       else kbdDOS_pause = 0;
	       break;
      case 3:  if (scancoderaw == 0xe1) kbdDOS_pause++;
	       else kbdDOS_pause = 0;
	       break;
      case 4:  if (scancoderaw == 0x9d) kbdDOS_pause++;
	       else kbdDOS_pause = 0;
	       break;
      case 5:  if (scancoderaw == 0xc5) {
	         pckey = PC_PAUSE;
	         pressed = TRUE;
	       }
      default: kbdDOS_pause = 0;
    }
  }
  else if (scancoderaw == 0xe1) kbdDOS_pause++;
  else {
    pckey = kbdDOS_xlat_no[kbdDOS_e0][scancode];
    kbdDOS_e0 = FALSE;
  }

  if (pckey != PC_NONE && !kbdDOS_capture_done && pressed) {
    kbdDOS_capture_key = pckey;
    kbdDOS_capture_done = TRUE;
  }
  outp(0x20,0x20);
}


/*================*/
/* Lock irq pages */
/*================*/

void kbdDOSLockPages(void) {
  if (!kbdDOS_pages_locked) {
    kbdDOS_pages_locked = TRUE;
    lock_region((void near *) kbdDOSIrqHandler, 4096);
    lock_region(&kbdDOS_e0, sizeof(kbdDOS_e0));
    lock_region(&kbdDOS_home, sizeof(kbdDOS_home));
    lock_region(&kbdDOS_end, sizeof(kbdDOS_end));
    lock_region(&kbdDOS_lctrl, sizeof(kbdDOS_lctrl));
    lock_region(&kbdDOS_page_up, sizeof(kbdDOS_page_up));
    lock_region(&kbdDOS_page_down, sizeof(kbdDOS_page_down));
    lock_region(&kbdDOS_pause, sizeof(kbdDOS_pause));
    lock_region(&kbdDOS_nack, sizeof(kbdDOS_nack));
    lock_region(&kbdDOS_ack, sizeof(kbdDOS_ack));
    lock_region(kbdDOS_xlat_no, sizeof(kbdDOS_xlat_no));
    lock_region(kbdDOS_xlat_amiga_no, sizeof(kbdDOS_xlat_amiga_no));
    lock_region((void near *) kbdDOSEventDetect, 4096);
    lock_region((void near *) kbdDOSSpecialKeysTest, 4096);
    lock_region((void near *) kbdDOSJoystickTest, 4096);
    lock_region(kbdDOS_joy_up, sizeof(kbdDOS_joy_up));
    lock_region(kbdDOS_joy_down, sizeof(kbdDOS_joy_down));
    lock_region(kbdDOS_joy_left, sizeof(kbdDOS_joy_left));
    lock_region(kbdDOS_joy_right, sizeof(kbdDOS_joy_right));
    lock_region(joy_config, sizeof(joy_config));
    lock_region((void near *) kbdDOSEventTest, 4096);
    lock_region((void near *) kbdQueueAdd, 4096);
    lock_region(kbd_queue, sizeof(kbd_queue));
    lock_region(&kbd_queue_in_pos, sizeof(kbd_queue_in_pos));
    lock_region(&kbd_queue_out_pos, sizeof(kbd_queue_out_pos));
    lock_region(&kbd_queue_eols_to_wait, sizeof(kbd_queue_eols_to_wait));
    lock_region((void near *) kbdEventAdd, 4096);
    lock_region(kbd_event, sizeof(kbd_event));
    lock_region(&kbd_event_master, sizeof(kbd_event_master));
  }
}

void kbdDOSUnLockPages(void) {
  if (kbdDOS_pages_locked) {
    kbdDOS_pages_locked = FALSE;
    unlock_region((void near *) kbdDOSIrqHandler, 4096);
    unlock_region(&kbdDOS_e0, sizeof(kbdDOS_e0));
    unlock_region(&kbdDOS_home, sizeof(kbdDOS_home));
    unlock_region(&kbdDOS_end, sizeof(kbdDOS_end));
    unlock_region(&kbdDOS_lctrl, sizeof(kbdDOS_lctrl));
    unlock_region(&kbdDOS_page_up, sizeof(kbdDOS_page_up));
    unlock_region(&kbdDOS_page_down, sizeof(kbdDOS_page_down));
    unlock_region(&kbdDOS_pause, sizeof(kbdDOS_pause));
    unlock_region(&kbdDOS_nack, sizeof(kbdDOS_nack));
    unlock_region(&kbdDOS_ack, sizeof(kbdDOS_ack));
    unlock_region(kbdDOS_xlat_no, sizeof(kbdDOS_xlat_no));
    unlock_region(kbdDOS_xlat_amiga_no, sizeof(kbdDOS_xlat_amiga_no));
    unlock_region((void near *) kbdDOSEventDetect, 4096);
    unlock_region((void near *) kbdDOSSpecialKeysTest, 4096);
    unlock_region((void near *) kbdDOSJoystickTest, 4096);
    unlock_region(kbdDOS_joy_up, sizeof(kbdDOS_joy_up));
    unlock_region(kbdDOS_joy_down, sizeof(kbdDOS_joy_down));
    unlock_region(kbdDOS_joy_left, sizeof(kbdDOS_joy_left));
    unlock_region(kbdDOS_joy_right, sizeof(kbdDOS_joy_right));
    unlock_region(joy_config, sizeof(joy_config));
    unlock_region((void near *) kbdDOSEventTest, 4096);
    unlock_region((void near *) kbdQueueAdd, 4096);
    unlock_region(kbd_queue, sizeof(kbd_queue));
    unlock_region(&kbd_queue_in_pos, sizeof(kbd_queue_in_pos));
    unlock_region(&kbd_queue_out_pos, sizeof(kbd_queue_out_pos));
    unlock_region(&kbd_queue_eols_to_wait, sizeof(kbd_queue_eols_to_wait));
    unlock_region((void near *) kbdEventAdd, 4096);
    unlock_region(kbd_event, sizeof(kbd_event));
    unlock_region(&kbd_event_master, sizeof(kbd_event_master));
  }
}


/*=================*/
/* Init irq vector */
/*=================*/

void kbdDOSIrqInstall(void) {
  if (!kbdDOS_irq_installed) {
    kbdDOS_irq_org_vector = _dos_getvect(9);
    _dos_setvect(9, kbdDOSIrqHandler);
    kbdDOS_irq_installed = TRUE;
  }
}

void kbdDOSIrqUnInstall(void) {
  if (kbdDOS_irq_installed) {
    _dos_setvect(9, kbdDOS_irq_org_vector);
    kbdDOS_irq_installed = FALSE;
  }
}

void kbdDOSIrqInstallCapture(void) {
  kbdDOS_irq_org_vector = _dos_getvect(9);
  _dos_setvect(9, kbdDOSIrqHandlerCapture);
}

void kbdDOSIrqUnInstallCapture(void) {
  _dos_setvect(9, kbdDOS_irq_org_vector);
}


/*======================*/
/* Keyboard LED support */
/*======================*/

void kbdDOSLEDSet(ULO lednr, BOOLE state) {
  ULO oldstate;

  oldstate = kbdDOS_led_status;
  kbdDOS_led_status &= kbdDOS_led_mask[lednr];
  kbdDOS_led_status |= ((state) ? 1 : 0)<<lednr;
  if (oldstate != kbdDOS_led_status) {
    outp(0x60, 0xed);
    outp(0x60, kbdDOS_led_status);
  }
}


/*================*/
/* Reset routines */
/*================*/

kbdDOSReset(void) {
  kbdDOS_home = FALSE;
  kbdDOS_end = FALSE;
  kbdDOS_lctrl = FALSE;
  kbdDOS_page_up = FALSE;
  kbdDOS_page_down = FALSE;
  kbdDOS_caps_lock = FALSE;
  kbdDOS_ack = FALSE;
  kbdDOS_nack = FALSE;
  kbdDOS_led_status = 0;
}

void kbdDOSSoftReset(void) {
  kbdDOSReset();
}

void kbdDOSHardReset(void) {
  kbdDOSReset();
}


/*================================*/
/* Starting and stopping routines */
/*================================*/

void kbdDOSEmulationStarting(void) {
  kbdDOSIrqInstall();
}

void kbdDOSEmulationStopping(void) {
  kbdDOSIrqUnInstall();
}


/*============================*/
/* Called on emulator startup */
/*============================*/

void kbdDOSStartup(void) {
  kbdSoftResetCallback = kbdDOSSoftReset;
  kbdHardResetCallback = kbdDOSHardReset;
  kbdEmulationStartingCallback = kbdDOSEmulationStarting;
  kbdEmulationStoppingCallback = kbdDOSEmulationStopping;
  kbd_LED_supported = TRUE;
  kbdLEDSetCallback = kbdDOSLEDSet;
  kbd_LED_count = 3;
  kbdJoystickSetCallback = kbdDOSJoystickSet;
  kbdCaptureCallback = kbdDOSCapture;
  kbdJoystickGetCallback = kbdDOSJoystickGet;
  kbdGetStringCallback = kbdDOSGetString;
  kbdDOS_joy_up[0] = PC_UP;
  kbdDOS_joy_down[0] = PC_DOWN;
  kbdDOS_joy_left[0] = PC_LEFT;
  kbdDOS_joy_right[0] = PC_RIGHT;
  kbdDOS_joy_fire[0][0] = PC_RIGHT_CTRL;
  kbdDOS_joy_fire[0][1] = PC_RIGHT_ALT;
  kbdDOS_joy_up[1] = PC_R;
  kbdDOS_joy_down[1] = PC_F;
  kbdDOS_joy_left[1] = PC_D;
  kbdDOS_joy_right[1] = PC_G;
  kbdDOS_joy_fire[1][0] = PC_LEFT_CTRL;
  kbdDOS_joy_fire[1][1] = PC_LEFT_ALT;
  kbdDOSLockPages();
}


/*=============================*/
/* Called on emulator shutdown */
/*=============================*/

void kbdDOSShutdown(void) {
  kbdDOSIrqUnInstall();
  kbdDOSUnlockPages();
}
