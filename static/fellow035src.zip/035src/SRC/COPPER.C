/*=================================*/
/* Fellow Amiga Emulator           */
/* Copper Emulation Initialization */
/* (C) 1997-1998 Petter Schau      */
/*=================================*/


#include "defs.h"
#include "fellow.h"
#include "graphem.h"
#include "draw.h"
#include "memory.h"

/* Not exactly correct, but a good average..? */

ULO copper_cycletable[16] = {4, 4, 4, 4, 4, 5, 6, 4,  4, 4, 4, 8, 16, 4, 4, 4};

/* Speedup table for ypos to cycle translation */

ULO copperytable[512];
ULO curcopptr;          /* Copper program counter */
ULO cop_running_beyond_line = FALSE;
ULO cop_already_done = FALSE;
ULO nxtcopaccess, copperdma, coppersuspendedwait; 

void init_copperytable(void) {
  int i, ex = (config_draw_cycleexact && (config_graphics_mode == 0)) ? 0:16;
  if (config_draw_cycleexact && (config_graphics_mode == 0))
    sprite_delay = 56;
  else sprite_delay = 40;
  for (i = 0; i < 512; i++) {
    copperytable[i] = i*228 + ex;
  }
}

void copper_init(void) {
  init_copperytable();
  nxtcopaccess = -1;
  curcopptr = 0;
  cop1lc = 0;
  cop2lc = 0;
}

