/*=============================*/
/* Fellow Amiga Emulator       */
/* Sound emulation             */
/* (C) 1996-1998 Petter Schau  */
/*           and Rainer Sinsch */
/*=============================*/


#include <stdio.h>
#include "defs.h"
#include "memory.h"
#include "sound.h"

#include "sblast.h"

#ifndef SOUND_C
#include "sounda.h"
#endif


/*===============================*/
/* Sound emulation configuration */
/*===============================*/

soundrates sound_rate;
soundchannels sound_channels;
soundbits sound_bits;
ULO sound_buffer_depth;        /* Buffer length in frames */
ULO sound_buffer_depth_eol_index;
BOOLE sound_set_by_config;     /* Don't use default settings */
soundmodes sound_mode;
soundfilters sound_filter;
BOOLE sound_wav_dump;
BOOLE sound_device_found;
ULO sound_scale;
soundFrequencyHandlerFunc sound_freqhandlers[4] = {
                                                audio_frequency_handler_15650,
                                                audio_frequency_handler_22050,
                                                audio_frequency_handler_31300,
                                                audio_frequency_handler_44100};
ULO sound_rate_default[4] = {15650, 22050, 31300, 44100};


/*====================================*/
/* Information about the sound device */
/*====================================*/

sound_device sound_sbdev;
sound_device sound_wavdev;


/*=================================================*/
/* Callback pointers used by emulation at run-time */
/* Extracted from the sound_device information     */
/*=================================================*/

soundDevSampleAddFunc soundSampleAddCallback; /* Selected from card config */
soundDevSampleAddFunc soundSampleAddSecondaryCallback; /* For wav layer */
soundDevEmulationStartingFunc soundEmulationStartingCallback;
soundDevEmulationStoppingFunc soundEmulationStoppingCallback;
soundDevBufferPlayFunc soundBufferPlayCallback;
soundFrequencyHandlerFunc soundFrequencyHandlerCallback;


/*===============*/
/* Run-time data */
/*===============*/

WOR left[8], right[8];        /* Temorary buffer for samples, 16-bit signed */
ULO audiocounter;             /* Used in 22050/44100 to decide samples */
ULO audioodd;                 /* Used for skipping samples in 22050 */
ULO sound_framecounter;       /* Count frames, and then play */
ULO audio_hblanks;            /* Used by the "contiguous sound" option */
ULO audio_hblanks_thisbuffer;


/*=================*/
/* Audio-registers */
/*=================*/

ULO audpt[4];             /* Sample-DMA pointer */
ULO audlen[4];            /* Length */
ULO audper[4];            /* Used directly, NOTE: translated value */ 
ULO audvol[4];            /* Volume, possibly not reloaded by state-machine */
ULO auddat[4];            /* Last data word read by DMA */


/*==========================================*/
/* Internal variables used by state-machine */
/*==========================================*/

ULO audlenw[4];             /* Length counter */
ULO audpercounter[4];       /* Period counter */
ULO auddatw[4];             /* Sample currently output, 16-bit signed */
soundStateFunc audstate[4]; /* Current state for the channel */
ULO audvolw[4];             /* Current volume, reloaded at some points */
ULO audptw[4];              /* Current dma-pointer, reloaded at some points */ 


/*====================*/
/* Translation tables */
/*====================*/

ULO periodtable[65536];
WOR volumes[256][64];
ULO audioirqmask[4] = {0x0080, 0x0100, 0x0200, 0x0400};
ULO audiodmaconmask[4] = {0x1, 0x2, 0x4, 0x8};

void audiostate0(int);
void audiostate1(int);
void audiostate2(int);
void audiostate3(int);
void audiostate5(int);

void soundSampleAddDummy(ULO newsamples) {};


#ifdef SOUND_C

/*======================*/
/* Register write stubs */
/*======================*/

#define GET_CHANNEL_NUMBER(address) (((address>>4) & 7) - 2)

/* AUDXPTH - $dff0a0,b0,c0,d0 */

#pragma aux waudXpth parm [ecx] [edx];
void waudXpth(int address, int data) {
  push_eax();
  *(((UWO *) &audpt[GET_CHANNEL_NUMBER(address)]) + 1) = data & 0x1f;
  pop_eax();
}

/* AUDXPTL - $dff0a2,b2,c2,d2 */

#pragma aux waudXptl parm [ecx] [edx];
void waudXptl(int address, int data) {
  push_eax();
  *((UWO *) &audpt[GET_CHANNEL_NUMBER(address)]) = data & 0xfffe;
  pop_eax();
}

/* AUDXLEN - $dff0a4,b4,c4,d4 */

#pragma aux waudXlen parm [ecx] [edx];
void waudXlen(int address, int data) {
  push_eax();
  audlen[GET_CHANNEL_NUMBER(address)] = data & 0xffff;
  pop_eax();
}

/* AUDXPER - $dff0a6,b6,c6,d6 */

#pragma aux waudXper parm [ecx] [edx];
void waudXper(int address, int data) {
  push_eax();
  audper[GET_CHANNEL_NUMBER(address)] = periodtable[data & 0xffff];
  pop_eax();
}

/* AUDXVOL - $dff0a8,b8,c8,d8 */

#pragma aux waudXvol parm [ecx] [edx];
void waudXvol(int address, int data) {
  push_eax();
  if ((data & 0xff00) && !(data & 0xff)) data >>= 8; 
  if (data & 64) data = 63;
  audvol[GET_CHANNEL_NUMBER(address)] = (data & 63);
  pop_eax();
}

/*=====================*/
/* Audio state machine */
/*=====================*/

/* Inline intreq */
/* Can be replaced by the slower wriw(address,data) */

void wintreq_inline(ULO data);
#pragma aux wintreq_inline parm [edx] = "call   wintreq";

/* State 0 */
/* Never called when dma is off */

void audiostate0(int channel) {
  audlenw[channel] = audlen[channel]; /* State-change 0 to 1 */
  audptw[channel] = audpt[channel];
  audpercounter[channel] = 0;
  audstate[channel] = audiostate1;
}

/* State 1 */

void audiostate1(int channel) {
  if (audlenw[channel] != 1) audlenw[channel]--;   /* State-change 1 to 5 */
  audstate[channel] = audiostate5;
  wintreq_inline(0x8000 | audioirqmask[channel]);
}

/* State 2 */

void audiostate2(int channel) {
  if (audpercounter[channel] >= 0x10000) {      /* State-change 2 to 3 */
    audpercounter[channel] = audpercounter[channel] - 0x10000 + audper[channel];
    audvolw[channel] = audvol[channel];
    auddatw[channel] = volumes[*((char *) &auddat[channel])][audvolw[channel]];
    audstate[channel] = audiostate3;
    }
  else audpercounter[channel] += audper[channel]; /* State-change 2 to 2 */
}

/* State 3 */

void audiostate3(int channel) {
  if (audpercounter[channel] >= 0x10000) {     /* State-change 3 to 2 */
    audpercounter[channel] = audpercounter[channel] - 0x10000 + audper[channel];
    auddatw[channel] = volumes[*(((char *) &auddat[channel]) + 1)][audvolw[channel]];
    auddat[channel] = (((ULO) cmem[audptw[channel]])<<8) | cmem[audptw[channel] + 1];
    audptw[channel] = (audptw[channel] + 2) & 0x1ffffe;
    audstate[channel] = audiostate2;
    if (audlenw[channel] == 1) {
      audlenw[channel] = audlen[channel];
      audptw[channel] = audpt[channel];
      wintreq_inline(0x8000 | audioirqmask[channel]);
      }
    else audlenw[channel]--;
  }
  else audpercounter[channel] += audper[channel]; /* State-change 3 to 3 */
}    			

/* State 5 */

void audiostate5(int channel) {
  audvolw[channel] = audvol[channel];
  audpercounter[channel] = 0;
  auddatw[channel] = volumes[*(((char *) &auddat[channel]) + 1)][audvolw[channel]];
  auddat[channel] = (((ULO) cmem[audptw[channel]])<<8) | cmem[audptw[channel] + 1];
  audptw[channel] = (audptw[channel] + 2) & 0x1ffffe;
  audstate[channel] = audiostate2;
  if (audlenw[channel] == 1) {
    audlenw[channel] = audlen[channel];
    audptw[channel] = audpt[channel];
    wintreq_inline(0x8000 | audioirqmask[channel]);
    }
  else audlenw[channel]--;
}

/* Called by DMACON write when dma for a channel is turned off */
/* This is why audiostates do not check DMA on/off */

#pragma aux audio_kill_channel parm [ecx];
void audio_kill_channel(int channel) {
  push_eax();
  auddatw[channel] = 0;
  audstate[channel] = audiostate0;
  pop_eax();
}


/*================================*/
/* Frequency handler for 44100 hz */
/*================================*/

void audio_frequency_handler_44100(void) {
  push_eax();
  *((ULO *) left) = 0;
  *((ULO *) right) = 0;
  if (dmacon & 1) {
    audstate[0](0);
    left[0] = auddatw[0];
    audstate[0](0);
    left[1] = auddatw[0];
    }
  if (dmacon & 8) {
    audstate[3](3);
    left[0] += auddatw[3];
    audstate[3](3);
    left[1] += auddatw[3];
    }
  if (dmacon & 2) {
    audstate[1](1);
    right[0] = auddatw[1];
    audstate[1](1);
    right[1] = auddatw[1];
    }
  if (dmacon & 4) {
    audstate[2](2);
    right[0] += auddatw[2];
    audstate[2](2);
    right[1] += auddatw[2];
    }
  audio_putinbuffer(2);
  pop_eax();
}


/*================================*/
/* Frequency handler for 31300 hz */
/*================================*/

void audio_frequency_handler_31300(void) {
  push_eax();
  *((ULO *) left) = 0;
  *((ULO *) right) = 0;
  if (dmacon & 1) {
    audstate[0](0);
    left[0] = auddatw[0];
    audstate[0](0);
    left[1] = auddatw[0];
    }
  if (dmacon & 8) {
    audstate[3](3);
    left[0] += auddatw[3];
    audstate[3](3);
    left[1] += auddatw[3];
    }
  if (dmacon & 2) {
    audstate[1](1);
    right[0] = auddatw[1];
    audstate[1](1);
    right[1] = auddatw[1];
    }
  if (dmacon & 4) {
    audstate[2](2);
    right[0] += auddatw[2];
    audstate[2](2);
    right[1] += auddatw[2];
    }
  audio_putinbuffer(2);
  pop_eax();
}


/*================================*/
/* Frequency handler for 22050 hz */
/*================================*/

void audio_frequency_handler_22050(void) {
  push_eax();
  *((ULO *) left) = 0;
  *((ULO *) right) = 0;
  if (dmacon & 1) {
    audstate[0](0);
    left[0] = auddatw[0];
    audstate[0](0);
    left[1] = auddatw[0];
    }
  if (dmacon & 8) {
    audstate[3](3);
    left[0] += auddatw[3];
    audstate[3](3);
    left[1] += auddatw[3];
    }
  if (dmacon & 2) {
    audstate[1](1);
    right[0] = auddatw[1];
    audstate[1](1);
    right[1] = auddatw[1];
    }
  if (dmacon & 4) {
    audstate[2](2);
    right[0] += auddatw[2];
    audstate[2](2);
    right[1] += auddatw[2];
    }
  audio_putinbuffer(2);
  pop_eax();
}


/*================================*/
/* Frequency handler for 15650 hz */
/*================================*/

void audio_frequency_handler_15650(void) {
  push_eax();
  *((ULO *) left) = 0;
  *((ULO *) right) = 0;
  if (dmacon & 1) {
    audstate[0](0);
    left[0] = auddatw[0];
    audstate[0](0);
    left[1] = auddatw[0];
    }
  if (dmacon & 8) {
    audstate[3](3);
    left[0] += auddatw[3];
    audstate[3](3);
    left[1] += auddatw[3];
    }
  if (dmacon & 2) {
    audstate[1](1);
    right[0] = auddatw[1];
    audstate[1](1);
    right[1] = auddatw[1];
    }
  if (dmacon & 4) {
    audstate[2](2);
    right[0] += auddatw[2];
    audstate[2](2);
    right[1] += auddatw[2];
    }
  audio_putinbuffer(2);
  pop_eax();
}

#endif


/*==================*/
/* Play full buffer */
/*==================*/

void soundBufferPlay(void) {
  if (soundBufferPlayCallback != NULL)
    (*soundBufferPlayCallback)();
}


/*====================================================*/
/* Must be called every time sound quality is changed */
/*====================================================*/

void soundVolumeTabInit(void) {
  LON i, s, j;

  if (sound_channels == SOUND_MONO)
    s = 1;    /* Mono */
  else
    s = 2;                                        /* Stereo */

  for (i = -128; i < 128; i++) 
    for (j = 0; j < 64; j++)
      if (j == 0)
	volumes[i & 0xff][j] = 0;
      else
        volumes[i & 0xff][j] = (i*j*s)/2;
}


/*====================================================*/
/* Must be called every time sound_quality is changed */
/* baseperiod is the output frequency                 */
/*====================================================*/

void soundPeriodTabInit(ULO baseperiod) {
  double j;  /* TAKE ME AWAY! Floating point! */
  LON i;

  if (baseperiod < 29000)
    baseperiod *= 2;  /* Internally, can not run slower than max Amiga rate */
  sound_scale = (0x20000 * 31300)/baseperiod;
  periodtable[0] = 0x10000;
  for (i = 1; i < 65536; i++) {
    j = 3568200/i;                  /* Sample rate */
    periodtable[i] = (ULO) ((j*65536)/baseperiod);
    if (periodtable[i] > 0x10000)
      periodtable[i] = 0x10000;
    }
}


/*=====================*/
/* Clear all callbacks */
/*=====================*/

void soundCallbacksClear(void) {
  soundFrequencyHandlerCallback = NULL;
  soundBufferPlayCallback = NULL;
  soundEmulationStartingCallback = NULL;
  soundEmulationStoppingCallback = NULL;
}


/*================================================================*/
/* Test sound mode, possibly adjusting config to minimum settings */
/*================================================================*/

void soundModeValid(sound_device *sd) {
  if (!sd->channels[sound_channels])
    sound_channels = SOUND_MONO;
  if (!sd->bits[sound_bits])
    sound_bits = SOUND_8BITS;
  if (sd->rates_max[sound_bits][sound_channels] < sound_rate)
    sound_rate = SOUND_15650;
}  
    

/*===================================================*/
/* Called whenever a new sound quality is selected   */
/* Call the sound card init routine for this quality */
/*===================================================*/

void soundModeInit(void) {
  ULO oldrate, oldchannels, oldbits;

  audiocounter = 0;
  if (sound_mode == SOUND_EMULATE) {      /* Emulate, no output */
    soundPeriodTabInit(sound_rate_default[sound_rate]);
    soundVolumeTabInit();
    soundFrequencyHandlerCallback = sound_freqhandlers[sound_rate];
    soundSampleAddCallback = soundSampleAddDummy;
    soundBufferPlayCallback = NULL;
    soundEmulationStartingCallback = NULL;
    soundEmulationStoppingCallback = NULL;
    }
  else if (sound_mode > SOUND_NONE) { /* Play sound */
    /* Check here for valid sound quality */
    soundModeValid(&sound_sbdev);
    soundPeriodTabInit(sound_sbdev.modeSetCallback());
    soundVolumeTabInit();
    soundFrequencyHandlerCallback = sound_freqhandlers[sound_rate];
    soundSampleAddCallback =
      sound_sbdev.sampleAddCallback[sound_bits][sound_channels];
    soundBufferPlayCallback = sound_sbdev.bufferPlayCallback;
    soundEmulationStartingCallback = sound_sbdev.emulationStartingCallback;
    soundEmulationStoppingCallback = sound_sbdev.emulationStoppingCallback;
    
  }
  else /* Sound off */
    soundCallbacksClear();
}


/*=======================*/
/* Clear a device struct */
/*=======================*/

void soundDeviceClear(sound_device *sd) {
  memset(sd, 0, sizeof(sd));
}


/*====================================*/
/* Called on emulation start and stop */
/*====================================*/

void soundEmulationStarting(void) {
  sound_buffer_depth_eol_index = (9*313) - (sound_buffer_depth*313);
  if (sound_mode != SOUND_NONE && sound_mode != SOUND_EMULATE)
    if (soundEmulationStartingCallback != NULL)
      (*soundEmulationStartingCallback)();
  if (sound_wav_dump) {
    (*sound_wavdev.emulationStartingCallback)();
    soundSampleAddSecondaryCallback = soundSampleAddCallback;
    soundSampleAddCallback =
      sound_wavdev.sampleAddCallback[sound_bits][sound_channels];
  }
}


void soundEmulationStopping(void) {
  if (sound_mode != SOUND_NONE && sound_mode != SOUND_EMULATE)
    if (soundEmulationStoppingCallback != NULL)
      (*soundEmulationStoppingCallback)();
  if (sound_wav_dump) {
    (*sound_wavdev.emulationStoppingCallback)();
    soundSampleAddCallback = soundSampleAddSecondaryCallback;
  }
}


/*======================================*/
/* Called every time we do a hard-reset */
/*======================================*/

void soundReset(void) {
  ULO i;

  for (i = 0; i < 4; i++) {
    audpt[i] = 0;
    audptw[i] = 0;
    audlen[i] = 2;
    audper[i] = 0;
    audvol[i] = 0;
    audpercounter[i] = 0;
    auddat[i] = 0;
    auddatw[i] = 0;
    audlenw[i] = 2;
    audstate[i] = audiostate0;
    audvolw[i] = 0;
    iowrite[(0xa0>>1) + (0x8*i)] = waudXpth;
    iowrite[(0xa2>>1) + (0x8*i)] = waudXptl;
    iowrite[(0xa4>>1) + (0x8*i)] = waudXlen;
    iowrite[(0xa6>>1) + (0x8*i)] = waudXper;
    iowrite[(0xa8>>1) + (0x8*i)] = waudXvol;
  }
#ifdef SOUND_C       
  audio_hblanks = (ULO) audio_kill_channel;
#endif
  audio_hblanks = 0;
  audio_hblanks_thisbuffer = 0;
}


/*=================================*/
/* Called once on emulator startup */
/*=================================*/

void soundStartup(void) {
  soundReset();
  soundCallbacksClear();
  soundDeviceClear(&sound_sbdev);
  soundDeviceClear(&sound_wavdev);
  audioodd = 0;
#ifdef WITH_OS_SOUND
  sbStartup(&sound_sbdev);
#endif
  wavStartup(&sound_wavdev);
  sound_device_found = sound_sbdev.found;
  if (!sound_device_found)
    if (sound_mode == SOUND_PLAY || sound_mode == SOUND_CONTIGUOUS)
      sound_mode = SOUND_NONE;
}


/*==================================*/
/* Called once on emulator shutdown */
/*==================================*/

void soundShutdown(void) {
#ifdef WITH_OS_SOUND
  if (sound_sbdev.found)
    sbShutdown();
#endif
}

