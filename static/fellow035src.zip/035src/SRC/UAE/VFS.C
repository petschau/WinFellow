 /*
  * UAE - The Un*x Amiga Emulator
  *
  * Virtual File System support - dos version
  *
  * (c) 1997 Gustavo Goedert
  */

/*===================================================================*/
/* Adapted for use in Fellow by Petter Schau, 1998                   */
/* vfs.c was taken from the source code distribution of DOSUAE V075b */
/* Sections of code taken out are marked by FELLOW OUT               */
/* Sections added are marked by FELLOW IN                            */
/*                                                                   */
/* Included with permission from the original authors                */
/*===================================================================*/


/* FELLOW OUT (START)---------------------

#include "sysconfig.h"
#include "sysdeps.h"

#include <ctype.h>

#include "filesys.h"
#include "vfs.h"

   FELLOW OUT (END)-----------------------*/


/* FELLOW IN (START)----------------------*/

#include <stdio.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <ctype.h>
#include <direct.h>
#include <dos.h>
#include <io.h>

#include "uae2fell.h"
#include "filesys.h"
#include "vfs.h"

/* D_OK is not defined by Watcom...? Trying F_OK for now.... PS */

#define D_OK F_OK        

/* FELLOW IN (END)------------------------*/


typedef struct {
	char *RealName;
	char *VirtualName;
	ULONG Attributes;
	int Modified;
} VFS_Entry;

int NumberEntrys;
VFS_Entry **Entrys;
char CurrentPath[1024] = "";

#define PROTNAMES 12

char *ProtectedNames[PROTNAMES] = {
    "AUX", "CLOCK$", "COM1", "COM2", "COM3", "COM4",
    "CON", "LPT1",   "LPT2", "LPT3", "NUL",  "PRN"
};

char *ProtectedCharacters = " \t`%^*-+=|\\?[]:;\",.<>";

int LoadVFS(void);
int LoadPath(char *Directory);
void AddVFS_Entry(VFS_Entry *NewEntry);
VFS_Entry *FindRealName(char *RealName);
VFS_Entry *FindVirtualName(char *VirtualName);
int IsProtectedName(char *RealName);
void ResetVFS(void);
void SaveVFS(void);

int LoadVFS(void) {
    char TempName[1024];
    FILE *VFSFile;
    int i, Error = 0;
    unsigned short NEntrys, Length;
    VFS_Entry *Entry;
    DIR *dir;
    struct dirent *ent;

    ResetVFS();

    /* FELLOW OUT (START)---------------------

    if (access(CurrentPath, D_OK) != 0)
	return(0);

       FELLOW OUT (END)-----------------------*/
    
    strcpy(TempName, CurrentPath);
    strcat(TempName, VFSFILENAME);
    if (access(TempName, F_OK) == 0) {
	VFSFile = fopen(TempName, "rb");
	if (VFSFile != NULL) {
	    if (fread(&NEntrys, sizeof(unsigned short), 1, VFSFile) == 1) {
		for (i=0; i<NEntrys; i++) {
		    Entry = malloc(sizeof(VFS_Entry));
		    Entry->RealName = NULL;
		    Entry->VirtualName = NULL;
		    if (Entry == NULL)
			Error = 1;
		    if (!Error)
			if (fread(&Length, sizeof(unsigned short), 1, VFSFile) != 1)
			    Error = 1;
		    if (!Error) {
			Entry->RealName = malloc(Length+1);
			if (Entry->RealName == NULL)
			    Error = 1;
			if (!Error) {
			    Entry->RealName[Length] = '\0';
			    if (fread(Entry->RealName, 1, Length, VFSFile) != (unsigned) Length) {
				free(Entry->RealName);
				Error = 1;
			    }
			}
		    }
		    if (!Error)
			if (fread(&Length, sizeof(unsigned short), 1, VFSFile) != 1)
			    Error = 1;
		    if (!Error) {
			if (Length) {
			    Entry->VirtualName = malloc(Length+1);
			    if (Entry->VirtualName == NULL)
				Error = 1;
			    if (!Error) {
				Entry->VirtualName[Length] = '\0';
				if (fread(Entry->VirtualName, 1, Length, VFSFile) != (unsigned) Length) {
				    free(Entry->VirtualName);
				    Error = 1;
				}
			    }
			} else
			    Entry->VirtualName = Entry->RealName;
		    }
		    if (!Error) {
			if (fread(&(Entry->Attributes), sizeof(ULONG), 1, VFSFile) != 1)
			    Error = 1;
			else
			    Entry->Modified = 1;
		    }
		    if (!Error) {
			strcpy(TempName, CurrentPath);
			strcat(TempName, Entry->RealName);
			if (access(TempName, F_OK) == 0)
			    AddVFS_Entry(Entry);
			else {
			    if ((Entry->RealName) != (Entry->VirtualName))
				free(Entry->VirtualName);
			    free(Entry->RealName);
			    free(Entry);
			}
		    } else {
			if (Entry->RealName != NULL) {
			    if ((Entry->RealName) != (Entry->VirtualName))
				free(Entry->VirtualName);
			    free(Entry->RealName);
			}
			free(Entry);
			break;
		    }
		}
		if (Error)
		    ResetVFS();
	    }
	    fclose(VFSFile);
	}
    }
    if ((dir = opendir(CurrentPath)) == NULL)
	return(0);
    while ((ent = readdir(dir)) != NULL) {
	if (FindRealName(ent->d_name) == NULL) {
	    Entry = malloc(sizeof(VFS_Entry));
	    if (Entry != NULL) {
		Entry->RealName = strdup(ent->d_name);
		Entry->VirtualName = Entry->RealName;
		Entry->Attributes = 0;
		Entry->Modified = 0;
		AddVFS_Entry(Entry);
	    }
	}
    }
    closedir(dir);
    return(1);
}

int LoadPath(char *Directory) {
    char TempName[1024];

    strcpy(TempName, Directory);
    strcat(TempName, "/");
    if (CurrentPath[0]) {
	if (strcasecmp(TempName, CurrentPath) == 0)
	    return(1);
    }
    strcpy(CurrentPath, TempName);
    if (!LoadVFS()) {
	*CurrentPath = '\0';
	return(0);
    }
    return(1);
}

void AddVFS_Entry(VFS_Entry *NewEntry) {
    if (NumberEntrys == 0)
	Entrys = malloc(sizeof(VFS_Entry *));
    else
	Entrys = realloc(Entrys, sizeof(VFS_Entry *)*(NumberEntrys+1));
    if (Entrys != NULL) {
	Entrys[NumberEntrys] = NewEntry;
	NumberEntrys++;
    }
}

VFS_Entry *FindRealName(char *RealName) {
    int i;
    VFS_Entry *Entry;

    for (i = 0; i < NumberEntrys; i++)
	if (stricmp(RealName, Entrys[i]->RealName) == 0)
	    return (Entrys[i]);
    return(NULL);
}

VFS_Entry *FindVirtualName(char *VirtualName) {
    int i;
    VFS_Entry *Entry;

    for (i = 0; i < NumberEntrys; i++)
	if (stricmp(VirtualName, Entrys[i]->VirtualName) == 0)
	    return (Entrys[i]);
    return(NULL);
}

int IsProtectedName(char *RealName) {
    int i;

    for (i = 0; i < PROTNAMES; i++)
	if (stricmp(RealName, ProtectedNames[i]) == 0)
	    return(1);
    return(0);
}

char *CreateRealName(char *Directory, char *VirtualName, int MangleSize) {
    static char RealName[1024];
    char TempName[1024];
    char *Ptr, *VirtualNameCopy;
    char *BaseName, *ExtName;
    int i, LenName, PosNumber, IsProtected;
    VFS_Entry *Entry;

    *RealName = '\0';
    if (LoadPath(Directory)) {
	Entry = FindVirtualName(VirtualName);
	if (Entry != NULL)
	    strcpy(RealName, Entry->RealName);
	else {
	    VirtualNameCopy = strdup(VirtualName);
	    BaseName = VirtualNameCopy;
	    Ptr = strrchr(BaseName, '.');
	    if (Ptr) {
		*Ptr = '\0';
		ExtName = Ptr + 1;
	    } else
		ExtName = NULL;
	    while ((Ptr = strpbrk(BaseName, ProtectedCharacters)) != NULL)
		*Ptr = '_';
	    if (ExtName) {
		while ((Ptr = strpbrk(ExtName, ProtectedCharacters)) != NULL)
		    *Ptr = '_';
		if (strlen(ExtName) > strlen(BaseName)) {
		    Ptr = BaseName;
		    BaseName = ExtName;
		    ExtName = Ptr;
		}
	    }
	    LenName = strlen(BaseName);
	    if (LenName > MangleSize)
		BaseName[MangleSize] = '\0';
	    strcpy(TempName, BaseName);
	    if (ExtName)
		if (ExtName[0]) {
		    LenName = strlen(ExtName);
		    if (MangleSize < 3) {
			if (LenName > MangleSize)
			    ExtName[MangleSize] = '\0';
		    } else if (LenName > 3)
			ExtName[3] = '\0';
		    strcat(TempName, ".");
		    strcat(TempName, ExtName);
		}
	    IsProtected = IsProtectedName(TempName);
	    strcpy(TempName, CurrentPath);
	    strcat(TempName, BaseName);
	    if (ExtName)
		if (ExtName[0]) {
		    strcat(TempName, ".");
		    strcat(TempName, ExtName);
		}
	    if (IsProtected || (access(TempName, F_OK) == 0)) {
		LenName = strlen(BaseName);
		for (i=0; i<10000; i++) {
		    PosNumber = 7 - strlen(itoa(i, TempName, 10));
		    if (PosNumber < LenName)
			BaseName[PosNumber] = '\0';
		    sprintf(TempName, "%s%s#%d", CurrentPath, BaseName, i);
		    if (ExtName)
			if (ExtName[0]) {
			    strcat(TempName, ".");
			    strcat(TempName, ExtName);
			}
		    if (access(TempName, F_OK) != 0)
			break;
		}
		if (i == 10000) {
		    *RealName = '\0';
		    free(VirtualNameCopy);
		    return(RealName);
		}
	    }
	    if ((Ptr = strrchr(TempName, '/')) != NULL)
		strcpy(TempName, Ptr+1);
	    Entry = FindRealName(TempName);
	    if (Entry != NULL) {
		if ((Entry->RealName) != (Entry->VirtualName))
		    free(Entry->VirtualName);
		Entry->VirtualName = strdup(VirtualName);
		Entry->Attributes = 0;
		Entry->Modified = 1;
		strcpy(RealName, TempName);
	    } else {
		Entry = malloc(sizeof(VFS_Entry));
		if (Entry != NULL) {
		    Entry->RealName = strdup(TempName);
		    Entry->VirtualName = strdup(VirtualName);
		    Entry->Attributes = 0;
		    Entry->Modified = 1;
		    AddVFS_Entry(Entry);
		    strcpy(RealName, TempName);
		} else
		    *RealName = '\0';
	    }
	    SaveVFS();
	    free(VirtualNameCopy);
	}
    }
    return(RealName);
}

char *GetRealName(char *Directory, char *VirtualName) {
    static char RealName[1024];
    VFS_Entry *Entry;

    *RealName = '\0';
    if (LoadPath(Directory)) {
	Entry = FindVirtualName(VirtualName);
	if (Entry != NULL)
	    strcpy(RealName, Entry->RealName);
    }
    return(RealName);
}

char *GetVirtualName(char *Directory, char *RealName) {
    static char VirtualName[1024];
    VFS_Entry *Entry;

    *VirtualName = '\0';
    if (LoadPath(Directory)) {
	Entry = FindRealName(RealName);
	if (Entry != NULL)
	    strcpy(VirtualName, Entry->VirtualName);
    }
    return(VirtualName);
}

ULONG GetAttributes(char *Directory, char *RealName, mode_t Mode) {
    VFS_Entry *Entry;

    if (LoadPath(Directory)) {
	Entry = FindRealName(RealName);
	if (Entry != NULL)
	    if (Entry->Modified)
		return(Entry->Attributes);
    }
    return((S_IWUSR & Mode ? 0 : A_FIBF_WRITE) |
#if 0 /* This makes it impossible to overwrite those. */
	   (S_IWUSR & Mode ? 0 : A_FIBF_DELETE) |
#endif
	   (S_IRUSR & Mode ? 0 : A_FIBF_READ));
}

int SetAttributes(char *Directory, char *RealName, mode_t Mode, ULONG Attributes) {
    VFS_Entry *Entry;

    if (LoadPath(Directory)) {
	Entry = FindRealName(RealName);
	if (Entry != NULL) {
	    Entry->Attributes = Attributes;
	    Entry->Modified = 1;
	    SaveVFS();
	}
    }
    if (Attributes & A_FIBF_READ)
	Mode &= ~S_IRUSR;
    else
	Mode |= S_IRUSR;

    if ((Attributes & A_FIBF_WRITE) != 0 || (Attributes & A_FIBF_DELETE) != 0)
	Mode &= ~S_IWUSR;
    else
	Mode |= S_IWUSR;

    if (Attributes & A_FIBF_EXECUTE)
	Mode &= ~S_IXUSR;
    else
	Mode |= S_IXUSR;
    return(chmod(RealName, Mode));
}

void ResetVFS(void) {
    int i;

    for (i = 0; i < NumberEntrys; i++) {
	if ((Entrys[i]->RealName) != (Entrys[i]->VirtualName))
	    free(Entrys[i]->VirtualName);
	free(Entrys[i]->RealName);
	free(Entrys[i]);
    }
    if (NumberEntrys)
	free(Entrys);
    NumberEntrys = 0;
}

void CleanDir(char *Directory) {
    strcpy(CurrentPath, Directory);
    strcat(CurrentPath, "/");
    LoadVFS();
    SaveVFS();
    *CurrentPath = '\0';
}

void SaveVFS(void) {
    char TempName[1024];
    int i;
    unsigned short Length = 0;
    FILE *VFSFile = NULL;

    strcpy(TempName, CurrentPath);
    strcat(TempName, VFSFILENAME);
    unlink(TempName);
    for (i = 0; i < NumberEntrys; i++)
	if (Entrys[i]->Modified)
	    Length++;
    if (Length) {
	VFSFile = fopen(TempName, "wb");
	if (VFSFile != NULL) {
	    fwrite(&Length, sizeof(unsigned short), 1, VFSFile);
	    for (i = 0; (i < NumberEntrys) && (VFSFile != NULL); i++) {
		if (Entrys[i]->Modified) {
		    Length = strlen(Entrys[i]->RealName);
		    fwrite(&Length, sizeof(unsigned short), 1, VFSFile);
		    fwrite(Entrys[i]->RealName, Length, 1, VFSFile);
		    if (strcmp(Entrys[i]->RealName, Entrys[i]->VirtualName)) {
			Length = strlen(Entrys[i]->VirtualName);
			fwrite(&Length, sizeof(unsigned short), 1, VFSFile);
			fwrite(Entrys[i]->VirtualName, Length, 1, VFSFile);
		    } else {
			Length = 0;
			fwrite(&Length, sizeof(unsigned short), 1, VFSFile);
		    }
		    fwrite(&Entrys[i]->Attributes, sizeof(ULONG), 1, VFSFile);
		}
	    }
	}
    }
    if (VFSFile != NULL)
	fclose(VFSFile);
}
