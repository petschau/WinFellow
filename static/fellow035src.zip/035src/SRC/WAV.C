/*=============================*/
/* Fellow Amiga Emulator       */
/* Wav file sound dump         */
/* (C) 1997-1998 Petter Schau  */
/*           and Rainer Sinsch */
/*=============================*/


#include <stdio.h>
#include <stdlib.h>
#include "defs.h"
#include "fellow.h"
#include "sound.h"
#include "graphem.h"
#include "draw.h"


FILE *wav_FILE;
STR wav_filename[16];
ULO wav_serial;
soundrates wav_rate;
soundchannels wav_channels;
soundbits wav_bits;
ULO wav_filelength;
soundDevSampleAddFunc wavSampleAddOldCallback;
ULO wav_samplecount;
LON wav_samplesum;


/*===============================================*/
/* Assembly stub to call old Sample Add Callback */
/*===============================================*/

void wavSampleAddOld(ULO newsamples);
#pragma aux wavSampleAddOld="cmp  dword ptr [wavSampleAddOldCallback], 0"\
                            "je   l1"\
			    "call dword ptr [wavSampleAddOldCallback]"\
			    "l1:"\
                            parm [ebx];


/*============================================================*/
/* Add samples to device                                      */
/* We're not very concerned with performance here. After all, */
/* we're doing file output, which is likely to be slower than */
/* anything we can do on our own.                             */
/*============================================================*/

#pragma aux wav8BitMonoSampleAdd parm [ebx];
void wav8BitMonoSampleAdd(ULO newsamples) {
  ULO i;

  push_eax();
  wav_samplecount = newsamples;
  if (wav_FILE)
    for (i = 0; i < wav_samplecount; i++) {
      wav_samplesum = (((LON) left[i] + (LON) right[i])>>8) + 0x80;
      fwrite(&wav_samplesum, 1, 1, wav_FILE);
    }
  wav_filelength += wav_samplecount;
  wavSampleAddOld(wav_samplecount);
  pop_eax();
}

#pragma aux wav8BitStereoSampleAdd parm [ebx];
void wav8BitStereoSampleAdd(ULO newsamples) {
  ULO i;

  push_eax();
  wav_samplecount = newsamples;
  if (wav_FILE)
    for (i = 0; i < wav_samplecount; i++) {
      wav_samplesum = (((LON) left[i])>>8) + 0x80;
      fwrite(&wav_samplesum, 1, 1, wav_FILE);
      wav_samplesum = (((LON) right[i])>>8) + 0x80;
      fwrite(&wav_samplesum, 1, 1, wav_FILE);
    }
  wav_filelength += wav_samplecount*2;
  wavSampleAddOld(wav_samplecount);
  pop_eax();
}

#pragma aux wav16BitMonoSampleAdd parm [ebx];
void wav16BitMonoSampleAdd(ULO newsamples) {
  ULO i;

  push_eax();
  wav_samplecount = newsamples;    
  if (wav_FILE)
    for (i = 0; i < wav_samplecount; i++) {
      wav_samplesum = left[i] + right[i];
      fwrite(&wav_samplesum, 2, 1, wav_FILE);
    }
  wav_filelength += wav_samplecount*2;
  wavSampleAddOld(wav_samplecount);
  pop_eax();
}

#pragma aux wav16BitStereoSampleAdd parm [ebx];
void wav16BitStereoSampleAdd(ULO newsamples) {
  ULO i;
  push_eax();
  wav_samplecount = newsamples;    
  if (wav_FILE)
    for (i = 0; i < wav_samplecount; i++) {
      fwrite(&left[i], 2, 1, wav_FILE);
      fwrite(&right[i], 2, 1, wav_FILE);
    }
  wav_filelength += wav_samplecount*4;
  wavSampleAddOld(wav_samplecount);
  pop_eax();
}


/*==================*/
/* Write WAV header */
/*==================*/

void wavHeaderWrite(void) {
  static STR *wav_RIFF = {"RIFF"};
  static STR *wav_WAVEfmt = {"WAVEfmt "};
  static ULO wav_fmtchunklength = 16;
  static STR *wav_data = {"data"};
  ULO bytespersecond;
  ULO bits = (wav_bits + 1)*8;
  ULO blockalign = (wav_channels + 1)*(wav_bits + 1);
  ULO rate_real;

  if (wav_rate == SOUND_15650) rate_real = 15650;
  else if (wav_rate == SOUND_22050) rate_real = 22050;
  else if (wav_rate == SOUND_31300) rate_real = 31300;
  else if (wav_rate == SOUND_44100) rate_real = 44100;
  bytespersecond = rate_real*(wav_channels+1)*(wav_bits+1);

  /* This must still be wrong since wav-editors only reluctantly reads it */
  
  if ((wav_FILE = fopen(wav_filename, "wb")) != NULL) {
    wav_filelength = 36;
    fwrite(wav_RIFF, 4, 1, wav_FILE);           /* 0  RIFF signature */
    fwrite(&wav_filelength, 4, 1, wav_FILE);    /* 4  Length of file, that is, the number of bytes following the RIFF/Length pair */

    fwrite(wav_WAVEfmt, 8, 1, wav_FILE);        /* 8  Wave format chunk coming up */
    fwrite(&wav_fmtchunklength, 1, 4, wav_FILE);/* 16 Length of data in WAVEfmt chunk */

    /* Write a WAVEFORMATEX struct */

    fputc(0x01, wav_FILE); fputc(0, wav_FILE);  /* 20 Wave-format WAVE_FORMAT_PCM */
    fputc(wav_channels + 1, wav_FILE);		/* 22 Channels in file */
    fputc(0, wav_FILE);
    fwrite(&rate_real, 4, 1, wav_FILE);          /* 24 Samples per second */
    fwrite(&bytespersecond, 4, 1, wav_FILE);    /* 28 Average bytes per second */
    fwrite(&blockalign, 2, 1, wav_FILE);        /* 32 Block align */
    fwrite(&bits, 2, 1, wav_FILE);              /* 34 Bits per sample */
    fwrite(wav_data, 4, 1, wav_FILE);		/* 36 Data chunk */
    wav_filelength -= 36;
    fwrite(&wav_filelength, 4, 1, wav_FILE);    /* 40 Bytes in data chunk */
    wav_filelength += 36;
    fclose(wav_FILE);
    wav_FILE = NULL;
  }
}  


void wavHeaderWriteOld(void) {
  static STR *wav_RIFF = {"RIFF"};
  static STR *wav_WAVEfmt = {"WAVEfmt "};
  static ULO wav_fmtchunklength = 16;
  static STR *wav_data = {"data"};
  ULO bytespersecond=wav_rate*(wav_channels+1)*(wav_bits+1);
  ULO bits = (wav_bits + 1)*8;
  ULO blockalign = (wav_channels + 1)*(wav_bits + 1);

  /* This must still be wrong since wav-editors only reluctantly reads it */
  
  if ((wav_FILE = fopen(wav_filename, "wb")) != NULL) {
    wav_filelength = 42;
    fwrite(wav_RIFF, 4, 1, wav_FILE);
    fwrite(&wav_filelength, 4, 1, wav_FILE);
    fwrite(wav_WAVEfmt, 8, 1, wav_FILE);
    fwrite(&wav_fmtchunklength, 1, 4, wav_FILE);/* Length of data in fmtchunk*/
    fputc(0x01, wav_FILE); fputc(0, wav_FILE);  /* Wave-format PCM */
    fputc(wav_channels + 1, wav_FILE);          /* Channels in file */
    fputc(0, wav_FILE);
    fwrite(&wav_rate, 4, 1, wav_FILE);          /* Sample rate */
    fwrite(&bytespersecond, 4, 1, wav_FILE);    /* Bytes per second */
    fwrite(&blockalign, 2, 1, wav_FILE);        /* Block align */
    fwrite(&wav_bits, 2, 1, wav_FILE);          /* Bits */
    fwrite(wav_data, 4, 1, wav_FILE);
    wav_filelength -= 42;
    fwrite(&wav_filelength, 4, 1, wav_FILE);
    wav_filelength += 42;
    fclose(wav_FILE);
    wav_FILE = NULL;
  }
}  

void wavLengthUpdate(void) {
  if (wav_FILE != NULL) {
    char s[80];

    sprintf(s, "Length is: %X\n", wav_filelength);
    addlog(s);
    fseek(wav_FILE, 4, SEEK_SET);
    fwrite(&wav_filelength, 4, 1, wav_FILE);
    fseek(wav_FILE, 40, SEEK_SET);
    wav_filelength -= 36;
    fwrite(&wav_filelength, 4, 1, wav_FILE);
    wav_filelength += 36;
  }
}

/*=================*/
/* Set up WAV file */
/*=================*/

void wavFileInit(void) {
  if ((wav_rate != sound_rate) ||
      (wav_bits != sound_bits) ||
      (wav_channels != sound_channels)) {
    sprintf(wav_filename, "FWAV%d.WAV", wav_serial++);
    wav_rate = sound_rate;
    wav_bits = sound_bits;
    wav_channels = sound_bits;
    wav_filelength = 0;
    wavHeaderWrite();
  }
  wav_FILE = fopen(wav_filename, "r+b");
  fseek(wav_FILE, 0, SEEK_END);
}

    
/*=====================================================*/
/* Emulation start and stop                            */
/*                                                     */
/* Called when wav dump is enabled                     */
/* Will either continue with old file (same settings), */
/* or create new (changed settings)                    */
/*=====================================================*/

void wavEmulationStarting(void) {
  wavFileInit();
  wavSampleAddOldCallback = soundSampleAddCallback;
}

void wavEmulationStopping(void) {
  wavLengthUpdate();
  if (wav_FILE != NULL) {
    fclose(wav_FILE);
    wav_FILE = NULL;
  }
}


/*==================================================*/
/* Called once on startup                           */
/*                                                  */
/* WAV supports any sound quality                   */
/* Hook into emulation start and stop notification  */
/* and listen to the samples generated by the sound */
/* emulation.                                       */
/*==================================================*/

void wavStartup(sound_device *sd) {
  ULO i, j;
  
  sd->found = TRUE;
  sd->channels[SOUND_MONO] = TRUE;
  sd->channels[SOUND_STEREO] = TRUE;
  sd->bits[SOUND_8BITS] = TRUE;
  sd->bits[SOUND_16BITS] = TRUE;
  sd->modeSetCallback = NULL;
  sd->emulationStartingCallback = wavEmulationStarting;
  sd->emulationStoppingCallback = wavEmulationStopping;
  sd->sampleAddCallback[SOUND_8BITS][SOUND_MONO] = wav8BitMonoSampleAdd;
  sd->sampleAddCallback[SOUND_8BITS][SOUND_STEREO] = wav8BitStereoSampleAdd;
  sd->sampleAddCallback[SOUND_16BITS][SOUND_MONO] = wav16BitMonoSampleAdd;
  sd->sampleAddCallback[SOUND_16BITS][SOUND_STEREO] = wav16BitStereoSampleAdd;
  sd->bufferPlayCallback = NULL;
  for (i = SOUND_8BITS; i <= SOUND_16BITS; i++)
    for (j = SOUND_MONO; j <= SOUND_STEREO; j++)
      sd->rates_max[i][j] = SOUND_44100;
  wav_serial = 0;
  wav_rate = wav_bits = wav_channels = 9999; /* ILLEGAL */
  wav_FILE = NULL;
  wav_filelength = 0;
}

/*=========================*/
/* Called once on shutdown */
/*=========================*/

void wavShutdown(void) {
  if (wav_FILE != NULL)
    fclose(wav_FILE);
}
