/*============================================================*/
/* Fellow Amiga Emulator                                      */
/* Host screen drawing initialization and some implementation */
/* (C) 1998 Petter Schau                                      */
/*============================================================*/


#include <stdio.h>
#include "defs.h"
#include "fellow.h"
#include "inout.h"
#include "68000.h"
#include "memory.h"
#include "graphem.h"

#include "draw.h"


ULO bg2ddf;

/* Description of the framebuffer */

char *draw_framebuffer[3];
ULO draw_effectiveheight;
ULO draw_linefullwidth;
ULO config_draw_framebuffers;


/* REORG: 25/8-98 */

ULO draw_startoffset[3]; /* Bytes from buffer start until first pixel */
ULO draw_scanlinemodulo; /* Bytes from last pixel to first pixel on next line*/
ULO draw_buffershow, draw_bufferdraw;



/* Old description */

ULO scanlinelength; /* Total length in bytes for a line */

ULO lineflags[314];       /* Last color the line was drawn with */
UBY lineflagstimes[314];  /* Multi-buffer countdown for lineflags */

ULO HAMRedMask = 0x0eff0eff;
ULO HAMGreenMask = 0xf81ff81f;
ULO HAMBlueMask = 0xffe0ffe0;
ULO HAMRedPos = 12, HAMGreenPos = 7, HAMBluePos = 1;


/* List of modes we can use */

struct gm_modelist *draw_modelist = NULL;

/* Clip positions for lores host screens */

ULO clipleftx = 120;
ULO cliprightx = 440;
ULO cliptop = 0x45;
ULO clipbot = 0x10d;

draw_routine_ptr drawptr;
draw_routine_ptr drawbgroutine;
draw_routine_ptr drawddfroutine;
draw_routine_ptr drawroutineptr;
draw_routine_ptr drawloresroutine,drawhiresroutine,drawdualloresroutine,
                 drawdualhiresroutine,drawhamroutine;



/* Used in translation of dual playfield
   syntax: dualtranslate[0 - PF1 behind, 1 - PF2 behind][PF1data][PF2data] */

UBY dualtranslate[2][256][256];


void drawMakeMaskPos(ULO size, ULO pos, ULO *mask_var, ULO *pos_var)
{
  ULO mask = 0, i;
  for (i = 0; i < size; i++)
  {
    mask <<= 1;
    mask |= 1;
  }
  *mask_var = ~((mask << (pos + 16)) | (mask << pos));
  *pos_var = pos + (size - 4);
}

void drawInitHamMaskPos(ULO redsize,
			ULO greensize,
			ULO bluesize,
			ULO redpos,
			ULO greenpos,
			ULO bluepos)
{
  drawMakeMaskPos(redsize, redpos, &HAMRedMask, &HAMRedPos);    
  drawMakeMaskPos(greensize, greenpos, &HAMGreenMask, &HAMGreenPos); 
  drawMakeMaskPos(bluesize, bluepos, &HAMBlueMask, &HAMBluePos);
}



ULO config_draw_cycleexact = FALSE;

ULO frames, frameskip;


void set_displaybuffer(void) {
 ULO tmp;
 int heightmodifier = config_graphics_scaley + 1;

 if (heightmodifier == 3) heightmodifier = 1;
 if (config_graphics_mode == 6 || debugging) return;
 if (config_graphics_maxfps == 2)
   tmp = 1;
 else
   tmp = 0;

 switch (config_graphics_mode) {
   case 0:                                       
     switch (draw_buffershow) {
       case 0:  VBE_setDisplayStart(0,0,tmp);
                break;
       case 1:  VBE_setDisplayStart(0,600/heightmodifier,tmp);
                break;
       case 2:  VBE_setDisplayStart(0,1200/heightmodifier,tmp);
                break;
       }
       break;
   case 1:
     switch (draw_buffershow) {
       case 0:  VBE_setDisplayStart(0,0,tmp);
                break;
       case 1:  VBE_setDisplayStart(0,200,tmp);
                break;
       case 2:  VBE_setDisplayStart(0,400,tmp);
                break;
       }
       break;
   case 2:
     switch (draw_buffershow) {
       case 0:  VBE_setDisplayStart(0,0,tmp);
                break;
       case 1:  VBE_setDisplayStart(0,240,tmp);
                break;
       case 2:  VBE_setDisplayStart(0,480,tmp);
                break;
       }
       break;
   case 3:
     switch (draw_buffershow) {
       case 0:  VBE_setDisplayStart(0,0,tmp);
                break;
       case 1:  VBE_setDisplayStart(0,480/heightmodifier,tmp);
                break;
       case 2:  VBE_setDisplayStart(0,960/heightmodifier,tmp);
                break;
       }
       break;
   case 4:
     switch (draw_buffershow) {
       case 0:  VBE_setDisplayStart(0,0,tmp);
                break;
       case 1:  VBE_setDisplayStart(0,400/heightmodifier,tmp);
                break;
       case 2:  VBE_setDisplayStart(0,800/heightmodifier,tmp);
                break;
       }
       break;
   case 5:
     switch (draw_buffershow) {
       case 0:  VBE_setDisplayStart(0,0,tmp);
                break;
       case 1:  VBE_setDisplayStart(0,350/heightmodifier,tmp);
                break;
       case 2:  VBE_setDisplayStart(0,700/heightmodifier,tmp);
                break;
       }
       break;
   case 7:
     switch (draw_buffershow) {
       case 0:  VBE_setDisplayStart(0,0,tmp);
                break;
       case 1:  VBE_setDisplayStart(0,240,tmp);
                break;
       case 2:  VBE_setDisplayStart(0,480,tmp);
                break;
       }
       break;
   case 8:
   case 11:
     switch (draw_buffershow) {
       case 0:  VBE_setDisplayStart(0,0,tmp);
                break;
       case 1:  VBE_setDisplayStart(0,400,tmp);
                break;
       case 2:  VBE_setDisplayStart(0,800,tmp);
                break;
       }
       break;
   case 9:
   case 12:
     switch (draw_buffershow) {
       case 0:  VBE_setDisplayStart(0,0,tmp);
                break;
       case 1:  VBE_setDisplayStart(0,480,tmp);
                break;
       case 2:  VBE_setDisplayStart(0,960,tmp);
                break;
       }
       break;
   case 10:
   case 13:
     switch (draw_buffershow) {
       case 0:  VBE_setDisplayStart(0,0,tmp);
                break;
       case 1:  VBE_setDisplayStart(0,300,tmp);
                break;
       case 2:  VBE_setDisplayStart(0,600,tmp);
                break;
       }
       break;
   }


}


/*========================*/
/* Graphics Mode handling */
/*========================*/

struct gm_modelist *draw_alloc_modelist_node(void) {
  return (struct gm_modelist *) malloc(sizeof(struct gm_modelist));
}

void draw_add_modelist_node(struct gm_modelist *node) {
  struct gm_modelist *tmp;

  if (draw_modelist == NULL) {
    draw_modelist = node;
    node->next = NULL;
    }
  else {
    tmp = draw_modelist;
    while (tmp->next != NULL) tmp = tmp->next;
    tmp->next = node;
    node->next = NULL;
    }
}

/*============================================================*/
/* Call graphics-driver to display the drawn buffer           */
/* Then prepare the buffer geometry for a drawing a new frame */ 
/*============================================================*/

void draw_switchbuffer(void) {
  if (++draw_buffershow > configdoublebuffer)
    draw_buffershow = 0;
  if (++draw_bufferdraw > configdoublebuffer)
    draw_bufferdraw = 0;
  screenptr = (ULO) ((UBY *) framebuffer) + bufferoffsets[draw_bufferdraw] +
	      draw_startoffset[draw_bufferdraw];
  if (configdoublebuffer != 0)
    set_displaybuffer();
  else if (config_graphics_flickerfree != 6 && config_graphics_flickerfree &&
	  !(lof & 0x8000))
    screenptr += scanlinelength;
}


/* Init tables */

void init_drawtables_320b(void) {
    int i;
    for (i = 0xc0; i < (0xc0 + 32); i++) iowrite[i] = wcolor;
    drawbgroutine = drawptr = drawbgline320b;
    drawddfroutine = drawddfline320b;
    drawloresroutine = drawlores320b;
    drawhiresroutine = drawlores320b;
    drawdualloresroutine = drawduallores320b;
    drawdualhiresroutine = drawduallores320b;
    drawhamroutine = drawham320b;
}

void init_drawtables_320w(void) {
    int i;
    for (i = 0xc0; i < (0xc0 + 32); i++) iowrite[i] = wcolor;
    drawbgroutine = drawptr = drawbgline320w;
    drawddfroutine = drawddfline320w;
    if (mmx_detected) {
      drawloresroutine = drawlores320wmmx;
      }
    else {
      drawloresroutine = drawlores320w;
      }
    drawhiresroutine = drawlores320w;
    drawdualloresroutine = drawduallores320w;
    drawdualhiresroutine = drawduallores320w;
    drawhamroutine = drawham320w;
}

void init_drawtables_640w(void) {
    int i;
    for (i = 0xc0; i < (0xc0 + 32); i++) iowrite[i] = wcolor;
    drawbgroutine = drawptr = drawbgline640w;
    drawddfroutine = drawddfline640w;
    drawloresroutine = drawlores640w;
    drawhiresroutine = drawhires640w;
    drawdualloresroutine = drawduallores640w;
    drawdualhiresroutine = drawdualhires640w;
    drawhamroutine = drawham640w;
}

void init_drawtables_800w(void) {
  int i;
  for (i = 0xc0; i < (0xc0 + 32); i++) iowrite[i] = wcolor; 
#ifndef DRAW_C
  if (config_draw_cycleexact) {       
    if (mmx_detected) {
      drawbgroutine = drawptr = drawbgline800wCC;
      drawloresroutine = drawlores800wmmxCC;
      drawhiresroutine = drawhires800wmmxCC;
      drawdualloresroutine = drawduallores800wmmx;
      }
    else {
      drawbgroutine = drawptr = drawbgline800wCC;
      drawloresroutine = drawlores800wCC;
      drawhiresroutine = drawhires800wCC;
      drawdualloresroutine = drawduallores800w;
      }
    for (i = 0xc0; i < (0xc0 + 32); i++) iowrite[i] = wcolorCC;
    }
  else if (mmx_detected) {
      drawbgroutine = drawptr = drawbgline800wmmx;
      drawloresroutine = drawlores800wmmx;
      drawhiresroutine = drawhires800wmmx;
      drawdualloresroutine = drawduallores800wmmx;
    }
  else
#endif
    {
    drawbgroutine = drawptr = drawbgline800w;
    drawloresroutine = drawlores800w;
    drawhiresroutine = drawhires800w;
    drawdualloresroutine = drawduallores800w;
    }
#ifndef DRAW_C
  if (config_draw_cycleexact) drawddfroutine = drawddfline800wCC;
  else
#endif
    drawddfroutine = drawddfline;
  drawdualhiresroutine = drawdualhires800w;
  drawhamroutine = drawham;
  
}

void draw_init_lineflagstables(void) {
  int i;

  for (i = 0; i < 314; i++) {
    lineflags[i] = 0xffff;
    lineflagstimes[i] = 10;
    }
}

void draw_init_dualtranslation_table(void) {
  int i,j,k,l;
  for (k = 0; k < 2; k++) {
    for (i = 0; i < 256; i++) {
      for (j = 0; j < 256; j++) {
        if (k == 0) { /* PF1 behind, PF2 in front */
          if (j == 0) l = i; /* PF2 transparent, PF1 visible */
          else { /* PF2 visible */
                 /* If color is higher than 0x3c it is a sprite */
            if (j < 0x40) l = j + 0x20;
            else l = j;
            }
          }
        else { /* PF1 in front, PF2 behind */
          if (i == 0) { /* PF1 transparent, PF2 visible */
            if (j == 0) l = 0;
            else {
              if (j < 0x40) l = j + 0x20;
              else l = j;
              }
            }
          else l = i; /* PF1 visible amd not transparent */
          }
        dualtranslate[k][i][j] = l;
        }
      }
    }
}

/* Things initialized once at startup */

void draw_init(void) {
  draw_init_lineflagstables();
  draw_init_dualtranslation_table();
  frameskip = 0;
}

