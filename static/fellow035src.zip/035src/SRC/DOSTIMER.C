/*=======================*/
/* Fellow Amiga Emulator */
/* DOS Timer routines    */
/* (C) 1998 Petter Schau */
/*=======================*/


#include "defs.h"
#include "timer.h"


BOOLE dostimer_started;
BOOLE dostimer_locked;
void (__interrupt __far *dostimer_old)();


/*=============================*/
/* DOS Timer Interrupt Handler */
/*=============================*/

void __interrupt __far dostimerHandler() {
  timerTick();
  outp(0x20,0x20);
}


/*================================*/
/* Lock pages used by this module */
/*================================*/

void dostimerLock(void) {
  if (!dostimer_locked) {
    lock_region((void near *)timer_routine_continuous, 1024);
    lock_region((void near *)timer_routine, 1024);
    lock_region(timer_calc_emuspeed, 1024);
    lock_region(&tick, sizeof(tick));
    lock_region(&tick2, sizeof(tick2));
    lock_region(&audio_hblanks, sizeof(audio_hblanks));
    lock_region(&newcc, sizeof(newcc));
    lock_region(&lastcc, sizeof(lastcc));
    lock_region(&xpos, sizeof(xpos));
    lock_region(&ypos, sizeof(ypos));
    lock_region(&emuspeed, sizeof(emuspeed));
    dostimer_locked = TRUE;
  }
}


/*==================================*/
/* Unlock pages used by this module */
/*==================================*/

void dostimerUnlock(void) {
  if (dostimer_locked) {
    unlock_region((void near *)timer_routine_continuous, 1024);
    unlock_region((void near *)timer_routine, 1024);
    unlock_region(timer_calc_emuspeed, 1024);
    unlock_region(&tick, sizeof(tick));
    unlock_region(&tick2, sizeof(tick2));
    unlock_region(&audio_hblanks, sizeof(audio_hblanks));
    unlock_region(&newcc, sizeof(newcc));
    unlock_region(&lastcc, sizeof(lastcc));
    unlock_region(&xpos, sizeof(xpos));
    unlock_region(&ypos, sizeof(ypos));
    unlock_region(&emuspeed, sizeof(emuspeed));
    dostimer_locked = FALSE;
  }
}


/*================*/
/* Set timer rate */
/*================*/

void dostimerRateSet(ULO divider) {
  outp(0x43, 0xb6);
  outp(0x40, divider & 0xff);
  outp(0x40, (divider >> 8) & 0xff;
}

/*==================*/
/* Start this timer */
/*==================*/

BOOLE dostimerStart(ULO hz) {
  dostimer_old = _dos_getvect(0x1c);
  dostimerLock();
  _dos_setvect(0x1c, dostimerHandler);
  dostimerRateSet(1193000/hz);
}


/*=================*/
/* Stop this timer */
/*=================*/

void dostimerStop(void) {
  dostimerRateSet(0xffff);
  _dos_setvect(0x1c, dostimer_old);
}


/*===================*/
/* DOS Timer Startup */
/*===================*/

void dostimerStartup(void) {
  dostimer_locked = FALSE;
  dostimer_started = FALSE;
  timerRegister(dostimerStart, dostimerStop);
}


/*====================*/
/* DOS Timer Shutdown */
/*====================*/

void dostimerStartup(void) {
  if (dostimer_started)
    dostimerStop();
  if (dostimer_locked)
    dostimerUnlock();
}


