/*=======================*/
/* Fellow Amiga Emulator */
/* List and Tree         */
/* (C) 1997 Petter Schau */
/*=======================*/


#include <stdio.h>
#include "defs.h"
#include "listtree.h"


/*==============*/
/* Generic list */
/*==============*/

list *listNew(void *node) {
  list *l;
  
  l = (list *) myMalloc(sizeof(list));
  l->next = l->prev = NULL;
  l->node = node;
  return l;
}

list *listNext(list *l) {
  return (l != NULL) ? l->next : NULL;
}

list *listPrev(list *l) {
  return (l != NULL) ? l->prev : NULL;
}

list *listLast(list *l) {
  list *t, *o;

  t = l;
  while ((o = listNext(t)) != NULL) t = o;
  return t;
}  

void *listNode(list *l) {
  return (l != NULL) ? l->node : NULL;
}

list *listAddFirst(list *root, list *l) {
  if (l != NULL) {
    l->next = root;
    l->prev = NULL;
    if (root != NULL) {
      if (root->prev != NULL) {
	l->prev = root->prev;
	root->prev->next = l;
      }
      root->prev = l;
    }
    return l;
  }
  return root;
}

list *listAddLast(list *root, list *l) {
  if (root != NULL) {
    list *tmp = listLast(root);
    tmp->next = l;
    l->prev = tmp;
    return root;
  }
  return l;
}

list *listAddSorted(list *root, list *l, int (*comp)(void *, void *)) {
  list *tmp;

  tmp = root;
  if (l == NULL) return tmp;
  while (tmp != NULL) {
    if (comp(listNode(tmp), listNode(l)) >= 0) {
      listAddFirst(tmp, l);
      if (tmp == root) return l;
      else return root;
    }
    tmp = listNext(tmp);
  }
  return listAddLast(root, l);
}

list *listCat(list *l1, list *l2) {
  list *t;
  
  if (l1 == NULL) return l2;
  else if (l2 == NULL) return l1;
  else {
    t = listLast(l1);
    t->next = l2;
    l2->prev = t;
  }
  return l1;
}

ULO listCount(list *l) {
  list *t;
  ULO i;

  t = l;
  i = 0;
  while (t != NULL) {
    t = listNext(t);
    i++;
  }
  return i;
}

void listRemove(list *l) {
  if (l != NULL) {
    if (l->prev != NULL) l->prev->next = l->next;
    if (l->next != NULL) l->next->prev = l->prev;
  }
}

void listFree(list *node) {
  listRemove(node);
  if (node != NULL) free(node);
}


/*==============*/
/* Generic tree */
/*==============*/

tree *treeNew(tree *parent, void *node) {
  tree *t;
  
  t = (tree *) myMalloc(sizeof(tree));
  t->parent = parent;
  t->node = node;
  t->child = NULL;
  t->lnode = listNew(t);
  return t;
}

void treeChildAdd(tree *t, tree *c) {
  if (t != NULL && c != NULL)
    t->child = (tree *) listNode(listAddLast((t->child != NULL) ?
					     t->child->lnode : NULL,
					     c->lnode));
}

tree *treeChild(tree *t) {
  return (t != NULL) ? t->child : NULL;
}

tree *treeSisterNext(tree *t) {
  return (tree *) listNode(listNext((t != NULL) ? t->lnode : NULL));
}

tree *treeSisterPrev(tree *t) {
  return (tree *) listNode(listPrev((t != NULL) ? t->lnode : NULL));
}

void *treeNode(tree *t) {
  return (t != NULL) ? t->node : NULL;
}

tree *treeParent(tree *t) {
  return (t != NULL) ? t->parent : NULL;
}

ULO treeChildCount(tree *t) {
  return listCount(t->child->lnode);
}
