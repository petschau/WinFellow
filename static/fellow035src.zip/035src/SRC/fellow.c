/*=========================================*/
/* Fellow Amiga Emulator                   */
/* Everything that didn't fit in elsewhere */
/* Main                                    */
/* (C) 1996-1998 Petter Schau              */
/*           and Roman Doljesi             */
/*=========================================*/


#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <setjmp.h>

#include "defs.h"
#include "fellow.h"
#include "inout.h"
#include "68000.h"
#include "memory.h"
#include "eventid.h"
#include "floppy.h"
#include "sblast.h"
#include "sound.h"
#include "joymouse.h"
#include "keyboard.h"
#include "draw.h"
#include "graphem.h"
#include "fhfile.h"
#include "bus.h"
#include "gui.h"
#include "copper.h"
#include "led.h"
#include "cianew.h"
#include "blit.h"
#include "various.h"
#include "BMP.h"

#ifdef UAE_FILESYS
#include "uaefsys.h"
#endif

/* Some vital paths used by various functions */

STR fellow_homedir[256];          /* The home-directory of fellow */
STR fellow_homeoriginaldir[256];  /* Original path for drive containing flw */
STR fellow_startdir[256];         /* The directory fellow was started in */

/* Debugger must init the screen emulation properly one time */

BOOLE debug_screentables_not_set = TRUE;

char *tmploc;

ULO trackmo = 0;

extern ULO bytestotransfer;

extern ULO indexx,leng;

extern ULO leftbutton;
extern ULO rightbutton;
extern ULO curcycle;


BOOLE mmx_detected;
ULO configdoublebuffer;
ULO config_printspeed;
ULO configguires;
ULO configmakelogfile;
BOOLE save_permit = TRUE;

STR configfilename[80] = "Fellow.cfg";

jmp_buf fellow_runtime_error_env;
ULO fellow_runtime_error_code;


#ifdef CYCLE_EXACT
BOOLE configcycleexact = FALSE;
#endif

/* Flags set if option was on cmd-line */

BOOLE cmddf[4] = {FALSE,FALSE,FALSE,FALSE};
BOOLE cmddfenabled[4] = {FALSE,FALSE,FALSE,FALSE};
BOOLE cmdfhfile[FHFILE_MAX_DEVICES], cmdfhfileenabled = FALSE;
BOOLE cmdfhfileinit = FALSE;
BOOLE cmdkick = FALSE, cmdfloppyfast = FALSE, cmddiskpath = FALSE;
BOOLE cmdchip = FALSE, cmdbogo = FALSE, cmdfast = FALSE;
BOOLE cmdjoya = FALSE, cmdjoyb = FALSE;
BOOLE cmdsoundrate = FALSE, cmdsoundchannels = FALSE, cmdsoundbits = FALSE;
BOOLE cmdsoundmethod = FALSE, cmdsoundfilter = FALSE;
BOOLE cmdsoundbufferdepth = FALSE;
BOOLE cmdmaxfps = FALSE, cmdlace = FALSE, cmdleds = FALSE, cmdkbdl = FALSE;
BOOLE cmdprintspeed = FALSE, cmdnogui = FALSE, cmdgmode = FALSE;
BOOLE cmdskip = FALSE, cmdcpuspeed = FALSE, cmdcputype = FALSE;
BOOLE cmddm1 = FALSE, cmddm2 = FALSE, cmddm3 = FALSE, cmddm4 = FALSE;
BOOLE cmddm5 = FALSE, cmddm6 = FALSE, cmddm7 = FALSE, cmddm8 = FALSE;
BOOLE cmddm9 = FALSE, cmddm0 = FALSE;
BOOLE cmdaltn = FALSE, cmdarun = FALSE;
BOOLE cmdmpos = FALSE, cmdsmpos = FALSE;
BOOLE cmdcycleexact = FALSE, cmdscaley = FALSE;
BOOLE cmdnommx = FALSE, cmdmemspace32 = FALSE, cmdf12exit = FALSE;
BOOLE cmdkeyname = FALSE;
BOOLE cmdsoundwav = FALSE;

ULO a7pointer;

#ifdef DEBUGBUILD
ULO cputracebuffer[524288];
ULO cputracebase[524288];
int cputraceflag;
int cputracecount=0;
int cputraceptr=0;
#endif


BOOLE gmodefirsttime[NROFMODES];

#ifdef DEBUGBUILD
/* ******************************************************************
   EVENT LOG CONFIGURATION DATA
   ******************************************************************

   Log buffer
   Layout:  
   -----------
   event id
   Frame number
   Ypos
   Xpos
  12 data longwords */

ULO logbuffer[EVENTCOUNT][16];
int logfirst;
int loglast;


/* Logging flags */

BOOLE logserialtransmitbufferemptyirq = FALSE;
BOOLE logdiskdmatransferdoneirq = FALSE;
BOOLE logsoftwareirq = FALSE;
BOOLE logciaairq = FALSE;
BOOLE logcopperirq = FALSE;
BOOLE logverticalblankirq = FALSE;
BOOLE logblitterreadyirq = FALSE;
BOOLE logaudioirq = FALSE;
BOOLE logserialreceivebufferfullirq = FALSE;
BOOLE logdisksyncvaluerecognizedirq = FALSE;
BOOLE logciabirq = FALSE;
BOOLE logstop = FALSE;
BOOLE logbuserrorex = FALSE;
BOOLE logoddaddressex = FALSE;
BOOLE logillegalinstructionex = FALSE;
BOOLE logdivisionby0ex = FALSE;
BOOLE logprivilegieviolationex = FALSE;
BOOLE logtrapex = FALSE;
BOOLE logfline = FALSE;


/* ******************************************************************
   END OF CONFIGURATION DATA
   ****************************************************************** */

#endif


void load_fellow_cfg(void) {
  FILE *C;
  char var[80];
  char val[256];
  char ledstr[256];
  char kbdstr[256];
  char arnstr[256];
  UWO *lptcfg;
  int i;

  /* Set default values, unless option was set on cmd-line */

  if (!cmdkbdl) kbdleds = 0;
  ledstr[0] = 0; kbdstr[0] = 0; arnstr[0] = 0;
  for (i = 0; i < 4; i++) {
    if (!cmddf[i])
      strcpy(floppy[i].imagename, "__None__");
    if (!cmddfenabled[i])
      floppy[i].enabled = TRUE;
  }
  for (i = 0; i < FHFILE_MAX_DEVICES; i++)
    if (!cmdfhfile[i])
      strcpy(config_fhfile_name[i], "__None__");
  if (!cmdfhfileenabled) config_fhfile_enabled = TRUE;
  if (!cmdkick) strcpy(config_memory_kickname, "kick.rom");
  if (!cmdkeyname) strcpy(config_memory_keyname,"rom.key");
  if (!cmdfloppyfast) floppy_fast = FALSE;
  if (!cmdchip) config_memory_chipsize = CHIPMEM;
  if (!cmdbogo) config_memory_bogosize = 0;
  if (!cmdfast) config_memory_fastsize = 0;
  if (!cmdjoya) config_joy[0] = 5;
  if (!cmdjoyb) config_joy[1] = 0;
  if (!cmdsoundrate) sound_rate = SOUND_15650;
  if (!cmdsoundchannels) sound_channels = SOUND_MONO;
  if (!cmdsoundbits) sound_bits = SOUND_8BITS;
  if (!cmdsoundmethod) sound_mode = SOUND_NONE;
  if (!cmdsoundfilter) sound_filter = SOUND_FILTER_ORIGINAL;
  if (!cmdsoundbufferdepth) sound_buffer_depth = 5;
  if (!cmdskip) config_graphics_skiprate = 0;
  if (!cmdleds) config_enableleds = 1;
  if (!cmdcpuspeed) config_cpu_speed = 1;
  if (!cmdprintspeed) config_printspeed = FALSE;
  if (!cmdlace) config_graphics_flickerfree = FALSE;
  if (!cmdmaxfps) config_graphics_maxfps = 0;
  if (!cmdcputype) config_cpu_type = 0;
#ifdef USE_GUI
  if (!cmdaltn) config_altn_loop = 0;
  if (!cmddiskpath) config_diskpath[0] = 0;
  if (!cmdarun) config_autorun = 0;
#endif
  if (!cmdcycleexact) config_draw_cycleexact = FALSE;
  if (!cmdscaley) config_graphics_scaley = 0;
  if (!cmdmemspace32) config_memory_space_32bit = FALSE;
  blit_fast = FALSE;
  blit_long = FALSE;
  if ((C = fopen(configfilename,"r")) != NULL) {
    while (!feof(C)) {
      fscanf(C, "%s %s\n", var, val);
      if (!strcmpi("Df0", var) && !cmddf[0])
        strcpy(floppy[0].imagename, val);
      else if (!strcmpi("Df1", var) && !cmddf[1])
        strcpy(floppy[1].imagename, val);
      else if (!strcmpi("Df2", var) && !cmddf[2])
        strcpy(floppy[2].imagename, val);
      else if (!strcmpi("Df3", var) && !cmddf[3])
        strcpy(floppy[3].imagename, val);
      else if (!strcmpi("Df0enabled", var) && !cmddfenabled[0])
        floppy[0].enabled = atoi(val);
      else if (!strcmpi("Df1enabled", var) && !cmddfenabled[1])
        floppy[1].enabled = atoi(val);
      else if (!strcmpi("Df2enabled", var) && !cmddfenabled[2])
        floppy[2].enabled = atoi(val);
      else if (!strcmpi("Df3enabled", var) && !cmddfenabled[3])
        floppy[3].enabled = atoi(val);
      else if (!strnicmp("HDfile", var, 6)) {
	if (!cmdfhfile[var[6] - 0x30]) {
          strcpy(config_fhfile_name[var[6] - 0x30], val);
	}
      }
      else if (!strcmpi("HDfileenabled",var) && !cmdfhfileenabled)
        config_fhfile_enabled = atoi(val);
      else if (!strcmpi("Kickfile",var) && !cmdkick)
        strcpy(config_memory_kickname, val);
      else if (!strcmpi("Keyfile",var) && !cmdkeyname)
        strcpy(config_memory_keyname,val);
      else if (!strcmpi("Floppyfast",var) && !cmdfloppyfast)
        floppy_fast = atoi(val);
#ifdef USE_GUI
      else if (!strcmp("Diskpath",var) && !cmddiskpath)
        strcpy(config_diskpath,val);
      else if (!strcmpi("Diskmem1",var) && !cmddm1)
        strcpy(memnames[0],val);
      else if (!strcmpi("Diskmem2",var) && !cmddm2)
        strcpy(memnames[1],val);
      else if (!strcmpi("Diskmem3",var) && !cmddm3)
        strcpy(memnames[2],val);
      else if (!strcmpi("Diskmem4",var) && !cmddm4)
        strcpy(memnames[3],val);
      else if (!strcmpi("Diskmem5",var) && !cmddm5)
        strcpy(memnames[4],val);
      else if (!strcmpi("Diskmem6",var) && !cmddm6)
        strcpy(memnames[5],val);
      else if (!strcmpi("Diskmem7",var) && !cmddm7)
        strcpy(memnames[6],val);
      else if (!strcmpi("Diskmem8",var) && !cmddm8)
        strcpy(memnames[7],val);
      else if (!strcmpi("Diskmem9",var) && !cmddm9)
        strcpy(memnames[8],val);
      else if (!strcmpi("Diskmem0",var) && !cmddm0)
        strcpy(memnames[9],val);
      else if (!strcmpi("AltNloop",var) && !cmdaltn)
        config_altn_loop = atoi(val) - 1;
      else if (!strcmpi("AutoRun",var) && !cmdarun)
        strcpy( &arnstr, val );
#endif /* USE_GUI */
      else if (!strcmpi("Chipmem",var) && !cmdchip)
        config_memory_chipsize = atoi(val);
      else if (!strcmpi("Bogomem",var) && !cmdbogo)
        config_memory_bogosize = atoi(val);
      else if (!strcmpi("Fastmem",var) && !cmdfast)
        config_memory_fastsize = atoi(val);
      else if (!strcmpi("Memoryspace",var) && !cmdmemspace32)
        config_memory_space_32bit = atoi(val);
      else if (!strcmpi("Sound",var) && !cmdsoundmethod)
        sound_mode = atoi(val);
      else if (!strcmpi("Soundrate", var) && !cmdsoundrate) {
        sound_rate = atoi(val);
        sound_set_by_config = TRUE;
      }
      else if (!strcmpi("Soundchannels", var) && !cmdsoundchannels) {
        sound_channels = atoi(val);
        sound_set_by_config = TRUE;
      }
      else if (!strcmpi("Soundbits", var) && !cmdsoundbits) {
        sound_bits = atoi(val);
        sound_set_by_config = TRUE;
      }
      else if (!strcmpi("SoundFilter",var) && !cmdsoundfilter)
	sound_filter = atoi(val);
      else if (!strcmpi("SoundWavDump",var) && !cmdsoundwav)
	sound_wav_dump = atoi(val);
      else if (!strcmpi("JoystickA",var) && !cmdjoya)
        config_joy[0] = atoi(val);
      else if (!strcmpi("JoystickB",var) && !cmdjoyb)
        config_joy[1] = atoi(val);
      else if (!strcmpi("Skiprate",var) && !cmdskip)
        config_graphics_skiprate = atoi(val);
      else if (!strcmpi("CycleExact",var) && !cmdcycleexact)
        config_draw_cycleexact = atoi(val);
      else if (!strcmpi("Scaley",var) && !cmdscaley)
        config_graphics_scaley = atoi(val);
      else if (!strcmpi("EnableLeds",var) && !cmdleds)
        strcpy( &ledstr, val );
      else if (!strcmpi("KbdLeds",var) && !cmdkbdl)
        strcpy( &kbdstr, val );
      else if (!strcmpi("Enableleds",var) && !cmdleds)
        config_enableleds = atoi(val);
      else if (!strcmpi("Cputype",var) && !cmdcputype)
        config_cpu_type = atoi(val);
      else if (!strcmpi("Cpuspeed",var) && !cmdcpuspeed)
        config_cpu_speed = atoi(val);
      else if (!strcmpi("Printspeed",var) && !cmdprintspeed)
        config_printspeed = atoi(val);
      else if (!strcmpi("Vesamode",var) && !cmdgmode)
        config_graphics_mode = atoi(val);
      else if (!strcmpi("Maxfps",var) && !cmdmaxfps)
        config_graphics_maxfps = atoi(val);
      else if (!strcmpi("Flickerfree",var) && !cmdlace)
        config_graphics_flickerfree = atoi(val);
      else if (!strcmpi("BlitFast", var))
        blit_fast = atoi(val);
      else if (!strcmpi("BlitLong", var))
        blit_long = atoi(val);
      else if (!strcmpi("SoundBufferDepth", var))
        sound_buffer_depth = atoi(val);
#ifdef UAE_FILESYS
      else if ((!strcmpi(var, "-m")) ||
	       (!strcmpi(var, "-v"))) {
	char buf[256];
	char *s2, *ptr;
	int c = var[1];
	int readonly = isupper(c);
	int vfs_module = (tolower(c) == 'v');
	int vfs_mangle_size = 8;
	
	strncpy(buf, val, 255); buf[255] = 0;
	s2 = strchr(buf, ':');
	if(s2) {
	  *s2++ = '\0';
	  if (vfs_module) {
	    ptr = strchr(s2, '*');
	    if (ptr) {
	      *ptr++ = '\0';
	      if ((*ptr) != 0)
		vfs_mangle_size = atoi(ptr);
	      if ((vfs_mangle_size<1) ||  (vfs_mangle_size>8))
		vfs_mangle_size = 8;
	    }
	  }
	  
	  {
	    char *tmp;
	    while ((tmp = strchr(s2, '\\')))
	      *tmp = '/';
	  }
	  
	  various_switch_to_homedir();
	  add_filesys_unit(buf, s2, readonly, 0, 0, 0, vfs_module,
			   vfs_mangle_size);
	  various_switch_to_startdir();
	}
      }
#endif
    }
    fclose(C);
    config_memory_chipsize &= 0x3c0000;
    if (config_memory_chipsize > CHIPMEM || config_memory_chipsize == 0)
      config_memory_chipsize = 0x200000;
    config_memory_bogosize &= 0x1c0000;
    if (config_memory_bogosize > BOGOMEM) config_memory_bogosize = BOGOMEM;
    if (config_memory_fastsize != 0x800000 &&
        config_memory_fastsize != 0x400000 &&
        config_memory_fastsize != 0x200000 &&
        config_memory_fastsize != 0x100000) config_memory_fastsize = 0;
    if (config_joy[0] > 5) config_joy[0] = 5;
    if (config_joy[1] > 5) config_joy[1] = 0;
    if (sound_rate > SOUND_44100) sound_rate = SOUND_15650;
    if (sound_channels > SOUND_STEREO) sound_channels = SOUND_MONO;
    if (sound_bits > SOUND_16BITS) sound_bits = SOUND_8BITS;
    if (sound_mode > SOUND_EMULATE) sound_mode = SOUND_NONE;
    if (sound_buffer_depth < 0 || sound_buffer_depth > 9)
      sound_buffer_depth = 5;
    if (config_cpu_speed > 1) config_cpu_speed = 1;
    if (config_printspeed > 1) config_printspeed = 0;
    if (config_graphics_mode > NROFMODES) config_graphics_mode = 0;
    if (config_graphics_flickerfree > 1) config_graphics_flickerfree = 0;
    if (config_graphics_maxfps > 2) config_graphics_maxfps = 0;
    if( ledstr[0] ) {
      if( !strcmpi( &ledstr, "off" ) ) config_enableleds = 0;/* no led diags */
      else if( !strcmpi( &ledstr, "scr" ) )
	config_enableleds = 1;/* PWR,DFx on SCR */
      else if( !strcmpi( &ledstr, "kb1" ) )
	config_enableleds = 0x81; /* DF123 on KBD */
      else if( !strcmpi( &ledstr, "kb2" ) )
	config_enableleds = 0x82; /* PWR,DF12 on KBD */
      else if( !strcmpi( &ledstr, "kb3" ) )
	config_enableleds = 0x83; /* PWR,DF1+2/3+4 on KBD */
      else if( !strcmpi( &ledstr, "lp1" ) )
	config_enableleds = 0x41; /* PWR,DFx on LPT1 */
      else if( !strcmpi( &ledstr, "lp2" ) )
	config_enableleds = 0x42; /* PWR,DFx on LPT2 */
      else if( !strcmpi( &ledstr, "lp3" ) )
	config_enableleds = 0x43; /* PWR,DFx on LPT3 */
      else if( !strcmpi( &ledstr, "lp1m" ) )
	config_enableleds = 0x51; /* PWR,DFx on LPT1 mirrored */
      else if( !strcmpi( &ledstr, "lp2m" ) )
	config_enableleds = 0x52; /* PWR,DFx on LPT2 mirrored */
      else if( !strcmpi( &ledstr, "lp3m" ) )
	config_enableleds = 0x53; /* PWR,DFx on LPT3 mirrored */
    };
    if( kbdstr[0] ) {
      if( !strcmpi( &kbdstr, "ncs" ) ) kbdleds = 0;      /* Num/Caps/Scroll */
      else if( !strcmpi( &kbdstr, "nsc" ) ) kbdleds = 1; /* Num/Scroll/Caps */
      else if( !strcmpi( &kbdstr, "cns" ) ) kbdleds = 2; /* Caps/Num/Scroll */
      else if( !strcmpi( &kbdstr, "csn" ) ) kbdleds = 3; /* Caps/Scroll/Num */
      else if( !strcmpi( &kbdstr, "scn" ) ) kbdleds = 4; /* Scroll/Caps/Num */
      else if( !strcmpi( &kbdstr, "ncs" ) ) kbdleds = 5; /* Scroll/Num/Caps */
    };
  }
  if( config_enableleds & 0x40 ) {
    lptcfg = (UWO *)0x410;                    /* paralel port config address */
    if( (config_enableleds & 3) > (lptcfg[0] >> 14) ) config_enableleds = 1;
    else {
      lptcfg = (UWO *)0x406;
      ledlpt = lptcfg[ config_enableleds & 3 ];  /* get info from BIOS area */
    };
  };
  /*  if( cmdfhfileinit ) {
    cmdfhfileinit = FALSE;
    fhfile_create();
  };*/
#ifdef USE_GUI
  if( config_altn_loop > 3 ) config_altn_loop = 0;
  i = -1;
  if( arnstr[0] ) {
    if( !strcmpi( &arnstr, "AltN" ) ) config_autorun = 1;
    if( !strcmpi( &arnstr, "Res" ) ) config_autorun = 2;
    if( !strcmpi( &arnstr, "AltNRes" ) ) config_autorun = 3;
  }
#endif
}

void save_fellow_cfg(void) {
  FILE *C;
  char ledstr[5];
  char kbdstr[4];
  char menustr[128];
  char arnstr[10];
  int i = -1;


  if( save_permit ) {
    switch( config_enableleds ) {
      case    1: strcpy( ledstr, "scr" ); break;
      case 0x81: strcpy( ledstr, "kb1" ); break;
      case 0x82: strcpy( ledstr, "kb2" ); break;
      case 0x83: strcpy( ledstr, "kb3" ); break;
      case 0x41: strcpy( ledstr, "lp1" ); break;
      case 0x42: strcpy( ledstr, "lp2" ); break;
      case 0x43: strcpy( ledstr, "lp3" ); break;
      case 0x51: strcpy( ledstr, "lp1m" ); break;
      case 0x52: strcpy( ledstr, "lp2m" ); break;
      case 0x53: strcpy( ledstr, "lp3m" ); break;
      default: strcpy( ledstr, "off" ); break;
    };
    switch( kbdleds ) {
      case 1: strcpy( kbdstr, "nsc" ); break;
      case 2: strcpy( kbdstr, "cns" ); break;
      case 3: strcpy( kbdstr, "csn" ); break;
      case 4: strcpy( kbdstr, "scn" ); break;
      case 5: strcpy( kbdstr, "snc" ); break;
      default: strcpy( kbdstr, "ncs" ); break;
    };
    if ((C = fopen(configfilename, "w")) != NULL) {
      for (i = 0; i < 4; i++)
	fprintf(C, "Df%d           %s\n", i, floppy[i].imagename);
      for (i = 0; i < FHFILE_MAX_DEVICES; i++) {
	fprintf(C,"HDfile%d       %s\n",i,config_fhfile_name[i]);
      }
      fprintf(C,"Kickfile      %s\n", config_memory_kicknameloaded);
      fprintf(C,"Keyfile       %s\n",config_memory_keyname);

      for (i = 0; i < 4; i++)
	fprintf(C, "Df%denabled    %d\n", i, floppy[i].enabled);
      fprintf(C, "HDfileenabled %d\n", config_fhfile_enabled);
      fprintf(C, "Floppyfast    %d\n", floppy_fast);
#ifdef USE_GUI
      switch( config_autorun ) {
	case 1: strcpy( arnstr, "AltN" ); break;
	case 2: strcpy( arnstr, "Res" ); break;
	case 3: strcpy( arnstr, "AltNRes" ); break;
	default: strcpy( arnstr, "None" ); break;
      }
      for (i = 0; i < 10; i++) {
	if( strcmp( memnames[i], "__None__" ) )
	  fprintf(C,"Diskmem%i      %s\n",(i==9) ? 0 : i+1, memnames[i]);
      };
      if( config_diskpath[0] )
	fprintf(C, "Diskpath      %s\n", config_diskpath);
      fprintf(C, "AltNloop      %d\n", config_altn_loop + 1);
      fprintf(C, "MenuPosActive %d\n", config_store_mpos);
      if( strlen( &menustr ) && config_store_mpos )
	fprintf(C, "MenuPos       %s\n", &menustr);
      fprintf(C, "Autorun       %s\n", arnstr);
#endif
      fprintf(C, "Chipmem       %d\n", config_memory_chipsize);
      fprintf(C, "Bogomem       %d\n", config_memory_bogosize);
      fprintf(C, "Fastmem       %d\n", config_memory_fastsize);
      fprintf(C, "Memoryspace   %d\n", config_memory_space_32bit);
      fprintf(C, "JoystickA     %d\n", config_joy[0]);
      fprintf(C, "JoystickB     %d\n", config_joy[1]);
      fprintf(C, "Sound         %d\n", sound_mode);
      fprintf(C, "Soundrate     %d\n", sound_rate);
      fprintf(C, "Soundchannels %d\n", sound_channels);
      fprintf(C, "Soundbits     %d\n", sound_bits);
      fprintf(C, "SoundFilter   %d\n", sound_filter);
      fprintf(C, "SoundWavDump  %d\n", sound_wav_dump);
      fprintf(C, "Skiprate      %d\n", config_graphics_skiprate);
      fprintf(C, "CycleExact    %d\n", config_draw_cycleexact);
      fprintf(C, "Scaley        %d\n", config_graphics_scaley);
      fprintf(C, "EnableLeds    %s\n", ledstr);
      fprintf(C, "KbdLeds       %s\n", kbdstr);
      fprintf(C, "Cputype       %d\n", config_cpu_type);
      fprintf(C, "Cpuspeed      %d\n", config_cpu_speed);
      fprintf(C, "Printspeed    %d\n", config_printspeed);
      fprintf(C, "Vesamode      %d\n", config_graphics_mode);
      fprintf(C, "Maxfps        %d\n", config_graphics_maxfps);
      fprintf(C, "Flickerfree   %d\n", config_graphics_flickerfree);
      fprintf(C, "BlitFast      %d\n", blit_fast);
      fprintf(C, "BlitLong      %d\n", blit_long);
      fprintf(C, "SoundBufferDepth %d\n", sound_buffer_depth);
      write_filesys_config(C);
      fclose(C);
    }
  }
}

#ifdef DEBUGBUILD

/* ******************************************************************
   LOGGING CONFIGURATION PROCEDURES
   ******************************************************************

   Returns false when something went wrong */


BOOLE loadlogconfig(void) {
  FILE *F;
  STR var[80];
  ULO value;

  if ((F = fopen("log.cfg", "r")) == NULL) return FALSE;
  while (!feof(F)) {
    fscanf(F, "%s %d\n", var, &value);
    if (strcmp("LOGSERIALTRANSMITBUFFEREMPTYIRQ", var) == 0)
      logserialtransmitbufferemptyirq = value;
    else if (strcmp("LOGDISKDMATRANSFERDONEIRQ", var) == 0)
      logdiskdmatransferdoneirq = value;
    else if (strcmp("LOGSOFTWAREIRQ", var) == 0)
      logsoftwareirq = value;
    else if (strcmp("LOGCIAAIRQ", var) == 0)
      logciaairq = value;
    else if (strcmp("LOGCOPPERIRQ", var) == 0)
      logcopperirq = value;
    else if (strcmp("LOGVERTICALBLANKIRQ", var) == 0)
      logverticalblankirq = value;
    else if (strcmp("LOGBLITTERREADYIRQ", var) == 0)
      logblitterreadyirq = value;
    else if (strcmp("LOGAUDIOIRQ", var) == 0)
      logaudioirq = value;
    else if (strcmp("LOGSERIALRECEIVEBUFFERFULLIRQ", var) == 0)
      logserialreceivebufferfullirq = value;
    else if (strcmp("LOGDISKSYNCVALUERECOGNIZEDIRQ", var) == 0)
      logdisksyncvaluerecognizedirq = value;
    else if (strcmp("LOGCIABIRQ", var) == 0)
      logciabirq = value;
    else if (strcmp("LOGSTOP", var) == 0)
      logstop = value;
    else if (strcmp("LOGBUSERROREX", var) == 0)
      logbuserrorex = value;
    else if (strcmp("LOGODDADDRESSEX", var) == 0)
      logoddaddressex = value;
    else if (strcmp("LOGILLEGALINSTRUCTIONEX", var) == 0)
      logillegalinstructionex = value;
    else if (strcmp("LOGDIVISIONBY0EX", var) == 0)
      logdivisionby0ex = value;
    else if (strcmp("LOGPRIVILEGIEVIOLATIONEX", var) == 0)
      logprivilegieviolationex = value;
    else if (strcmp("LOGTRAPEX", var) == 0)
      logtrapex = value;
    else if (strcmp("LOGFLINE", var) == 0)
      logfline = value;
  }
  fclose(F);
  return TRUE;
}    

BOOLE savelogconfig(void) {
  FILE *F;

  if ((F = fopen("log.cfg", "w")) == NULL) return FALSE;
  fprintf(F, "%s %d\n", "LOGSERIALTRANSMITBUFFEREMPTYIRQ",
	  logserialtransmitbufferemptyirq);
  fprintf(F, "%s %d\n", "LOGDISKDMATRANSFERDONEIRQ",
	  logdiskdmatransferdoneirq);
  fprintf(F, "%s %d\n", "LOGSOFTWAREIRQ",
	  logsoftwareirq);
  fprintf(F, "%s %d\n", "LOGCIAAIRQ",
	  logciaairq);
  fprintf(F, "%s %d\n", "LOGCOPPERIRQ",
	  logcopperirq);
  fprintf(F, "%s %d\n", "LOGVERTICALBLANKIRQ",
	  logverticalblankirq);
  fprintf(F, "%s %d\n", "LOGBLITTERREADYIRQ",
	  logblitterreadyirq);
  fprintf(F, "%s %d\n", "LOGAUDIOIRQ",
	  logaudioirq);
  fprintf(F, "%s %d\n", "LOGSERIALRECEIVEBUFFERFULLIRQ",
	  logserialreceivebufferfullirq);
  fprintf(F, "%s %d\n", "LOGDISKSYNCVALUERECOGNIZEDIRQ",
	  logdisksyncvaluerecognizedirq);
  fprintf(F, "%s %d\n", "LOGCIABIRQ",
	  logciabirq);
  fprintf(F, "%s %d\n", "LOGSTOP",
	  logstop);
  fprintf(F, "%s %d\n", "LOGBUSERROREX",
	  logbuserrorex);
  fprintf(F, "%s %d\n", "LOGODDADDRESSEX",
	  logoddaddressex);
  fprintf(F, "%s %d\n", "LOGILLEGALINSTRUCTIONEX",
	  logillegalinstructionex);
  fprintf(F, "%s %d\n", "LOGDIVISIONBY0EX",
	  logdivisionby0ex);
  fprintf(F, "%s %d\n", "LOGPRIVILEGIEVIOLATIONEX",
	  logprivilegieviolationex);
  fprintf(F, "%s %d\n", "LOGTRAPEX",
	  logtrapex);    
  fprintf(F, "%s %d\n", "LOGFLINE",
	  logfline);    
  fclose(F);
  return TRUE;
}    

#endif




extern ULO keybufferconsumepos;
extern ULO keybufferproducepos;
extern UBY keybuffer[];


UBY emuspeedstring[20];

void print_emuspeed(void) {
#ifdef WITH_OS_TIMER
  if ((sound_mode == SOUND_PLAY) || (config_graphics_maxfps == 1)) {
    if (fps > 50)
      fps = 50;
  }
  sprintf(emuspeedstring, "%3d", fps);
  plot_text_speedbuffer(emuspeedstring, 0x7fff, 0);
#endif
}


void setup_320w_tables(void) {
  init_drawtables_320w();
  graphem_init_p2c_320();
  wriw(bplcon0,0xdff100);
}

void setup_320b_tables(void) {
  init_drawtables_320b();
  graphem_init_p2c_320();
  wriw(bplcon0,0xdff100);
}

void setup_640w_tables(void) {
  init_drawtables_640w();
  graphem_init_p2c_800();
  wriw(bplcon0,0xdff100);
}

void setup_800w_tables(void) {
  init_drawtables_800w();
  graphem_init_p2c_800();
  wriw(bplcon0,0xdff100);
}

void setup_emu_800600w(void) {
  int hey;
  setup_800w_tables();
  set_mode800600w();
  clipleftx = 88;
  cliprightx = 472;
  cliptop = 0x1a;
  clipbot = 0x139;
  
  if (!config_graphics_flickerfree && config_graphics_scaley == 1) {
    vesa_scaley();
  }
}

void setup_emu_320200w(void) {
  setup_320w_tables();
  set_mode320200w();
  if (gmodefirsttime[config_graphics_mode]) {
    clipleftx = 129;
    cliprightx = 449;
    cliptop = 0x2c;
    clipbot = 0xf4;
    gmodefirsttime[config_graphics_mode] = 0;
  }
}

void setup_emu_320200b_bank(void) {
  setup_320b_tables();
  set_mode320200oldvga();
  if (gmodefirsttime[config_graphics_mode]) {
    clipleftx = 129;
    cliprightx = 449;
    cliptop = 0x2c;
    clipbot = 0xf4;
    gmodefirsttime[config_graphics_mode] = 0;
  }
  screenptr = (ULO) framebuffer;
}

void setup_emu_320240w(void) {
  setup_320w_tables();
  set_mode320240w();
  if (gmodefirsttime[config_graphics_mode]) {
    clipleftx = 129;
    cliprightx = 449;
    cliptop = 0x2c;
    clipbot = 0x11c;
    gmodefirsttime[config_graphics_mode] = 0;
  }
}

void setup_emu_320240b(void) {
  setup_320b_tables();
  set_mode320240b();
  if (gmodefirsttime[config_graphics_mode]) {
    clipleftx = 129;
    cliprightx = 449;
    cliptop = 0x2c;
    clipbot = 0x11c;
    gmodefirsttime[config_graphics_mode] = 0;
  }
}

void setup_emu_320400b(void) {
  setup_320b_tables();
  set_mode320400b();
  if (gmodefirsttime[config_graphics_mode]) {
    clipleftx = 129;
    cliprightx = 449;
    cliptop = 0x1a;
    clipbot = 0x139;
    gmodefirsttime[config_graphics_mode] = 0;
  }
}

void setup_emu_320480b(void) {
  setup_320b_tables();
  set_mode320480b();
  if (gmodefirsttime[config_graphics_mode]) {
    clipleftx = 129;
    cliprightx = 449;
    cliptop = 0x1a;
    clipbot = 0x139;
    gmodefirsttime[config_graphics_mode] = 0;
  }
}

void setup_emu_400300b(void) {
  setup_320b_tables();
  set_mode400300b();
  clipleftx = 88;
  cliprightx = 472;
  cliptop = 0x1a;
  clipbot = 0x139;
}

void setup_emu_320400w(void) {
  setup_320w_tables();
  set_mode320400w();
  if (gmodefirsttime[config_graphics_mode]) {
    clipleftx = 129;
    cliprightx = 449;
    cliptop = 0x1a;
    clipbot = 0x139;
    gmodefirsttime[config_graphics_mode] = 0;
  }
}

void setup_emu_320480w(void) {
  setup_320w_tables();
  set_mode320480w();
  if (gmodefirsttime[config_graphics_mode]) {
    clipleftx = 129;
    cliprightx = 449;
    cliptop = 0x1a;
    clipbot = 0x139;
    gmodefirsttime[config_graphics_mode] = 0;
  }
}

void setup_emu_400300w(void) {
  setup_320w_tables();
  set_mode400300w();
  clipleftx = 88;
  cliprightx = 472;
  cliptop = 0x1a;
  clipbot = 0x139;
}

void setup_emu_640480w(void) {
  int hey;
  setup_640w_tables();
  set_mode640480w();
  if (gmodefirsttime[config_graphics_mode]) {
    if (config_graphics_scaley == 0) {
      clipleftx = 129;
      cliprightx = 449;
      cliptop = 0x1a;
      clipbot = 0x139;
    }
    else {
      clipleftx = 129;
      cliprightx = 449;
      cliptop = 0x2c;
      clipbot = 0x2c + (480/2);
    }
    gmodefirsttime[config_graphics_mode] = 0;
  }
  if (config_graphics_scaley == 1) {
    vesa_scaley();
  }
}

void setup_emu_640400w(void) {
  int hey;
  setup_640w_tables();
  set_mode640400w();
  if (gmodefirsttime[config_graphics_mode]) {
    if (config_graphics_scaley == 0) {
      clipleftx = 129;
      cliprightx = 449;
      cliptop = 0x1a;
      clipbot = 0x139;
    }
    else {
      clipleftx = 129;
      cliprightx = 449;
      cliptop = 0x2c;
      clipbot = 0x2c + (400/2);
    }
    gmodefirsttime[config_graphics_mode] = 0;
  }
  if (config_graphics_scaley == 1) {
    vesa_scaley();
  }
}

void setup_emu_640350w(void) {
  int hey;
  setup_640w_tables();
  set_mode640350w();
  if (gmodefirsttime[config_graphics_mode]) {
    if (config_graphics_scaley == 0) {
      clipleftx = 129;
      cliprightx = 449;
      cliptop = 0x1a;
      clipbot = 0x139;
    }
    else {
      clipleftx = 129;
      cliprightx = 449;
      cliptop = 0x2c;
      clipbot = 0x2c + (350/2);
    }
    gmodefirsttime[config_graphics_mode] = 0;
  }
  if (config_graphics_scaley == 1) {
    vesa_scaley();
  }
}


void drawBufferGeometryDump(void) {
  STR s[80];
  ULO i;
  
  addlog("Draw-buffer geometry:\n");
  sprintf(s, "configdoublebuffer %d\n", configdoublebuffer);
  addlog(s);
  sprintf(s, "screenptr %X\n", screenptr);
  addlog(s);
  sprintf(s, "draw_buffershow %X\n", draw_buffershow);
  addlog(s);
  sprintf(s, "draw_bufferdraw %X\n", draw_bufferdraw);
  addlog(s);
  sprintf(s, "draw_scanlinemodulo %X\n", draw_scanlinemodulo);
  addlog(s);
  for (i = 0; i < 3; i++) {
    sprintf(s, "draw_startoffset[%d] %X\n", i, draw_startoffset[i]);
    addlog(s);
  }
  for (i = 0; i < 3; i++) {
    sprintf(s, "draw_bufferoffset[%d] %X\n", i, bufferoffsets[i]);
    addlog(s);
  }
}


void setup_emu_videomode(void) {
  int hey;
  
  debug_screentables_not_set = FALSE;
  if (newvmode == 2) {
    gmodefirsttime[config_graphics_mode] = TRUE;
    if (config_graphics_scaley == 0) newvmode = 1;
    }
  switch (config_graphics_mode) {
    case 0: setup_emu_800600w();
            break;
    case 1: setup_emu_320200w();
            break;
    case 2: setup_emu_320240w();
            break;
    case 3: setup_emu_640480w();
            break;
    case 4: setup_emu_640400w();
            break;
    case 5: setup_emu_640350w();
            break;
    case 6: setup_emu_320200b_bank();
            break;
    case 7: setup_emu_320240b();
            break;
    case 8: setup_emu_320400b();
            break;
    case 9: setup_emu_320480b();
            break;
    case 10: setup_emu_400300b();
            break;
    case 11: setup_emu_320400w();
            break;
    case 12: setup_emu_320480w();
            break;
    case 13: setup_emu_400300w();
            break;
    }

  if (configdoublebuffer == 1) {
    draw_bufferdraw = 0;
    draw_buffershow = 1;
  }
  else if (configdoublebuffer == 2) {
    draw_bufferdraw = 2;
    draw_buffershow = 1;
  }
  else {
    draw_buffershow = draw_bufferdraw = 0;
  }

  memoryColorTranslationInit();
  clear_framebuffer();
  draw_init_lineflagstables();
  if (config_graphics_mode != 6)
    screenptr = ( (ULO) framebuffer) + bufferoffsets[draw_bufferdraw] +
                draw_startoffset[draw_bufferdraw];
  init_copperytable();
  newvmode = 0;
  drawBufferGeometryDump();
}

ULO oldprintspeed;

void print_usage(void) {
  printf("Fellow V0.3.5\n");
  printf("Released 2000, Petter Schau and contributors under the GNU GPL.\n\n");
  printf("Option summary:\n");

  printf("\nGeneral options:\n");

  printf("-h                         This options summary\n");
  printf("-log                       Generate log-file while initializing\n");
#ifdef USE_GUI
  printf("-nogui                     Bypass initial GUI-session.\n");
  printf("-f12exit                   F12 exits emulator completely.\n");
#endif
  printf("-config file               Use file instead of default cfg-file\n");
  printf("-ns                        Don't save settings on exit\n" );
  printf("-nommx                     Don't use MMX instructions\n" );

  printf("\nFloppy disk options:\n");

  printf("-0 file                    Diskfile in df0\n");
  printf("-1 file                    Diskfile in df1\n");
  printf("-2 file                    Diskfile in df2\n");
  printf("-3 file                    Diskfile in df3\n");
  printf("-0e +|-                    Enable/disable df0\n");
  printf("-1e +|-                    Enable/disable df1\n");
  printf("-2e +|-                    Enable/disable df2\n");
  printf("-3e +|-                    Enable/disable df3\n");
  printf("-ds +|-                    Fast floppy-disk enable/disable\n");
  printf("-dmX file                  Disk memory X (0..9) contents\n" );
  printf("-dpath dir/file            Active disk path\n" );

  printf("\nHardfile options:\n");

  printf("-hfX file                  Hardfile filename, X is a number below %d\n", FHFILE_MAX_DEVICES);
  printf("-he +|-                    Hardfile devices enable/disable\n");

  printf("\nMemory options:\n");

  printf("-c size                    Chipmemory size,256,512,768,1024,1280,1536,1792,2048\n");
  printf("-b size                    Bogomemory size, 0,256,512,768,1024,1280,1536,1792\n");
  printf("-fm size                   Fastmemory size, size in MB, (0,1,2,4,8)\n");
  printf("-ms 24|32                  Memory space size, 24 or 32 bits\n");
  printf("-r file                    Kickstart file (Loads anywhere above $f00000)\n");
  printf("-r2 file                   Secondary Kickstart file (Loads at $f80000),\n");
  printf("                           for testing purposes.\n");
  printf("-K file                    Kickstart key-file\n");

  printf("\nJoystick options:\n");

  printf("-j1 n|a|m|k1|k2\n");
  printf("-j2 n|a|m|k1|k2            Joystick port 1 or 2:\n");
  printf("                           n - none, a - Analog Joystick\n");
  printf("                           m - mouse, k1 - Keyboard replacement 1\n");
  printf("                           k2 - Keyboard replacement 2\n");

  printf("\nSound emulation options:\n");

  printf("-s d|n|c|e                 Sound-emulation:\n");
  printf("                           d - disable n - normal c - continuous\n");
  printf("                           e - emulated, no output\n");
  printf("-sf quality                Sound quality: 44100,31300,22050,15650\n");
  printf("-ss on|off                 Stereo, on or off\n");
  printf("-sb bits                   8 or 16 bits\n");
  printf("-sd frames                 Sound buffer length in Amiga frames (1-9)\n");
  printf("-sw + | -                  Wav-dump soundlayer enable / disable\n");
  printf("-sl 0|1|2                  Low-pass Filter, 0-Original, 1-Always, 2-Never\n");
#ifdef SOUNDDRV_SOUNDBLASTER
  printf("-s1                        Force Soundblaster V1.0 driver\n");
#endif

  printf("\nScreen options:\n");

  printf("-res 320200b | 320200  |\n");
  printf("     320240  | 640350  |\n");
  printf("     640400  | 640480  |\n");
  printf("     800600  | 320240b |\n");
  printf("     320400b | 320480b |\n");
  printf("     400300b | 320400  |\n");
  printf("     320400  | 320480  |\n");
  printf("     400300\n");
  printf("                           Resolution, default: 800600\n");
  printf("-fl none|50|vga            Framerate limit: none, 50 - 50hz, vga - from card\n");
  printf("-f number                  Skip 1/number of frames.\n");
  printf("-i on|off                  De-interlace in 800x600 resolution\n");
  printf("-gc on|off                 Cycle-exact color update (Experimental)\n");
  printf("-y 0 | 1 | 2               Vertical scaling:\n");
  printf("                           0 - None\n");
  printf("                           1 - Hardware VGA line doubling\n");
  printf("                           2 - Blank line interleave\n");

  printf("\nCPU and blitter options:\n");

  printf("-cpu 0|1|2|3               CPU instruction set, 680X0\n");
  printf("-cs 3.5 | 7 | 14 | 28      CPU clock speed, 3.5MHZ, 7MHZ, 14MHZ or 28MHZ\n");

  printf("\nFilesystem options:\n");

  printf("-m volname:path            Mounts a normal filesystem\n");
  printf("-M volname:path            Mounts a normal filesystem readonly\n");
  printf("-v volname:path*mangle     Mounts a virtual filesystem\n");
  printf("-V volname:path*mangle     Mounts a virtual filesystem readonly\n");

  printf("\nVarious options:\n");

  printf("-p on|off                  On-screen speedmeasurement.\n");
  printf("-l scr|kb?|lp?|lp?m|off    Power/diskdrive led indicators:\n");
  printf("                               scr - on screen\n");
  printf("                               kb1 - on keyboard (drive 0, 1, 2)\n");
  printf("                               kb2 - on keyboard (power, drive 0, 1)\n");
  printf("                               kb3 - on keyboard (power, drive 0+1, 2+3)\n");
  printf("                            lp1/2/3 - on parallel port led meter\n");
  printf("                           lp1/2/3m - on parallel port led meter (mirrored)\n");
  printf("-lk ncs|nsc...             Use leds on PC keyboard in specified order\n" );
  printf("                           (Num lock = N, Caps lock = C, Scroll lock = S)\n" );
  printf("\nPlease consult the documentation for more information.\n");
  exit(EXIT_FAILURE);
}

/* Whoa!  Bastard Monster Function from Hell coming up */
/* Kludge, must be performed using the startup directory, not fellow homedir */

void parsecmd(int argc, char *argv[]) {
  int i,j;

  various_switch_to_startdir();

  config_graphics_flickerfree = FALSE;
  config_printspeed = FALSE;
  config_enableleds = TRUE;
#ifdef WITH_OS_SOUND
  config_sb_forceV1 = FALSE;
#endif
  configmakelogfile = FALSE;
  sound_rate = SOUND_15650;
  sound_channels = SOUND_MONO;
  sound_bits = SOUND_8BITS;
  for (i = 1; i < argc; i++) {

    /* General options: */

    if (!strcmpi(argv[i],"-log")) configmakelogfile = 1;
    else if (!strcmpi(argv[i],"-ns")) save_permit = FALSE;
    else if (!strcmpi(argv[i],"-nommx")) cmdnommx = TRUE;
    else if (!strcmpi(argv[i],"-h")) print_usage();
#ifdef USE_GUI
    else if (!strcmpi(argv[i],"-nogui")) cmdnogui = TRUE;
    else if (!strcmpi(argv[i],"-f12exit")) cmdf12exit = TRUE;
#endif
    else if (!strcmpi(argv[i],"-config")) { /* Use config-file */
      if (++i < argc) {
	strcpy(configfilename,argv[i]);
        various_make_relative_path(configfilename);
      }
      else {
	printf("Missing filename for -config\n");
	exit(EXIT_FAILURE);
      }
    }

    /* Filesystem options; */

#ifdef UAE_FILESYS
    else if ((!strcmpi(argv[i],"-m")) ||
	     (!strcmpi(argv[i],"-v"))) {
      char buf[256];
      char *s2, *ptr;
      int c = argv[i][1];
      int readonly = isupper(c);
      int vfs_module = (tolower(c) == 'v');
      int vfs_mangle_size = 8;
      
      strncpy(buf, argv[i + 1], 255); buf[255] = 0;
      s2 = strchr(buf, ':');
      if(s2) {
	*s2++ = '\0';
	if (vfs_module) {
	  ptr = strchr(s2, '*');
	  if (ptr) {
	    *ptr++ = '\0';
	    if ((*ptr) != 0)
	      vfs_mangle_size = atoi(ptr);
	    if ((vfs_mangle_size<1) ||  (vfs_mangle_size>8))
	      vfs_mangle_size = 8;
	  }
	}

	{
	  char *tmp;
	  while ((tmp = strchr(s2, '\\')))
	    *tmp = '/';
	}

	//various_make_relative_path(s2);
	various_switch_to_homedir();
	add_filesys_unit(buf, s2, readonly, 0, 0, 0, vfs_module,
			 vfs_mangle_size);
	various_switch_to_startdir();
      } else {
	if (!vfs_module)
	  fprintf(stderr, "Usage: [-m | -M] VOLNAME:/mount_point\n");
	else
	  fprintf(stderr, "Usage: [-v | -V] VOLNAME:/mount_point*mangle_size\n");
      }
    i++;
    }
#endif

    /* Joystick options: */

    else if (!strcmpi(argv[i],"-j1")) { /* Gameport 1 */
      cmdjoya = TRUE;
      if (++i < argc) {
	if (!strcmpi(argv[i],"n")) config_joy[0] = 0;
	else if (!strcmpi(argv[i],"k1")) config_joy[0] = 1;
	else if (!strcmpi(argv[i],"k2")) config_joy[0] = 2;
	else if (!strcmpi(argv[i],"a")) config_joy[0] = 3;
	else if (!strcmpi(argv[i],"m")) config_joy[0] = 5;
	else {
	  printf("Unknown argument for -j1\n");
	  exit(EXIT_FAILURE);
	}
      }
      else {
	printf("Missing argument for -j1\n");
	exit(EXIT_FAILURE);
      }
    }

    else if (!strcmpi(argv[i],"-j2")) { /* Gameport 2 */
      cmdjoyb = TRUE;
      if (++i < argc) {
	if (!strcmpi(argv[i],"n")) config_joy[1] = 0;
	else if (!strcmpi(argv[i],"k1")) config_joy[1] = 1;
	else if (!strcmpi(argv[i],"k2")) config_joy[1] = 2;
	else if (!strcmpi(argv[i],"a")) config_joy[1] = 3;
	else if (!strcmpi(argv[i],"m")) config_joy[1] = 5;
	else {
	  printf("Unknown argument for -j2\n");
	  exit(EXIT_FAILURE);
	}
      }
      else {
	printf("Missing argument for -j2\n");
	exit(EXIT_FAILURE);
      }
    }

    /* Sound options: */

    else if (!strcmpi(argv[i],"-s")) {  /* Sound emulation method: */
      cmdsoundmethod = TRUE;
      if (++i < argc) {
	if (!strcmpi(argv[i],"d")) sound_mode = SOUND_NONE;
	else if (!strcmpi(argv[i],"n")) sound_mode = SOUND_PLAY;
	else if (!strcmpi(argv[i],"c")) sound_mode = SOUND_CONTIGUOUS;
	else if (!strcmpi(argv[i],"e")) sound_mode = SOUND_EMULATE;
	else {
	  printf("Unknown argument for -s\n");
	  exit(EXIT_FAILURE);
	}
      }
      else {
	printf("Missing d/n/c/e for -s\n");
	exit(EXIT_FAILURE);
      }
    }

    else if (!strcmpi(argv[i], "-sf")) { /* Sound output rate */
      cmdsoundrate = TRUE;
      if (++i < argc) {
	sound_set_by_config = TRUE;
	if (!strcmpi(argv[i], "44100")) sound_rate = SOUND_44100;
	else if (!strcmpi(argv[i], "31300")) sound_rate = SOUND_31300;
	else if (!strcmpi(argv[i], "22050")) sound_rate = SOUND_22050;
	else if (!strcmpi(argv[i], "15650")) sound_rate = SOUND_15650;
	else {
	  printf("Unknown argument for -sf, specify 44100, 31300, 22050 or 15650\n");
	  exit(EXIT_FAILURE);
	}
      }
      else {
	printf("Missing frequency for -sf\n");
	exit(EXIT_FAILURE);
      }
    }

    else if (!strcmpi(argv[i], "-ss")) {  /* Stereo output */
      cmdsoundchannels = TRUE;
      if (++i < argc) {
	sound_set_by_config = TRUE;
	if (!strcmpi(argv[i], "on")) sound_channels = SOUND_STEREO;
	else if (!strcmpi(argv[i], "off")) sound_channels = SOUND_MONO;
	else {
	  printf("Unknown argument for -ss, stereo settings are ON or OFF\n");
	  exit(EXIT_FAILURE);
	}
      }
      else {
	printf("Missing on/off for -ss\n");
	exit(EXIT_FAILURE);
      }
    }

    else if (!strcmpi(argv[i],"-sb")) { /* Sound bits */
      cmdsoundbits = TRUE;
      if (++i < argc) {
	sound_set_by_config = TRUE;
	if (!strcmpi(argv[i], "8")) sound_bits = SOUND_8BITS;
	else if (!strcmpi(argv[i], "16")) sound_bits = SOUND_16BITS;
	else {
	  printf("Unknown argument for -sb , specifiy 8 or 16 bits.\n");
	  exit(EXIT_FAILURE);
	}
      }
      else {
	printf("Missing 8/16 for -sb\n");
	exit(EXIT_FAILURE);
      }
    }

    else if (!strcmpi(argv[i],"-sw")) { /* Wav dump */
      cmdsoundwav = TRUE;
      if (++i < argc) {
        if (strcmpi(argv[i], "+") == 0) sound_wav_dump = TRUE;
	else if (strcmpi(argv[i], "-") == 0) sound_wav_dump = FALSE;
	else {
	  printf("Please specify + or - for the -sw option\n");
          exit(EXIT_FAILURE);
	}
      }
      else {
	printf("Missing + or - for -sw\n");
	exit(EXIT_FAILURE);
      }
    }

    else if (!strcmpi(argv[i],"-sd")) { /* Sound buffer depth */
      cmdsoundbufferdepth = TRUE;
      if (++i < argc) {
        sound_buffer_depth = atoi(argv[i]);
	if (sound_buffer_depth < 1 || sound_buffer_depth > 9)
	  sound_buffer_depth = 5;
      }
      else {
	printf("Missing depth for -sd\n");
	exit(EXIT_FAILURE);
      }
    }

#ifdef WITH_OS_SOUND
    else if (!strcmpi(argv[i],"-s1")) config_sb_forceV1 = TRUE; /* SB1 force */
#endif

    else if (!strcmpi(argv[i],"-sl")) { /* Sound filter */
      cmdsoundfilter = TRUE;
      if (++i < argc) {
	if (!strcmpi(argv[i],"0")) sound_filter = SOUND_FILTER_ORIGINAL;
	else if (!strcmpi(argv[i],"1")) sound_filter = SOUND_FILTER_ALWAYS;
	else if (!strcmpi(argv[i],"2")) sound_filter = SOUND_FILTER_NEVER;
	else {
	  printf("Unknown argument for -sl, needs 0, 1 or 2\n");
	  exit(EXIT_FAILURE);
	}
      }
      else {
	printf("Missing 0, 1 or 2 for -sl\n");
	exit(EXIT_FAILURE);
      }
    }

    /* Memory options: */

    else if (!strcmpi(argv[i],"-c")) { /* Chip memory size */
      cmdchip = TRUE;
      if (++i < argc) {
	if (strcmpi(argv[i], "256") == 0) config_memory_chipsize = 1;
	else if (strcmpi(argv[i], "512") == 0) config_memory_chipsize = 2;
	else if (strcmpi(argv[i], "768") == 0) config_memory_chipsize = 3;
	else if (strcmpi(argv[i], "1024") == 0) config_memory_chipsize = 4;
	else if (strcmpi(argv[i], "1280") == 0) config_memory_chipsize = 5;
	else if (strcmpi(argv[i], "1536") == 0) config_memory_chipsize = 6;
	else if (strcmpi(argv[i], "1792") == 0) config_memory_chipsize = 7;
	else if (strcmpi(argv[i], "2048") == 0) config_memory_chipsize = 8;
	else {
          printf("Illegal memory size for chipmem, -c\n");
          exit(EXIT_FAILURE);
	}
	config_memory_chipsize *= 262144;
      }
      else {
	printf("Missing size for -c\n");
	exit(EXIT_FAILURE);
      }
    }

    else if (!strcmpi(argv[i], "-fm")) { /* Fast memory size */
      cmdfast = TRUE;
      if (++i < argc) {
	config_memory_fastsize = atoi(argv[i]);
	if (config_memory_fastsize == 0 ||
	    config_memory_fastsize == 1 ||
	    config_memory_fastsize == 2 ||
	    config_memory_fastsize == 4 ||
	    config_memory_fastsize == 8) config_memory_fastsize *= 0x100000;
	else {
	  printf("Illegal size for fast memory, -fm\n");
	  exit(EXIT_FAILURE);
	}
      }
      else {
	printf("Missing size for -fm\n");
	exit(EXIT_FAILURE);
      }
    }

    else if (!strcmpi(argv[i],"-b")) { /* Bogo memory size */
      cmdbogo = TRUE;
      if (++i < argc) {
	if (strcmpi(argv[i], "0") == 0) config_memory_bogosize = 0;
	else if (strcmpi(argv[i], "256") == 0) config_memory_bogosize = 1;
	else if (strcmpi(argv[i], "512") == 0) config_memory_bogosize = 2;
	else if (strcmpi(argv[i], "768") == 0) config_memory_bogosize = 3;
	else if (strcmpi(argv[i], "1024") == 0) config_memory_bogosize = 4;
	else if (strcmpi(argv[i], "1280") == 0) config_memory_bogosize = 5;
	else if (strcmpi(argv[i], "1536") == 0) config_memory_bogosize = 6;
	else if (strcmpi(argv[i], "1792") == 0) config_memory_bogosize = 7;
	else {
          printf("Illegal memory size for bogomem, -b\n");
          exit(EXIT_FAILURE);
	}
	config_memory_bogosize *= 262144;
      }
      else {
	printf("Missing size for -b\n");
	exit(EXIT_FAILURE);
      }
    }

    else if (!strcmpi(argv[i],"-r")) { /* Kickstart ROM */
      if (++i < argc) {
	cmdkick = TRUE;
	strcpy(config_memory_kickname,argv[i]);
        various_make_relative_path(config_memory_kickname);
      }
      else {
	printf("Missing filename for Kickstart-image, -r\n");
	exit(EXIT_FAILURE);
      }
    }

    else if (!strcmpi(argv[i],"-r2")) { /* Kickstart ROM image 2 */
      if (++i < argc) {
	strcpy(config_memory_kick2name,argv[i]);
        various_make_relative_path(config_memory_kick2name);
      }
      else {
	printf("Missing filename for secondary Kickstart-image, -r2\n");
	exit(EXIT_FAILURE);
      }
    }

    else if (!strcmpi(argv[i],"-K")) { /* Keyfile name */
      if (++i < argc) {
	cmdkeyname = TRUE;
	strcpy(config_memory_keyname,argv[i]);
        various_make_relative_path(config_memory_keyname);
      }
      else {
	printf("Missing filename for Kickstart-key\n");
	exit(EXIT_FAILURE);
      }
    }

    else if (!strcmpi(argv[i],"-ms")) { /* Memory space */
      cmdmemspace32 = TRUE;
      if (++i < argc) {
	if (!strcmpi(argv[i], "24")) config_memory_space_32bit = FALSE;
	else if (!strcmpi(argv[i], "32")) config_memory_space_32bit = TRUE;
	else {
	  printf("Unknown argument for -ms , specifiy 24 or 32\n");
	  exit(EXIT_FAILURE);
	}
      }
      else {
	printf("Missing 24/32 for -ms\n");
	exit(EXIT_FAILURE);
      }
    }

    /* Screen settings: */

    else if (!strcmpi(argv[i],"-res")) { /* Resolution */
      if (++i < argc) {
	cmdgmode = TRUE;
	if (!strcmpi(argv[i],"800600")) config_graphics_mode = 0;
	else if (!strcmpi(argv[i],"320200")) config_graphics_mode = 1;
	else if (!strcmpi(argv[i],"320240")) config_graphics_mode = 2;
	else if (!strcmpi(argv[i],"640480")) config_graphics_mode = 3;
	else if (!strcmpi(argv[i],"640400")) config_graphics_mode = 4;
	else if (!strcmpi(argv[i],"640350")) config_graphics_mode = 5;
	else if (!strcmpi(argv[i],"320200b")) config_graphics_mode = 6;
	else if (!strcmpi(argv[i],"320240b")) config_graphics_mode = 7;
	else if (!strcmpi(argv[i],"320400b")) config_graphics_mode = 8;
	else if (!strcmpi(argv[i],"320480b")) config_graphics_mode = 9;
	else if (!strcmpi(argv[i],"400300b")) config_graphics_mode = 10;
	else if (!strcmpi(argv[i],"320400")) config_graphics_mode = 11;
	else if (!strcmpi(argv[i],"320480")) config_graphics_mode = 12;
	else if (!strcmpi(argv[i],"400300")) config_graphics_mode = 13;
	else {
	  printf("Unknown resolution in -res\n");
	  exit(EXIT_FAILURE);
	}
      }
      else {
	printf("Missing resolution for -res\n");
	exit(EXIT_FAILURE);
      }
    }

    else if (!strcmpi(argv[i],"-f")) { /* Skiprate */
      cmdskip = TRUE;
      if (++i < argc) {
	config_graphics_skiprate = atoi(argv[i]);
	if (config_graphics_skiprate < 1) config_graphics_skiprate = 1;
	else if (config_graphics_skiprate > 25) config_graphics_skiprate = 25;
	config_graphics_skiprate--;
      }
      else {
	printf("Missing size for -f\n");
	exit(EXIT_FAILURE);
      }
    }

    else if (!strcmpi(argv[i],"-fl")) {  /* Graphics timing constraint */
      cmdmaxfps = TRUE;
      if (++i < argc) {
	if (!strcmpi(argv[i],"none")) config_graphics_maxfps = 0;
	else if (!strcmpi(argv[i],"50")) config_graphics_maxfps = 1;
	else if (!strcmpi(argv[i],"vga")) config_graphics_maxfps = 2;
	else {
	  printf("Unknown argument for -fl\n");
	  exit(EXIT_FAILURE);
	}
      }
      else {
	printf("Missing none | 50 | vga for -fl\n");
	exit(EXIT_FAILURE);
      }
    }

    else if (!strcmpi(argv[i],"-i")) {  /* Deinterlace */
      cmdlace = TRUE;
      if (++i < argc) {
	if (!strcmpi(argv[i],"on")) config_graphics_flickerfree = 1;
	else if (!strcmpi(argv[i],"off")) config_graphics_flickerfree = 0;
	else {
	  printf("Unknown argument for -i\n");
	  exit(EXIT_FAILURE);
	}
      }
      else {
	printf("Missing on|off for -i\n");
	exit(EXIT_FAILURE);
      }
    }

    else if (!strcmpi(argv[i],"-gc")) {  /* Cycle exact graphics */
      cmdcycleexact = TRUE;
      if (++i < argc) {
	if (!strcmpi(argv[i],"on")) config_draw_cycleexact = TRUE;
	else if (!strcmpi(argv[i],"off")) config_draw_cycleexact = FALSE;
	else {
	  printf("Unknown argument for -gc\n");
	  exit(EXIT_FAILURE);
	}
      }
      else {
	printf("Missing on|off for -gc\n");
	exit(EXIT_FAILURE);
      }
    }

    else if (!strcmpi(argv[i],"-y")) {  /* Vertical scale method */
      cmdscaley = TRUE;
      if (++i < argc) {
	if (!strcmpi(argv[i],"0")) config_graphics_scaley = 0;
	else if (!strcmpi(argv[i],"1")) config_graphics_scaley = 1;
	else if (!strcmpi(argv[i],"2")) config_graphics_scaley = 2;
	else {
	  printf("Unknown argument for -y\n");
	  exit(EXIT_FAILURE);
	}
      }
      else {
	printf("Missing 0|1|2 for -y\n");
	exit(EXIT_FAILURE);
      }
    }

    /* CPU options: */

    else if (!strcmpi(argv[i],"-cpu")) { /* CPU type */
      cmdcputype = TRUE;
      if (++i < argc) {
	config_cpu_type = atoi(argv[i]);
	if (config_cpu_type > 3) config_cpu_type = 3;
      }
      else {
	printf("Missing argument for -cpu\n");
	exit(EXIT_FAILURE);
      }
    }

    else if (!strcmpi(argv[i],"-cs")) { /* CPU speed */
      cmdcpuspeed = TRUE;
      if (++i < argc) {
	if (!strcmpi(argv[i],"3.5")) config_cpu_speed = 0;
	else if (!strcmpi(argv[i],"7")) config_cpu_speed = 1;
	else if (!strcmpi(argv[i],"14")) config_cpu_speed = 2;
	else if (!strcmpi(argv[i],"28")) config_cpu_speed = 3;
	else {
	  printf("Unknown argument for -cs\n");
	  exit(EXIT_FAILURE);
	}
      }
      else {
	printf("Missing speed specifier for -cs\n");
	exit(EXIT_FAILURE);
      }
    }

    /* Various options: */

    else if (!strcmpi(argv[i],"-p")) {  /* Print speed on screen */
      cmdprintspeed = TRUE;
      if (++i < argc) {
	if (!strcmpi(argv[i],"on")) config_printspeed = 1;
	else if (!strcmpi(argv[i],"off")) config_printspeed = 0;
	else {
	  printf("Unknown argument for -p\n");
	  exit(EXIT_FAILURE);
	}
      }
      else {
	printf("Missing on|off for -p\n");
	exit(EXIT_FAILURE);
      }
    }

    else if (!strcmpi(argv[i],"-l")) {  /* LED */
      cmdleds = 1;
      if (++i < argc) {
	if (!strcmpi(argv[i],"off")) config_enableleds = 0;
	else if (!strcmpi(argv[i],"scr")) config_enableleds = 1;
	else if (!strcmpi(argv[i],"kb1")) config_enableleds = 0x81;
	else if (!strcmpi(argv[i],"kb2")) config_enableleds = 0x82;
	else if (!strcmpi(argv[i],"kb3")) config_enableleds = 0x83;
	else if (!strcmpi(argv[i],"lp1")) config_enableleds = 0x41;
	else if (!strcmpi(argv[i],"lp2")) config_enableleds = 0x42;
	else if (!strcmpi(argv[i],"lp3")) config_enableleds = 0x43;
	else if (!strcmpi(argv[i],"lp1m")) config_enableleds = 0x51;
	else if (!strcmpi(argv[i],"lp2m")) config_enableleds = 0x52;
	else if (!strcmpi(argv[i],"lp3m")) config_enableleds = 0x53;
	else {
	  printf("Unknown argument for -l\n");
	  exit(EXIT_FAILURE);
	}
      }
      else {
	printf("Missing scr|kb?|lp?|lp?m|off for -l\n");
	exit(EXIT_FAILURE);
      }
    }

    else if (!strcmpi(argv[i],"-lk")) { /* LED */
      cmdkbdl = 1;
      if (++i < argc) {
	if (!strcmpi(argv[i],"ncs")) kbdleds = 0;
	else if (!strcmpi(argv[i],"nsc")) kbdleds = 1;
	else if (!strcmpi(argv[i],"cns")) kbdleds = 2;
	else if (!strcmpi(argv[i],"csn")) kbdleds = 3;
	else if (!strcmpi(argv[i],"scn")) kbdleds = 4;
	else if (!strcmpi(argv[i],"snc")) kbdleds = 5;
	else {
	  printf("Unknown argument for -lk\n");
	  exit(EXIT_FAILURE);
	}
      }
      else {
	printf("Missing ncs|nsc|cns|csn|scn|snc for -lk\n");
	exit(EXIT_FAILURE);
      }
    }

    /* Floppy options: */

    else if ((strcmpi(argv[i], "-0") == 0) ||   /* Diskimage name */
             (strcmpi(argv[i], "-1") == 0) ||
             (strcmpi(argv[i], "-2") == 0) ||
             (strcmpi(argv[i], "-3") == 0)) {
      ULO drive = argv[i][1] - 0x30;
      if (++i < argc) {
	cmddf[drive] = TRUE;
	strcpy(floppy[drive].imagename, argv[i]);
        various_make_relative_path(floppy[drive].imagename);
      }
      else {
	printf("Missing filename for diskimage in drive %d\n", drive);
	exit(EXIT_FAILURE);
      }
    }

    else if ((!strcmpi(argv[i], "-0e")) ||  /* Enable / disable drive */
	     (!strcmpi(argv[i], "-1e")) ||
	     (!strcmpi(argv[i], "-2e")) ||
	     (!strcmpi(argv[i], "-3e"))) {
      ULO drive = argv[i][1] - 0x30;
      if (++i < argc) {
	cmddfenabled[drive] = TRUE;
	if (!strcmpi(argv[i], "+"))
	  floppy[drive].enabled = TRUE;
	else if (!strcmpi(argv[i], "-"))
	  floppy[drive].enabled = FALSE;
	else {
	  printf("Error in -%de: + to enable, - to disable\n", drive);
	  exit(EXIT_FAILURE);
	}
      }
      else {
	printf("Missing argument for -%de enable.\n", drive);
	exit(EXIT_FAILURE);
      }
    }

    else if (!strcmpi(argv[i],"-ds")) { /* DMA speed */
      if (++i < argc) {
	cmdfloppyfast = TRUE;
	if (!strcmpi(argv[i],"+"))
	  floppy_fast = TRUE;
	else if (!strcmpi(argv[i],"-"))
	  floppy_fast = FALSE;
	else {
	  printf("Error in fast floppy enable: + to enable, - to disable\n");
	  exit(EXIT_FAILURE);
	}
      }
      else {
	printf("Missing argument for fast floppy enable.\n");
	exit(EXIT_FAILURE);
      }
    }

#ifdef USE_GUI
    else if (!strcmpi( argv[ i ], "-dm1" )) {  /* File requester disk memory */
      cmddm1 = 1; if (++i < argc) strcpy( memnames[ 0 ], argv[ i ] );
      else { printf( "Missing argument for -dm1\n" ); exit( 1 ); };
    }
    else if (!strcmpi( argv[ i ], "-dm2" )) {
      cmddm2 = 1; if (++i < argc) strcpy( memnames[ 1 ], argv[ i ] );
      else { printf( "Missing argument for -dm2\n" ); exit( 1 ); };
    }
    else if (!strcmpi( argv[ i ], "-dm3" )) {
      cmddm3 = 1; if (++i < argc) strcpy( memnames[ 2 ], argv[ i ] );
      else { printf( "Missing argument for -dm3\n" ); exit( 1 ); };
    }
    else if (!strcmpi( argv[ i ], "-dm4" )) {
      cmddm4 = 1; if (++i < argc) strcpy( memnames[ 3 ], argv[ i ] );
      else { printf( "Missing argument for -dm4\n" ); exit( 1 ); };
    }
    else if (!strcmpi( argv[ i ], "-dm5" )) {
      cmddm5 = 1; if (++i < argc) strcpy( memnames[ 4 ], argv[ i ] );
      else { printf( "Missing argument for -dm5\n" ); exit( 1 ); };
    }
    else if (!strcmpi( argv[ i ], "-dm6" )) {
      cmddm6 = 1; if (++i < argc) strcpy( memnames[ 5 ], argv[ i ] );
      else { printf( "Missing argument for -dm6\n" ); exit( 1 ); };
    }
    else if (!strcmpi( argv[ i ], "-dm7" )) {
      cmddm7 = 1; if (++i < argc) strcpy( memnames[ 6 ], argv[ i ] );
      else { printf( "Missing argument for -dm7\n" ); exit( 1 ); };
    }
    else if (!strcmpi( argv[ i ], "-dm8" )) {
      cmddm8 = 1; if (++i < argc) strcpy( memnames[ 7 ], argv[ i ] );
      else { printf( "Missing argument for -dm8\n" ); exit( 1 ); };
    }
    else if (!strcmpi( argv[ i ], "-dm9" )) {
      cmddm9 = 1; if (++i < argc) strcpy( memnames[ 8 ], argv[ i ] );
      else { printf( "Missing argument for -dm9\n" ); exit( 1 ); };
    }
    else if (!strcmpi( argv[ i ], "-dm0" )) {
      cmddm0 = 1; if (++i < argc) strcpy( memnames[ 9 ], argv[ i ] );
      else { printf( "Missing argument for -dm0\n" ); exit( 1 ); };
    }

    else if (!strcmpi(argv[i],"-dpath")) {  /* Current gui path */
      if (++i < argc) {
	cmddiskpath = TRUE;
	strcpy(config_diskpath,argv[i]);
        various_make_relative_path(config_diskpath);
      }
      else {
	printf("Missing disk path string\n");
	exit(EXIT_FAILURE);
      }
    }
#endif

    /* Hardfile options: */

    else if (!strnicmp(argv[i],"-hf",3)) {  /* Hardfile name */
      if (((UBY) (argv[i][3] - 0x30)) >= FHFILE_MAX_DEVICES) {
	printf("Error in -hfX, X must be a number less than %d\n",FHFILE_MAX_DEVICES);
	exit(EXIT_FAILURE);
      }
      else {
	if (++i < argc) {
	  cmdfhfile[argv[i - 1][3] - 0x30] = TRUE;
	  strcpy(config_fhfile_name[argv[i-1][3] - 0x30],argv[i]);
          various_make_relative_path(config_fhfile_name[argv[i-1][3]-0x30]);
	}
	else {
	  printf("Missing filename for hardfile\n");
	  exit(EXIT_FAILURE);
	}
      }
    }

    else if (!strcmpi(argv[i],"-he")) { /* Hardfiles enable/disable */
      if (++i < argc) {
	cmdfhfileenabled = TRUE;
	if (!strcmpi(argv[i],"+"))
	  config_fhfile_enabled = TRUE;
	else if (!strcmpi(argv[i],"-"))
	  config_fhfile_enabled = FALSE;
	else {
	  printf("Error in hardfile enable: + to enable, - to disable\n");
	  exit(EXIT_FAILURE);
	}
      }
      else {
	printf("Missing argument for hardfile enable.\n");
	exit(EXIT_FAILURE);
      }
    }

    else print_usage(); /* Command not recognized */
  }

  various_switch_to_homedir();
}

/*==================*/
/* The run-time log */
/*==================*/

BOOLE addlogfirst = TRUE;

void addlog(STR *msg) {
  FILE *F;

  if (!configmakelogfile)
    return;
  if (addlogfirst) {
    F = fopen("fellow.log", "w");
    addlogfirst = FALSE;
  }
  else
    F = fopen("fellow.log", "a");
  if (F != NULL) {
    fprintf(F, "%s", msg);
    fflush(F);
    fclose(F);
  }
}


/*=====================*/
/* Runtime Error Check */
/*=====================*/

void fellowRuntimeErrorCheck(void) {
  switch (fellow_runtime_error_code) {
    case FELLOW_RUNTIME_ERROR_CPU_PC_BAD_BANK:
#ifdef USE_GUI
      fguiRequester("A serious emulation runtime error occured:",
		    "The emulated CPU entered a part of Amiga memory that can not contain",
		    "executable data. Emulation could not continue.");
#endif
      break;
  }
  fellow_runtime_error_code = FELLOW_RUNTIME_ERROR_NO_ERROR;
}


/*===========*/
/* Softreset */
/*===========*/

void fellow_softreset(void) {
  bg2ddf = 0;
  softreset = 0;
  cpureset();
  blitterstatus = 0;
  intreq = 0;
}

/*====================================*/
/* Hardreset, reinit memory, hardfile */
/*====================================*/

BOOLE fellow_reset_firsttime = TRUE;

void fellow_hardreset(void) {
  bg2ddf = 0;

#ifdef UAE_FILESYS
  if (!fellow_reset_firsttime) {
    filesys_prepare_reset();
    filesys_reset();
  }
#endif

  memoryInit();
  if (fellow_reset_firsttime)
    cpuInit();
  
#ifdef CPU_TRACE_TO_FILE
  cpu_trace_to_file_reset();
#endif
  
  fellow_reset_firsttime = FALSE;
  
  fhfileSetup();
  
  rtarea_init();
  hardfile_install();
  rtarea_setup();   
  filesys_install();
  if (config_memory_romversion > 36) 
    memoryEmemCardAdd(expamem_init_filesys, expamem_map_filesys);  

  memoryEmemCardInit();

  cpureset();

  blitterstatus = 0;
  blitend = 0xffffffff;
  irq_next = 0xffffffff;
  cop1lc = cop2lc = 0;
  nxtcopaccess = 0xffffffff;
  blitReset();
  
  intreq = 0;
  intena = intenar = 0;
  reset_keyboard();
  reset_mouse();
  curcycle = 0;
  xpos = ypos = 0;
  cpu_next = 0;
  eol_next = CYCLESPERLINE - 1;
  eof_next = CYCLESPERFRAME;
  bus_clear_eventlist();
}

/* Called from debugger */

void fellow_step(void) {
  ULO oldpc = get_pc(pc);
  
#ifdef WITH_OS_TIMER
  if (sound_mode != SOUND_PLAY)
    start_timerirq();
#endif
  audio_hblanks = 0;
#ifdef WITH_OS_MOUSE
  init_mouseirq();
#endif
  /*        init_kbdirq(); */
  soundEmulationStarting();
  debugging = TRUE;
  fellow_runtime_error_code = setjmp(&fellow_runtime_error_env);
  if (fellow_runtime_error_code == 0)
    bus_debug();
  debugging = FALSE;
#ifdef WITH_OS_TIMER
  if (sound_mode != SOUND_PLAY)
    stop_timerirq();
#endif
  soundEmulationStopping();
  /*        restore_kbdirq(); */
#ifdef WITH_OS_MOUSE
  restore_mouseirq();
#endif
}

/* Called from debugger */

void fellow_step_over(void) {
  ULO mpc, opco;
  union { ULO lo; ULO (*fun)(); } yeah;
  char s[80];

  mpc = get_pc(pc);
  opco = fetw(mpc);
  yeah.lo = cpu_dis_tab[opco];
  mpc = yeah.fun(mpc, opco, s);
#ifdef WITH_OS_TIMER
  if (sound_mode != SOUND_PLAY) start_timerirq();
#endif
  audio_hblanks = 0;
#ifdef WITH_OS_MOUSE
  init_mouseirq();
#endif
  /*        init_kbdirq(); */
  soundEmulationStarting();
  debugging = TRUE;
  fellow_runtime_error_code = setjmp(&fellow_runtime_error_env);
  if (fellow_runtime_error_code == 0)
    while (mpc != get_pc(pc) && !f12pressed) bus_debug();
  debugging = FALSE;
#ifdef WITH_OS_TIMER
  if (sound_mode != SOUND_PLAY) stop_timerirq();
#endif
  soundEmulationStopping();
  /*        restore_kbdirq(); */
#ifdef WITH_OS_MOUSE
  restore_mouseirq();
#endif
  f12pressed = FALSE;
}

/* Called from debugger */

void fellow_run_until_breakpoint(ULO breakpoint) {
  setup_emu_videomode();
#ifdef WITH_OS_TIMER
  if (sound_mode != SOUND_PLAY) start_timerirq();
#endif
  audio_hblanks = 0;
#ifdef WITH_OS_MOUSE
  init_mouseirq();
#endif
#ifdef WITH_OS_KEYBOARD
  init_kbdirq();
#endif
  soundEmulationStarting();
  debugging = TRUE;
  fellow_runtime_error_code = setjmp(&fellow_runtime_error_env);
  if (fellow_runtime_error_code == 0)
    while (get_pc(pc) != breakpoint && !f12pressed) bus_debug();
  debugging = FALSE;
#ifdef WITH_OS_TIMER
  if (sound_mode != SOUND_PLAY) stop_timerirq();
#endif
  soundEmulationStopping();
#ifdef WITH_OS_KEYBOARD
  restore_kbdirq();
#endif
#ifdef WITH_OS_MOUSE
  restore_mouseirq();
#endif
  f12pressed = FALSE;
}


#ifdef DEBUGBUILD

/* Called from debugger */

void fellow_run_until_event(void) {
  int oldlogpos = loglast;

#ifdef WITH_OS_TIMER
  if (sound_mode != SOUND_PLAY) start_timerirq();
#endif
  audio_hblanks = 0;
#ifdef WITH_OS_MOUSE
  init_mouseirq();
#endif
#ifdef WITH_OS_KEYBOARD
  init_kbdirq();
#endif
  soundEmulationStarting();
  debugging = TRUE;
  fellow_runtime_error_code = setjmp(&fellow_runtime_error_env);
  if (fellow_runtime_error_code == 0)
    while ((loglast == oldlogpos) && !f12pressed)
      bus_debug();
  debugging = FALSE;
#ifdef WITH_OS_TIMER
  if (sound_mode != SOUND_PLAY) stop_timerirq();
#endif
  soundEmulationStopping();
#ifdef WITH_OS_KEYBOARD
  restore_kbdirq();
#endif
#ifdef WITH_OS_MOUSE
  restore_mouseirq();
#endif
  f12pressed = FALSE;
}

#endif

/* Called from debugger */

void fellow_run_until_line(ULO line) {
  if (line < 0) line = 0;
  else if (line > 312) line = 312;
#ifdef WITH_OS_TIMER
  if (sound_mode != SOUND_PLAY) start_timerirq();
#endif
  audio_hblanks = 0;
#ifdef WITH_OS_MOUSE
  init_mouseirq();
#endif
#ifdef WITH_OS_KEYBOARD
  init_kbdirq();
#endif
  soundEmulationStarting();
  debugging = TRUE;
  fellow_runtime_error_code = setjmp(&fellow_runtime_error_env);
  if (fellow_runtime_error_code == 0) {
    if (ypos == line) while (ypos == line && !f12pressed) bus_debug();
    while (ypos != line && !f12pressed) bus_debug();
  }
  debugging = FALSE;
#ifdef WITH_OS_TIMER
  if (sound_mode != SOUND_PLAY) stop_timerirq();
#endif
  soundEmulationStopping();
#ifdef WITH_OS_KEYBOARD
  restore_kbdirq();
#endif
#ifdef WITH_OS_MOUSE
  restore_mouseirq();
#endif
  f12pressed = FALSE;
}

/* Called when RUN is selected, will run until F12 is pressed */

void fellow_run(void) {
  UBY *kbdstat = (UBY *)0x417;
  int i;

  setup_emu_videomode();
#ifdef WITH_OS_TIMER
  if (sound_mode != SOUND_PLAY) start_timerirq();
#endif
  audio_hblanks = 0;
#ifdef WITH_OS_MOUSE
  init_mouseirq();
#endif
#ifdef WITH_OS_KEYBOARD
  init_kbdirq();
#endif
  if( config_enableleds & 0xc0 ) drawledlpt(); /* update leds */
  soundEmulationStarting();
  debugging = FALSE;
  /*debugging = TRUE; */
  fellow_runtime_error_code = setjmp(&fellow_runtime_error_env);
  if (fellow_runtime_error_code == 0) bus_run();
  soundEmulationStopping();
#ifdef WITH_OS_TIMER
  if (sound_mode != SOUND_PLAY) stop_timerirq();
#endif
#ifdef WITH_OS_KEYBOARD
  restore_kbdirq();
#endif
#ifdef WITH_OS_MOUSE
  restore_mouseirq();
#endif
  if( config_enableleds & 0x40 ) outp( ledlpt, 0 );/* Clear par port leds*/
  /*  if( config_enableleds & 0x80 ) drawoldkbd();       restore kbd leds */
  audio_hblanks = 0;
  debugging = FALSE;
  f12pressed = FALSE;
}


/* Something really bad happened, immediate emulation stop */


void fellow_nasty_exit(void) {
  longjmp(&fellow_runtime_error_env, fellow_runtime_error_code);  
  printf("Died twice, I give in!\n");
#ifdef WITH_OS_MOUSE
  mouse_close();
#endif
#ifdef WITH_OS_KEYBOARD
  kbd_close();
#endif
#ifdef WITH_OS_TIMER
  if (sound_mode != SOUND_PLAY) stop_timerirq();
#endif
  soundShutdown();
  printf("Serious error! Exit.\n");
  various_switch_to_startdir();
  exit(EXIT_FAILURE);
}


void main(int argc,char *argv[]) {
  ULO i;
  FILE *F;

  config_memory_romversion = 0x200;
  /* Set some config-vars to default values */

  for (i = 0; i < FHFILE_MAX_DEVICES; i++) cmdfhfile[i] = FALSE;
  for (i = 0; i < NROFMODES; i++) gmodefirsttime[i] = TRUE;
#ifdef USE_GUI
  guiMemnamesClear();
#endif
  various_resolve_original_paths(argv[0]);
  variousTMPPathInit();
  
#ifdef UAE_FILESYS
  /* Tests for existance of that file, and records the filesize */

  hardfile_size = 0;

  rtarea_init();          /* UAE */
  
  hardfile_install();     /* UAE */
#endif
  
  /* Parse command-line args, and load config-file */
  
  parsecmd(argc, argv);
  load_fellow_cfg();

#ifdef UAE_FILESYS
  rtarea_setup();         /* UAE */
  filesys_install();      /* UAE */
#endif


  strcpy(config_memory_kicknameloaded, "__None__");
  config_memory_nokick = TRUE;
#ifdef DEBUGBUILD
  loadlogconfig();
#endif
  mmx_detected = detect_mmx();
  if (cmdnommx) mmx_detected = FALSE;
  bus_init();
  screeninit();
  soundStartup();
  BMPStartup();  
  blitStartup();
  draw_init();
  copper_init();
  graphem_init_tables();
#ifdef USE_GUI
  fguiEnterPre();
#endif
  floppyStartup();
  cia_init();
  init_joysticks();

  /* Hack */

  fix_a7pointer();
  soundModeInit();
  fellow_hardreset();
  
#ifdef USE_GUI
  fguiEnter();
#else
  fellow_hardreset();
  home_pressed = FALSE;
  end_pressed = FALSE;
  fellow_run();
#endif
  /* Save configuration */

  save_fellow_cfg();

  /* Free memory allocated for the disk-image caches */

  floppyShutdown();
#ifdef WITH_OS_KEYBOARD
  kbd_close();     
#endif
#ifdef WITH_OS_MOUSE
  mouse_close();     
#endif
  
  /* Kill soundblaster */

  soundShutdown();
  
  memoryShutdown();
#ifdef DEBUGBUILD
  savelogconfig();
#endif
  screenclose();
  various_switch_to_startdir();
}

