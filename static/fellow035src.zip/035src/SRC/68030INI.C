/*==============================*/
/* Fellow Amiga Emulator        */
/* Initialization of 680X0 core */
/* (C) 1997-1998 Roman Dolejsi  */
/*           and Petter Schau   */
/*==============================*/


#include <stdio.h>
#include "defs.h"
#include "68000ini.h"
#include "68030ini.h"
#include "68000.h"
#include "68000dis.h"
#include "memory.h"


/*====================*/
/* Extended registers */
/*====================*/

/* ssp is used for isp */

ULO vbr, sfc, dfc;              /* X12346 */
ULO caar;                       /* XX23XX */
ULO cacr;                       /* XX2346 */
ULO msp;                        /* XX234X */
ULO iacr0, iacr1, dacr0, dacr1; /* 68EC40 */
ULO pcr, buscr;                 /* XXXXX6 */


/*===================================*/
/* ea calculation tables for 68020++ */
/*===================================*/

eareadfunc arb680X0[12] = {arb00, NULL, arb02, arb03, arb04, arb05, arb063,
                           arb70, arb71, arb72, arb0733, arb74};
eareadfunc arw680X0[12] = {arw00, arw01, arw02, arw03, arw04, arw05, arw063,
                           arw70, arw71, arw72, arw0733, arw74};
eareadfunc arl680X0[12] = {arl00, arl01, arl02, arl03, arl04, arl05, arl063,
                           arl70, arl71, arl72, arl0733, arl74};
eareadfunc parb680X0[12] = {arb00, NULL, arb02, parb03, parb04, parb05,
                            parb063, parb70, parb71, parb72, parb0733, parb74};
eareadfunc parw680X0[12] = {arw00, arw01, arw02, parw03, parw04, parw05,
                            parw063, parw70, parw71, parw72, parw0733, parw74};
eareadfunc parl680X0[12] = {arl00, arl01, arl02, parl03, parl04, parl05,
                            parl063, parl70, parl71, parl72, parl0733, parl74};
eawritefunc awb680X0[12] = {awb00, NULL, awb02, awb03, awb04, awb05, awb063,
                            awb70, awb71};
eawritefunc aww680X0[12] = {aww00, aww01, aww02, aww03, aww04, aww05, aww063,
                            aww70, aww71};
eawritefunc awl680X0[12] = {awl00, awl01, awl02, awl03, awl04, awl05, awl063,
                            awl70, awl71};
eacalcfunc eac680X0[12] = {NULL, NULL, eac02, NULL, NULL, eac05, eac063, eac70,
                           eac71, eac72, eac0733, NULL};


/*====================================*/
/* 680X0 specific instructions follow */
/*====================================*/

/*==========================================================================
   Instruction BFCHG <ea>{offset:size}
   Instruction BFCLR <ea>{offset:size}
   Instruction BFEXTS <ea>{offset:size},Dn
   Instruction BFEXTU <ea>{offset:size},Dn
   Instruction BFFFO <ea>{offset:size},Dn
   Instruction BFINS Dn,<ea>{offset:size}
   Instruction BFSET <ea>{offset:size}
   Instruction BFTST <ea>{offset:size}

   Table-usage:
   0 - Routineptr, 1 - srcreg, 2-srcroutine, 3 - cycle count
  ==========================================================================*/

STR *bftxt[8] = {"TST ","EXTU","CHG ","EXTS","CLR ","FFO ","SET ","INS "};

ULO bfdis(ULO prc, ULO opc, STR *st) {
  ULO pos = 18, reg = get_sreg(opc), ext = fetw(prc + 2), n = (opc>>8) & 7;
  ULO offset = (ext & 0x7c0)>>6, width = ext & 0x1f;
  STR stmp[16];

  sprintf(st, "$%.6X %.4X %.4X              BF%s   ", prc, opc, ext, bftxt[n]);
  if (n == 7) {
    sprintf(stmp, "D%d,", (ext>>12) & 7);
    strcat(st, stmp);
  }
  prc = disAdrMode(reg, prc + 4, st, 16, modreg(get_smod(opc), reg), &pos);
  if (ext & 0x800) sprintf(stmp, "{D%d:", offset & 7);
  else sprintf(stmp, "{%d:", offset);
  strcat(st, stmp);
  if (ext & 0x20) sprintf(stmp, "D%d}", width & 7);
  else sprintf(stmp, "%d}", width);
  strcat(st, stmp);
  if ((n == 1) || (n == 3) || (n == 7)) {
    sprintf(stmp, ",D%d", (ext>>12) & 7);
    strcat(st, stmp);
  }
  return prc;
}

int bfadrselect(ULO n, ULO flats) {
  if ((n == 1) || (n == 3) || (n == 5)) return control[flats] || !flats;
  return (control[flats] && alterable[flats]) || !flats;
}

void bfini(ULO o, ULO Rfunc, ULO Mfunc) {
  ULO op = o, ind, modes, regs, flats, n = (o>>8) & 7;

  for (modes = 0; modes < 8; modes++)
    for (regs = 0; regs < 8; regs++) {
      flats = modreg(modes, regs);
      if (bfadrselect(n, flats)) {
        ind = op | modes<<3 | regs;
        t[ind][0] = (ULO) ((modes == 0) ? Rfunc : Mfunc);
        t[ind][1] = greg(modes, regs);
        t[ind][2] = (ULO) eac[flats];
	t[ind][3] = 4;
        cpu_dis_tab[ind] = (ULO) bfdis;
      }
    }
}

void i301ini(void) {
  bfini(0xeac0, (ULO) i301_R, (ULO) i301_M);
  bfini(0xecc0, (ULO) i302_R, (ULO) i302_M);
  bfini(0xebc0, (ULO) i303_R, (ULO) i303_M);
  bfini(0xe9c0, (ULO) i304_R, (ULO) i304_M);
  bfini(0xedc0, (ULO) i305_R, (ULO) i305_M);
  bfini(0xefc0, (ULO) i306_R, (ULO) i306_M);
  bfini(0xeec0, (ULO) i307_R, (ULO) i307_M);
  bfini(0xe8c0, (ULO) i308_R, (ULO) i308_M);
}


/*==========================================================================
  Instruction CAS Dc,Du,<ea> CAS2 Dc1:Dc2,Du1:Du2,(Rn1):(Rn2)
   Table-usage:
   0 - Routinepointer, 1 - srcreg, 2 - srcroutine, 3 - cycle count
   0 - Routinepointer, 1 - cycle count (CAS2)
  ==========================================================================*/

ULO i309dis(ULO prc, ULO opc, STR *st) {
  ULO pos = 18, reg = get_sreg(opc), mode = get_smod(opc), ext = fetw(prc + 2);

  if ((opc & 0x3f) == 0x3c) { /* CAS2 */
    ULO ext2 = fetw(prc + 4);
    STR stmp[16];
    
    sprintf(st, "$%.6X %.4X %.4X %.4X  CAS2.%c  D%d:D%d,D%d:D%d,(%s%d):(%s%d)",
	    prc, opc, ext, ext2, sizec(get_size4(opc)), ext & 7, ext2 & 7,
	    (ext>>6) & 7, (ext2>>6) & 7, (ext & 0x8000) ? "A":"D",
            (ext >> 12) & 7, (ext2 & 0x8000) ? "A":"D", (ext2 >> 12) & 7);
    prc += 6;
  }
  else {
    mode = modreg(mode, reg);
    sprintf(st,"$%.6X %.4X %.4X              CAS.%c     D%d,D%d,", prc, opc,
	    ext, sizec(get_size4(opc)), ext & 7, (ext>>6) & 7);
    prc = disAdrMode(reg, prc + 4, st, 16, mode, &pos);
  }
  return prc;
}

void i309ini(void) {
  ULO op = 0x08c0, ind, siz, modes, regs, flats;

  for (siz = 1; siz < 4; siz++) /* CAS */
    for (modes = 0; modes < 8; modes++)
      for (regs = 0; regs < 8; regs++) {
        flats = modreg(modes, regs);
        if (memory[flats] && alterable[flats]) {
          ind = op | siz<<9 | modes<<3 | regs;
          t[ind][0] = (ULO) ((siz == 0) ? i309_B:((siz == 1) ? i309_W:i309_L));
          t[ind][1] = greg(modes, regs);
          t[ind][2] = (ULO) eac[flats];
	  t[ind][3] = 4;
          cpu_dis_tab[ind] = (ULO) i309dis;
        }
      }
  op = 0x08fc;
  for (siz = 2; siz < 4; siz++) {
    ind = op | siz<<9;
    t[ind][0] = (ULO) ((siz == 1) ? i310_W:i310_L);
    t[ind][1] = 4;
    cpu_dis_tab[ind] = (ULO) i309dis;
  }
}


/*==============================================================
   Instruction CHK.L <ea>,Dn
   Table-usage:
   0 - Routinepointer, 1 - sourreg, 2 - sourceroutine
                       3 - Dreg
  ==============================================================*/

ULO i311dis(ULO prc, ULO opc, STR *st) {  
  ULO pos = 13, reg = get_sreg(opc);

  sprintf(st, "$%.6X %.4X                   CHK.L   ", prc, opc);
  prc = disAdrMode(reg, prc + 2, st, 16, modreg(get_smod(opc), reg), &pos);
  strcat(st, ",");
  return disAdrMode(get_dreg(opc), prc + 2, st, 16, 0, &pos);
}

void i311ini(void) {
  ULO op = 0x4100, ind, regd, modes, regs, flats;

  for (regd = 0; regd < 8; regd++)
    for (modes = 0; modes < 8; modes++)
      for (regs = 0; regs < 8; regs++)
        if (data[flats = modreg(modes, regs)]) {
          ind = op | regd<<9 | modes<<3 | regs;
          t[ind][0] = (ULO) i311;
          t[ind][1] = greg(modes, regs);
          t[ind][2] = (ULO) arw[flats];
          t[ind][3] = greg(0, regd);
          cpu_dis_tab[ind] = (ULO) i311dis;
          }
}


/*======================================================
   Instruction CHK2.X <ea>,Rn / CMP2.X <ea>,Rn
    Table-usage:
     0 - Routinepointer, 1 - source register
     2 - source routine, 3 - cycle count
  ======================================================*/

ULO i312dis(ULO prc,ULO opc,STR *st) {  
  ULO pos = 18, reg = get_sreg(opc), dreg = get_dreg(opc),
      mode = get_smod(opc), ext = fetw(prc + 2);
  STR stmp[16];
  
  mode = modreg(mode, reg);
  sprintf(st, "$%.6X %.4X %.4X              %s2.%c  ", prc, opc, ext,
	  (ext & 0x800) ? "CHK" : "CMP", sizec(get_size4(opc)));
  prc = disAdrMode(reg, prc + 4, st, 16, mode, &pos);
  strcat(st, ",");
  sprintf(stmp, "%s%d", (ext & 0x8000) ? "A" : "D", (ext>>12) & 7);
  strcat(st, stmp);
  return prc;
}

void i312ini(void) {
  ULO op = 0x00c0, ind, siz, modes, regs, flats;

  for (siz = 0; siz < 3; siz++)
    for (modes = 0; modes < 8; modes++)
      for (regs = 0; regs < 8; regs++)
        if (control[flats = modreg(modes, regs)]) {
          ind = op | siz<<9 | modes<<3 | regs;
          t[ind][0] = (ULO) ((siz == 0) ? i312_B:((siz == 1) ? i312_W:i312_L));
          t[ind][1] = greg(modes, regs);
          t[ind][2] = (ULO) ((siz == 0) ? arb[flats] :
                             ((siz == 1) ? arw[flats] : arl[flats]));
          t[ind][3] = 4;
          cpu_dis_tab[ind] = (ULO) i312dis;
        }
}


/*========================================================================
   Instruction cpBcc <label>
   Table-usage:
   0 - Routinepointer, 1 - disasm routine, 2 - coprocessor, 3 - condition
  ========================================================================*/

ULO i313dis(ULO prc, ULO opc, STR *st) {  
  ULO pos = 13, reg = get_sreg(opc), dreg = get_dreg(opc), mode =get_smod(opc);

  mode = greg(mode, reg);
  sprintf(st, "$%.6X %.4X      !!!!!!       cpBcc    ", prc, opc);
  prc = disAdrMode(reg, prc + 2, st, 16, mode, &pos);
  strcat(st, ",");
  disAdrMode(dreg, prc, st, 16, 0, &pos);  
  return prc;
}

void i313ini(void) {
  ULO op = 0xf080, ind, cpnum, cpnumstart, cond, siz;

  cpnumstart = (config_cpu_type == 3) ? 1 : 0;
  for (siz = 0; siz < 2; siz++)
    for (cpnum = cpnumstart; cpnum < 8; cpnum++)
      for (cond = 0; cond < 64; cond++) {
        ind = op | cpnum<<9 | siz<<6 | cond;
	if (t[ind][0] != (ULO)i00) printf("13\n");
        t[ind][0] = (ULO) ( (siz == 0) ? i313_W : i313_L );
        cpu_dis_tab[ind] = (ULO) i313dis;
        t[ind][2] = cpnum;
        t[ind][3] = cond;
      }
}


/*==================================================================
   Instruction cpDBcc <label>
   Table-usage:
   0 - Routinepointer, 1 - disasm routine, 2 - coprocessor, 3 - *Dn
  ==================================================================*/

ULO i314dis(ULO prc,ULO opc,STR *st) {  
  ULO pos = 13, reg = get_sreg(opc), dreg = get_dreg(opc), mode =get_smod(opc);

  mode = greg(mode, reg);
  sprintf(st, "$%.6X %.4X      !!!!!!       cpDBcc   ", prc, opc);
  prc = disAdrMode(reg, prc + 2, st, 16, mode, &pos);
  strcat(st, ",");
  disAdrMode(dreg, prc, st, 16, 0, &pos);  
  return prc;
}

void i314ini(void) {
  ULO op = 0xf048, ind, cpnum, cpnumstart, reg;

  cpnumstart = (config_cpu_type == 3) ? 1 : 0;
  for (cpnum = cpnumstart; cpnum < 8; cpnum++)
    for (reg = 0; reg < 8; reg++) {
      ind = op | cpnum<<9 | reg;
      if (t[ind][0] != (ULO)i00) printf("14\n");
      t[ind][0] = (ULO) i314;
      cpu_dis_tab[ind] = (ULO) i314dis;
      t[ind][2] = cpnum;
      t[ind][3] = greg(0, reg);
    }
}


/*========================================
   Instruction cpGEN
   Table-usage:
   0 - Routinepointer, 1 - disasm routine
   2 - coprocessor, 3 - reg, 4 - srcproc
  ========================================*/

ULO i315dis(ULO prc,ULO opc,STR *st) {  
  ULO pos = 13, reg = get_sreg(opc), dreg = get_dreg(opc),mode=(opc&0x38)>>3;

  if (mode == 7) mode += reg;
  sprintf(st,"$%.6X %.4X      !!!!!!       cpGEN    ",prc,opc);
  prc = disAdrMode(reg,prc+2,st,16,mode,&pos);
  strcat(st,",");
  disAdrMode(dreg,prc,st,16,0,&pos);  
  return prc;
}

void i315ini(void) {
  ULO op = 0xf000, ind, cpnum, cpnumstart, modes, regs, flats;

  cpnumstart = (config_cpu_type == 3) ? 1 : 0;
  for (cpnum = cpnumstart; cpnum < 8; cpnum++)
    for (modes = 0; modes < 8; modes++)
      for (regs = 0; regs < 8; regs++)
        if(allmodes[flats = modreg(modes, regs)]) {
          ind = op | cpnum<<9 | modes<<3 | regs;
	  if (t[ind][0] != (ULO)i00) printf("15\n");
          t[ind][0] = (ULO) i315;
          cpu_dis_tab[ind] = (ULO) i315dis;
          t[ind][2] = cpnum;
          t[ind][3] = greg(modes, regs);
          t[ind][4] = (ULO) arw[flats];
        }
}


/*========================================
   Instruction cpRESTORE <ea>
   Table-usage:
   0 - Routinepointer, 1 - disasm routine
   2 - coprocessor, 3 - reg, 4 - srcproc
  ========================================*/

ULO i316dis(ULO prc,ULO opc,STR *st) {  
  ULO pos=13,reg=opc&0x7,dreg=(opc&0xe00)>>9,mode=(opc&0x38)>>3;

  if (mode == 7) mode += reg;
  sprintf(st,"$%.6X %.4X      !!!!!!       cpRESTORE",prc,opc);
  prc = disAdrMode(reg,prc+2,st,16,mode,&pos);
  strcat(st,",");
  disAdrMode(dreg,prc,st,16,0,&pos);
  return prc;
}

void i316ini(void) {
  ULO op = 0xf140, ind, cpnum, cpnumstart, modes, regs, flats;

  cpnumstart = (config_cpu_type == 3) ? 1 : 0;
  for (cpnum = cpnumstart; cpnum < 8; cpnum++)
    for (modes = 0; modes < 8; modes++)
      for (regs = 0; regs < 8; regs++) {
        flats = modreg(modes, regs);
        if( control[flats] || flats == 2 ) {
          ind = op|cpnum<<9|modes<<3|regs;
  	  if (t[ind][0] != (ULO)i00) printf("16\n");
          t[ind][0] = (ULO) i316;
          cpu_dis_tab[ind] = (ULO) i316dis;
          t[ind][2] = cpnum;
          t[ind][3] = greg(1, regs);
          t[ind][4] = (ULO) arw[flats];
        }
      }
}


/*========================================
   Instruction cpSAVE <ea>
   Table-usage:
   0 - Routinepointer, 1 - disasm routine
   2 - coprocessor, 3 - reg, 4 - dstproc
  ========================================*/

ULO i317dis(ULO prc,ULO opc,STR *st) {  
  ULO pos=13,reg=opc&0x7,dreg=(opc&0xe00)>>9,mode=(opc&0x38)>>3;
  if (mode == 7) mode += reg;
  sprintf(st,"$%.6X %.4X      !!!!!!       cpSAVE   ",prc,opc);
  prc = disAdrMode(reg,prc+2,st,16,mode,&pos);
  strcat(st,",");
  disAdrMode(dreg,prc,st,16,0,&pos);
  return prc;
}

void i317ini(void) {
  ULO op = 0xf100, ind, cpnum, cpnumstart, modes, regs, flats;

  cpnumstart = (config_cpu_type == 3) ? 1 : 0;
  for (cpnum = cpnumstart; cpnum < 8; cpnum++)
    for (modes = 0; modes < 8; modes++)
      for (regs = 0; regs < 8; regs++) {
        flats = modreg(modes, regs);
        if( control[flats] || flats == 3 ) {
          ind = op|cpnum<<9|modes<<3|regs;
	  if (t[ind][0] != (ULO)i00) printf("17\n");
          t[ind][0] = (ULO) i317;
          cpu_dis_tab[ind] = (ULO) i317dis;
          t[ind][2] = cpnum;
          t[ind][3] = greg(1, regs);
          t[ind][4] = (ULO) aww[flats];
        }
      }
}


/*========================================
   Instruction cpScc <ea>
   Table-usage:
   0 - Routinepointer, 1 - disasm routine
   2 - coprocessor, 3 - reg, 4 - dstproc
  ========================================*/

ULO i318dis(ULO prc,ULO opc,STR *st) {  
  ULO pos=13,reg=opc&0x7,dreg=(opc&0xe00)>>9,mode=(opc&0x38)>>3;

  if (mode == 7) mode += reg;
  sprintf(st,"$%.6X %.4X      !!!!!!       cpScc    ",prc,opc);
  prc = disAdrMode(reg,prc+2,st,16,mode,&pos);
  strcat(st,",");
  disAdrMode(dreg,prc,st,16,0,&pos);
  return prc;
}

void i318ini(void) {
  ULO op = 0xf040, ind, cpnum, cpnumstart, modes, regs, flats;

  cpnumstart = (config_cpu_type == 3) ? 1 : 0;
  for (cpnum = cpnumstart; cpnum < 8; cpnum++)
    for (modes = 0; modes < 8; modes++)
      for (regs = 0; regs < 8; regs++) {
        flats = modreg(modes, regs);
        if( data[flats] && alterable[flats] ) {
          ind = op|cpnum<<9|modes<<3|regs;
	if (t[ind][0] != (ULO)i00) printf("18\n");
          t[ind][0] = (ULO) i318;
          cpu_dis_tab[ind] = (ULO) i318dis;
          t[ind][2] = cpnum;
          t[ind][3] = greg(modes, regs);
          t[ind][4] = (ULO) awb[flats];
        }
      }
}


/*========================================
   Instruction cpTRAPcc #
   Table-usage:
   0 - Routinepointer, 1 - disasm routine
   2 - coprocessor, 3 - operand type
  ========================================*/

ULO i319dis(ULO prc,ULO opc,STR *st) {
  ULO pos=13,reg=opc&0x7,dreg=(opc&0xe00)>>9,mode=(opc&0x38)>>3;

  if (mode == 7) mode += reg;
  sprintf(st,"$%.6X %.4X      !!!!!!       cpTRAPcc ",prc,opc);
  prc = disAdrMode(reg,prc+2,st,16,mode,&pos);
  strcat(st,",");
  disAdrMode(dreg,prc,st,16,0,&pos);
  return prc;
}

void i319ini(void) {
  ULO op = 0xf078, ind, cpnum, cpnumstart, optype;

  cpnumstart = (config_cpu_type == 3) ? 1 : 0;
  for (cpnum = cpnumstart; cpnum < 8; cpnum++)
    for( optype = 2; optype < 5; optype++) {
      ind = op|cpnum<<9|optype;
      if (t[ind][0] != (ULO)i00) printf("19\n");
      t[ind][0] = (ULO) i319;
      cpu_dis_tab[ind] = (ULO) i319dis;
      t[ind][2] = cpnum;
      t[ind][3] = (ULO) ( (optype!=4) ? optype-1 : 0 );
    }
}


/*=============================================================================
   Instruction DIV(S/U).L <ea>,Dq / DIV(S/U).L <ea>,Dr:Dq /DIV(S/U)L <ea>,Dr:Dq
   Table-usage:
   0 - Routinepointer, 1 - source register, 2 - source routine
  ===========================================================================*/

ULO i320dis(ULO prc, ULO opc, STR *st) {
  ULO pos = 18, reg = get_sreg(opc), ext = fetw(prc + 2), dq, dr;
  STR stmp[16];
  
  dq = (ext>>12) & 7;
  dr = ext & 7;
  if (ext & 0x400)
    sprintf(st, "$%.6X %.4X %.4X              DIV%cL.L ", prc, opc, ext,
	    (ext & 0x800) ? 'S':'U');
  else
    sprintf(st, "$%.6X %.4X %.4X              DIV%c.L  ", prc, opc, ext,
	    (ext & 0x800) ? 'S':'U');
  prc = disAdrMode(reg, prc + 4, st, 32, modreg(get_smod(opc), reg), &pos);
  if (ext & 0x400 || dq != dr)
    sprintf(stmp, ",D%d:D%d", dr, dq);
  else
    sprintf(stmp, ",D%d", dq);
  strcat(st, stmp);
  return prc;
}

void i320ini(void) {
  ULO op = 0x4c40, ind, modes, regs, flats;

  for (modes = 0; modes < 8; modes++)
    for (regs = 0; regs < 8; regs++) {
      flats = modreg(modes, regs);
      if (data[flats]) {
        ind = op | modes<<3 | regs;
        t[ind][0] = (ULO) i320;
        t[ind][1] = greg(modes, regs);
        t[ind][2] = (ULO) arl[flats];
        cpu_dis_tab[ind] = (ULO) i320dis;
      }
    }
}


/*====================================================*/
/* The complexity of this routine is not asm material */
/* Trade some cycles in for the ease of doing it in C */
/* Returns: 0 - div by zero  1 - OK, -1 - 060 unimpl  */
/*====================================================*/

#define DIV_OK 1
#define DIV_BY_ZERO 0
#define DIV_UNIMPLEMENTED_060 -1


LON i320_C(ULO ext, ULO divisor) {
  ULL q, dvsor, result, rest;
  LON dq, dr, size64, sign;
  BOOLE resultsigned = FALSE, restsigned = FALSE;
  
  if (divisor != 0) {
    dq = (ext>>12) & 7; /* Get operand registers, size and sign */
    dr = ext & 7;
    if ((size64 = (ext>>10) & 1) && (config_cpu_type == 6))
      return DIV_UNIMPLEMENTED_060;
    sign = (ext>>11) & 1;
    if (sign) {         /* Convert operands to 64 bit */
      if (size64) q = d[dq] || (d[dr]<<32);
      else q = (LLO) (LON) d[dq];
      dvsor = (LLO) (LON) divisor;
      if (((LLO) dvsor) < 0) {
	dvsor = -((LLO) dvsor);
	resultsigned = !resultsigned;
      }
      if (((LLO) q) < 0) {
	q = -((LLO) q);
	resultsigned = !resultsigned;
	restsigned = TRUE;
      }	
    }
    else {
      if (size64) q = d[dq] || (d[dr]<<32);
      else q = (ULL) d[dq];
      dvsor = (ULL) divisor;
    }
    if ((dvsor*0xffffffff + dvsor - 1) >= q) {
      result = q / dvsor;
      rest = q % dvsor;
      if (sign) {
	if (result > 0x80000000 && resultsigned) { /* Overflow */
	  sr &= 0xfffffffc;
	  sr |= 2;
	  return DIV_OK;
	}
	else if (result > 0x7fffffff && !resultsigned) { /* Overflow */
	  sr &= 0xfffffffc;
	  sr |= 2;
	  return DIV_OK;
	}
	if (resultsigned && (result != 0)) result = -((LLO) result);
	if (restsigned) rest = -((LLO) rest);
      }
      d[dr] = rest;
      d[dq] = result;   
      sr &= 0xfffffff0;
      if (((LLO) result) < 0) sr |= 8;
      else if (result == 0) sr |= 4;
    }
    else { /* Numerical overflow, leave operands untouched, set V */
      sr &= 0xfffffffc;
      sr |= 2;
      return DIV_OK;
    }
  }
  else return DIV_BY_ZERO; /* Division by zero, generate exception */
  return DIV_OK;
}


/*=========================================================
   Instruction EXTB Dx
   Table-usage:
     0 - Routine pointer 1 - Register Pointer
  =========================================================*/

ULO i321dis(ULO prc, ULO opc, STR *st) {  
  sprintf(st, "$%.6X %.4X                   EXTB.L  D%d", prc, opc,
	  get_sreg(opc));
  return prc + 2;
}

void i321ini(void) {
  ULO op = 0x49c0, ind, regs;

  for (regs = 0; regs < 8; regs++) {
    ind = op | regs;
    t[ind][0] = (ULO) i321;
    t[ind][1] = greg(0, regs);
    cpu_dis_tab[ind] = (ULO) i321dis;
  }
}


/*==================================================
   Instruction LINK.L An,#
   Table-usage:
    0 - Routinepointer, 1 - register pointer
  ==================================================*/

ULO i322dis(ULO prc, ULO opc, STR *st) {
  sprintf(st, "$%.6X %.4X                   LINK.L  A%d", prc, opc,
	  get_sreg(opc));
  return prc + 2;
}

void i322ini(void) {
  ULO op = 0x4808, ind, regs;

  for (regs = 0; regs < 8; regs++) {
    ind = op | regs;
    t[ind][0] = (ULO) i322;
    t[ind][1] = greg(0, regs);
    cpu_dis_tab[ind] = (ULO) i322dis;
  }
}


/*==================================================================
   Instruction MOVE.W CCR,<ea>
   Table-usage:
    0 - Routinepointer, 1 - dstreg, 2 - dstroutine, 3 - cycle count
  ==================================================================*/

ULO i323dis(ULO prc, ULO opc, STR *st) {
  ULO pos = 13, reg = get_sreg(opc);

  sprintf(st, "$%.6X %.4X                   MOVE.W  CCR,", prc, opc);
  return disAdrMode(reg, prc + 2, st, 16, modreg(get_smod(opc), reg), &pos);
}

void i323ini(void) {
  ULO op = 0x42c0, ind, reg, mode, flat;

  for (reg = 0; reg < 8; reg++)
    for (mode = 0; mode < 8; mode++) {
      flat = modreg(mode, reg);
      if (data[flat] && alterable[flat]) {
        ind = op | mode<<3 | reg;
        t[ind][0] = (ULO) i323;
        t[ind][1] = greg(mode, reg);
        t[ind][2] = (ULO) aww[flat];
        t[ind][3] = 12 + tarw[flat];
        cpu_dis_tab[ind] = (ULO) i323dis;
      }
    }
}


/*=================================
   Instruction MOVEC Rc,Rn / Rn,Rc
   Table-usage:
    0 - Routinepointer
  =================================*/

ULO i324dis(ULO prc, ULO opc, STR *st) {
  ULO creg, extw = fetw(prc + 2);
  STR stmp[16];

  sprintf(st, "$%.6X %.4X %.4X              MOVEC.L ", prc, opc, extw);
  if (opc & 1) { /* To control register */
    sprintf(stmp, "%s%d,", (extw & 0x8000) ? "A" : "D", (extw>>12) & 7); 
    strcat(st, stmp);
  }
  creg = extw & 0xfff;
  if (config_cpu_type == 1 && ((creg != 0) && (creg != 1) && (creg != 0x800) &&
			       (creg != 0x801))) creg = 0xfff;
  switch (creg) {
    case 0x000:    /* SFC, Source function code X12346*/
      strcat(st, "SFC");
      break;
    case 0x001:    /* DFC, Destination function code X12346 */
      strcat(st, "DFC");
      break;
    case 0x800:    /* USP, User stack pointer X12346 */
      strcat(st, "USP");
      break;
    case 0x801:    /* VBR, Vector base register X12346 */
      strcat(st, "VBR");
      break;
    case 0x002:    /* CACR, Cache control register XX2346 */
      strcat(st, "CACR");
      break;
    case 0x802:    /* CAAR, Cache adress register XX2346 */
      strcat(st, "CAAR");
      break;
    case 0x803:    /* MSP, Master stack pointer XX234X */
      strcat(st, "MSP");
      break;
    case 0x804:    /* ISP, Interrupt stack pointer XX234X */
      strcat(st, "ISP");
      break;
    default:
      strcat(st, "ILLEGAL!");
      break;
  }
  if (!(opc & 1)) { /* From control register */
    sprintf(stmp, ",%s%d", (extw & 0x8000) ? "A":"D", (extw>>12) & 7); 
    strcat(st, stmp);
  }
  return prc + 4;
}

void i324ini(void) {
  ULO op = 0x4e7a, ind, mode;

  for (mode = 0; mode < 2; mode++) {
    ind = op | mode;
    t[ind][0] = (ULO) ((mode == 0) ? i324_FROM : i324_TO);
    cpu_dis_tab[ind] = (ULO) i324dis;
  }
}


/*===========================================
   Instruction MOVES Rn,<ea> / <ea>,Rn
   Table-usage:

   0 - Routinepointer, 1 - register pointer
   2 - srcroutine,     3 - dstroutine
  ===========================================*/

ULO i325dis(ULO prc, ULO opc, STR *st) {
  ULO pos = 18, reg = get_sreg(opc), ext = fetw(prc + 2);
  STR stmp[16];
 
  sprintf(st, "$%.6X %.4X %.4X              MOVES.%c ", prc, opc, ext,
	  sizec(get_size(opc)));
  if (ext & 0x800) {
    sprintf(stmp, "%s%d,", (ext & 0x8000) ? "A":"D", (ext>>12) & 7);
    strcat(st, stmp);
  }
  prc = disAdrMode(reg, prc + 4, st, 8, modreg(get_smod(opc), reg), &pos);
  if (!(ext & 0x800)) {
    sprintf(stmp, ",%s%d", (ext & 0x8000) ? "A":"D", (ext>>12) & 7);
    strcat(st, stmp);
  }
  return prc;
}

void i325ini(void) {
  ULO op = 0x0e00, ind, siz, reg, mode, flat;

  for (siz = 0; siz < 3; siz++)
    for (reg = 0; reg < 8; reg++)
      for (mode = 0; mode < 8; mode++) {
        flat = modreg(mode, reg);
        if (memory[flat] && alterable[flat]) {
          ind = op | siz<<6 | mode<<3 | reg;
          t[ind][0] = (ULO) ( (siz == 0) ? i325_B :
                              (siz == 1) ? i325_W : i325_L );
          t[ind][1] = greg(1, reg);
          t[ind][2] = (ULO) ( (siz == 0) ? arb[flat] :
                              (siz == 1) ? arw[flat] : arl[flat] );
          t[ind][3] = (ULO) ( (siz == 0) ? awb[flat] :
                              (siz == 1) ? aww[flat] : awl[flat] );
          /*t[ind][5] = 12 + tarw[flat];*/
          cpu_dis_tab[ind] = (ULO) i325dis;
        }
      }
}


/*========================================================
   Instruction MUL(S/U).L <ea>,Dn / MUL(S/U).L <ea>,Dh:Dl
   Table-usage:
   0 - Routinepointer, 1 - sourcereg, 2 - sourceroutine
  ========================================================*/

ULO i326dis(ULO prc, ULO opc, STR *st) {
  ULO pos = 18, reg = get_sreg(opc), ext = fetw(prc + 2), dl, dh;
  STR stmp[16];
  
  dl = (ext>>12) & 7;
  dh = ext & 7;
  sprintf(st, "$%.6X %.4X %.4X              MUL%c.L  ", prc, opc, ext,
	  (ext & 0x800) ? 'S':'U');
  prc = disAdrMode(reg, prc + 4, st, 32, modreg(get_smod(opc), reg), &pos);
  if (ext & 0x400)
    sprintf(stmp, ",D%d:D%d", dh, dl);
  else
    sprintf(stmp, ",D%d", dl);
  strcat(st, stmp);
  return prc;
}

void i326ini(void) {
  ULO op = 0x4c00, ind, modes, regs, flats;

  for (modes = 0; modes < 8; modes++)
    for (regs = 0; regs < 8; regs++)
      if (data[flats = modreg(modes, regs)]) {
        ind = op | modes<<3 | regs;
        t[ind][0] = (ULO) i326;
        t[ind][1] = greg(modes, regs);
        t[ind][2] = (ULO) arl[flats];
        cpu_dis_tab[ind] = (ULO) i326dis;
      }
}


/*==================================================
   Instruction PACK -(Ax),-(Ay),# / Dx,Dy,#
   Table-usage:
   0 - Routinepointer, 1 - srcreg
   2 - srcroutine, 3 - dstreg, 4 - dstroutine
  ==================================================*/

ULO i327dis(ULO prc, ULO opc, STR *st) {
  ULO pos = 13, reg = get_sreg(opc), dreg = get_dreg(opc), mode = (opc & 8)>>1,
      adjw = fetw(prc + 2);

  sprintf(st,"$%.6X %.4X %.4X !!!!!!!      PACK    ", prc, opc, adjw);
  prc = disAdrMode(reg, prc + 4, st, 16, mode, &pos);
  strcat(st,",");
  return disAdrMode(dreg, prc, st, 16, mode, &pos);
}

void i327ini(void) {
  ULO op = 0x8140, ind, rm, rx, ry;

  for (rm = 0; rm < 2; rm++)
    for (rx = 0; rx < 8; rx++)
      for (ry = 0; ry < 8; ry++) {
        ind = op | ry<<9 | rm<<3 | rx;
        t[ind][0] = (ULO) i327;
        t[ind][1] = greg(rm, rx);
        t[ind][2] = (ULO) arw[rm<<2];
        t[ind][3] = greg(rm, ry);
        t[ind][4] = (ULO) awb[rm<<2];
        cpu_dis_tab[ind] = (ULO) i327dis;
      }
}

/*===================================================================
   Instruction PFLUSH A / <fc>,# / <fc>,#,<ea>
   Instruction PLOADR <fc>,<ea> / PLOADW <fc>,<ea>
   Instruction PMOVE reg,<ea> / <ea>,reg / PMOVEFD <ea>,reg
   Instruction PTESTR/W <fc>,<ea>,# / <fc>,<ea>,#,An
   Table-usage:
   0-Routinepointer 1-disasm routine  2-srcreg 3-srcroutine

   PFLUSH, On 68030 and 68851 same opcode, 851 slightly more options
   PFLUSH, On 68040, different from 68030 
   In any case, test S bit and then NOOP
  ===================================================================*/


/* Disassemble for 030 */

void i328dis_030_print_fc(STR *st, ULO fcode) {
  STR stmp[16];

  if (fcode == 0) strcat(st, "   SFC,");
  else if (fcode == 1) strcat(st, "   DFC,");
  else if ((fcode & 0x18) == 8) {
    sprintf(stmp, "    D%d,", fcode & 7);
    strcat(st, stmp);
  }
  else if ((fcode & 0x18) == 0x10) {
    sprintf(stmp, "    #%d,", fcode & 7);
    strcat(st, stmp);
  }
}

ULO i328dis_030(ULO prc, ULO opc, STR *st) {
  ULO pos = 13, reg = get_sreg(opc), ext = fetw(prc + 2), mode, fcode, mask,op;
  STR stmp[16];
  
  mode = (ext >> 10) & 7;
  fcode = ext & 0x1f;
  mask = (ext >> 5) & 7;
  op = (ext >> 13) & 7;
  
  if (op == 0x1) {
    if (mode != 0) {  /* PFLUSH */
      sprintf(st, "$%.6X %.4X %.4X              PFLUSH", prc, opc, ext);
      prc += 4;
      if (mode == 1) strcat(st, "A");
      else {
        i328dis_030_print_fc(st, fcode);
        sprintf(stmp, "%.3X", mask);
        strcat(st, stmp);
        if (mode == 6) {
	  strcat(st, ",");
          prc = disAdrMode(reg, prc, st, 16, modreg(get_smod(opc), reg), &pos);
        }
      }
    }
    else { /* PLOAD */
      sprintf(st, "$%.6X %.4X %.4X              PLOAD%c", prc, opc, ext,
	      (ext & 0x200) ? 'R':'W');
      prc += 4;
      i328dis_030_print_fc(st, fcode);
      strcat(st, ",");
      prc = disAdrMode(reg, prc, st, 16, modreg(get_smod(opc), reg), &pos);
    }
  }
  else if (op == 4) { /* PTEST */
      sprintf(st, "$%.6X %.4X %.4X              PTEST ", prc, opc, ext);
      prc += 4;
      prc = disAdrMode(reg, prc, st, 16, modreg(get_smod(opc), reg), &pos);
  }
  else if (op == 0 || op == 2 || op == 3) { /* PMOVE */
      sprintf(st, "$%.6X %.4X %.4X              PMOVE ", prc, opc, ext);
      prc += 4;
      prc = disAdrMode(reg, prc, st, 16, modreg(get_smod(opc), reg), &pos);
  }
  return prc;
}

/* PFLUSH disassemble on EC040 */

ULO PFLUSHDisEC040(ULO prc, ULO opc, STR *st) {
  ULO pos = 13, reg = get_sreg(opc), opmode;
  STR namesuff[16];
  
  opmode = (opc & 0x18)>>3;
  switch (opmode) {
    case 0:
      sprintf(namesuff, "N  (A%d)", reg);
      break;
    case 1:
      sprintf(namesuff, "   (A%d)", reg);
      break;
    case 2:
      strcpy(namesuff, "AN");
      break;
    case 3:
      strcpy(namesuff, "A");
      break;
  }      
  sprintf(st, "$%.6X %.4X                   PFLUSH%s", prc, opc, namesuff);
  return prc + 2;
}

/* PTEST disassemble on EC040 */

ULO PTESTDisEC040(ULO prc, ULO opc, STR *st) {
  ULO pos = 13, reg = get_sreg(opc), rw;
  
  rw = (opc & 0x20)>>5;
  sprintf(st, "$%.6X %.4X                   PTEST%c (A%d)", prc, opc,
	  (rw) ? "R" : "W", reg);
  return prc + 2;
}

/*
   030: Coprocessor ID 0 is MMU, EC030 has a couple of NOP MMU instructions
        Unimplemented ID 0 instructions take priv. violation in User mode
	F-line exception in Supervisor
*/

void MMUIni030(void) {
  ULO op, ind, modes, regs, flats;

  op = 0xf000;
  for (ind = 0xf000; ind < 0xf200; ind++) { /* Clear ID 0 instructions */
    t[ind][0] = (ULO) MMUIllegal030;
    cpu_dis_tab[ind] = (ULO) i00dis;
  }
  for (modes = 0; modes < 8; modes++)
    for (regs = 0; regs < 8; regs++) {
      flats = modreg(modes, regs);
      if (control[flats] && alterable[flats]) {
	ind = op | modes<<3 | regs;
	t[ind][0] = (ULO) MMU030;
	t[ind][1] = (ULO) greg(modes, regs);
	t[ind][2] = (ULO) arl[flats];
	cpu_dis_tab[ind] = (ULO) i328dis_030;
      }
    }
}


/*
   040: All unimplemented Coprocessor opcodes generate F-lines
*/

void MMUIni040(void) {
  ULO op, ind, modes, regs, flats;

  op = 0xf500;                          /* PFLUSH on EC040, = NOP */
  for (modes = 0; modes < 4; modes++)
    for (regs = 0; regs < 8; regs++) {
      ind = op | modes<<3 | regs;
      t[ind][0] = (ULO) PFLUSHEC040;
      cpu_dis_tab[ind] = (ULO) PFLUSHDisEC040;
    }
  op = 0xf548;                          /* PTEST on EC040, = NOP */ 
  for (modes = 0; modes < 2; modes++)
    for (regs = 0; regs < 8; regs++) {
      ind = op | modes<<5 | regs;
      t[ind][0] = (ULO) PTESTEC040;
      cpu_dis_tab[ind] = (ULO) PTESTDisEC040;
    }
}


/*====================================
  Instruction RTD
   Table-usage:
   0-Routinepointer, 1-disasm routine
  ====================================*/

ULO i329dis(ULO prc, ULO opc, STR *st) {
  ULO extw = fetw(prc + 2);

  sprintf(st, "$%.6X %.4X %.4X              RTD    #%.4X", prc, opc,extw,extw);
  return prc + 4;
}

void i329ini(void) {
  if (t[0x4e74][0] != (ULO)i00) printf("29\n");
  t[0x4e74][0] = (ULO) i329;
  cpu_dis_tab[0x4e74] = (ULO) i329dis;
}


/*===========================================================================
   Instruction TRAPcc
   Table-usage:
   0 - Routinepointer, 1 - handle routine, 2 - paramsize
  ===========================================================================*/

ULO i330dis(ULO prc, ULO opc, STR *st) {
  ULO pos = 13, j, adr, mode = get_smod(opc), reg = get_sreg(opc),
      bratype = get_branchtype(opc), ext, op;
  char stmp[16];
  
  op = (opc & 7) - 2;
  if (op == 2)
    sprintf(st,"$%.6X %.4X                   TRAP",prc,opc);
  else if (op == 0) {
    ext = fetw(prc += 2);
    sprintf(st,"$%.6X %.4X %.4X              TRAP",prc,opc, ext);
  }
  else if (op == 1) {
    ext = fetl(prc += 4);
    sprintf(st,"$%.6X %.4X %.8X          TRAP",prc,opc, ext);
  }
  if (bratype == 0) strcat(st, "T    ");
  else if (bratype == 1) strcat(st, "F    ");
  else {
    strcat(st, btab[bratype]);
  }
  if (op == 0) {
    sprintf(stmp, ".W    #%.4X", ext);
    strcat(st, stmp);
  }
  else if (op == 1) {
    sprintf(stmp, ".L    #%.8X", ext);
    strcat(st, stmp);
  }
  return prc;
}


void i330ini(void) {
  ULO op = 0x50f8, c, mode, ind;
  ULO routines[16] = {(ULO) cc0,(ULO) cc1,(ULO) cc2,(ULO) cc3,(ULO) cc4,
		      (ULO) cc5,(ULO) cc6,(ULO) cc7,(ULO) cc8,(ULO) cc9,
		      (ULO) cca,(ULO) ccb,(ULO) ccc,(ULO) ccd,(ULO) cce,
		      (ULO) ccf};
  for (c = 0; c < 16; c++)
    for (mode = 2; mode < 5; mode++) {
      ind = op | c<<8 | mode;
	if (t[ind][0] != (ULO)i00) printf("30\n");
      t[ind][0] = (ULO) i330;
      t[ind][1] = routines[c];
      t[ind][2] = (mode != 4) ? mode-1 : 0;
      cpu_dis_tab[ind] = (ULO) i330dis;
      }
}


/*==================================================
   Instruction UNPK -(Ax),-(Ay),# / Dx,Dy,#
   Table-usage:
   0 - Routinepointer, 1 - srcreg
   2 - srcroutine, 3 - dstreg, 4 - dstroutine
  ==================================================*/

ULO i331dis(ULO prc, ULO opc, STR *st) {
  ULO pos = 18, reg = get_sreg(opc), dreg = get_dreg(opc), mode = (opc & 8)>>1,
      adjw = fetw(prc + 2);

  sprintf(st, "$%.6X %.4X %.4X              UNPK    ", prc, opc, adjw);
  prc = disAdrMode(reg, prc + 4, st, 16, mode, &pos);
  strcat(st, ",");
  return disAdrMode(dreg, prc, st, 16, mode, &pos);
}

void i331ini(void) {
  ULO op = 0x8180, ind, rm, rx, ry;

  for (rm = 0; rm < 2; rm++)
    for (rx = 0; rx < 8; rx++)
      for (ry = 0; ry < 8; ry++) {
        ind = op | ry<<9 | rm<<3 | rx;
	if (t[ind][0] != (ULO)i00) printf("31\n");
        t[ind][0] = (ULO) i327;
        t[ind][1] = greg(rm, rx);
        t[ind][2] = (ULO) arw[rm<<2];
        t[ind][3] = greg(rm, ry);
        t[ind][4] = (ULO) awb[rm<<2];
        cpu_dis_tab[ind] = (ULO) i327dis;
      }
}


/*===============================================
  Instruction CALLM #x,<ea>
   Table-usage:
   0 - Routinepointer, 1 - srcreg, 2 - earoutine
  ===============================================*/

ULO i332dis(ULO prc, ULO opc, STR *st) {
  ULO pos = 18, reg = get_sreg(opc), ext = fetw(prc + 2);
  
  sprintf(st, "$%.6X %.4X %.4X              CALLM   #%d,", prc, opc, ext,
	  ext & 0xff);
  return disAdrMode(reg, prc + 4, st, 16, modreg(get_smod(opc), reg), &pos);
}

void i332ini(void) {
  ULO op = 0x06c0, ind, mode, reg, flat;

  for (mode = 0; mode < 8; mode++)
    for (reg = 0; reg < 8; reg++)
      if (control[flat = modreg(mode, reg)]) {
        ind = op | mode<<3 | reg;
	if (t[ind][0] != (ULO)i00) printf("32\n");
        t[ind][0] = (ULO) i332;
        t[ind][1] = greg(mode, reg);
        t[ind][2] = (ULO) eac[flat];
        cpu_dis_tab[ind] = (ULO) i332dis;
      }
}


/*=================================================
   Instruction RTM
   Table-usage:
   0 - Routinepointer, 1 - reg
  =================================================*/

ULO i333dis(ULO prc, ULO opc, STR *st) {  
  sprintf(st, "$%.6X %.4X                   RTM      %c%d", prc, opc,
	  (opc & 8) ? 'A':'D', get_sreg(opc));
  return prc + 2;
}

void i333ini(void) {
  ULO op = 0x06c0, ind, mode, reg, flat;

  for (mode = 0; mode < 2; mode++)
    for (reg = 0; reg < 8; reg++) {
      ind = op | mode<<3 | reg;
	if (t[ind][0] != (ULO)i00) printf("33\n");
      t[ind][0] = (ULO) i333;
      t[ind][1] = greg(mode, reg);
      cpu_dis_tab[ind] = (ULO) i333dis;
    }
}


/*======================================================================
   Instruction MOVE16 (040 060)

   Type 1: move16 (Ax)+, (Ay)+   (post-increment format)

   Type 2: move16 $L, (An)   11  (absolute long address or destination)
           move16 $L, (An)+  01
	   move16 (An), $L   10
	   move16 (An)+, $L  00    

   Table-usage:
     0 - Routine-pointer  1 - Pointer to address register
  ======================================================================*/

ULO i334dis(ULO prc, ULO opc, STR *st) {  
  sprintf(st, "$%.6X %.4X                   MOVE16", prc, opc);
  if (opc & 0x0020) return prc + 2;
  return prc + 6;
}

void i334ini(void) {
  ULO op, reg, mode, ind;
  ULO instructions[4] = {(ULO) i334_2_00, (ULO) i334_2_01,
			 (ULO) i334_2_10, (ULO) i334_2_11};
  
  op = 0xf620;           /* Type 1, second register in extension word */
  for (reg = 0; reg < 8; reg++) {
    ind = op | reg;
    t[ind][0] = (ULO) i334_1;
    t[ind][1] = greg(1, reg);
    cpu_dis_tab[ind] = (ULO) i334dis;
  }

  op = 0xf600;           /* Type 2 */
  for (mode = 0; mode < 4; mode++)
    for (reg = 0; reg < 8; reg++) {
      ind = op | mode << 3 | reg;
      t[ind][0] = instructions[mode];
      t[ind][1] = greg(1, reg);
      cpu_dis_tab[ind] = (ULO) i334dis;
    }
}


/*======================================================================
   Instruction CINV (040 040LC)

   CINVL  <cache>, (An)    Line invalidate
   CINVP  <cache>, (An)    Page invalidate
   CINVA  <cache>          All invalidate

   Table-usage:
     0 - Routine-pointer,  1 - register ptr,  2 - cache spec, 3 - scope
  ======================================================================*/


void CINVGetCacheDesc(ULO cache, STR *cachedesc) {
  switch (cache) {
    case 0:
      strcpy(cachedesc, "NOP");
      break;
    case 1:
      strcpy(cachedesc, "INST");
      break;
    case 2:
      strcpy(cachedesc, "DATA");
      break;
    case 3:
      strcpy(cachedesc, "BOTH");
      break;
  }  
}

void CINVGetScopeDesc(ULO scope, STR *scopedesc, STR *cachedesc, ULO reg) {
  switch (scope) {
    case 1:
      sprintf(scopedesc, "L  %s, (A%d)", cachedesc, reg);
      break;
    case 2:
      sprintf(scopedesc, "P  %s, (A%d)", cachedesc, reg);
      break;
    case 3:
      sprintf(scopedesc, "A  %s", cachedesc);
      break;
  }      
}

ULO CINVDis040(ULO prc, ULO opc, STR *st) {
  ULO pos = 13, reg = get_sreg(opc), cache = (opc>>6) & 3, scope =(opc>>3) & 3;
  STR scopedesc[32];
  STR cachedesc[8];

  CINVGetCacheDesc(cache, cachedesc);
  CINVGetScopeDesc(scope, scopedesc, cachedesc, reg);
  sprintf(st, "$%.6X %.4X                   CINV%s", prc, opc, scopedesc);
  return prc + 2;
}

void CINVIni(void) {
  ULO op, ind, cache, regs, scope;

  if (config_cpu_type == 4) {
    op = 0xf400;
    for (cache = 0; cache < 4; cache++)
      for (scope = 1; scope < 4; scope++)
	for (regs = 0; regs < 8; regs++) {
	  ind = op | cache<<6 | scope<<3 | regs;
	  t[ind][0] = (ULO) CINV040;
	  t[ind][1] = greg(1, regs);
	  t[ind][2] = cache;
	  t[ind][3] = scope;
	  cpu_dis_tab[ind] = (ULO) CINVDis040;
    }
  }
}


/*======================================================================
   Instruction CPUSH (040 040LC)

   CPUSHL  <cache>, (An)    Line
   CPUSHP  <cache>, (An)    Page
   CPUSHA  <cache>          All

   Table-usage:
     0 - Routine-pointer,  1 - register ptr,  2 - cache spec, 3 - scope
  ======================================================================*/


ULO CPUSHDis040(ULO prc, ULO opc, STR *st) {
  ULO pos = 13, reg = get_sreg(opc), cache = (opc>>6) & 3, scope =(opc>>3) & 3;
  STR scopedesc[32];
  STR cachedesc[8];

  CINVGetCacheDesc(cache, cachedesc);
  CINVGetScopeDesc(scope, scopedesc, cachedesc, reg);
  sprintf(st, "$%.6X %.4X                   CPUSH%s", prc, opc, scopedesc);
  return prc + 2;
}

void CPUSHIni(void) {
  ULO op, ind, cache, regs, scope;

  if (config_cpu_type == 4) {
    op = 0xf420;
    for (cache = 0; cache < 4; cache++)
      for (scope = 1; scope < 4; scope++)
	for (regs = 0; regs < 8; regs++) {
	  ind = op | cache<<6 | scope<<3 | regs;
	  t[ind][0] = (ULO) CPUSH040;
	  t[ind][1] = greg(1, regs);
	  t[ind][2] = cache;
	  t[ind][3] = scope;
	  cpu_dis_tab[ind] = (ULO) CPUSHDis040;
    }
  }
}


/*=============================================================*/
/* Set address-mode tables to 020 and above compilant routines */
/*=============================================================*/

void cpuAdrModeTablesInit020(void) {
  ULO i;

  for (i = 0; i < 12; i++) {    /* Set adressmode data to 680x0 stubs */
    arb[i] = arb680X0[i];
    arw[i] = arw680X0[i];
    arl[i] = arl680X0[i];
    parb[i] = parb680X0[i];
    parw[i] = parw680X0[i];
    parl[i] = parl680X0[i];
    awb[i] = awb680X0[i];
    aww[i] = aww680X0[i];
    awl[i] = awl680X0[i];
    eac[i] = eac680X0[i];
    tarb[i] = tarb68000[i];    /* let even 68030 instrs to have same timing */
    tarw[i] = tarw68000[i];    /* not right, though... */
    tarl[i] = tarl68000[i];
    }
}


/*======================================*/
/* This is actually the RESET exception */
/*======================================*/

void cpuReset010(void) {
  sr &= 0x271f;         /* T1T0 = 0 */
  sr |= 0x2700;         /* S = 1, ilvl = 7 */
  vbr = 0;              /* vbr = 0 */
  if (config_memory_kickbase < 0xf8) {
    ssp = fetl(0xf00000);        /* ssp = fake vector 0 */
    set_pc(fetl(0xf00004)); /* pc = fake vector 1 */
  }
  else {
    ssp = fetl(0xf80000);        /* ssp = fake vector 0 */
    set_pc(fetl(0xf80004)); /* pc = fake vector 1 */
  }
#ifdef PREFETCH
  prefetch_fill(pc);
#endif
}

void cpuReset020(void) {
  sr &= 0x271f;         /* T1T0 = 0, M = 0 */
  sr |= 0x2700;         /* S = 1, ilvl = 7 */
  vbr = 0;              /* vbr = 0 */
  cacr = 0;             /* E = 0, F = 0 */
                        /* Invalidate cache, we don't have one */
  if (config_memory_kickbase < 0xf8) {
    ssp = fetl(0xf00000);        /* ssp = fake vector 0 */
    set_pc(fetl(0xf00004)); /* pc = fake vector 1 */
  }
  else {
    ssp = fetl(0xf80000);        /* ssp = fake vector 0 */
    set_pc(fetl(0xf80004)); /* pc = fake vector 1 */
  }
#ifdef PREFETCH
  prefetch_fill(pc);
#endif
}

void cpuReset030(void) {
  sr &= 0x271f;         /* T1T0 = 0, M = 0 */
  sr |= 0x2700;         /* S = 1, ilvl = 7 */
  vbr = 0;              /* vbr = 0 */
  cacr = 0;             /* E = 0, F = 0 */
                        /* Invalidate cache, we don't have one */
  if (config_memory_kickbase < 0xf8) {
    ssp = fetl(0xf00000);        /* ssp = fake vector 0 */
    set_pc(fetl(0xf00004)); /* pc = fake vector 1 */
  }
  else {
    ssp = fetl(0xf80000);        /* ssp = fake vector 0 */
    set_pc(fetl(0xf80004)); /* pc = fake vector 1 */
  }
#ifdef PREFETCH
  prefetch_fill(pc);
#endif
}

void cpuReset040(void) {
  sr &= 0x271f;         /* T1T0 = 0, M = 0 */
  sr |= 0x2700;         /* S = 1, ilvl = 7 */
  vbr = 0;              /* vbr = 0 */
  cacr = 0;             /* E = 0, F = 0 */
                        /* Invalidate cache, we don't have one */
  if (config_memory_kickbase < 0xf8) {
    ssp = fetl(0xf00000);        /* ssp = fake vector 0 */
    set_pc(fetl(0xf00004)); /* pc = fake vector 1 */
  }
  else {
    ssp = fetl(0xf80000);        /* ssp = fake vector 0 */
    set_pc(fetl(0xf80004)); /* pc = fake vector 1 */
  }
#ifdef PREFETCH
  prefetch_fill(pc);
#endif
}

void cpuReset060(void) {
  sr &= 0x271f;         /* T = 0 */
  sr |= 0x2700;         /* S = 1, ilvl = 7 */
  vbr = 0;              /* vbr = 0 */
  cacr = 0;             /* cacr = 0 */
                        /* DTTn[E-bit] = 0 */
                        /* ITTn[E-bit] = 0 */
                        /* TCR = 0 */
                        /* BUSCR = 0 */
                        /* PCR = 0 */
                        /* FPU Data regs = NAN */
                        /* FPU Control regs = 0 */
  if (config_memory_kickbase < 0xf8) {
    ssp = fetl(0xf00000);        /* ssp = fake vector 0 */
    set_pc(fetl(0xf00004)); /* pc = fake vector 1 */
  }
  else {
    ssp = fetl(0xf80000);        /* ssp = fake vector 0 */
    set_pc(fetl(0xf80004)); /* pc = fake vector 1 */
  }
#ifdef PREFETCH
  prefetch_fill(pc);
#endif
}


/*==================================================*/
/* Add 000 specific instruction set to opcode table */
/*==================================================*/

void cpuInit000(void) {
  i44ini();                           /* MOVEP */
}


/*==================================================*/
/* Add 010 specific instruction set to opcode table */
/*==================================================*/

void cpuInit010(void) {
  i44ini();                           /* MOVEP */
  i323ini();                          /* MOVE.W CCR */
  i324ini();                          /* MOVEC */
  i325ini();                          /* MOVES */
  i329ini();                          /* RTD */
}


/*==================================================*/
/* Add 020 specific instruction set to opcode table */
/*==================================================*/

void cpuInit020(void) {
  i44ini();                           /* MOVEP */
  i301ini();                          /* Bit fields */
  i309ini();                          /* CAS CAS2 */
  i311ini();                          /* CHK.D */
  i312ini();                          /* CHK2/CMP2 */
  i313ini();                          /* cpBcc */
  i314ini();                          /* cpDBcc */
  i315ini();                          /* cpGEN */
  i316ini();                          /* cpRESTORE */
  i317ini();                          /* cpSAVE */
  i318ini();                          /* cpScc */
  i319ini();                          /* cpTRAPcc */
  i320ini();                          /* DIVSL/DIVUL */
  i321ini();                          /* EXTB */
  i322ini();                          /* LINK.L */
  i323ini();                          /* MOVE.W CCR */
  i324ini();                          /* MOVEC */
  i325ini();                          /* MOVES */
  i326ini();                          /* MULSL/MULUL */
  i327ini();                          /* PACK */
  i329ini();                          /* RTD */
  i330ini();                          /* TRAPcc */
  i331ini();                          /* UNPK */
  i332ini();                          /* CALLM */
  i333ini();                          /* RTM */
}


/*==================================================*/
/* Add 030 specific instruction set to opcode table */
/*==================================================*/

void cpuInit030(void) {
  i44ini();                           /* MOVEP */
  i301ini();                          /* Bit fields */
  i309ini();                          /* CAS CAS2 */
  i311ini();                          /* CHK.D */
  i312ini();                          /* CHK2/CMP2 */
  i313ini();                          /* cpBcc */
  i314ini();                          /* cpDBcc */
  i315ini();                          /* cpGEN */
  i316ini();                          /* cpRESTORE */
  i317ini();                          /* cpSAVE */
  i318ini();                          /* cpScc */
  i319ini();                          /* cpTRAPcc */
  i320ini();                          /* DIVSL/DIVUL */
  i321ini();                          /* EXTB */
  i322ini();                          /* LINK.L */
  i323ini();                          /* MOVE.W CCR */
  i324ini();                          /* MOVEC */
  i325ini();                          /* MOVES */
  i326ini();                          /* MULSL/MULUL */
  i327ini();                          /* PACK */
  MMUini030();                        /* PFLUSH/PLOAD/PMOVE/PTEST */
  i329ini();                          /* RTD */
  i330ini();                          /* TRAPcc */
  i331ini();                          /* UNPK */
}


/*==================================================*/
/* Add 040 specific instruction set to opcode table */
/*==================================================*/

void cpuInit040(void) {
  i44ini();                           /* MOVEP */
  i301ini();                          /* Bit fields */
  i309ini();                          /* CAS CAS2 */
  i311ini();                          /* CHK.D */
  i312ini();                          /* CHK2/CMP2 */
  i320ini();                          /* DIVSL/DIVUL */
  i321ini();                          /* EXTB */
  i322ini();                          /* LINK.L */
  i323ini();                          /* MOVE.W CCR */
  i324ini();                          /* MOVEC */
  i325ini();                          /* MOVES */
  i326ini();                          /* MULSL/MULUL */
  i327ini();                          /* PACK */
  MMUIni040();                        /* PFLUSH/PTEST */
  i329ini();                          /* RTD */
  i330ini();                          /* TRAPcc */
  i331ini();                          /* UNPK */
  i334ini();                          /* MOVE16 */
/*  CINVIni();*/                          /* CINV (Full 040 and LC040 only) */
/*  CPUSHIni();*/                         /* CPUSH (Full 040 and LC040 only) */
} 


/*==================================================*/
/* Add 060 specific instruction set to opcode table */
/*==================================================*/

void cpuInit060(void) {
  i301ini();                          /* Bit fields */
  i311ini();                          /* CHK.D */
  i320ini();                          /* DIVSL/DIVUL */
  i321ini();                          /* EXTB */
  i322ini();                          /* LINK.L */
  i323ini();                          /* MOVE.W CCR */
  i324ini();                          /* MOVEC */
  i325ini();                          /* MOVES */
  i326ini();                          /* MULSL/MULUL */
  i327ini();                          /* PACK */
  i329ini();                          /* RTD */
  i330ini();                          /* TRAPcc */
  i331ini();                          /* UNPK */
  i334ini();                          /* MOVE16 */
}

