/*==============================*/
/* Fellow Amiga Emulator        */
/* Blitter (OCS) Initialization */
/* (C) 1997-1998 Petter Schau   */
/*==============================*/


#include "defs.h"
#include "blita.h"
#include "blit.h"
#include "memory.h"


/* Blitter registers */

ULO bltcon,bltafwm,bltalwm,bltapt,bltbpt,bltcpt,bltdpt,bltamod,bltbmod;
ULO bltcmod,bltdmod,bltadat,bltbdat,bltcdat,bltzero;

/* Blitter cycle usage table */

ULO blit_cycletab[16] = {4, 4, 4, 5, 5, 5, 5, 6, 4, 4, 4, 5, 5, 5, 5, 6};

/* Holds previous word */

ULO leftoverA, leftoverB;

/* Callback table for minterm-calculation functions */

blit_min_func blit_min_functable[256];
blit_min_func bltminterm;

/* Blitter fill-mode lookup tables */

UWO fillincfc0[65536], fillincfc1[65536];
UBY fillincfc0after[65536], fillincfc1after[65536];
UWO fillexcfc0[65536], fillexcfc1[65536];
UBY fillexcfc0after[65536], fillexcfc1after[65536];

/* Various blitter variables */

ULO bltdesc, blitend, blitterstatus;
ULO bltadatoriginal, bltbdatoriginal;
ULO bltbdatline, bltlineheight, bltlinepointflag, bltfillbltconsave;

blitmodefunc blittermodes[16] = {blitterline, Dblitterline, blitterline,
				 blitterline, blitterline, blitterline,
				 blitterline, blitterline, blitterline,
				 ADblitterline, blitterline, blitterline,
				 blitterline, blitterline, blitterline,
				 blitterline};
				 
blitmodefunc blitterfillmodes[16] = {blitterfillline, blitterfillline,
				     blitterfillline, blitterfillline,
				     blitterfillline, blitterfillline,
				     blitterfillline, blitterfillline,
				     blitterfillline, ADblitterfillline,
				     blitterfillline, blitterfillline,
				     blitterfillline, blitterfillline,
				     blitterfillline, blitterfillline};

blitmodefunc bltlinesudsulaul[8] = {blitterlinemodeoctant0,
				    blitterlinemodeoctant1,
				    blitterlinemodeoctant2,
				    blitterlinemodeoctant3,
				    blitterlinemodeoctant4,
				    blitterlinemodeoctant5,
				    blitterlinemodeoctant6,
				    blitterlinemodeoctant7};

BOOLE blit_fast;   /* Blitter finishes in zero time */
BOOLE blit_long;   /* Enable long blits */

/*=================*/
/* Fill-table init */
/*=================*/

void blitFillTableInit(void) {
  int i,j,k,l;
/* inclusive fill, fc = 0 at start of word */
  for (i = 0; i < 65536; i++) {
    l = 0;
    j = i;
    for (k = 0; k < 16; k++) {
      j |= l<<k;                 /* Set fill for this bit */
/* Check if fill status has changed */
      if ((i & (0x1<<k))) {
        if (l == 1) l = 0; else l = 1;
        }
      }
    fillincfc0[i] = j;
    fillincfc0after[i] = l;
    }
/* inclusive fill, fc = 1 at start of word */
  for (i = 0; i < 65536; i++) {
    l = 1;
    j = i;
    for (k = 0; k < 16; k++) {
      j |= l<<k;                 /* Set fill for this bit */
/* Check if fill status has changed */
      if ((i & (0x1<<k))) {
        if (l == 1) l = 0; else l = 1;
        }
      }
    fillincfc1[i] = j;
    fillincfc1after[i] = l;
    }
/* exclusive fill, fc = 0 at start of word */
  for (i = 0; i < 65536; i++) {
    l = 0;
    j = i;
    for (k = 0; k < 16; k++) {
      j ^= l<<k;                 /* Set fill for this bit */
/* Check if fill status has changed */
      if ((i & (0x1<<k))) {
        if (l == 1) l = 0; else l = 1;
        }
      }
    fillexcfc0[i] = j;
    fillexcfc0after[i] = l;
    }

/* exclusive fill, fc = 1 at start of word */
  for (i = 0; i < 65536; i++) {
    l = 1;
    j = i;
    for (k = 0; k < 16; k++) {
      j ^= l<<k;                 /* Set fill for this bit */
/* Check if fill status has changed */
      if ((i & (0x1<<k))) {
        if (l == 1) l = 0; else l = 1;
        }
      }
    fillexcfc1[i] = j;
    fillexcfc1after[i] = l;
    }
}


/*===================================================*/
/* Minterm calculation callback table initialization */
/*===================================================*/

void blitMinTableInit(void) {
  ULO i;

  for (i = 0; i < 256; i++) blit_min_functable[i] = blit_min_generic;
  blit_min_functable[0x00] = blit_min_00;
  blit_min_functable[0x01] = blit_min_01;
  blit_min_functable[0x02] = blit_min_02;
  blit_min_functable[0x03] = blit_min_03;
  blit_min_functable[0x04] = blit_min_04;
  blit_min_functable[0x05] = blit_min_05;
  blit_min_functable[0x06] = blit_min_06;
  blit_min_functable[0x07] = blit_min_07;
  blit_min_functable[0x08] = blit_min_08;
  blit_min_functable[0x09] = blit_min_09;
  blit_min_functable[0x0a] = blit_min_0a;
  blit_min_functable[0x0b] = blit_min_0b;
  blit_min_functable[0x0c] = blit_min_0c;
  blit_min_functable[0x0d] = blit_min_0d;
  blit_min_functable[0x0e] = blit_min_0e;
  blit_min_functable[0x0f] = blit_min_0f;
  blit_min_functable[0x2a] = blit_min_2a;
  blit_min_functable[0x4a] = blit_min_4a;
  blit_min_functable[0xca] = blit_min_ca;
  blit_min_functable[0xd8] = blit_min_d8;
  blit_min_functable[0xea] = blit_min_ea;
  blit_min_functable[0xf0] = blit_min_f0;
  blit_min_functable[0xfa] = blit_min_fa;
  blit_min_functable[0xfc] = blit_min_fc;
  blit_min_functable[0xff] = blit_min_ff;
}  


/*=============================================*/
/* Set blitter IO stubs in IO read/write table */
/*=============================================*/

void blitIOStubsInit(void) {
  iowrite[0x40/2] = wbltcon0;
  iowrite[0x42/2] = wbltcon1;
  iowrite[0x44/2] = wbltafwm;
  iowrite[0x46/2] = wbltalwm;
  iowrite[0x48/2] = wbltcpth;
  iowrite[0x4a/2] = wbltcptl;
  iowrite[0x4c/2] = wbltbpth;
  iowrite[0x4e/2] = wbltbptl;
  iowrite[0x50/2] = wbltapth;
  iowrite[0x52/2] = wbltaptl;
  iowrite[0x54/2] = wbltdpth;
  iowrite[0x56/2] = wbltdptl;
  iowrite[0x58/2] = wbltsize;
  iowrite[0x60/2] = wbltcmod;
  iowrite[0x62/2] = wbltbmod;
  iowrite[0x64/2] = wbltamod;
  iowrite[0x66/2] = wbltdmod;
  iowrite[0x70/2] = wbltcdat;
  iowrite[0x72/2] = wbltbdat;
  iowrite[0x74/2] = wbltadat;
  if (blit_long) {
    iowrite[0x5a/2] = wbltcon0l;
    iowrite[0x5c/2] = wbltsizv;
    iowrite[0x5e/2] = wbltsizh;
  }    
}


/*=================================*/
/* Reset blitter to default values */
/*=================================*/

void blitReset(void) {
  bltminterm = blit_min_generic;
  blitend = -1;         /* Must keep blitend -1 when not blitting */
  blitterstatus = 0;
  bltapt = 0;
  bltbpt = 0;
  bltcpt = 0;
  bltdpt = 0;
  bltcon = 0;
  bltafwm = bltalwm = 0;
  bltamod = 0;
  bltbmod = 0;
  bltcmod = 0;
  bltdmod = 0;
  bltadat = 0;
  bltbdat = 0;
  bltcdat = 0;
  bltzero = 0;
  blitIOStubsInit();
}


/*============================*/
/* Called on emulator startup */
/*============================*/

void blitStartup(void) {
  blitMinTableInit();
  blitFillTableInit();
}




void logblit(void) {
  STR s[80];

  sprintf(s, "BLIT: V-%d H-%d M-%d\n", linecount, linelength, linenum);
  addlog(s);
}
