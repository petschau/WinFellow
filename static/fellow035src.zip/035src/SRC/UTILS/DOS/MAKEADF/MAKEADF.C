#include <stdio.h>

#include <string.h>





/* Make an empty amiga disk file(s) */

/* David V. of the Fellow-support posse */

/* Added -quiet option, Petter Schau 24/7-98 */


void help(void) {

        fprintf(stderr,"Make an empty .adf diskfile(s)\n");

        fprintf(stderr,"syntax: makeadf <filename> [number] -quiet\n");

        exit(1);

}



void main(int argc, char *argv[]) {

        int i,j,count;

        char dfname[255];

        char tmpname[255];

        short int a='a';

        FILE *F;

	int quiet;


        if (argc >= 3) count = atoi(argv[2])-1; else count = 0;
	quiet = (stricmp(argv[argc - 1], "-quiet") == 0); 


        if (!quiet) fprintf(stdout,"\nMakeADF v1.2, written by David Voracek 1997\n\n");



        if (argc < 4) help();

                else { 

                        strcpy (dfname,argv[1]);



                       for (j = 0; j <= count; j++, a++ ) {

                        if (a > 'z') break;

                        strcpy (tmpname,dfname);

                        if (count != 0) { 

                                strcat (tmpname,"_");

                                strcat (tmpname,(char *)&a);

                                }

                        strcat (tmpname,".adf");

                        if (F=fopen(tmpname,"rb")) {

                                if (!quiet) fprintf(stderr,"error: file %s already exists !",tmpname);

                                fclose(F);

                                exit(1);

                                }

                        if (F=fopen(tmpname,"wb")) {

                                if (!quiet) fprintf(stdout,"Building-up disk image %s\n",tmpname);

                                for (i = 0; i < 901120; i++) 

                                if (fputc(0,F)!=NULL) {

                                        if (!quiet) fprintf (stderr,"Error: no space left on device !\n");

                                        fclose(F);

                                        exit(1); 

                                        }

                                fclose(F);

                                }

                        else {

                                if (!quiet) fprintf(stderr,"Error: cannot open file %s !\n",tmpname);

                                exit(1);

                                }

                        }

                        if (!quiet) fprintf(stdout,"Done.\n");

        }

}

