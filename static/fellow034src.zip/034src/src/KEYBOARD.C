/*=======================*/
/* Fellow Emulator       */
/* Keyboard emulation    */
/* (C) 1997 Petter Schau */
/*=======================*/


#include <dos.h>
#include "defs.h"
#include "fellow.h"
#include "keycodes.h"
#include "inout.h"
#include "joymouse.h"
#include "graphem.h"
#include "BMP.h"

/* Keyboard buffer data */

void (__interrupt __far *kbdirqorgvect)();  /* Ptr to old keyboard vector */
UBY keybuffer[512];
ULO keybufferconsumepos, keytimetowait, keybufferproducepos;
ULO lastwase0 = FALSE;
ULO center_code = 0;
ULO home_pressed = FALSE;
ULO end_pressed = FALSE;
ULO softreset;
ULO newvmode = 0;
ULO f12pressed;
UBY insert_dfX[4] = {0,0,0,0}; /* 0 - nothing 1- insert 2-eject */
ULO kbd_pages_locked = FALSE;
ULO keyboard_irq_installed = FALSE;
ULO key;

/* First level translation table */

unsigned char kbd1stlevel[0x59] = {
 A_NOKEY, /* pc none code 0x00 - Amiga none */
 A_ESC  , /* pc esc  code 0x01 - Amiga esc  */
 A_1    , /* pc 1    code 0x02 - Amiga 1    */
 A_2    , /* pc 2    code 0x03 - Amiga 2    */
 A_3    , /* pc 3    code 0x04 - Amiga 3    */
 A_4    , /* pc 4    code 0x05 - Amiga 4    */
 A_5    , /* pc 5    code 0x06 - Amiga 5    */
 A_6    , /* pc 6    code 0x07 - Amiga 6    */
 A_7    , /* pc 7    code 0x08 - Amiga 7    */
 A_8    , /* pc 8    code 0x09 - Amiga 8    */
 A_9    , /* pc 9    code 0x0a - Amiga 9    */
 A_0    , /* pc 0    code 0x0b - Amiga 0    */
 A_PLUS , /* pc +    code 0x0c - Amiga +    */
 A_SMSLA, /* pc \    code 0x0d - Amiga small slash */
 A_BSPA , /* pc bspa code 0x0e - Amiga bspace*/
 A_TAB  , /* pc tab  code 0x0f - Amiga tab  */
 A_Q    , /* pc q    code 0x10 - Amiga q    */
 A_W    , /* pc w    code 0x11 - Amiga w    */
 A_E    , /* pc e    code 0x12 - Amiga e    */
 A_R    , /* pc r    code 0x13 - Amiga r    */
 A_T    , /* pc t    code 0x14 - Amiga t    */
 A_Y    , /* pc y    code 0x15 - Amiga y    */
 A_U    , /* pc u    code 0x16 - Amiga u    */
 A_I    , /* pc i    code 0x17 - Amiga i    */
 A_O    , /* pc o    code 0x18 - Amiga o    */
 A_P    , /* pc p    code 0x19 - Amiga p    */
 A_AA   , /* pc aa   code 0x1a - Amiga aa   */
 A_HAT  , /* pc hat  code 0x1b - Amiga hat  */
 A_RET  , /* pc ret  code 0x1c - Amiga ret  */
 A_CTRL , /* pc rctrlcode 0x1d - Amiga ctrl */
 A_A    , /* pc a    code 0x1e - Amiga a    */
 A_S    , /* pc a    code 0x1f - Amiga s    */
 A_D    , /* pc a    code 0x20 - Amiga d    */
 A_F    , /* pc a    code 0x21 - Amiga f    */
 A_G    , /* pc a    code 0x22 - Amiga g    */
 A_H    , /* pc a    code 0x23 - Amiga h    */
 A_J    , /* pc a    code 0x24 - Amiga j    */
 A_K    , /* pc a    code 0x25 - Amiga k    */
 A_L    , /* pc a    code 0x26 - Amiga l    */
 A_OE   , /* pc oe   code 0x27 - Amiga oe   */
 A_AE   , /* pc ae   code 0x28 - Amiga ae   */
 A_TILDE, /* pc or   code 0x29 - Amiga tilde*/
 A_RSHIFT,/* pc rshifcode 0x2a - Amiga rshift*/
 A_STAR , /* pc star code 0x2b - Amiga star */
 A_Z    , /* pc z    code 0x2c - Amiga z    */
 A_X    , /* pc x    code 0x2d - Amiga x    */
 A_C    , /* pc c    code 0x2e - Amiga c    */
 A_V    , /* pc v    code 0x2f - Amiga v    */
 A_B    , /* pc b    code 0x30 - Amiga b    */
 A_N    , /* pc n    code 0x31 - Amiga n    */
 A_M    , /* pc m    code 0x32 - Amiga m    */
 A_COMMA, /* pc ,    code 0x33 - Amiga ,    */
 A_DOT  , /* pc .    code 0x34 - Amiga .    */
 A_QUEST, /* pc -    code 0x35 - Amiga ?    */
 A_LSHIFT,/* pc lshifcode 0x36 - Amiga lshift*/
 A_KPSTAR,/* pc kp*  code 0x37 - Amiga kpmul*/
 A_RALT  ,/* pc ralt code 0x38 - Amiga ralt */
 A_SPACE ,/* pc space code 0x39 - Amiga space */
 A_CAPS  ,/* pc caps code 0x3a - Amiga caps */
 A_F1    ,/* pc f1   code 0x3B - Amiga f1   */
 A_F2    ,/* pc f2   code 0x3C - Amiga f2   */
 A_F3    ,/* pc f3   code 0x3D - Amiga f3   */
 A_F4    ,/* pc f4   code 0x3E - Amiga f4   */
 A_F5    ,/* pc f5   code 0x3F - Amiga f5   */
 A_F6    ,/* pc f6   code 0x40 - Amiga f6   */
 A_F7    ,/* pc f7   code 0x41 - Amiga f7   */
 A_F8    ,/* pc f8   code 0x42 - Amiga f8   */
 A_F9    ,/* pc f9   code 0x43 - Amiga f9   */
 A_F10   ,/* pc f10  code 0x44 - Amiga f10  */
 A_KPLBRA,/* pc nlockcode 0x45 - Amiga keypad right backet */
 A_NOKEY ,/* pc scrolllock 0x46- Amiga none */
 A_KP7   ,/* pc kp 7 code 0x47 - Amiga kp 7 */
 A_KP8   ,/* pc kp 8 code 0x48 - Amiga kp 8 */
 A_KP9   ,/* pc kp 9 code 0x49 - Amiga kp 9 */
 A_KPMINUS,/* pc kp - code 0x4a - Amiga kp - */
 A_KP4   ,/* pc kp 4 code 0x4b - Amiga kp 4 */
 A_KP5   ,/* pc kp 5 code 0x4c - Amiga kp 5 */
 A_KP6   ,/* pc kp 6 code 0x4d - Amiga kp 6 */
 A_KPPLUS,/* pc kp + code 0x4e - Amiga kp plus */
 A_KP1   ,/* pc kp 1 code 0x4f - Amiga kp 1 */
 A_KP2   ,/* pc kp 2 code 0x50 - Amiga kp 2 */
 A_KP3   ,/* pc kp 3 code 0x51 - Amiga kp 3 */
 A_KP0   ,/* pc kp 0 code 0x52 - Amiga kp 0 */
 A_KPDOT ,/* pc kp . code 0x53 - Amiga kp . */
 A_NOKEY ,/* pc none code 0x54 - Amiga none */
 A_NOKEY ,/* pc none code 0x55 - Amiga none */
 A_BRAC  ,/* pc <    code 0x56 - Amiga <    */
 A_BSLA  ,/* pc f11  code 0x57 - Amiga bslash*/
 A_NOKEY};  /* code 0x58 */



/* Keyboard routines
   -----------------

   Interrupt handler
   -----------------
   - Translate scancode to the corresponding amiga scancode
   - Check press and release bit
   - Add key to keybuffer
   - Set keytimetowait if buffer was empty
   - keytimetowait is horisontal blanks before key is visible
     to the CIA serial port. */

UBY tmpcode;

void __interrupt __far kbdirqhandler() {
  int scancode,i;

  scancode = inp(0x60);
  if (lastwase0) {
    lastwase0 = FALSE;
    if (config_joy[0] == 1 || config_joy[1] == 1) { /* Joystick, arrowkeys */
      if (joy_keyreplacement1(scancode)) {
        outp(0x20,0x20);
        return;
      }
    }

    /* Generate keycode for used keys with E0 prefix */

    switch (scancode & 0x7f) {
    case 0x35:      tmpcode = A_KPDIV | (scancode & 0x80); /* Keypad divide */
      break;
    case 0x38:      tmpcode = 0x65 | (scancode & 0x80);  /* Right Alt */
      break;
    case 0x1c:      tmpcode = 0x43 | (scancode & 0x80);  /* Keypad enter */
      break;
    case 0x48:      tmpcode = A_UP | (scancode & 0x80);  /* up */
      break;
    case 0x4b:      tmpcode = A_LEFT | (scancode & 0x80);  /* left */
      break;
    case 0x4d:      tmpcode = A_RIGHT | (scancode & 0x80);  /* right */
      break;
    case 0x50:      tmpcode = A_DOWN | (scancode & 0x80);  /* down */
      break;
    case 0x52:      tmpcode = A_HELP | (scancode & 0x80); /* Ins is help */
      break;
    case 0x57:      tmpcode = A_LAMIGA | (scancode & 0x80); /* Lwin is LAmiga*/
      break;
    case 0x58:      tmpcode = A_RAMIGA | (scancode & 0x80); /* Rwin is RAmiga*/
      break;
    case 0x4f:      if (scancode == 0x4f) end_pressed = TRUE; /* End */
    else end_pressed = FALSE; 
    outp(0x20,0x20);
    return;
    break;
    case 0x53:      tmpcode = A_DEL | (scancode & 0x80); /* Del is Del */
      break;
    case 0x47:      if (scancode == 0x47) home_pressed = TRUE; /* Home */
    else home_pressed = FALSE; 
    outp(0x20,0x20);
    return;
    break;
    case 0x49:      if (home_pressed) {
      if (scancode == (0x49|0x80)) {  /* Pg Up */
	config_graphics_mode++;
	if (config_graphics_mode > (NROFMODES-1))
	  config_graphics_mode = 0;
	for (i = 0; i < (NROFMODES-1); i++)
	  if (!config_graphics_modeavailable[config_graphics_mode]) {
	    config_graphics_mode++;
	    if (config_graphics_mode > (NROFMODES-1))
	      config_graphics_mode = 0;
	  }
	newvmode = 1;
	gmodefirsttime[config_graphics_mode] = 1;
      }
      outp(0x20,0x20);
      return;
    }
    else if (end_pressed) {
      if (scancode == (0x49|0x80)) { /* Pg up */
	if (config_graphics_scaley < 2) {
	  config_graphics_scaley++;
	  newvmode = 2;
	}
      }
      outp(0x20,0x20);
      return;
    }
    else {
      tmpcode = A_RAMIGA | (scancode & 0x80);
      if ((scancode & 0x80) == 0x80) softreset &= 3;
      else softreset |= 4;
      break;
    }
    case 0x51:     if (home_pressed) {
      if (scancode == (0x51|0x80)) {    /* Pg Down */
	config_graphics_mode--;
	if (config_graphics_mode == 0xffffffff)
	  config_graphics_mode = NROFMODES-1;
	for (i = 0; i < (NROFMODES-1); i++)
	  if (!config_graphics_modeavailable[config_graphics_mode]) {
	    config_graphics_mode--;
	    if (config_graphics_mode == 0xffffffff)
	      config_graphics_mode = NROFMODES-1;
	  }
	newvmode = 1;
	gmodefirsttime[config_graphics_mode] = 1;
      }
      outp(0x20,0x20);
      return;
    }
    else if (end_pressed) {
      if (scancode == (0x51|0x80)) { /* Pg down */
	if (config_graphics_scaley > 0) {
	  config_graphics_scaley--;
	  newvmode = 2;
	}
      }
      outp(0x20,0x20);
      return;
    }
    else {
      tmpcode = A_LAMIGA | (scancode & 0x80);
      if ((scancode & 0x80) == 0x80) softreset &= 5;
      else softreset |= 2;
      break;
    }
    default:        outp(0x20,0x20);
      return;
    }
  }
  else {
    /* Last was not 0xe0 */

    if (scancode == 0xe0) {
      lastwase0 = TRUE;
      outp(0x20,0x20);
      return;
    }
    if (scancode == (0x58 | 0x80)) {
      f12pressed = 1;                   /* F12 - exit to GUI */
      outp(0x20,0x20);
      return;
    }
    if (config_joy[0] == 2 || config_joy[1] == 2) {
      /* Joystick, DFG R Left CTRL */
      if (joy_keyreplacement2(scancode)) {
        outp(0x20,0x20);
        return;
      }
    }

    if (home_pressed) {
      if ((scancode&0x7f) == 0x57) {
        if ((scancode&0x80) == 0x80) BMPdumpflag = TRUE;
        outp(0x20,0x20);
        return;
      }
      else if (scancode == 80) {
        center_code = 80;
        outp(0x20,0x20);
        return;
      }
      else if (scancode == 72) {
        center_code = 72;
        outp(0x20,0x20);
        return;
      }
      else if (scancode == 75) {
        center_code = 75;
        outp(0x20,0x20);
        return;
      }
      else if (scancode == 77) {
        center_code = 77;
        outp(0x20,0x20);
        return;
      }
      else if (((scancode & 0x7f) == 0x3b) || ((scancode & 0x7f) == 0x3c) ||
               ((scancode & 0x7f) == 0x3d) || ((scancode & 0x7f) == 0x3e)) {
	/* HOME + F1/F2/F3/F4, Insert image */
        if ((scancode & 0x80) == 0x80) {
          insert_dfX[(scancode&0x7f) - 0x3b] = 1;
          f12pressed = TRUE;        /* Force exit on next end_of_frame */
	}
        outp(0x20,0x20);
        return;
      }
    }
    if (end_pressed) {
      if (((scancode & 0x7f) == 0x3b) || ((scancode & 0x7f) == 0x3c) ||
          ((scancode & 0x7f) == 0x3d) || ((scancode & 0x7f) == 0x3e)) {
	/* END + F1/F2/F3/F4, Eject image */
        if ((scancode & 0x80) == 0x80) {
          insert_dfX[(scancode&0x7f) - 0x3b] = 2;
          f12pressed = TRUE;        /* Force exit on next end_of_frame */
	}
        outp(0x20,0x20);
        return;
      }
    }

    if ((scancode & 0x7f) == 0x1d) {
      if ((scancode & 0x80) == 0x80) softreset &= 6;
      else softreset |= 1;
    }

    if ((scancode & 0x7f) >= 0x59) {
      outp(0x20,0x20);
      return; /* Illegal scancode, simply ignore */
    }

    tmpcode = kbd1stlevel[scancode&0x7f];
    if (tmpcode == 0xff) { 
      outp(0x20,0x20);
      return;  /* Scancode for nonmapped key */
    }
  } /* End of not E0 */

  /* Here we have got a mapped scancode, set press/release bit */

  tmpcode |= (scancode & 0x80);

  /* Add scancode to end of keybuffer */

  keybuffer[(keybufferproducepos) & 511] = tmpcode;
  keybufferproducepos++;

  key = scancode;

  outp(0x20,0x20);
}

/* Set keyboard irq vector to our irq handler */

void init_kbdirq(void) {
  lastwase0 = 0;
  softreset = 0;
  if (!kbd_pages_locked) {
    kbd_pages_locked = TRUE;
    lock_region((void near *) kbdirqhandler, 4096);
    lock_region(joy_keyreplacement1, 1024);
    lock_region(joy_keyreplacement2, 1024);
    lock_region(&lastwase0, sizeof(lastwase0));
    lock_region(config_joy, sizeof(config_joy));
    lock_region(&tmpcode, sizeof(tmpcode));
    lock_region(&home_pressed, sizeof(home_pressed));
    lock_region(&end_pressed, sizeof(end_pressed));
    lock_region(&config_graphics_mode, sizeof(config_graphics_mode));
    lock_region(config_graphics_modeavailable, sizeof(config_graphics_modeavailable));
    lock_region(&newvmode, sizeof(newvmode));
    lock_region(gmodefirsttime, sizeof(gmodefirsttime));
    lock_region(&f12pressed, sizeof(f12pressed));
    lock_region(&BMPdumpflag, sizeof(BMPdumpflag));
    lock_region(&center_code, sizeof(center_code));
    lock_region(kbd1stlevel, sizeof(kbd1stlevel));
    lock_region(keybuffer, sizeof(keybuffer));
    lock_region(&keybufferproducepos, sizeof(keybufferproducepos));
    lock_region(insert_dfX, sizeof(insert_dfX));
    lock_region(&softreset, sizeof(&softreset));
    }
  kbdirqorgvect = _dos_getvect(9);
  _dos_setvect(9, kbdirqhandler);
  keyboard_irq_installed = TRUE;
}

/* Uninstall our keyboard irq handler */

void restore_kbdirq(void) {
  if (keyboard_irq_installed) {
    _dos_setvect(9, kbdirqorgvect);
    keyboard_irq_installed = FALSE;
  }
}

/*=========================*/
/* Called on emulator exit */
/*=========================*/

void kbd_close(void) {
  if (kbd_pages_locked) {
    unlock_region((void near *)kbdirqhandler, 4096);
    unlock_region(joy_keyreplacement1, 1024);
    unlock_region(joy_keyreplacement2, 1024);
    unlock_region(&lastwase0, sizeof(lastwase0));
    unlock_region(config_joy, sizeof(config_joy));
    unlock_region(&tmpcode, sizeof(tmpcode));
    unlock_region(&home_pressed, sizeof(home_pressed));
    unlock_region(&end_pressed, sizeof(end_pressed));
    unlock_region(&config_graphics_mode, sizeof(config_graphics_mode));
    unlock_region(config_graphics_modeavailable, sizeof(config_graphics_modeavailable));
    unlock_region(&newvmode, sizeof(newvmode));
    unlock_region(gmodefirsttime, sizeof(gmodefirsttime));
    unlock_region(&f12pressed, sizeof(f12pressed));
    unlock_region(&BMPdumpflag, sizeof(BMPdumpflag));
    unlock_region(&center_code, sizeof(center_code));
    unlock_region(kbd1stlevel, sizeof(kbd1stlevel));
    unlock_region(keybuffer, sizeof(keybuffer));
    unlock_region(&keybufferproducepos, sizeof(keybufferproducepos));
    unlock_region(insert_dfX, sizeof(insert_dfX));
    unlock_region(&softreset, sizeof(&softreset));
    }
  restore_kbdirq();
}

/* Called every time we reset */

void reset_keyboard(void) {
  keybufferconsumepos = 0;
  keytimetowait = 10;
  keybufferproducepos = 2;
  keybuffer[0] = 0xfd; /* Start of keys pressed during reset */
  keybuffer[1] = 0xfe; /* End of keys pressed during reset */
  f12pressed = 0;
  lastwase0 = 0;
}





