/*=============================*/
/* Fellow Amiga Emulator       */
/* Setup for videomodes        */
/* (C) 1997-1998 Petter Schau, */
/*               Roman Dolejsi */
/*           and David Voracek */
/*=============================*/



/* This vesa stuff should really be killed and rewritten */

/* Too many kludges ++ */


#define DPMI32

#include <dos.h>
#include <stdio.h>
#include "defs.h"
#include "fellow.h"
#include "sddsdk\\vesavbe.h"
#include "memory.h"
#include "sddsdk\\pmpro.h"
#include "sblast.h"
#include "sound.h"
#include "fonts.h"
#include "graphem.h"
#include "draw.h"
#include "keyboard.h"

/* Memory to build the speedomeeter image */

UWO speedbuffer[8][16];

// Data, constants and pointers for VESA & VGA graphic routines

UWO *framebufferunmodified; /* Unmodified pointer to framebuffer memory */
UWO *framebuffer; /* Pointer to framebuffer when mapped to our memory */
ULO framebuffersize; /* Number of bytes to clear when buffer is cleared */

/* These are updated when a new mode is set */

ULO framebuffermapped; /* Flag to avoid mapping the framebuffer twice */


ULO bufferoffsets[3];
UBY graph256_palette[256][3];

/*---*/

ULO config_graphics_modenr[NROFMODES];
UBY config_graphics_modeavailable[NROFMODES];
UBY config_graphics_modebits[NROFMODES];
ULO config_graphics_moderesx[NROFMODES] = { 800, 320, 320, 640, 640, 640, 320, 320, 320, 320, 400, 320, 320, 400};
ULO config_graphics_moderesy[NROFMODES] = { 300, 200, 240, 480, 400, 350, 200, 240, 400, 480, 300, 400, 480, 300};

ULO tick, tick2, tock;


#ifdef WITH_OS_TIMER

/*=======================================*/
/* Generic frames per second calculation */
/*=======================================*/

ULO fps_lastcc, fps_nowcc;
ULO fps;

void timerFPSCalculate(void) {
  fps_nowcc = (frames*71364) + (ypos*228) + xpos;
  fps = ((fps_nowcc - fps_lastcc)*50)/(71364*sound_buffer_depth);
  fps_lastcc = fps_nowcc;
}
	 

/* Used when sound is off, or not played */
/* Frequency 50 hz, counts frames and calculated virtual speed */

void __interrupt __far timer_routine() {
  tick++;
    if ((tock++ % sound_buffer_depth) == 0)
    timerFPSCalculate();
  outp(0x20,0x20);
}


/* Used for real-time synch sound */
/* Frequency 63*50 hz */

void __interrupt __far timer_routine_continuous() {
  audio_hblanks += 5;
  if (++tick2 >= 63) {
    tick2 = 0;
    tick++;
    if ((tock++ % sound_buffer_depth) == 0)
      timerFPSCalculate();
       }
  outp(0x20,0x20);
}

void (__interrupt __far *prev_int_1c)();  /* Ptr to old timer vector */

/* Using _dos_setvect etc. to set timer irq.  Assume dos always has the */
/* timer running so don't enable in the mask */

/* Two routines: */
/* timer_routine_continuous - will provide real-time sound-emulation with */
/*                            real-time synchronization + update speedmtr */
/* timer_routine - use when sound is not played for 50hz synchronization */


void start_timerirq(void) {
  tick = 0;
  prev_int_1c = _dos_getvect(0x1c);

  /* Lock all code and data touched by the timer irq */

  lock_region((void near *)timer_routine_continuous, 1024);
  lock_region((void near *)timer_routine, 1024);
  lock_region(timerFPSCalculate, 1024);
  lock_region(&tick, sizeof(tick));
  lock_region(&tick2, sizeof(tick2));
  lock_region(&audio_hblanks, sizeof(audio_hblanks));
  lock_region(&fps_nowcc, sizeof(fps_nowcc));
  lock_region(&fps_lastcc, sizeof(fps_lastcc));
  lock_region(&xpos, sizeof(xpos));
  lock_region(&ypos, sizeof(ypos));
  lock_region(&fps, sizeof(fps));
  if (sound_mode == SOUND_CONTIGUOUS) {
    _dos_setvect(0x1c, timer_routine_continuous);
    outp(0x43,0xb6);    /* Set timer to expire 31300/5 times per second */
    outp(0x40,0x7d);    /* Used to run sound-emulation in real-time */
    outp(0x40,0x01);
    }
  else {
    _dos_setvect(0x1c, timer_routine);
    outp(0x43,0xb6);    /* Set timer to expire 50 times per second */
    outp(0x40,0x37);
    outp(0x40,0x5d);
    }
  fps_lastcc = frames*71364+ypos*228+xpos;
}

void stop_timerirq(void) {
  outp(0x43,0xb6);      /* Set slowest timer rate */
  outp(0x40,0xff);
  outp(0x40,0xff);
  _dos_setvect(0x1c, prev_int_1c);
  unlock_region((void near *)timer_routine_continuous, 1024);
  unlock_region((void near *)timer_routine, 1024);
  unlock_region(timerFPSCalculate, 1024);
  unlock_region(&tick, sizeof(tick));
  unlock_region(&tick2, sizeof(tick2));
  unlock_region(&audio_hblanks, sizeof(audio_hblanks));
  unlock_region(&fps_nowcc, sizeof(fps_nowcc));
  unlock_region(&fps_lastcc, sizeof(fps_lastcc));
  unlock_region(&xpos, sizeof(xpos));
  unlock_region(&ypos, sizeof(ypos));
  unlock_region(&fps, sizeof(fps));
}

#endif

void set_VGAcolor(UBY col,UBY b,UBY g,UBY r) {
  outp(0x3c8,col);
  outp(0x3c9,r);
  outp(0x3c9,g);
  outp(0x3c9,b);
  graph256_palette[col][0] = r;
  graph256_palette[col][1] = g;
  graph256_palette[col][2] = b;
};



// oldmode stores the screenmode present when the emulator was started
// screenclose() returns the screen to this mode
// -------------------------------------------------------------------

ULO oldmode;

// Variables and function provided for the VESA code
// -------------------------------------------------

uint             VESABuf_len = 1024;    /* Length of the VESABuf buffer         */
uint             VESABuf_sel = 0;    /* Selector for VESABuf                         */
uint             VESABuf_off;    /* Offset for VESABuf                           */
uint             VESABuf_rseg;   /* Real mode segment of VESABuf         */
uint             VESABuf_roff;   /* Real mode offset of VESABuf          */

// ===================================================
// Some routines grabbed from some VBE library I found
// The Scitech SDK
// ===================================================

static void ExitVBEBuf(void)
{ PM_freeRealSeg(VESABuf_sel,VESABuf_off); }

/****************************************************************************
*
* Function:             VBE_initRMBuf
*
* Description:  Initialises the VBE transfer buffer in real mode memory.
*                               This routine is called by the VESAVBE module every time
*                               it needs to use the transfer buffer, so we simply allocate
*                               it once and then return.
*
****************************************************************************/

void _PUBAPI VBE_initRMBuf(void) {
  if (!VESABuf_sel) {
    /* Allocate a global buffer for communicating with the VESA VBE */
    if (!PM_allocRealSeg(VESABuf_len, &VESABuf_sel, &VESABuf_off,
			 &VESABuf_rseg, &VESABuf_roff))
      exit(1);
    atexit(ExitVBEBuf);
  }
}

void plot_char_speedbuffer(UBY character, ULO x,UWO fgcolor, UWO bgcolor) {
  int i,j;

  for (i = 0; i < 5; i++) 
    for (j = 0; j < 4; j++) {
      if (speedfont[character][i][j] == 1) 
	speedbuffer[i][x*4+j] = fgcolor; 
      else                    /* Clear point */
	speedbuffer[i][x*4+j] = bgcolor; 
    }
}

void plot_text_speedbuffer(char *text, UWO fgcolor, UWO bgcolor) {
  int i,c,fg;
  static ULO blue=0x1f,red=0x1f,green=0x1f;
  static ULO bluedir=0,reddir=0,greendir=0;
  static count = 0;

  count++;
  if ((count % 2) == 0) {
    switch (bluedir) {
      case 0:  blue--;
               if (blue == 0x10) bluedir++;
               break;
      case 1:  blue++;
               if (blue == 0x1f) bluedir--;
               break;
               }
     }
  if ((count % 4) == 0) {
    switch (reddir) {
      case 0:  red--;
               if (red == 0x10) reddir++;
               break;
      case 1:  red++;
               if (red == 0x1f) reddir--;
               break;
               }
     }

  if ((count % 8) == 0) {
    switch (greendir) {
      case 0:  green--;
               if (green == 0x10) greendir++;
               break;
      case 1:  green++;
               if (green == 0x1f) greendir--;
               break;
               }
     }

  fg = blue | (green<<5) | (red<<10);

  for (i = 0; i< 4; i++) {
   c = *text++;
   switch (c) {
     case '0': plot_char_speedbuffer(9,i,fg,bgcolor);
               break;
     case '1': plot_char_speedbuffer(0,i,fg,bgcolor);
               break;
     case '2': plot_char_speedbuffer(1,i,fg,bgcolor);
               break;
     case '3': plot_char_speedbuffer(2,i,fg,bgcolor);
               break;
     case '4': plot_char_speedbuffer(3,i,fg,bgcolor);
               break;
     case '5': plot_char_speedbuffer(4,i,fg,bgcolor);
               break;
     case '6': plot_char_speedbuffer(5,i,fg,bgcolor);
               break;
     case '7': plot_char_speedbuffer(6,i,fg,bgcolor);
               break;
     case '8': plot_char_speedbuffer(7,i,fg,bgcolor);
               break;
     case '9': plot_char_speedbuffer(8,i,fg,bgcolor);
               break;
     case '%': plot_char_speedbuffer(10,i,fg,bgcolor);
               break;
     case ' ': plot_char_speedbuffer(11,i,fg,bgcolor);
               break;
     }
   }
}

ULO newbytes,newpixels,newmaxscans;
int dispx,dispy;

void clear_framebuffer(void) {
  memset(framebuffer, 0, framebuffersize);
}


void set_bufferoffsets(ULO width, ULO height, ULO hmod) {
  bufferoffsets[0] = 0;
  bufferoffsets[1] = ((height/hmod)*width) + ((height/hmod)*draw_scanlinemodulo);
  bufferoffsets[2] = bufferoffsets[1]*2;
}

/* When Vesa returns NULL for framebuffer, the computer is likely */
/* to suffer a crash when Fellow attempts to use it */
/* So disable all modes that needs it if it fails */

int map_framebuffer(void) {  
  VBE_modeInfo mymodeinfo;
  int domap = -1, i;

  addlog("In map_framebuffer\n");
  if (!framebuffermapped) {
    for (i = 0; i < NROFMODES; i++)  /* Check if we need to map buffer */
      if ((i != 6) && config_graphics_modeavailable[i]) domap = i;

    if (domap != -1) {  /* Map buffer */
      addlog("Mapping buffer\n");
      VBE_getModeInfo(config_graphics_modenr[domap], &mymodeinfo);
      framebufferunmodified = (UWO *) VBE_getLinearPointer(&mymodeinfo);
      {
	char s[80];

	sprintf(s, "fbuf at %X\n", framebufferunmodified);
	addlog(s);
      }
      if (!framebufferunmodified) { /* NULL pointer, serious error */
	framebuffermapped = FALSE;
	addlog("VESA ERROR!: VESA returned NULL for framebuffer\n");
      }
      else framebuffermapped = TRUE;
    }
  }
  return framebuffermapped;    
}

void decide_buffers(ULO height, ULO maxlines, ULO heightmodifier) {
  if (maxlines >= ((height*3)/heightmodifier)) configdoublebuffer = 2;
  else if (maxlines >= ((height*2)/heightmodifier)) configdoublebuffer = 1;
  else configdoublebuffer = 0;
}



int get_heightmodifier(void) {
  if (config_graphics_scaley == 0)
    return 1;
  else if (config_graphics_scaley == 1)
    return 2;
  else
    return 1;
}
  

void blanklineModuloAdjust(ULO visiblebytes) {
  if (config_graphics_scaley == 2)
    draw_scanlinemodulo += draw_scanlinemodulo + visiblebytes;
}


/* Not much testing of attributes, we've already tested them */

void set_mode800600w(void) {
  int heightmodifier = get_heightmodifier();

  if (config_graphics_flickerfree) heightmodifier = 1;
  if (newvmode != 2) VBE_setVideoMode(config_graphics_modenr[0] | 0x4000);
  VBE_getDisplayStart(&dispx,&dispy);
  framebuffer = framebufferunmodified;
  draw_scanlinemodulo = 0;
  VBE_getScanLineLength(&newbytes,&newpixels,&newmaxscans);
  scanlinelength = newbytes;
  if (!config_graphics_flickerfree)
    decide_buffers(600, newmaxscans, heightmodifier);
  else configdoublebuffer = 0;
  if (newpixels > 800) draw_scanlinemodulo = (newpixels-800)*2;
  if (config_graphics_flickerfree) draw_scanlinemodulo = draw_scanlinemodulo*2 + 1600;

  draw_startoffset[0] = 8*1600 + 8*draw_scanlinemodulo + 32;
  if (config_graphics_scaley == 0 && !config_graphics_flickerfree)
    draw_startoffset[0] += (150*1600) + (150*draw_scanlinemodulo);
  draw_startoffset[1] = draw_startoffset[0];
  draw_startoffset[2] = draw_startoffset[0];

  set_bufferoffsets(1600, 600, heightmodifier);
  framebuffersize = bufferoffsets[1]*(configdoublebuffer + 1);
  blanklineModuloAdjust(1600);
  VBE_setDisplayStart(0,0,0);
}

void set_mode640350w(void) {
  int heightmodifier = get_heightmodifier();

  if (newvmode != 2) VBE_setVideoMode(config_graphics_modenr[5] | 0x4000);
  VBE_getDisplayStart(&dispx,&dispy);
  framebuffer = framebufferunmodified;
  draw_scanlinemodulo = 0;
  VBE_getScanLineLength(&newbytes,&newpixels,&newmaxscans);
  decide_buffers(350, newmaxscans, heightmodifier);
  if (newpixels > 640) draw_scanlinemodulo = (newpixels-640)*2;

  if (config_graphics_scaley == 0)
    draw_startoffset[0] = 31*1280 + 31*draw_scanlinemodulo;
  else
    draw_startoffset[0] = 0;
  draw_startoffset[1] = draw_startoffset[0];
  draw_startoffset[2] = draw_startoffset[0];

  set_bufferoffsets(1280, 350, heightmodifier);
  framebuffersize = bufferoffsets[1]*(configdoublebuffer + 1);
  blanklineModuloAdjust(1280);
  VBE_setDisplayStart(0,0,0);
}

void set_mode640400w(void) {
  int heightmodifier = get_heightmodifier();

  if (newvmode != 2) VBE_setVideoMode(config_graphics_modenr[4] | 0x4000);
  VBE_getDisplayStart(&dispx,&dispy);
  framebuffer = framebufferunmodified;
  draw_scanlinemodulo = 0;
  VBE_getScanLineLength(&newbytes,&newpixels,&newmaxscans);
  decide_buffers(400, newmaxscans, heightmodifier);
  if (newpixels > 640) draw_scanlinemodulo = (newpixels-640)*2;

  if (config_graphics_scaley == 0)
    draw_startoffset[0] = 56*1280 + 56*draw_scanlinemodulo;
  else
    draw_startoffset[0] = 0;
  draw_startoffset[1] = draw_startoffset[0];
  draw_startoffset[2] = draw_startoffset[0];

  set_bufferoffsets(1280, 400, heightmodifier);
  framebuffersize = bufferoffsets[1]*(configdoublebuffer + 1);
  blanklineModuloAdjust(1280);
  VBE_setDisplayStart(0,0,0);
}

void set_mode640480w(void) {
  int heightmodifier = get_heightmodifier();

  if (newvmode != 2) VBE_setVideoMode(config_graphics_modenr[3] | 0x4000);
  VBE_getDisplayStart(&dispx,&dispy);
  framebuffer = framebufferunmodified;
  draw_scanlinemodulo = 0;
  VBE_getScanLineLength(&newbytes,&newpixels,&newmaxscans);
  decide_buffers(480, newmaxscans, heightmodifier);
  if (newpixels > 640) draw_scanlinemodulo = (newpixels-640)*2;

  if (config_graphics_scaley == 0)
    draw_startoffset[0] = 92*1280 + 92*draw_scanlinemodulo;
  else
    draw_startoffset[0] = 0;
  draw_startoffset[1] = draw_startoffset[0];
  draw_startoffset[2] = draw_startoffset[0];

  set_bufferoffsets(1280, 480, heightmodifier);
  framebuffersize = bufferoffsets[1]*(configdoublebuffer + 1);
  blanklineModuloAdjust(1280);
  VBE_setDisplayStart(0,0,0);
}

void set_mode320200w(void) {
  if (newvmode != 2) VBE_setVideoMode(config_graphics_modenr[1] | 0x4000);
  VBE_getDisplayStart(&dispx,&dispy);
  framebuffer = framebufferunmodified;
  draw_scanlinemodulo = 0;
  if (VBE_getScanLineLength(&newbytes,&newpixels,&newmaxscans))
    if (newpixels > 320) draw_scanlinemodulo = (newpixels-320)*2;
  decide_buffers(200, newmaxscans, 1);

  draw_startoffset[0] = 0;
  draw_startoffset[1] = draw_startoffset[0];
  draw_startoffset[2] = draw_startoffset[0];

  set_bufferoffsets(640, 200, 1);
  framebuffersize = bufferoffsets[1]*(configdoublebuffer + 1);
  VBE_setDisplayStart(0,0,0);
}


void set_mode320200oldvga(void) {
  if (newvmode != 2) VBE_setVideoMode(0x13);
  framebuffer = (UWO *) 0xa0000;
  draw_scanlinemodulo = 0;
  configdoublebuffer = 0;

  draw_startoffset[0] = 0;
  draw_startoffset[1] = draw_startoffset[0];
  draw_startoffset[2] = draw_startoffset[0];

  set_bufferoffsets(320, 200, 1);
  framebuffersize = 65536;
}


void set_mode320240w(void) {
  if (newvmode != 2) VBE_setVideoMode(config_graphics_modenr[2] | 0x4000);
  VBE_getDisplayStart(&dispx,&dispy);
  framebuffer = framebufferunmodified;
  draw_scanlinemodulo = 0;
  if (VBE_getScanLineLength(&newbytes,&newpixels,&newmaxscans))
    if (newpixels > 320) draw_scanlinemodulo = (newpixels-320)*2;
  decide_buffers(240, newmaxscans, 1);

  draw_startoffset[0] = 0;
  draw_startoffset[1] = draw_startoffset[0];
  draw_startoffset[2] = draw_startoffset[0];

  set_bufferoffsets(640, 240, 1);
  framebuffersize = bufferoffsets[1]*(configdoublebuffer + 1);
  VBE_setDisplayStart(0,0,0);
}

void set_mode320240b(void) {
  if (newvmode != 2) VBE_setVideoMode(config_graphics_modenr[7] | 0x4000);
  framebuffer = framebufferunmodified;
  draw_scanlinemodulo = 0;
  if (VBE_getScanLineLength(&newbytes,&newpixels,&newmaxscans))
    if (newpixels > 320) draw_scanlinemodulo = (newpixels-320);
  decide_buffers(240, newmaxscans, 1);

  draw_startoffset[0] = 0;
  draw_startoffset[1] = draw_startoffset[0];
  draw_startoffset[2] = draw_startoffset[0];

  set_bufferoffsets(320, 240, 1);
  framebuffersize = bufferoffsets[1]*(configdoublebuffer + 1);
  VBE_setDisplayStart(0,0,0);
}

void set_mode320400b(void) {
  if (newvmode != 2) VBE_setVideoMode(config_graphics_modenr[8] | 0x4000);
  framebuffer = framebufferunmodified;
  draw_scanlinemodulo = 0;
  if (VBE_getScanLineLength(&newbytes,&newpixels,&newmaxscans))
    if (newpixels > 320) draw_scanlinemodulo = (newpixels-320);
  decide_buffers(400, newmaxscans, 1);

  draw_startoffset[0] = 56*320 + 56*draw_scanlinemodulo;
  draw_startoffset[1] = draw_startoffset[0];
  draw_startoffset[2] = draw_startoffset[0];

  set_bufferoffsets(320, 400, 1);
  framebuffersize = bufferoffsets[1]*(configdoublebuffer + 1);
  VBE_setDisplayStart(0,0,0);
}

void set_mode320480b(void) {
  if (newvmode != 2) VBE_setVideoMode(config_graphics_modenr[9] | 0x4000);
  framebuffer = framebufferunmodified;
  draw_scanlinemodulo = 0;
  if (VBE_getScanLineLength(&newbytes,&newpixels,&newmaxscans))
    if (newpixels > 320) draw_scanlinemodulo = (newpixels-320);
  decide_buffers(480, newmaxscans, 1);

  draw_startoffset[0] = 92*320 + 92*draw_scanlinemodulo;
  draw_startoffset[1] = draw_startoffset[0];
  draw_startoffset[2] = draw_startoffset[0];

  set_bufferoffsets(320, 480, 1);
  framebuffersize = bufferoffsets[1]*(configdoublebuffer + 1);
  VBE_setDisplayStart(0,0,0);
}

void set_mode400300b(void) {
  if (newvmode != 2) VBE_setVideoMode(config_graphics_modenr[10] | 0x4000);
  framebuffer = framebufferunmodified;
  draw_scanlinemodulo = 0;
  if (VBE_getScanLineLength(&newbytes,&newpixels,&newmaxscans))
    if (newpixels > 400) draw_scanlinemodulo = (newpixels-400);
  decide_buffers(300, newmaxscans, 1);

  draw_startoffset[0] = 8*400 + 8*draw_scanlinemodulo + 8;
  draw_startoffset[1] = draw_startoffset[0];
  draw_startoffset[2] = draw_startoffset[0];

  set_bufferoffsets(400, 300, 1);
  framebuffersize = bufferoffsets[1]*(configdoublebuffer + 1);
  VBE_setDisplayStart(0,0,0);
  draw_scanlinemodulo += 16;
}

void set_mode320400w(void) {
  if (newvmode != 2) VBE_setVideoMode(config_graphics_modenr[11] | 0x4000);
  framebuffer = framebufferunmodified;
  draw_scanlinemodulo = 0;
  if (VBE_getScanLineLength(&newbytes,&newpixels,&newmaxscans))
    if (newpixels > 320) draw_scanlinemodulo = (newpixels-320)*2;
  decide_buffers(400, newmaxscans, 1);

  draw_startoffset[0] = 56*640 + 56*draw_scanlinemodulo;
  draw_startoffset[1] = draw_startoffset[0];
  draw_startoffset[2] = draw_startoffset[0];

  set_bufferoffsets(640, 400, 1);
  framebuffersize = bufferoffsets[1]*(configdoublebuffer + 1);
  VBE_setDisplayStart(0,0,0);
}

void set_mode320480w(void) {
  if (newvmode != 2) VBE_setVideoMode(config_graphics_modenr[12] | 0x4000);
  framebuffer = framebufferunmodified;
  draw_scanlinemodulo = 0;
  if (VBE_getScanLineLength(&newbytes,&newpixels,&newmaxscans))
    if (newpixels > 640) draw_scanlinemodulo = (newpixels-320)*2;
  decide_buffers(480, newmaxscans, 1);

  draw_startoffset[0] = 92*640 + 92*draw_scanlinemodulo;
  draw_startoffset[1] = draw_startoffset[0];
  draw_startoffset[2] = draw_startoffset[0];

  set_bufferoffsets(640, 480, 1);
  framebuffersize = bufferoffsets[1]*(configdoublebuffer + 1);
  VBE_setDisplayStart(0,0,0);
}

void set_mode400300w(void) {
  if (newvmode != 2) VBE_setVideoMode(config_graphics_modenr[13] | 0x4000);
  framebuffer = framebufferunmodified;
  draw_scanlinemodulo = 0;
  if (VBE_getScanLineLength(&newbytes,&newpixels,&newmaxscans))
    if (newpixels > 400) draw_scanlinemodulo = (newpixels-400)*2;
  decide_buffers(300, newmaxscans, 1);

  draw_startoffset[0] = 8*800 + 8*draw_scanlinemodulo + 16;
  draw_startoffset[1] = draw_startoffset[0];
  draw_startoffset[2] = draw_startoffset[0];

  set_bufferoffsets(800, 300, 1);
  framebuffersize = bufferoffsets[1]*(configdoublebuffer + 1);
  VBE_setDisplayStart(0,0,0);
  draw_scanlinemodulo += 32;
}

ULO find_mode_nr(ULO width, ULO height, ULO bits, VBE_vgaInfo *vi, ULO nr) {
  VBE_modeInfo mymodeinfo;
  char o[80];
  UWO *i;
  int found;

  sprintf(o,"Searching for mode %dx%dx%d\n",width,height,bits);
  addlog(o);

  found = FALSE;
  i = vi->VideoModePtr;

  while (*i != 0xffff && !found) {
    VBE_getModeInfo(*i, &mymodeinfo);
    if ((mymodeinfo.XResolution == width) && (mymodeinfo.YResolution == height) &&
        (mymodeinfo.BitsPerPixel == bits)) found = TRUE;
    else i++;
  }

  if (found) {
    config_graphics_modenr[nr] = *i;
    VBE_getModeInfo(*i,&mymodeinfo);

    if (mymodeinfo.ModeAttributes & vbeMdAvailable) {
      addlog("Mode available\n");
      /* Here mode is available */
      if ((mymodeinfo.ModeAttributes & vbeMdLinear)) {
	/* Linear mode available */  
	addlog("Mode is capable of linear framebuffer\n");
	return 1;
      }
      else addlog("Mode not useable, missing linear framebuffer\n");
    }
  }
  else addlog("The mode was not found\n");
  return 0;
}


void find_modes(VBE_vgaInfo *vi) {
  ULO i;

  for (i = 0; i < NROFMODES; i++)
    config_graphics_modeavailable[i] = config_graphics_modebits[i] = 0;

  addlog("Searching for VESA mode 800x600 15/16 bit color\n");
  if (find_mode_nr(800,600,15,vi,0)) {
    config_graphics_modeavailable[0] = 1;
    config_graphics_modebits[0] = 15;
    addlog("800x600x15 found and enabled\n");
    }
  else if (find_mode_nr(800,600,16,vi,0)) {
    config_graphics_modeavailable[0] = 1;
    config_graphics_modebits[0] = 16;
    addlog("800x600x16 found and enabled\n");
    }

  addlog("Searching for VESA mode 320x200 15/16 bit color\n");
  if (find_mode_nr(320,200,15,vi,1)) {
    config_graphics_modeavailable[1] = 1;
    config_graphics_modebits[1] = 15;
    addlog("320x240x15 found and enabled\n");
    }
  else if (find_mode_nr(320,200,16,vi,1)) {
    config_graphics_modeavailable[1] = 1;
    config_graphics_modebits[1] = 16;
    addlog("320x200x16 found and enabled\n");
    }

  addlog("Searching for VESA mode 320x240 15/16 bit color\n");
  if (find_mode_nr(320,240,15,vi,2)) {
    config_graphics_modeavailable[2] = 1;
    config_graphics_modebits[2] = 15;
    addlog("320x240x15 found and enabled\n");
    }
  else if (find_mode_nr(320,240,16,vi,2)) {
    config_graphics_modeavailable[2] = 1;
    config_graphics_modebits[2] = 16;
    addlog("320x240x16 found and enabled\n");
    }

  addlog("Searching for VESA mode 640x480 15/16 bit color\n");
  if (find_mode_nr(640,480,15,vi,3)) {
    config_graphics_modeavailable[3] = 1;
    config_graphics_modebits[3] = 15;
    addlog("640x480x15 found and enabled\n");
    }
  else if (find_mode_nr(640,480,16,vi,3)) {
    config_graphics_modeavailable[3] = 1;
    config_graphics_modebits[3] = 16;
    addlog("640x480x16 found and enabled\n");
    }

  addlog("Searching for VESA mode 640x400 15/16 bit color\n");
  if (find_mode_nr(640,400,15,vi,4)) {
    config_graphics_modeavailable[4] = 1;
    config_graphics_modebits[4] = 15;
    addlog("640x400x15 found and enabled\n");
    }
  else if (find_mode_nr(640,400,16,vi,4)) {
    config_graphics_modeavailable[4] = 1;
    config_graphics_modebits[4] = 16;
    addlog("640x400x16 found and enabled\n");
    }
  addlog("Searching for VESA mode 640x350 15/16 bit color\n");
  if (find_mode_nr(640,350,15,vi,5)) {
    config_graphics_modeavailable[5] = 1;
    config_graphics_modebits[5] = 15;
    addlog("640x350x15 found and enabled\n");
    }
  else if (find_mode_nr(640,350,16,vi,5)) {
    config_graphics_modeavailable[5] = 1;
    config_graphics_modebits[5] = 16;
    addlog("640x350x16 found and enabled\n");
    }

  addlog("320x200x8 (mode 0x13) enabled, always available\n");
  config_graphics_modeavailable[6] = 1;
  config_graphics_modebits[6] = 8;

  addlog("Searching for VESA mode 320x240 8 bit color\n");
  if (find_mode_nr(320,240,8,vi,7)) {
    config_graphics_modeavailable[7] = 1;
    config_graphics_modebits[7] = 8;
    addlog("320x240x8 found and enabled\n");
    }

  addlog("Searching for VESA mode 320x400 8 bit color\n");
  if (find_mode_nr(320,400,8,vi,8)) {
    config_graphics_modeavailable[8] = 1;
    config_graphics_modebits[8] = 8;
    addlog("320x400x8 found and enabled\n");
    }

  addlog("Searching for VESA mode 320x480 8 bit color\n");
  if (find_mode_nr(320,480,8,vi,9)) {
    config_graphics_modeavailable[9] = 1;
    config_graphics_modebits[9] = 8;
    addlog("320x480x8 found and enabled\n");
    }

  addlog("Searching for VESA mode 400x300 8 bit color\n");
  if (find_mode_nr(400,300,8,vi,10)) {
    config_graphics_modeavailable[10] = 1;
    config_graphics_modebits[10] = 8;
    addlog("400x300x8 found and enabled\n");
    }

  addlog("Searching for VESA mode 320x400 15/16 bit color\n");
  if (find_mode_nr(320,400,15,vi,11)) {
    config_graphics_modeavailable[11] = 1;
    config_graphics_modebits[11] = 15;
    addlog("320x400x15 found and enabled\n");
    }
  else if (find_mode_nr(320,400,16,vi,11)) {
    config_graphics_modeavailable[11] = 1;
    config_graphics_modebits[11] = 16;
    addlog("320x400x16 found and enabled\n");
    }

  addlog("Searching for VESA mode 320x480 15/16 bit color\n");
  if (find_mode_nr(320,480,15,vi,12)) {
    config_graphics_modeavailable[12] = 1;
    config_graphics_modebits[12] = 15;
    addlog("320x480x15 found and enabled\n");
    }
  else if (find_mode_nr(320,480,16,vi,12)) {
    config_graphics_modeavailable[12] = 1;
    config_graphics_modebits[12] = 16;
    addlog("320x480x16 found and enabled\n");
    }

  addlog("Searching for VESA mode 400x300 15/16 bit color\n");
  if (find_mode_nr(400,300,15,vi,13)) {
    config_graphics_modeavailable[13] = 1;
    config_graphics_modebits[13] = 15;
    addlog("400x300x15 found and enabled\n");
    }
  else if (find_mode_nr(400,300,16,vi,13)) {
    config_graphics_modeavailable[13] = 1;
    config_graphics_modebits[13] = 16;
    addlog("400x300x16 found and enabled\n");
    }

}


/*=======================================*/
/* Scale some modes with VGA line double */
/*=======================================*/

void vesa_scaley(void) {
  ULO hey;

  outp(0x3d4,9);
  hey = inp(0x3d5);
  outp(0x3d4,9);
  outp(0x3d5,(hey&0xe0)|config_graphics_scaley);
}

/*===============================================================*/
/* screeninit					                 */
/* checks for VESA 2.0, records the current screenmode and sets  */
/* Returns TRUE if intialization was successful, FALSE otherwise */
/*===============================================================*/

ULO screeninit(void) {
  VBE_vgaInfo myinfo;
  ULO version;
  ULO i;
  STR o[80];


  tick = 0;
  tock = 0;
  
  /* Find VESA 2.0 driver */

  version = VBE_detect(&myinfo);
  sprintf(o,"VESA version %d.%d found.\n",(version&0xff00)>>8,version&0xff);
  addlog(o);
  if( !( version & 0xff00 ) ) addlog("No VESA found.\n");

  /* Find and select usable video-modes */

  if(version & 0xff00) {
    find_modes(&myinfo);
    if (!map_framebuffer()) {
      for (i = 0; i < NROFMODES; i++)
	if (i != 6) config_graphics_modeavailable[i] = FALSE;
      addlog("Can't set up linear framebuffer\n");
      addlog("Disabling all modes except 320x200x8\n");
    }
  }
  else {
    addlog("320x200x8 (mode 0x13) enabled, always available\n");
    config_graphics_modeavailable[6] = 1;
    config_graphics_modebits[6] = 8;
  }

  if( !config_graphics_modeavailable[config_graphics_mode] ) {
    i = 0;
    while( i < NROFMODES && !config_graphics_modeavailable[i] ) i++;
    config_graphics_mode = i;
  };


  /* Record old mode */

  oldmode = VBE_getVideoMode();

  return 1;
}

/* ULOscreenclose(void)
   Restores old videomode and frees memory used by VBE library
   Returns TRUE when successful, FALSE otherwise
   =========================================================== */

ULO screenclose(void)
{
  ULO returnvalue = 1;
  /* Restore screen to old videomode */

  if (!VBE_setVideoMode(oldmode)) {
    addlog("Failed to restore old video mode\n");
    returnvalue = 0;
    }
  
  /* Free some memory */

  VBE_freePMCode();
  return returnvalue;
}
