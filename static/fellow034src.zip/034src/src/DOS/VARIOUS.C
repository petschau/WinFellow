/*====================================*/
/* Fellow Amiga Emulator              */
/* Various DOS-specific functions     */
/* 1997-1998 Petter Schau             */
/* Some functions taken from examples */
/*====================================*/


#include <stdio.h>
#include <stdlib.h>

#include "i86.h"
#include "defs.h"
#include "fellow.h"
#include "various.h"

/*======================*/
/* Get available memory */
/*======================*/

#define DPMI_INT        0x31

struct meminfo {
  unsigned LargestBlockAvail;
  unsigned MaxUnlockedPage;
  unsigned LargestLockablePage;
  unsigned LinAddrSpace;
  unsigned NumFreePagesAvail;
  unsigned NumPhysicalPagesFree;
  unsigned TotalPhysicalPages;
  unsigned FreeLinAddrSpace;
  unsigned SizeOfPageFile;
  unsigned Reserved[3];
} MemInfo;

ULO getLargestMemBlock(void) {
  union REGS regs;
  struct SREGS sregs;

  regs.x.eax = 0x00000500;
  memset( &sregs, 0, sizeof(sregs) );
  sregs.es = FP_SEG( &MemInfo );
  regs.x.edi = FP_OFF( &MemInfo );
  int386x( DPMI_INT, &regs, &regs, &sregs );
  return MemInfo.LargestBlockAvail;
}

/*=======================================*/
/* Detect MMX                            */
/* Taken from AMD manual for MMX chipset */
/* Returns TRUE or FALSE                 */
/* Used in emulator startup, under other */
/* OSes there may be nicer ways to find  */
/* MMX.                                  */
/*=======================================*/

BOOLE dmmx(void);
#pragma aux dmmx=\
  "       pushad",\
  "       pushfd",\
  "       pop     eax",\
  "       mov     ebx,eax",\
  "       xor     eax,00200000h",\
  "       push    eax",\
  "       popfd",\
  "       pushfd",\
  "       pop     eax",\
  "       cmp     eax,ebx",\
  "       jz      no_mmx",\
  "       mov     eax,1",\
  "       cpuid",\
  "       test    edx,0800000h",\
  "       jz      no_mmx",\
  "       popad",\
  "       mov     eax,1",\
  "       jmp     outt",\
  "no_mmx:popad",\
  "       xor     eax,eax",\
  "outt:";

BOOLE detect_mmx(void) {return dmmx();};
  
/*====================================*/
/* Lock and unlock pages used in irqs */
/* Taken from a Watcom example        */
/*====================================*/

BOOLE lock_region (void *address, unsigned length) {
  union REGS regs;
  unsigned linear;
  linear = (unsigned) address;
  regs.w.ax = 0x600;
  regs.w.bx = (linear >> 16);
  regs.w.cx = (linear & 0xFFFF);
  regs.w.si = (length >> 16);
  regs.w.di = (length & 0xFFFF);
  int386 (0x31, &regs, &regs);
  return (!regs.w.cflag);
}

BOOLE unlock_region (void *address, unsigned length) {
  union REGS regs;
  unsigned linear;

  linear = (unsigned) address;
  regs.w.ax = 0x601;
  regs.w.bx = (linear >> 16);
  regs.w.cx = (linear & 0xFFFF);
  regs.w.si = (length >> 16);
  regs.w.di = (length & 0xFFFF);
  int386 (0x31, &regs, &regs);
  return (! regs.w.cflag);
}


/*========================================================================*/
/* Functions to find startup current dir, and the fellow installation dir */
/* Will set current dir to fellow instllation dir and on emulator exit    */
/* Restore them                                                           */
/*========================================================================*/

void various_resolve_original_paths(STR *s) {
  LON i;
  STR str[256];

  _fullpath(str, s, 256);
  
  /* Get home-directory of fellow.exe */
  
  strcpy(fellow_homedir, str);
  i = strlen(fellow_homedir) - 1;
  while ((i > 0) && (fellow_homedir[i] != '\\')) i--;
  fellow_homedir[i] = '\0';
  if (fellow_homedir[2] != '\\') {
    fellow_homedir[2] = '\\';
    fellow_homedir[3] = '\0';
  }

  /* Get directory fellow.exe was started in */

  getcwd(fellow_startdir, 256);

  /* Get original path for the drive fellow.exe resides on */

  _dos_setdrive(toupper(fellow_homedir[0]) - 'A' + 1, &i);
  getcwd(fellow_homeoriginaldir, 256);
  
  /* Set fellow_homedir as path */

  chdir(fellow_homedir);
}

void various_switch_to_startdir(void) {
  LON i;

  /* Restore path on drive that contains fellow.exe */

  _dos_setdrive(toupper(fellow_homedir[0]) - 'A' + 1, &i);
  chdir(fellow_homeoriginaldir);

  /* Change to drive of the directory fellow was started in and restore path */

  _dos_setdrive(toupper(fellow_startdir[0]) - 'A' + 1, &i);
  chdir(fellow_startdir);
}

void various_switch_to_homedir(void) {
  LON i;

  _dos_setdrive(toupper(fellow_homedir[0]) - 'A' + 1, &i);
  chdir(fellow_homedir);
}

/*==========================================================================*/
/* Access to files happens relative to the fellow homedirectory if the file */
/* is on the same drive                                                     */
/*==========================================================================*/

void various_decompose_path(STR *decomposed[], STR *str) {
  LON i = 3, until = 3, j = 0;
  BOOLE ended = FALSE;

  if (str[i] == '\0') decomposed[0] = NULL;
  else {
    while (!ended) {
      decomposed[j] = &str[i];
      while (str[until] != '\0' && str[until] != '\\') until++;
      if (str[until] == '\0') ended = TRUE;
      else str[until] = '\0';
      until++;
      j++;
      i = until;
    }
    decomposed[j] = NULL;
  }
}
  
/*===================================================================*/
/* How this works:                                                   */
/* As long as hpath and npath is the same, call recursively with one */
/* element less in the path arrays                                   */
/* then build relative path from remaining elements                  */
/*===================================================================*/

void various_build_relative_path(STR *hpath[], STR *npath[], STR *buf) {
  if (hpath[0] == NULL) { /* Bottom of hpath, name is below home */
    LON i = 0;
    while (npath[i] != NULL) {
      strcat(buf, npath[i]);
      i++;
      if (npath[i] != NULL) strcat(buf, "\\");
    }
  }
  else if (stricmp(hpath[0], npath[0]) == 0) /* path element same, take away */
    various_build_relative_path(&hpath[1], &npath[1], buf);
  else {
    /* Path no longer the same, add .. for each hpath left, and add */
    /* remaining part of npath */
    LON i = 0;

    while (hpath[i++] != NULL) strcat(buf, "..\\");
    i = 0;
    while (npath[i] != NULL) {
      strcat(buf, npath[i]);
      i++;
      if (npath[i] != NULL) strcat(buf, "\\");
    }
  }
}

void various_make_relative_path(STR *name) {
  LON i, ups, tmppos, goon;
  static STR tmpname[256];
  static STR tmphome[256];
  static STR *homedecomposed[128];
  static STR *namedecomposed[128];
  
  /* Expand to full path */

  _fullpath(tmpname, name, 256);
  
  /* Check drive-letter */

  if (toupper(tmpname[0]) != toupper(fellow_homedir[0])) {

    /* File is on a different drive, don't modify */

    strcpy(name, tmpname);
    return;
  }
 
  strcpy(tmphome, fellow_homedir);
  various_decompose_path(homedecomposed, tmphome);
  various_decompose_path(namedecomposed, tmpname);

  i = 0;
  while (homedecomposed[i] != NULL) i++;

  i = 0;
  while (namedecomposed[i] != NULL) i++;

  name[0] = '\0';
  various_build_relative_path(homedecomposed, namedecomposed, name);
  
  return;
}  


/*================*/
/* TEMP file path */
/*================*/

STR *tmppath;

void variousTMPPathInit(void) {
  tmppath = getenv("TMP");
  if (tmppath == NULL)
    tmppath = getenv("TEMP");
}


