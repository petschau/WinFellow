/*=========================*/
/* Fellow Amiga Emulator   */
/* Console library wrapper */
/* (C) 1998 Petter Schau   */
/*=========================*/

#include <stdio.h>
#include <graph.h>

#include "defs.h"


#ifdef USE_GUI

/*====================================================================*/
/* Replace code in these functions to use a different console library */
/* for the GUI.                                                       */
/* Colors, keycodes are defined in console.h                          */
/* If the console library does not support colors, set them to a      */
/* default value and simply ignore them here                          */
/* Character values to use for borders are defined in console.h       */
/* Some console libraries may not have nice characters for borders    */
/* Then they can be set to space or something                         */
/*====================================================================*/


/*====================*/
/* Console dimensions */
/*====================*/

ULO con_maxcols, con_maxrows;


/*===================*/
/* Generic text-plot */
/*===================*/

void conTextPlot(STR *text, ULO x, ULO y, ULO fgcolor, ULO bgcolor) {
  _settextposition(y, x);
  _settextcolor(fgcolor);
  _setbkcolor(bgcolor);
  _outtext(text);
}


/*=================*/
/* Clear rectangle */
/*=================*/

void conRectFill(ULO x, ULO y, ULO width, ULO height, ULO color, STR *cspc) {
  ULO i, j = y + height;
  STR *spcline = cspc + con_maxcols - width;

  _setbkcolor(color);
  for (i = y; i < j; i++) {
    _settextposition(i, x);
    _outtext(spcline);
    }
}


/*==============*/
/* Read one key */
/*==============*/

ULO conKeyGet(void) {
  ULO c;

  c = getch();
  if (c == 0)
    c = getch() + 256;
  return c;
}


/*========================*/
/* Prepare screen for use */
/*========================*/

void conScreenSetup(void) {
  _setvideomode(_TEXTC80);
  _displaycursor(_GCURSOROFF);
  _wrapon(_GWRAPOFF);
  con_maxcols = 80;
  con_maxrows = 25;
}


/*===================*/
/* Shut down console */
/*===================*/

void conScreenClose(void) {
  _setvideomode(_TEXTC80);
  _displaycursor(_GCURSORON);
  _wrapon(_GWRAPON);
}

#endif /* USE_GUI */
