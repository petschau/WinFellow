/*================================*/
/* Fellow Amiga Emulator          */
/* Routines to play sound through */
/* the MIDAS sound driver system  */
/* (C) 1998 Petter Schau 1998     */
/*================================*/


#include "midasdll.h"
#include <stdio.h>
#include <dos.h>
#include <stdlib.h>
#include <conio.h>
#include "defs.h"
#include "led.h"
#include "listtree.h"
#include "sound.h"
#include "memory.h"
#include "keyboard.h"
#include "draw.h"
#include "sblasta.h"            /* Symbols defined in sblasta.asm */
#include "fmidas.h"

#ifdef SOUNDDRV_MIDAS

UBY *auddmaptr;                /* pointer to dma buffer */
ULO playbuffer, editbuffer;     /* Doublebuffered sound, 0 or 1 */

ULO emuspeed;
ULO sbxpos,sbypos,sbframe;

ULO MyRateTable[4] = {15650, 22050, 31300, 44100};
ULO MyMixModeTable[4] = {MIDAS_SAMPLE_8BIT_MONO,  MIDAS_SAMPLE_8BIT_STEREO,
			 MIDAS_SAMPLE_16BIT_MONO, MIDAS_SAMPLE_16BIT_STEREO};
ULO MyOutModeTable[4] = {MIDAS_MODE_8BIT_MONO,  MIDAS_MODE_8BIT_STEREO,
			 MIDAS_MODE_16BIT_MONO, MIDAS_MODE_16BIT_STEREO};
ULO MyRate;
ULO MyBits16;
ULO MyStereo;
ULO MyRealBufferLength;
ULO MyMixMode;
ULO MyOutMode;
MIDASstreamHandle MyStreamHandle;
UBY MyBuffer[80000];
BOOLE MyChannelsOpened;
BOOLE MyStreamOpened;

void fMIDASBeforePlayInit(void);
void fMIDASAfterPlayUnInit(void);


static void fMIDASStartPlayingBuffer(void) {
  MIDASfeedStreamData(MyStreamHandle, MyBuffer, MyRealBufferLength, TRUE);
}

/*=========================*/
/* Clear the sound-buffers */
/*=========================*/

static void fMIDASClearBuffer(void) {
  ULO i;

  if (config_soundcard_found)
    for (i = 0; i < 40000; i++) MyBuffer[i] = 0;
}

/*===================================*/
/* Test irq, switch buffers and play */
/*===================================*/

static void fMIDASPlay(void) {
  auddmaptr = MyBuffer;
  fMIDASStartPlayingBuffer();
}

void fMIDASTestAndPlay(void) {
  fMIDASPlay();
}

/*======================================*/
/* Called before emulation is started   */
/*======================================*/

void fMIDASBeforeEmu(void) {
  fMIDASClearBuffer();
  fMIDASModeSetup(config_sound_bits, config_sound_channels, config_sound_rate);
  fMIDASBeforePlayInit();
  MIDASsetStreamVolume(MyStreamHandle, 64);
}

/*===================================*/
/* Called after emulation is stopped */
/*===================================*/

void fMIDASAfterEmu(void) {
  MIDASsetStreamVolume(MyStreamHandle, 0);
  fMIDASAfterPlayUnInit();
}


/*==========================================================*/
/* Install various callbacks in the central sound-emulation */
/*==========================================================*/

static void fMIDASSetGlobalCallbacks(void) {
  ULO bits, channels, rate;
  
  /* Install callback for playing a buffer */

  sound_playbuffer = fMIDASTestAndPlay;

  /* Install callbacks for before and after emulation setup */

  sound_before_emu = fMIDASBeforeEmu;
  sound_after_emu = fMIDASAfterEmu;
  soundDevModeSetCallback = fMIDASModeSetup;

  /* Set add sample to buffer routines */
  
  soundDevSampleAddCallback[SOUND_8BITS][SOUND_MONO] = sb_8bit_mono_put_in_buffer;
  soundDevSampleAddCallback[SOUND_8BITS][SOUND_STEREO] = sb_8bit_stereo_put_in_buffer;
  soundDevSampleAddCallback[SOUND_16BITS][SOUND_MONO] = sb_16bit_mono_put_in_buffer;
  soundDevSampleAddCallback[SOUND_16BITS][SOUND_STEREO] = sb_16bit_stereo_put_in_buffer;
}

/*=======================================================*/
/* Returns the frequency to use in the period-table      */
/*=======================================================*/

ULO fMIDASModeSetup(ULO bits, ULO channels, ULO rate) {
  ULO mode;
  fMIDASSetGlobalCallbacks();
  auddmaptr = MyBuffer;
  MyStereo = config_sound_channels;
  MyBits16 = config_sound_bits;
  mode = (MyStereo) ? 1 : 0;
  mode |= (MyBits16) ? 2 : 0;
  MyRate = MyRateTable[config_sound_rate];
  MyMixMode = MyMixModeTable[mode];
  MyOutMode = MyOutModeTable[mode];
  MyRealBufferLength =
    (sound_buffer_depth*MyRate*(MyStereo + 1)*(MyBits16 + 1))/50;
  return MyRate;
}

/*======================================*/
/* MIDAS before playback initialization */
/*======================================*/

void fMIDASBeforePlayInit(void) {
//  MIDASstartup();
  /*  MIDASsetOption(MIDAS_OPTION_MIXRATE, MyRate);
  MIDASsetOption(MIDAS_OPTION_OUTPUTMODE, MyOutMode);
  MIDASsetOption(MIDAS_OPTION_MIXING_MODE, MIDAS_MIX_NORMAL_QUALITY);
  */
  MIDASinit();
  MIDASopenChannels(1);
  MyChannelsOpened = TRUE;
  MyStreamHandle = MIDASplayStreamPolling(MyMixMode, MyRate,
					  20*2*sound_buffer_depth);
  MyStreamOpened = TRUE;
}

/*=======================================*/
/* MIDAS after playback uninitialization */
/*=======================================*/

void fMIDASAfterPlayUnInit(void) {
  if (MyStreamOpened) {
    MIDASstopStream(MyStreamHandle);
    MyStreamOpened = FALSE;
  }
  if (MyChannelsOpened) {
    MIDAScloseChannels();
    MyChannelsOpened = FALSE;
  }
//  MIDASclose();
}


/*====================*/
/* Run config utility */
/*====================*/

void fMIDASConfigRun(void) {
  MIDASclose();
  MIDASstartup();
  MIDASconfig();
  MIDASinit();
}


/*==========================*/
/* Top level initialization */
/*==========================*/

void fMIDASStartup(void) {
  BOOLE i;
  STR s[80];

  MyChannelsOpened = FALSE;
  MyStreamOpened = FALSE;
  config_soundcard_found = FALSE;
  i = MIDASstartup();

  if (MIDASdetectSoundCard()) {
    config_soundcard_found = TRUE;
    MyStreamHandle = 0;
    fMIDASSetGlobalCallbacks();
//    MIDASclose();
  }   
}

void fMIDASShutdown(void) {
  MIDASclose();
}

#endif
