/*==============================*/
/* Fellow Amiga Emulator        */
/* Initialization of 68000 core */
/* (C) 1994-1998 Petter Schau   */
/*           and Roman Dolejsi  */
/*==============================*/


/* 680X0 specifc code is in 680x0ini.c files, and called from */
/* this file when that cpu is selected. */

#include <stdio.h>
#include "defs.h"
#include "fellow.h"
#include "memory.h"
#include "68000ini.h"
#include "68000.h"
#include "68000dis.h"

int usenew_add  = FALSE;
int usenew_adda = FALSE;
int usenew_addi = FALSE;
int usenew_bcc  = FALSE;
int usenew_bit  = FALSE;
int usenew_clr  = FALSE;
int usenew_move = FALSE;


void i01_1();
void i01_2();
void i64_1();
void i64_2();


ULO cpugentab[1][1];/* [65536][4]; */
ULO cpu_dis_tab[65536];

/* Opcode data table */

ULO t[65536][8];

/* M68k registers */

ULO pc, usp, ssp, sr;
ULO ccr0, ccr1;

#ifdef PREFETCH

ULO prefetch_word;

#endif

/* Cycles spent by chips (Blitter) as a result of an instruction */

ULO thiscycle;

/* BCD number translation tables */

UBY bcd2hex[256], hex2bcd[256];

/* Cycle count calculation for MULX, only approximately, but who cares? */

UBY mulutab[256], mulstab[256];

/* Irq raise table */

UBY irq_table[0x20000];

#ifdef PC_PTR

/* pc-pcbaseadr gives actual PC-value when PC is a pointer to memory */

ULO pcbaseadr;

#endif

/* CPU configuration:   */
/* speed: 0 -  3.57 mhz */
/* ------ 1 -  7.14 mhz */
/*        2 - 14.28 mhz */
/*        3 - 28.56 mhz */
/*        4 - All operations take 1 bus-clock */
/* type:  0 - 68000 */
/* -----  1 - 68010 */
/*        2 - 68020 */
/*        3 - 68030 */
/*        etc...    */

ULO config_cpu_speed, config_cpu_type;

/* irq management */

ULO interruptlevel = 0;
ULO interruptaddress = 0;
ULO interruptflag = 0;
ULO irq_changed;

/* Event cycle time */

ULO cpu_next, irq_next;

/* intreq bit-number to irq-level translation table */

ULO int2int[16] = {1, 1, 1, 2, 3, 3, 3, 4, 4, 4, 4, 5, 5, 6, 6, 7};

/* Flag set if CPU is stopped */

ULO cpustopflag = FALSE;

/* Hacks to "simplify" exceptions */

ULO exceptionstack;
ULO exceptionbackdooraddress;
ULO stopreturnadr;

/* Truth table Variables GE True when 0X0X or 1X1X */

UBY ccctt[16] = {1, 1, 0, 0, 1, 1, 0, 0, 0, 0, 1, 1, 0, 0, 1, 1};

/* Truth table Variables LT True when 0X1X or 1X0X */

UBY ccdtt[16] = {0, 0, 1, 1, 0, 0, 1, 1, 1, 1, 0, 0, 1, 1, 0, 0};

/* Truth table Variables GT True when 000X or 101X */

UBY ccett[16] = {1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 0, 0, 0, 0};

/* Truth table Variables LE True when X1XX 1X0X or 0X1X */

UBY ccftt[16] = {0, 0, 1, 1, 1, 1, 1, 1, 1, 1, 0, 0, 1, 1, 1, 1};

/* Tables of pointers to ea calculation routines        */
/* These are used when initializing the opcode tables   */
/* and must be initialized first with pointers to the   */
/* routines for the selected cpu                        */

eareadfunc arb[12], arw[12], arl[12], parb[12], parw[12], parl[12];
eawritefunc awb[12], aww[12], awl[12];
eacalcfunc eac[12];

/* Tables of pointers to ea calculation routines */
/* These are for 68000 emulation opcode tables   */
/* Higher cpu emulation must provide 680x0 versions */

eareadfunc arb68000[12] = {arb00, NULL, arb02, arb03, arb04, arb05, arb06,
                           arb70, arb71, arb72, arb73, arb74};
eareadfunc arw68000[12] = {arw00, arw01, arw02, arw03, arw04, arw05, arw06,
                           arw70, arw71, arw72, arw73, arw74};
eareadfunc arl68000[12] = {arl00, arl01, arl02, arl03, arl04, arl05, arl06,
                           arl70, arl71, arl72, arl73, arl74};
eareadfunc parb68000[12] = {arb00, NULL, arb02, parb03, parb04, parb05,
                            parb06, parb70, parb71, parb72, parb73, parb74};
eareadfunc parw68000[12] = {arw00, arw01, arw02, parw03, parw04, parw05,
                            parw06, parw70, parw71, parw72, parw73, parw74};
eareadfunc parl68000[12] = {arl00, arl01, arl02, parl03, parl04, parl05,
                            parl06, parl70, parl71, parl72, parl73, parl74};
eawritefunc awb68000[12] = {awb00, NULL, awb02, awb03, awb04, awb05, awb06,
                            awb70, awb71};
eawritefunc aww68000[12] = {aww00, aww01, aww02, aww03, aww04, aww05, aww06,
                            aww70, aww71};
eawritefunc awl68000[12] = {awl00, awl01, awl02, awl03, awl04, awl05, awl06,
                            awl70, awl71};
eacalcfunc eac68000[12] = {NULL, NULL, eac02, NULL, NULL, eac05, eac06, eac70,
                           eac71, eac72, eac73, NULL};


/* Tables for cycle count calculation for each addressmode */
/* Must be initialized first by values appropriate for the selected cpu */

UBY tarb[12], tarw[12], tarl[12];

/* Tables for address mode cycle counts, 68000 */
/* These values are moved to tarX arrays when 68000 is selected */

const UBY tarb68000[12] = {0, 0, 4, 4, 6, 8, 10, 8, 12, 8, 10, 4};
const UBY tarw68000[12] = {0, 0, 4, 4, 6, 8, 10, 8, 12, 8, 10, 4};
const UBY tarl68000[12] = {0, 0, 8, 8, 10, 12, 14, 12, 16, 12, 14, 8};

/* Address modes included in the different classes */

const UBY allmodes[16]  = {1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0, 0, 0, 0};
const UBY data[16]      = {1, 0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0, 0, 0, 0};
const UBY memory[16]    = {0, 0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0, 0, 0, 0};
const UBY control[16]   = {0, 0, 1, 0, 0, 1, 1, 1, 1, 1, 1, 0, 0, 0, 0, 0};
const UBY alterable[16] = {1, 1, 1, 1, 1, 1, 1, 1, 1, 0, 0, 0, 0, 0, 0, 0};

/* Exception stack frame jmptables */

cpuStackFrameFunc cpu_stack_frame_gen[64];

/* Intel EFLAGS to 68k SR translation */

ULO statustab[4096];

#ifdef PC_PTR

/* PC entered unmapped memory */

#pragma aux cpu_pc_in_unmapped_mem parm [eax] [ebx] [ecx] [edx]
void cpu_pc_in_unmapped_mem(ULO rax, ULO rbx, ULO rcx, ULO rdx) {
  fellow_runtime_error_code = FELLOW_RUNTIME_ERROR_CPU_PC_BAD_BANK;
  fellow_nasty_exit();
}

#endif

#ifdef CPU_TRACE_TO_FILE

void cpu_trace_to_file_reset(void) {
  FILE *F;

  F = fopen("trace.cpu","w");
  fclose(F);
}

void cpu_trace_to_file(void) {
  static char str[160];
  FILE *F;

  if (pc == 0xfa43f2) { /* Lock */
    if ((F = fopen("trace.cpu","a"))) {
      fprintf(F, "Lock: %s\n", address_to_ptr(d[1]));
      fclose(F);
    }
  }
  else if (pc == 0xfa438c) { /* ExNext */
    if ((F = fopen("trace.cpu","a"))) {
      fprintf(F, "ExNext:\n");
      fclose(F);
    }
  }
}

#endif


/*============================*/
/* Extract fields from opcode */
/*============================*/

ULO get_smod(ULO opc) {
  return (opc & SMOD)>>3;
}

ULO get_sreg(ULO opc) {
  return (opc & SREG);
}

ULO get_dmod(ULO opc) {
  return (opc & DMOD)>>6;
}

ULO get_dreg(ULO opc) {
  return (opc & DREG)>>9;
}

STR *btab[16] = {"RA", "SR", "HI", "LS", "CC", "CS", "NE", "EQ", "VC", "VS",
		 "PL", "MI", "GE", "LT", "GT", "LE"};

ULO get_branchtype(ULO opc) {
  return (opc & BTYPE)>>8;
}

ULO get_bit3(ULO opc) {
  return !!(opc & BIT3);
}

ULO get_bit5(ULO opc) {
  return !!(opc & BIT5);
}

ULO get_bit6(ULO opc) {
  return !!(opc & BIT6);
}

ULO get_bit8(ULO opc) {
  return !!(opc & BIT8);
}

ULO get_bit10(ULO opc) {
  return !!(opc & BIT10);
}

ULO get_bit12(ULO opc) {
  return !!(opc & BIT12);
}

/* Size: bits 6 and 7, 00 - byte, 01 - word, 10 - long, returns 8,16,32 */
/* 64 used to determine memory shifts */

ULO get_size(ULO opc) {
  if ((opc & SIZE) == 0) return 8;
  else if ((opc & SIZE) == 0x40) return 16;
  else if ((opc & SIZE) == 0x80) return 32;
  else return 64;
}

/* Size: bit 8 - 0 - word, 1 - long */

ULO get_size2(ULO opc) {
  if ((opc & BIT8) == 0) return 16;
  else return 32;
}

/* Size: bits 12 and 13, 01 - byte, 11 - word, 10 - long, returns 8,16,32 */

ULO get_size3(ULO opc) {
  if ((opc & 0x3000) == 0x1000) return 8;
  else if ((opc & 0x3000) == 0x3000) return 16;
  else return 32;
}

/* Size: bits 10 and 9, 01 - byte, 10 - word, 11 - long, returns 8,16,32 */

ULO get_size4(ULO opc) {
  if ((opc & 0x600) == 0x200) return 8;
  else if ((opc & 0x600) == 0x400) return 16;
  else return 32;
}

char sizec(ULO size) {
  return (size == 8) ? 'B' : ((size == 16) ? 'W' : 'L');
}

/* Add regs to mode if mode is 7 */

ULO modreg(ULO modes, ULO regs) {
  return (modes != 7) ? modes : (modes + regs);
}

/* Return register ptr for mode */

ULO greg(ULO mode, ULO reg) {return reg*4 + (ULO) ((mode == 0) ? d:a);}

/*=============================*/
/* Common disassembly routines */
/*=============================*/

/* Common disassembly for BCHG, BCLR, BSET, BTST */

ULO btXtrans[4] = {3, 0, 1, 2};

ULO btXdis(ULO prc, ULO opc, STR *st) {
  ULO pos = 18 - (5*get_bit8(opc)), reg = get_sreg(opc),
      bitreg = get_dreg(opc), mode = get_smod(opc), sizech,
      nr = btXtrans[(opc >> 6) & 3];
  STR *bnr[4] = {"CHG","CLR","SET","TST"};
  mode = modreg(mode, reg);
  sizech = (mode == 0) ? 'L' : 'B'; 
  if (pos == 18) {
    sprintf(st, "$%.6X %.4X %.4X              B%s.%c  #$%.4X,", prc, opc,
	    fetw(prc + 2), bnr[nr], sizech,
	    fetw(prc + 2) & ((mode == 0) ? 0x1f : 7));
    prc += 2;
    }
  else sprintf(st, "$%.6X %.4X                   B%s.%c  D%1X,", prc, opc,
               bnr[nr], sizech, bitreg);
  prc = disAdrMode(reg, prc + 2, st, 8, mode, &pos);  
  return prc;
}

/* Common disassembly for ADD, SUB, CMP, AND, EOR, OR */

STR *anr[6] = {"ADD","SUB","CMP","AND","EOR","OR"};

ULO arith1dis(ULO prc, ULO opc, STR *st, int nr) {
  ULO pos = 13, reg = get_sreg(opc), dreg = get_dreg(opc), o = get_bit8(opc),
      size = get_size(opc), mode = get_smod(opc);

  mode = modreg(mode, reg);
  sprintf(st, "$%.6X %.4X                   %s.%c   ", prc, opc, anr[nr],
	  sizec(size));
  if (nr == 5) strcat(st, " ");
  prc = (!o) ? disAdrMode(reg, prc + 2, st, size, mode, &pos) :
               disAdrMode(dreg, prc + 2, st, size, 0, &pos);
  strcat(st, ",");
  prc = (o) ? disAdrMode(reg, prc, st, size, mode, &pos) :
              disAdrMode(dreg, prc, st, size, 0, &pos);
  return prc;
}

/* Common disassembly for ADDA, SUBA, CMPA */

ULO arith2dis(ULO prc, ULO opc, STR *st, int nr) {
  ULO pos = 13, reg = get_sreg(opc),dreg = get_dreg(opc), mode = get_smod(opc),
      size = get_size2(opc);
  
  mode = modreg(mode, reg);
  sprintf(st, "$%.6X %.4X                   %sA.%c  ", prc, opc, anr[nr],
	  sizec(size));
  prc = disAdrMode(reg, prc + 2, st, size, mode, &pos);
  strcat(st, ",");
  disAdrMode(dreg, prc, st, size, 1, &pos);
  return prc;
}

/* Common disassembly for ADDI, SUBI, CMPI, ANDI, EORI, ORI */

ULO arith3dis(ULO prc, ULO opc, STR *st, int nr) {
  ULO pos = 13, reg = get_sreg(opc), mode = get_smod(opc),
      size = get_size(opc);
  mode = modreg(mode, reg);
  sprintf(st, "$%.6X %.4X                   %sI.%c  ", prc, opc, anr[nr],
	  sizec(size));
  if (nr == 5) strcat(st, " ");
  prc = disAdrMode(4, prc + 2, st, size, 11, &pos);
  strcat(st, ",");
  if ((nr > 2) && (mode == 11)) strcat(st, (size == 8) ? "CCR" : "SR");
  else prc = disAdrMode(reg, prc, st, size, mode, &pos);
  return prc;
}

/* Common disassembly for ADDQ, SUBQ */

ULO arith4dis(ULO prc, ULO opc, STR *st, int nr) {
  ULO pos = 13, reg = get_sreg(opc), mode = get_smod(opc),
      size = get_size(opc);
  mode = modreg(mode, reg);
  sprintf(st, "$%.6X %.4X                   %sQ.%c  #$%.1d,", prc, opc,
	  anr[nr], sizec(size), t[opc][6]);
  prc = disAdrMode(reg, prc + 2, st, size, mode, &pos);
  return prc;
}

/* Common disassembly for ADDX, SUBX, ABCD, SBCD, CMPM */

STR *a5nr[5] = {"ADDX","SUBX","ABCD","SBCD","CMPM"};

ULO arith5dis(ULO prc, ULO opc, STR *st, int nr) {
  STR *minus = (nr == 4) ? "" : "-";
  STR *plus = (nr == 4) ? "+" : "";

  if (!get_bit3(opc)) minus = plus = "";
  
  sprintf(st, ((!get_bit3(opc)) ?
                "$%.6X %.4X                   %s.%c  %sD%d%s,%sD%d%s":
                "$%.6X %.4X                   %s.%c  %s(A%d)%s,%s(A%d)%s"),
          prc, opc, a5nr[nr], sizec(get_size(opc)), minus, get_sreg(opc),
	  plus, minus, get_dreg(opc), plus);
  return prc + 2;
}

/* Common disassembly for ASX, LSX, ROX, ROXX */

STR *shnr[4] = {"AS","LS","RO","ROX"};

ULO shiftdis(ULO prc, ULO opc, STR *st, int nr) {
  ULO pos = 13, reg = get_sreg(opc), mode = get_smod(opc),
      size = get_size(opc);
  char rl = (get_bit8(opc)) ? 'L' : 'R';
  STR *spaces = (nr < 3) ? "  " : " ";

  mode = modreg(mode, reg);
  if (size == 64) {
    sprintf(st, "$%.6X %.4X                   %s%c.W%s #$1,", prc, opc,
	    shnr[nr], rl, spaces);
    prc = disAdrMode(reg, prc + 2, st, 16, mode, &pos);
    }
  else {
    char sc = sizec(size);
    if (!get_bit5(opc))
      sprintf(st, "$%.6X %.4X                   %s%c.%c%s #$%1X,D%1d", prc,
	      opc, shnr[nr], rl, sc, spaces, t[opc][2], reg);
    else  
      sprintf(st, "$%.6X %.4X                   %s%c.%c%s D%1d,D%1d", prc, opc,
	      shnr[nr],rl, sc, spaces, get_dreg(opc), reg);
    prc += 2;
    }
  return prc;
}

/* Common disassembly for CLR, NEG, NOT, TST, JMP, JSR, PEA, NBCD, NEGX */

STR *unanr[10] = {"CLR","NEG","NOT","TST","JMP","JSR","PEA","TAS", "NCBD",
		   "NEGX"};

ULO unarydis(ULO prc, ULO opc, STR *st, int nr) {
  ULO pos = 13, reg = get_sreg(opc), mode = get_smod(opc),
      size = get_size(opc);
  char dot, sizech;
  STR *spaces = (nr > 7) ? " " : "  ";
  mode = modreg(mode, reg);
  if (nr < 4 || nr > 7) {
    dot = '.';
    sizech = sizec(size);
  }
  else dot = sizech = ' ';
  sprintf(st, "$%.6X %.4X                   %s%c%c%s ", prc, opc, unanr[nr],
	  dot, sizech, spaces);
  prc = disAdrMode(reg, prc + 2, st, size, mode, &pos);
  return prc;
}

/* Common disassembly for NOP, RESET, RTE, RTR, RTS, TRAPV */

STR *singnr[6] = {"NOP","RESET","RTE","RTR","RTS","TRAPV"};

ULO singledis(ULO prc, ULO opc, STR *st, int nr) {
  sprintf(st,"$%.6X %.4X                   %s", prc, opc, singnr[nr]);  
  return prc + 2;
}

/* Common disassembly for CHK, DIVS, DIVU, LEA, MULS, MULU */

STR *var1nr[6] = {"CHK","DIVS","DIVU","LEA","MULS","MULU"};

ULO various1dis(ULO prc, ULO opc, STR *st, int nr) {
  ULO pos = 13, reg = get_sreg(opc), dreg = get_dreg(opc),
      mode = get_smod(opc);
  mode = modreg(mode, reg);
  sprintf(st, "$%.6X %.4X                   %s.%s  ", prc, opc, var1nr[nr],
	  (nr == 3) ? "L ":"W");
  prc = disAdrMode(reg, prc + 2, st, 16, mode, &pos);
  strcat(st, ",");
  disAdrMode(dreg, prc, st, 16, (nr != 3) ? 0 : 1, &pos);  
  return prc;
}

/* Common disassembly for SWAP, UNLK */

STR *var2nr[2] = {"SWAP","UNLK"};

ULO various2dis(ULO prc, ULO opc, STR *st, int nr) {
  char regtype = (nr == 0) ? 'D' : 'A';
  sprintf(st, "$%.6X %.4X                   %s    %c%1X", prc, opc, var2nr[nr],
	  regtype, get_sreg(opc));  
  return prc+2;
}

/*  Illegal instruction */

ULO i00dis(ULO prc, ULO opc, STR *st) {
  sprintf(st, "$%.6X %.4X                   ILLEGAL INSTRUCTION", prc, opc);
  return prc + 2;
}

/* Instruction ABCD.B Ry,Rx / ABCD.B -(Ay),-(Ax)
   Table: 0 - Routinepointer 1 - Rx*4(dest) 2 - Ry*4 */

ULO i01dis(ULO prc, ULO opc, STR *st) {
  return arith5dis(prc, opc, st, 2);
}

void i01ini(void) {
  ULO op = 0xc100, ind, rm, rx, ry;

  for (rm = 0; rm < 2; rm++) 
    for (rx = 0; rx < 8; rx++) 
      for (ry = 0; ry < 8; ry++) {
        ind = op | ry | rx<<9 | rm<<3;
        t[ind][0] = (rm == 0) ? (ULO) i01_1 : (ULO) i01_2;
        cpu_dis_tab[ind] = (ULO) i01dis;
        t[ind][1] = greg(rm, rx);
        t[ind][2] = greg(rm, ry);
        }
}

/* Instruction ADD.X <ea>,Dn / ADD.X Dn,<ea>
   Table:
   Type 1:  add <ea>,Dn
     0-Routinepointer 1-disasm routine  2-sourreg 3-sourceroutine
                      4-Dreg        5-cycle count                   
   Type 2:  add Dn,<ea>
     0-Routinepointer 1-disasm routine  2-<ea>reg 3-get <ea> routine
                      4-Dreg        5-cycle count   6-write<ea> routine */

ULO i02dis(ULO prc, ULO opc, STR *st) {
  return arith1dis(prc, opc, st, 0);
}

void i02ini(void) {
  ULO op = 0xd000, ind, regd, modes, regs, flats, size, o;
  for (o = 0; o < 2; o++)
    for (size = 0; size < 3; size++)
      for (regd = 0; regd < 8; regd++) 
        for (modes = 0; modes < 8; modes++) 
          for (regs = 0; regs < 8; regs++) {
            flats = modreg(modes, regs);
            if ((o == 0 && size == 0 && data[flats]) ||
                (o == 0 && size != 0 && allmodes[flats]) ||
                (o == 1 && alterable[flats] && memory[flats])) {
              ind = op | regd<<9 | o<<8 | size<<6 | modes<<3 | regs;
              if (usenew_add && cpugentab[ind][0] != ((ULO) i00)) {
		t[ind][0] = cpugentab[ind][0];
		t[ind][1] = cpugentab[ind][1];
		t[ind][2] = cpugentab[ind][2];
		t[ind][3] = cpugentab[ind][3];
	      }
	      else if (usenew_add) printf("ADD opcode missing %X\n", ind);
	      else {
		t[ind][0] = (o == 0) ?
                             (size == 0) ?
                                (ULO) i02_B_1:
                                (size == 1) ?
                                   (ULO) i02_W_1:
                                   (ULO) i02_L_1:
                             (size == 0) ?
                                (ULO) i02_B_2:
                                (size == 1) ?
                                   (ULO) i02_W_2:
                                   (ULO) i02_L_2;
              t[ind][2] = greg(modes, regs);
              t[ind][3] = (ULO) ((o == 0) ?
                             (size == 0) ?
                                arb[flats]:
                                (size == 1) ?
                                   arw[flats]:
                                   arl[flats]:
                             (size == 0) ?
                                parb[flats]:
                                (size == 1) ?
                                   parw[flats]:
                                   parl[flats]);
              t[ind][4] = greg(0, regd);
              t[ind][5] = (o == 0) ?
                             (size == 0) ?
                                (4+tarb[flats]):
                                (size == 1) ?
                                   (4+tarw[flats]):
                                   (flats <= 1 || flats == 11) ?
                                      (8+tarl[flats]):
                                      (6+tarl[flats]):
                             (size == 0) ?
                                (8 + tarb[flats]):
                                (size == 1) ?
                                   (8 + tarw[flats]):
                                   (12 + tarl[flats]);
              if (o == 1) t[ind][6] = (ULO) ((size == 0) ?
                                         awb[flats]:
                                         (size == 1) ?
                                            aww[flats]:
                                            awl[flats]);
              }
              cpu_dis_tab[ind] = (ULO) i02dis;
	    }
            }
}

/* Instruction ADDA.W/L <ea>,An
   Table-usage:

   0-Routinepointer 1-disasm routine  2-sourreg 3-sourceroutine
                    4-Areg        5-cycle count                 */

ULO i03dis(ULO prc, ULO opc, STR *st) {
  return arith2dis(prc, opc, st, 0);
}

void i03ini(void) {
  ULO op = 0xd0c0, ind, regd, modes, regs, flats, o;
  for (o = 0; o < 2; o++)
    for (regd = 0; regd < 8; regd++) 
      for (modes = 0; modes < 8; modes++) 
        for (regs = 0; regs < 8; regs++) 
          if (allmodes[flats = modreg(modes, regs)]) {
            ind = op | regd<<9 | o<<8 | modes<<3 | regs;
	    if (usenew_adda && cpugentab[ind][0] != ((ULO) i00)) {
	      t[ind][0] = cpugentab[ind][0];
	      t[ind][1] = cpugentab[ind][1];
	      t[ind][2] = cpugentab[ind][2];
	      t[ind][3] = cpugentab[ind][3];
	    }
	    else if (usenew_adda) printf("ADDA opcode missing %X\n", ind);
	    else {
	      t[ind][0] = (o == 0) ? ((ULO) i03_W) : ((ULO) i03_L);
	      t[ind][2] = greg(modes, regs);
	      t[ind][3] = (ULO) ((o == 0) ? arw[flats] : arl[flats]);
	      t[ind][4] = greg(1, regd);
	      t[ind][5] = (o==0) ?
		(8 + tarw[flats]):
		(flats <= 1 || flats == 11) ?
		(8 + tarl[flats]):
		(6 + tarl[flats]);
	    }
	    cpu_dis_tab[ind] = (ULO) i03dis;
	  }
}

/* Instruction ADDI.X #i,<ea>
   Table-usage:

   0-Routinepointer 1-disasm routine  2-eareg 3-ea read routine
                    4-cycle count    5-ea write routine         */

ULO i04dis(ULO prc, ULO opc, STR *st) {
  return arith3dis(prc, opc, st, 0);
}

void i04ini(void) {
  ULO op=0x0600,ind,modes,regs,flats,size;
  for (size = 0; size < 3; size++)
    for (modes = 0; modes < 8; modes++) 
      for (regs = 0; regs < 8; regs++) {
        flats = modreg(modes, regs);
        if (data[flats] && alterable[flats]) {
          ind = op|size<<6|modes<<3|regs;
	  if (usenew_addi && cpugentab[ind][0] != ((ULO) i00)) {
	    t[ind][0] = cpugentab[ind][0];
	    t[ind][1] = cpugentab[ind][1];
	    t[ind][2] = cpugentab[ind][2];
	    t[ind][3] = cpugentab[ind][3];
	  }
	  else if (usenew_addi) printf("ADDI opcode missing %X\n", ind);
	  else {
	    t[ind][0] = (size == 0) ?
	      (ULO) i04_B:
	      (size == 1) ?
	      (ULO) i04_W:
	      (ULO) i04_L; 
	    t[ind][2] = greg(modes, regs);
	    t[ind][3] = (ULO) ((size == 0) ?
			       parb[flats]:
			       (size == 1) ?
			       parw[flats]:
			       parl[flats]);
	    t[ind][4] = (size == 0) ?
	      (flats == 0) ?
	      8:
	    (12 + tarb[flats]):
	      (size == 1)  ?
	      (flats == 0) ?
	      8:
	    (12 + tarw[flats]):
	      (flats == 0) ?
	      16:
	    (20 + tarl[flats]);
	    t[ind][5] = (ULO) ((size == 0) ?
			       awb[flats]:
			       (size == 1) ? 
			       aww[flats]:
			       awl[flats]);
          }
          cpu_dis_tab[ind] = (ULO) i04dis;
	}
      }
}

/* Instruction ADDQ.X #i,<ea>
   Table-usage:

   0-Routinepointer 1-disasm routine  2-eareg 3-ea read routine
                4-cycle count    5-ea write routine 6-add immediate */

ULO i05dis(ULO prc, ULO opc, STR *st) {
  return arith4dis(prc, opc, st, 0);
}

void i05ini(void) {
  ULO op = 0x5000, ind, imm, modes, regs, flats, size, o;
    for (size = 0; size < 3; size++)
      for (modes = 0; modes < 8; modes++) 
        for (regs = 0; regs < 8; regs++) 
          for (imm = 0; imm < 8; imm++) {
            flats = modreg(modes, regs);
            if ((size == 0 && alterable[flats] && modes != 1) ||
                (size != 0 && alterable[flats])) {
              ind = op | imm<<9 | size<<6 | modes<<3 | regs;
              if (modes == 1 && (size > 0)) t[ind][0] = (ULO) i05_ADR;
              else
                t[ind][0] = (ULO) ((size == 0) ? i05_B:
				   (size == 1) ? i05_W:i05_L);
              cpu_dis_tab[ind] = (ULO) i05dis;
              t[ind][2] = greg(modes, regs);
              t[ind][3] = (ULO)((size == 0) ?
                             parb[flats]:
                             (size == 1) ?
                                parw[flats]:
                                parl[flats]);
              t[ind][4] = (size == 0) ?
                             (flats == 0) ?
                                (4+tarb[flats]):
                                (8+tarb[flats]):
                             (size == 1) ?
                                (flats == 0) ?
                                   (4+tarw[flats]):
                                   (8+tarw[flats]):
                                (flats < 2) ?
                                   (8+tarl[flats]):
                                   (12+tarl[flats]);
              t[ind][5] = (ULO)((size == 0) ?
                             awb[flats]:
                             (size == 1) ?
                                aww[flats]:
                                awl[flats]);
              t[ind][6] = (imm == 0) ?
                             8:
                             imm;
              }
            }
}

/* Instruction ADDX.X Ry,Rx / ADD.X -(Ay),-(Ax)
   Table-usage: 0 -Routinepointer 1 - disasm routine 2 - Rx*4(dest) 3 - Ry*4 */

ULO i06dis(ULO prc, ULO opc, STR *st) {
  return arith5dis(prc, opc, st, 0);
}

void i06ini(void) {
  ULO op=0xd100, ind, rm, rx, ry, sz;
  for (sz = 0; sz <= 2; sz++)
    for (rm = 0; rm <= 1; rm++)
      for (rx = 0; rx <= 7; rx++) 
        for (ry = 0; ry <= 7; ry++) {
          ind = op | ry | rx<<9 | rm<<3 | sz<<6;
          t[ind][0] = (rm == 0) ?
                       ((sz == 0) ?
                          (ULO) i06_B_1:
                          (sz == 1) ?
                             (ULO) i06_W_1:
                             (ULO) i06_L_1):
                       ((sz == 0) ?
                          (ULO) i06_B_2:
                          (sz == 1) ?
                             (ULO) i06_W_2:
                             (ULO) i06_L_2);
        cpu_dis_tab[ind] = (ULO) i06dis;
        t[ind][2] = greg(rm, rx);
        t[ind][3] = greg(rm, ry);
        }
}

/* Instruction AND.X <ea>,Dn / AND.X Dn,<ea>
   Table-usage:
   Type 1:  and <ea>,Dn

     0-Routinepointer 1-disasm routine  2-sourreg 3-sourceroutine
                      4-Dreg        5-cycle count                   
   Type 2:  and Dn,<ea>

     0-Routinepointer 1-disasm routine  2-<ea>reg 3-get <ea> routine
                      4-Dreg        5-cycle count   6-write<ea> routine */

ULO i07dis(ULO prc, ULO opc, STR *st) {
  return arith1dis(prc, opc, st, 3);
}

void i07ini(void) {
  ULO op = 0xc000, ind, regd, modes, regs, flats, size, o;
  for (o = 0; o < 2; o++)
    for (size = 0; size < 3; size++)
      for (regd = 0; regd < 8; regd++) 
        for (modes = 0; modes < 8; modes++) 
          for (regs = 0; regs < 8; regs++) {
            flats = modreg(modes, regs);
            if ((o==0 && data[flats]) ||
                (o==1 && alterable[flats] && memory[flats])) {
              ind = op | regd<<9 | o<<8 | size<<6 | modes<<3 | regs;
	    if (usenew_add && cpugentab[ind][0] != ((ULO) i00)) {
	      t[ind][0] = cpugentab[ind][0];
	      t[ind][1] = cpugentab[ind][1];
	      t[ind][2] = cpugentab[ind][2];
	      t[ind][3] = cpugentab[ind][3];
	    }
	    else if (usenew_add) printf("AND opcode missing %X\n", ind);
	    else {
              t[ind][0] = (o == 0) ?
                             (size == 0) ?
                                (ULO) i07_B_1:
                                (size == 1) ?
                                   (ULO) i07_W_1:
                                   (ULO) i07_L_1:
                             (size == 0) ?
                                (ULO) i07_B_2:
                                (size == 1) ?
                                   (ULO) i07_W_2:
                                   (ULO) i07_L_2;
              t[ind][2] = greg(modes, regs);
              t[ind][3] = (ULO)((o == 0) ?
                             (size == 0) ?
                                arb[flats]:
                                (size == 1) ?
                                   arw[flats]:
                                   arl[flats]:
                             (size == 0) ?
                                parb[flats]:
                                (size == 1) ?
                                   parw[flats]:
                                   parl[flats]);
              t[ind][4] = greg(0, regd);
              t[ind][5] = (o == 0) ?
                             (size == 0) ?
                                (4+tarb[flats]):
                                (size == 1) ?
                                   (4+tarw[flats]):
                                   (flats <= 1 || flats == 11) ?
                                      (8+tarl[flats]):
                                      (6+tarl[flats]):
                             (size == 0) ?
                                (8 + tarb[flats]):
                                (size == 1) ?
                                   (8 + tarw[flats]):
                                   (12 + tarl[flats]);
              if (o == 1) t[ind][6] = (ULO)((size == 0) ?
                                         awb[flats]:
                                         (size == 1) ?
                                            aww[flats]:
                                            awl[flats]);
	    }
	    cpu_dis_tab[ind] = (ULO) i07dis;
	    }
	  }
}



/* Instruction ANDI.X #i,<ea>
   Table-usage:

   0-Routinepointer 1-disasm routine  2-eareg 3-ea read routine
                    4-cycle count    5-ea write routine               */

ULO i08dis(ULO prc, ULO opc, STR *st) {
  return arith3dis(prc, opc, st, 3);
}

void i08ini(void) {
  ULO op = 0x0200, ind, modes, regs, flats, size;
  for (size = 0; size < 3; size++)
    for (modes = 0; modes < 8; modes++) 
      for (regs = 0; regs < 8; regs++) {
	flats = modreg(modes, regs);
        if ((data[flats] && alterable[flats]) || (flats == 11 && size < 2)) {
          ind = op | size<<6 | modes<<3 | regs;
	  if (usenew_addi && cpugentab[ind][0] != ((ULO) i00)) {
	    t[ind][0] = cpugentab[ind][0];
	    t[ind][1] = cpugentab[ind][1];
	    t[ind][2] = cpugentab[ind][2];
	    t[ind][3] = cpugentab[ind][3];
	  }
	  else if (usenew_addi) printf("ANDI opcode missing %X\n", ind);
	  else {
          t[ind][0] = (size == 0) ?
                         ((flats == 11) ?
                           (ULO) i08_B_CCR:
                           (ULO) i08_B):
                         (size == 1) ?
                            ((flats == 11) ?
                              (ULO) i08_W_SR:
                              (ULO) i08_W):
                            (ULO) i08_L; 
          t[ind][2] = greg(modes, regs);
          t[ind][3] = (ULO)((size == 0) ?
                         parb[flats]:
                         (size == 1) ?
                            parw[flats]:
                            parl[flats]);
          t[ind][4] = (flats == 11) ?
                        20:
                        (size == 0) ?
                         (flats == 0) ?
                            8:
                            (12 + tarb[flats]):
                         (size == 1)  ?
                            (flats == 0) ?
                               8:
                               (12 + tarw[flats]):
                            (flats == 0) ?
                               16:
                               (20 + tarl[flats]);
          t[ind][5] = (ULO)((size == 0) ?
                         awb[flats]:
                         (size == 1) ? 
                            aww[flats]:
                            awl[flats]);
          }
          cpu_dis_tab[ind] = (ULO) i08dis;
	}
        }
}

/* Instruction ASL/ASR.X #i,<ea>
   3 versions: 
   Table-usage:

   ASX.X Dx,Dy
    0-Routinepointer 1-disasm routine  2-shcountreg 3-dreg
                     4-cycle count               

   ASX.X #,Dy
    0-Routinepointer 1-disasm routine  2-shiftcount 3-dreg
                     4-cycle count               

   ASX.X #1,<ea>
    0-Routinepointer 1-disasm routine  2-eareg 3-earead
                     4-eawrite        5-cycle count         */

ULO i09dis(ULO prc, ULO opc, STR *st) {
  return shiftdis(prc, opc, st, 0);
}

void i09ini(void) {
  ULO op = 0xe000, ind, dir, modes, regs, regc, flats, size, immreg;
  for (size = 0; size < 3; size++)
    for (regc = 0; regc < 8; regc++) 
      for (dir = 0; dir < 2; dir++) 
        for (regs = 0; regs < 8; regs++)
          for (immreg = 0; immreg < 2; immreg++) {
            ind = op | regc<<9 | dir<<8 | size<<6 | immreg<<5 | regs;
            t[ind][0] = (size == 0) ?
                           ((immreg==0) ?
                             ((dir==0) ?
                               (ULO) i09_RI_I_B:
                               (ULO) i09_LE_I_B):
                             ((dir==0) ?
                               (ULO) i09_RI_R_B:
                               (ULO) i09_LE_R_B)):
                           ((size == 1) ?
                             ((immreg==0) ?
                               ((dir==0) ?
                                 (ULO) i09_RI_I_W:
                                 (ULO) i09_LE_I_W):
                               ((dir==0) ?
                                 (ULO) i09_RI_R_W:
                                 (ULO) i09_LE_R_W)):
                             ((immreg==0) ?
                               ((dir==0) ?
                                 (ULO) i09_RI_I_L:
                                 (ULO) i09_LE_I_L):
                               ((dir==0) ?
                                 (ULO) i09_RI_R_L:
                                 (ULO) i09_LE_R_L)));
            cpu_dis_tab[ind] = (ULO) i09dis;
            t[ind][2] = (immreg == 0) ?
                          ((regc == 0) ?
                            8:
                            regc):
                          greg(0, regc);
            t[ind][3] = greg(0, regs);
            t[ind][4] = (size == 3) ?
                          ((immreg == 0) ?
                            (8+(t[ind][2]*2)):
                            8):
                          ((immreg == 0) ?
                            (6+(t[ind][2]*2)):
                            6);
            }

  op = 0xe0c0;
  for (dir = 0; dir < 2; dir++) 
    for (modes = 0; modes < 8; modes++) 
      for (regs = 0; regs < 8; regs++) {
        flats = modreg(modes, regs);
        if (memory[flats] && alterable[flats]) {
          ind = op | dir<<8 | modes<<3 | regs;
	  if (usenew_clr && cpugentab[ind][0] != ((ULO) i00)) {
	    t[ind][0] = cpugentab[ind][0];
	    t[ind][1] = cpugentab[ind][1];
	    t[ind][2] = cpugentab[ind][2];
	    t[ind][3] = cpugentab[ind][3];
	  }
	  else if (usenew_clr) printf("ASXM.W opcode missing %X\n", ind);
	  else {
	    t[ind][0] = (dir == 0) ? (ULO) i09_RI_M_W : (ULO) i09_LE_M_W;
	    t[ind][2] = greg(modes, regs);
	    t[ind][3] = (ULO) parw[flats];
	    t[ind][4] = (ULO) aww[flats];
	    t[ind][5] = 8+tarw[flats];
          }
          cpu_dis_tab[ind] = (ULO) i09dis;
	}
      }
}

/*===========================================================================
   Instruction Bcc
   Table-usage:

   0-Routinepointer 1-displacement 32 bit 2-handle routine 3-PC add (0/2/4)
  ===========================================================================*/

ULO i11dis(ULO prc, ULO opc, STR *st) {
  ULO pos = 13, j, adr;
  int disp = (int)(signed char) (opc & 0xff);
  
  sprintf(st, "$%.6X %.4X                   B%s.%c  ", prc, opc,
	  btab[get_branchtype(opc)],
	  (disp == -1) ? 'L':(disp == 0) ? 'W' : 'B');
  if (disp == 0) {
    prc += 2;
    j = fetw(prc);
    sprintf(&st[13], "%4.4X", j);
    st[17] = ' ';
    adr = (j > 32767) ? (prc + j - 65536) : (prc + j); 
    }
  else if (disp == -1 && config_cpu_type >= 2) {
    prc += 2;
    j = fetl(prc);
    sprintf(&st[13], "%8.8X", j);
    st[21] = ' ';
    adr = prc + j;
    }
  else adr = prc + 2 + disp;
  sprintf(&st[36], "   $%6.6X", adr);
  return prc + 2;
}

void i11ini(void) {
  ULO op = 0x6000, c, ind;
  int di;
  ULO routines[16] = {(ULO) cc0,(ULO) cc1,(ULO) cc2,(ULO) cc3,
		     (ULO) cc4,(ULO) cc5,(ULO) cc6,(ULO) cc7,
		     (ULO) cc8,(ULO) cc9,(ULO) cca,(ULO) ccb,
		     (ULO) ccc,(ULO) ccd,(ULO) cce,(ULO) ccf};
  for (c = 0; c < 16; c++)
    for (di = -128; di < 128; di++) {
      ind = op | di & 0xff | c<<8;
      if (usenew_bcc && cpugentab[ind][0] != ((ULO) i00)) {
	t[ind][0] = cpugentab[ind][0];
	t[ind][1] = cpugentab[ind][1];
      }
      else if (usenew_bit) printf("Bcc opcode missing %X\n", ind);
      else {
	if (config_cpu_type >= 2) {
	  t[ind][0] = (ULO) ((di == 0) ? i11_W:((di == -1) ? i11_L:i11_B));
	  t[ind][3] = (ULO) ((di == 0) ? 2:((di == -1) ? 4:0));
	}
	else {
	  t[ind][0] = (ULO) ((di == 0) ? i11_W:i11_B);
	  t[ind][3] = (ULO) ((di == 0) ? 2 : 0);
	}
	t[ind][1] = di;
	t[ind][2] = routines[c];
      }
      cpu_dis_tab[ind] = (ULO) i11dis;
    }
}

/* Instructions BCHG.B/L BCLR BSET BTST
   Table-usage dynamic:
     2 - eareg 3-earead 4-reg 5-cycle count 6-eawrite
   Table-usage static:
     2 - eareg 3-earead 4-cycle count 5-eawrite */

ULO i12dis(ULO prc, ULO opc, STR *st) {
  return btXdis(prc, opc, st);
}

int btXadrselect(int nr, int dynamic, int mode) {
  if (nr == 3) {
    if (dynamic) return data[mode];
    else if (mode == 11) return FALSE;
    else return data[mode];
  }
  return data[mode] && alterable[mode];
}

void btXini(int o, ULO dLfunc, ULO dBfunc, ULO sLfunc, ULO sBfunc,
	    int dc1, int dc2, int sc1, int sc2) {
  ULO op = o, ind, breg, mode, reg, flat, nr = btXtrans[(o >> 6) & 3];

  for (breg = 0; breg < 8; breg++) /* Dynamic */
    for (mode = 0; mode < 8; mode++) 
      for (reg = 0; reg < 8; reg++) {
        flat = modreg(mode, reg);
        if (btXadrselect(nr, TRUE, flat)) {
          ind = op | breg<<9 | mode<<3 | reg;
	  if (usenew_bit && cpugentab[ind][0] != ((ULO) i00)) {
	    t[ind][0] = cpugentab[ind][0];
	    t[ind][1] = cpugentab[ind][1];
	    t[ind][2] = cpugentab[ind][2];
	    t[ind][3] = cpugentab[ind][3];
	  }
	  else if (usenew_bit) printf("BIT opcode missing %X\n", ind);
	  else {
	    t[ind][0] = (mode == 0) ? dLfunc:dBfunc;
	    t[ind][2] = greg(mode, reg);
	    t[ind][3] = (ULO) ((nr != 3) ? parb[flat]:arb[flat]);
	    t[ind][4] = greg(0, breg);
	    t[ind][5] = (mode == 0) ? dc1:(dc2 + tarb[flat]);
	    t[ind][6] = (ULO) awb[flat];
	  }
	  cpu_dis_tab[ind] = (ULO) i12dis;
	}
      }
  op = (o & 0x00ff) | 0x800;
  for (mode = 0; mode < 8; mode++) /* Static */
    for (reg = 0; reg < 8; reg++) {
      flat = modreg(mode, reg);
      if (btXadrselect(nr, FALSE, flat)) {
        ind = op | mode<<3 | reg;
	if (usenew_bit && cpugentab[ind][0] != ((ULO) i00)) {
	  t[ind][0] = cpugentab[ind][0];
	  t[ind][1] = cpugentab[ind][1];
	  t[ind][2] = cpugentab[ind][2];
	  t[ind][3] = cpugentab[ind][3];
	}
	else if (usenew_bit) printf("BIT opcode missing %X\n", ind);
	else {
	  t[ind][0] = (mode == 0) ? sLfunc:sBfunc;
	  t[ind][2] = greg(mode, reg);
	  t[ind][3] = (ULO) ((nr != 3) ? parb[flat]:arb[flat]);
	  t[ind][4] = (mode == 0) ? sc1 : (sc2 + tarb[flat]);
	  t[ind][5] = (ULO) awb[flat];
	}
	cpu_dis_tab[ind] = (ULO) i12dis;
      }
    }
}

void i12ini(void) {
  btXini(0x0140, (ULO) i12_D_L, (ULO) i12_D_B, (ULO) i12_S_L, (ULO) i12_S_B,
	 8, 8, 12, 12); /* BCHG */
  btXini(0x0180, (ULO) i13_D_L, (ULO) i13_D_B, (ULO) i13_S_L, (ULO) i13_S_B,
	 10, 8, 14, 12); /* BCLR */
  btXini(0x01c0, (ULO) i15_D_L, (ULO) i15_D_B, (ULO) i15_S_L, (ULO) i15_S_B,
	 8, 8, 12, 12); /* BSET */
  btXini(0x0100, (ULO) i17_D_L, (ULO) i17_D_B, (ULO) i17_S_L, (ULO) i17_S_B,
	 6, 4, 10, 8); /* BTST */
}

/* Instruction CHK.W <ea>,Dn
   Table-usage:

    0-Routinepointer 1-disasm routine  2-sourreg 3-sourceroutine
                     4-Dreg        5 - cycle count             */

ULO i18dis(ULO prc, ULO opc, STR *st) {
  return various1dis(prc, opc, st, 0);
}

void i18ini(void) {
  ULO op = 0x4180, ind, regd, modes, regs, flats;
  for (regd = 0; regd < 8; regd++) 
    for (modes = 0; modes < 8; modes++) 
      for (regs = 0; regs < 8; regs++) 
        if (data[(flats = modreg(modes, regs))]) {
          ind = op | regd<<9 | modes<<3 | regs;
          t[ind][0] = (ULO) i18;
          cpu_dis_tab[ind] = (ULO) i18dis;
          t[ind][2] = greg(modes, regs);
          t[ind][3] = (ULO) arw[flats];
          t[ind][4] = greg(0, regd);
          t[ind][5] = 10+tarw[flats];
          }
}

/* Instruction CLR.X <ea>
   Table-usage:
    0-Routinepointer 1-disasm routine  2-sourreg 3-sourceroutine
                     4-cycle count                   */

ULO i19dis(ULO prc, ULO opc, STR *st) {
  return unarydis(prc, opc, st, 0);
}

void i19ini(void) {
  ULO op=0x4200,ind,modes,regs,flats,size;
  for (size = 0; size < 3; size++)
    for (modes = 0; modes < 8; modes++) 
      for (regs = 0; regs < 8; regs++) {
        flats = modreg(modes, regs);
        if (data[flats] && alterable[flats]) {
          ind = op|size<<6|modes<<3|regs;
	if (usenew_clr && cpugentab[ind][0] != ((ULO) i00)) {
	  t[ind][0] = cpugentab[ind][0];
	  t[ind][1] = cpugentab[ind][1];
	  t[ind][2] = cpugentab[ind][2];
	  t[ind][3] = cpugentab[ind][3];
	}
	else if (usenew_clr) printf("CLR opcode missing %X\n", ind);
	else {
	  t[ind][0] = (ULO) i19;
	  t[ind][2] = greg(modes, regs);
	  t[ind][3] = (ULO)((size == 0) ?
			    awb[flats]:
			    (size == 1) ?
			    aww[flats]:
			    awl[flats]);
	  t[ind][4] = (size == 0) ?
	    4+tarb[flats]:
	    (size == 1) ?
	    (4+tarw[flats]):
	    (modes == 0) ?
	    6:
	  (4+tarl[flats]);
        }
        cpu_dis_tab[ind] = (ULO) i19dis;
	}
      }
}

/* Instruction CMP.X <ea>,Dn
   Table-usage:
   Type 1:  CMP <ea>,Dn
    0-Routinepointer 1-disasm routine  2-sourreg 3-sourceroutine
                   4-Dreg        5-cycle count                   */

ULO i20dis(ULO prc, ULO opc, STR *st) {
  return arith1dis(prc, opc, st, 2);
}  

void i20ini(void) {
  ULO op=0xb000,ind,regd,modes,regs,flats,size;
  for (size = 0; size < 3; size++)
    for (regd = 0; regd < 8; regd++) 
      for (modes = 0; modes < 8; modes++) 
        for (regs = 0; regs < 8; regs++) {
          flats = modreg(modes, regs);
          if ((size == 0 && data[flats]) ||
              (size != 0 && allmodes[flats])) {
            ind = op|regd<<9|size<<6|modes<<3|regs;
	  if (usenew_add && cpugentab[ind][0] != ((ULO) i00)) {
	    t[ind][0] = cpugentab[ind][0];
	    t[ind][1] = cpugentab[ind][1];
	    t[ind][2] = cpugentab[ind][2];
	    t[ind][3] = cpugentab[ind][3];
	  }
	  else if (usenew_add) printf("CMP opcode missing %X\n", ind);
	  else {
            t[ind][0] = (size == 0) ?
                           (ULO) i20_B:
                           (size == 1) ?
                              (ULO) i20_W:
                              (ULO) i20_L;
            t[ind][2] = greg(modes, regs);
            t[ind][3] = (ULO)((size == 0) ?
                           arb[flats]:
                           (size == 1) ?
                              arw[flats]:
                              arl[flats]);
            t[ind][4] = greg(0, regd);
            t[ind][5] = (size == 0) ?
                           (4+tarb[flats]):
                           (size == 1) ?
                              (4+tarw[flats]):
                              (6+tarl[flats]);
	  }
	  cpu_dis_tab[ind] = (ULO) i20dis;
	  }
	}
}

/* Instruction CMPA.W/L <ea>,An
   Table-usage:

    0-Routinepointer 1-disasm routine  2-sourreg 3-sourceroutine
                     4-Areg        5-cycle count                   */

ULO i21dis(ULO prc,ULO opc,STR *st) {
  return arith2dis(prc, opc, st, 2);
}

void i21ini(void) {
  ULO op=0xb0c0,ind,regd,modes,regs,flats,o;
  for (o = 0; o < 2; o++)
    for (regd = 0; regd < 8; regd++) 
      for (modes = 0; modes < 8; modes++) 
        for (regs = 0; regs < 8; regs++) 
          if (allmodes[(flats = modreg(modes, regs))]) {
            ind = op|regd<<9|o<<8|modes<<3|regs;
	    if (usenew_adda && cpugentab[ind][0] != ((ULO) i00)) {
	      t[ind][0] = cpugentab[ind][0];
	      t[ind][1] = cpugentab[ind][1];
	      t[ind][2] = cpugentab[ind][2];
	      t[ind][3] = cpugentab[ind][3];
	    }
	    else if (usenew_adda) printf("CMPA opcode missing %X\n", ind);
	    else {
	      t[ind][0] = (o == 0) ?
		(ULO) i21_W:
		(ULO) i21_L;
	      t[ind][2] = greg(modes, regs);
	      t[ind][3] = (ULO)((o == 0) ?
				arw[flats]:
				arl[flats]);
	      t[ind][4] = greg(1, regd);
	      t[ind][5] = (o==0) ?
		(6 + tarw[flats]):
		(6 + tarl[flats]);
            }
	    cpu_dis_tab[ind] = (ULO) i21dis;
	  }
}


/* Instruction CMPI.X #i,<ea>
   Table-usage:

    0-Routinepointer 1-disasm routine  2-eareg 3-ea read routine
                     4-cycle count               */

ULO i22dis(ULO prc, ULO opc, STR *st) {
  return arith3dis(prc, opc, st, 2);
}

void i22ini(void) {
  ULO op = 0x0c00, ind, modes, regs, flats, size;

  for (size = 0; size < 3; size++)
    for (modes = 0; modes < 8; modes++) 
      for (regs = 0; regs < 8; regs++) {
        flats = modreg(modes, regs);
        if (data[flats] && alterable[flats] ||
	    (config_cpu_type >= 2 && (flats == 9 || flats == 10))) {
          ind = op | size<<6 | modes<<3 | regs;
	  if (usenew_addi && cpugentab[ind][0] != ((ULO) i00)) {
	    t[ind][0] = cpugentab[ind][0];
	    t[ind][1] = cpugentab[ind][1];
	    t[ind][2] = cpugentab[ind][2];
	    t[ind][3] = cpugentab[ind][3];
	  }
	  else if (usenew_addi) printf("CMPI opcode missing %X\n", ind);
	  else {
          t[ind][0] = (size == 0) ?
                         (ULO) i22_B:
                         (size == 1) ?
                            (ULO) i22_W:
                            (ULO) i22_L; 
          t[ind][2] = greg(modes, regs);
          t[ind][3] = (ULO)((size == 0) ?
                         arb[flats]:
                         (size == 1) ?
                            arw[flats]:
                            arl[flats]);
          t[ind][4] = (size == 0) ?
                         (8 + tarb[flats]):
                         (size == 1)  ?
                            (8 + tarw[flats]):
                            (flats == 0) ?
                               14:
                               (12 + tarl[flats]);
          }
          cpu_dis_tab[ind] = (ULO) i22dis;
	}
        }
}

/* Instruction CMPM.X (Ay)+,(Ax)+
   Table-usage: 0 - Routinepointer 1 - disasm routine 2 - sou 3 - dest */

ULO i23dis(ULO prc, ULO opc, STR *st) {
  return arith5dis(prc, opc, st, 4);
}

void i23ini(void) {
  ULO op=0xb108,ind,rx,ry,sz;
  for (sz = 0; sz <= 2; sz++)
    for (rx = 0; rx <= 7; rx++) 
      for (ry = 0; ry <= 7; ry++) {
        ind = op|ry|rx<<9|sz<<6;
        t[ind][0] = (sz == 0) ?
                      (ULO) i23_B:
                      (sz == 1) ?
                        (ULO) i23_W:
                        (ULO) i23_L;
        cpu_dis_tab[ind] = (ULO) i23dis;
        t[ind][2] = greg(1, ry);
        t[ind][3] = greg(1, rx);
        }
}
/* Instruction DBcc Dn,offset
   Table-usage:

   0-Routinepointer 1-disasm routine  2-displacement 32 bit 3-handle routine */

ULO i24dis(ULO prc, ULO opc, STR *st) {
  ULO pos=13,j,adr,bratype = get_branchtype(opc);
  prc += 2;
  j = fetw(prc);
  adr = (j > 32767) ?
           (prc+j-65536):
           (prc+j); 
  sprintf(st,"$%.6X %.4X %.4X              DB",prc-2,opc,j);
  
  if (bratype == 0) strcat(st, "T    ");
  else if (bratype == 1) strcat(st, "F    ");
  else {
    strcat(st, btab[bratype]);
    strcat(st, "   ");
  }
  sprintf(&st[36],"   D%1d,$%6.6X", get_sreg(opc),adr);
  return prc+2;
}


void i24ini(void) {
  ULO op=0x50c8,c,ind,reg;
  ULO routines[16] = {(ULO) cc0,(ULO) cc1false,(ULO) cc2,(ULO) cc3,(ULO) cc4,
		      (ULO) cc5,(ULO) cc6,(ULO) cc7,(ULO) cc8,(ULO) cc9,
		      (ULO) cca,(ULO) ccb,(ULO) ccc,(ULO) ccd,(ULO) cce,
		      (ULO) ccf};
  for (c = 0; c < 16; c++)
    for (reg = 0; reg < 8; reg++) {
      ind = op|reg|c<<8;
      t[ind][0] = (ULO) i24;
      cpu_dis_tab[ind] = (ULO) i24dis;
      t[ind][2] = greg(0, reg);
      t[ind][3] = routines[c];
      }
}

/* Instruction DIVS.W <ea>,Dn
   Table-usage:

    0-Routinepointer 1-disasm routine  2-sourreg 3-sourceroutine
                     4-Dreg                          */

ULO i25dis(ULO prc, ULO opc, STR *st) {
  return various1dis(prc, opc, st, 1);
}

void i25ini(void) {
  ULO op = 0x81c0, ind, regd, modes, regs, flats;
  for (regd = 0; regd < 8; regd++) 
    for (modes = 0; modes < 8; modes++) 
      for (regs = 0; regs < 8; regs++) 
        if (data[(flats = modreg(modes, regs))]) {
          ind = op|regd<<9|modes<<3|regs;
          t[ind][0] = (ULO) i25;
          cpu_dis_tab[ind] = (ULO) i25dis;
          t[ind][2] = greg(modes, regs);
          t[ind][3] = (ULO) arw[flats];
          t[ind][4] = greg(0, regd);
          }
}

/* Instruction DIVU.W <ea>,Dn
   Table-usage:

    0-Routinepointer 1-disasm routine  2-sourreg 3-sourceroutine
                     4-Dreg                          */

ULO i26dis(ULO prc, ULO opc, STR *st) {
  return various1dis(prc, opc, st, 2);
}

void i26ini(void) {
  ULO op=0x80c0,ind,regd,modes,regs,flats;
  for (regd = 0; regd < 8; regd++) 
    for (modes = 0; modes < 8; modes++) 
      for (regs = 0; regs < 8; regs++) 
        if (data[(flats = modreg(modes, regs))]) {
          ind = op|regd<<9|modes<<3|regs;
          t[ind][0] = (ULO) i26;
          cpu_dis_tab[ind] = (ULO) i26dis;
          t[ind][2] = greg(modes, regs);
          t[ind][3] = (ULO) arw[flats];
          t[ind][4] = regd*4 + (ULO) d;
          }
}

/* Instruction EOR.X <ea>,Dn / EOR.X Dn,<ea>
   Table-usage:
     EOR Dn,<ea>
       0-Routinepointer 1-disasm routine  2-<ea>reg 3-get <ea> routine
                        4-Dreg        5-cycle count   6-write<ea> routine */

ULO i27dis(ULO prc, ULO opc, STR *st) {
  return arith1dis(prc, opc, st, 4);
}

void i27ini(void) {
  ULO op=0xb100,ind,regd,modes,regs,flats,size;
  for (size = 0; size < 3; size++)
    for (regd = 0; regd < 8; regd++) 
      for (modes = 0; modes < 8; modes++) 
        for (regs = 0; regs < 8; regs++) {
          flats = modreg(modes, regs);
          if (data[flats] && alterable[flats]) {
            ind = op|regd<<9|size<<6|modes<<3|regs;
	    if (usenew_add && cpugentab[ind][0] != ((ULO) i00)) {
	      t[ind][0] = cpugentab[ind][0];
	      t[ind][1] = cpugentab[ind][1];
	      t[ind][2] = cpugentab[ind][2];
	      t[ind][3] = cpugentab[ind][3];
	    }
	    else if (usenew_add) printf("EOR opcode missing %X\n", ind);
	    else {
            t[ind][0] = (size == 0) ?
                           (ULO) i27_B:
                           (size == 1) ?
                              (ULO) i27_W:
                              (ULO) i27_L;
            cpu_dis_tab[ind] = (ULO) i27dis;
            t[ind][2] = greg(modes, regs);
            t[ind][3] = (ULO)((size == 0) ?
                           parb[flats]:
                           (size == 1) ?
                              parw[flats]:
                              parl[flats]);
            t[ind][4] = greg(0, regd);
            t[ind][5] = (size == 0) ?
                           (8 + tarb[flats]):
                           (size == 1) ?
                              (8 + tarw[flats]):
                              (12 + tarl[flats]);
            t[ind][6] = (ULO)((size == 0) ?
                           awb[flats]:
                           (size == 1) ?
                              aww[flats]:
                              awl[flats]);
	    }
            cpu_dis_tab[ind] = (ULO) i27dis;
            }
          }
}

/* Instruction EORI.X #i,<ea>
   Table-usage:

     0-Routinepointer 1-disasm routine  2-eareg 3-ea read routine
                      4-cycle count    5-ea write routine         */

ULO i28dis(ULO prc, ULO opc, STR *st) {
  return arith3dis(prc, opc, st, 4);
}

void i28ini(void) {
  ULO op=0x0a00,ind,modes,regs,flats,size;
  for (size = 0; size < 3; size++)
    for (modes = 0; modes < 8; modes++) 
      for (regs = 0; regs < 8; regs++) {
        flats = modreg(modes, regs);
        if ((data[flats] && alterable[flats]) || (flats == 11 && size < 2)) {
          ind = op|size<<6|modes<<3|regs;
	  if (usenew_addi && cpugentab[ind][0] != ((ULO) i00)) {
	    t[ind][0] = cpugentab[ind][0];
	    t[ind][1] = cpugentab[ind][1];
	    t[ind][2] = cpugentab[ind][2];
	    t[ind][3] = cpugentab[ind][3];
	  }
	  else if (usenew_addi) printf("EORI opcode missing %X\n", ind);
	  else {
          t[ind][0] = (size == 0) ?
                         ((flats == 11) ?
                           (ULO) i28_B_CCR:
                           (ULO) i28_B):
                         (size == 1) ?
                            ((flats == 11) ?
                              (ULO) i28_W_SR:
                              (ULO) i28_W):
                            (ULO) i28_L; 
          t[ind][2] = greg(modes, regs);
          t[ind][3] = (ULO)((size == 0) ?
                         parb[flats]:
                         (size == 1) ?
                            parw[flats]:
                            parl[flats]);
          t[ind][4] = (flats == 11) ?
                        20:
                        (size == 0) ?
                         (flats == 0) ?
                            8:
                            (12 + tarb[flats]):
                         (size == 1)  ?
                            (flats == 0) ?
                               8:
                               (12 + tarw[flats]):
                            (flats == 0) ?
                               16:
                               (20 + tarl[flats]);
          t[ind][5] = (ULO)((size == 0) ?
                         awb[flats]:
                         (size == 1) ? 
                            aww[flats]:
                            awl[flats]);
          }
          cpu_dis_tab[ind] = (ULO) i28dis;
	}
        }
}

/* Instruction exg Rx,Ry
   Table-usage:

    0-Routinepointer 1-disasm routine  2-reg1 3-reg2 */

ULO i29dis(ULO prc,ULO opc,STR *st) {
  ULO o=(opc&0x00f8)>>3, reg1 = get_dreg(opc), reg2 = get_sreg(opc);
  if (o == 8) 
    sprintf(st,"$%.6X %.4X                   EXG.L   D%d,D%d",prc,opc,reg2,reg1);
  else if (o == 9)
    sprintf(st,"$%.6X %.4X                   EXG.L   A%d,A%d",prc,opc,reg2,reg1);
  else
    sprintf(st,"$%.6X %.4X                   EXG.L   A%d,D%d",prc,opc,reg2,reg1);
  return prc + 2;
}

void i29ini(void) {
  ULO op=0xc100,ind,reg1,reg2;

  for (reg2 = 0; reg2 < 8; reg2++)
    for (reg1 = 0; reg1 < 8; reg1++) {
      ind = op | (8<<3) | (reg2<<9) | reg1;
      t[ind][0] = (ULO) i29;
      cpu_dis_tab[ind] = (ULO) i29dis;
      t[ind][2] = greg(0, reg1);
      t[ind][3] = greg(0, reg2);
      }

  for (reg2 = 0; reg2 < 8; reg2++)
    for (reg1 = 0; reg1 < 8; reg1++) {
      ind = op | (9<<3) | (reg2<<9) | reg1;
      t[ind][0] = (ULO) i29;
      cpu_dis_tab[ind] = (ULO) i29dis;
      t[ind][2] = greg(1, reg1);
      t[ind][3] = greg(1, reg2);
      }

  for (reg2 = 0; reg2 < 8; reg2++)
    for (reg1 = 0; reg1 < 8; reg1++) {
      ind = op | (0x11<<3) | (reg2<<9) | reg1;
      t[ind][0] = (ULO) i29;
      cpu_dis_tab[ind] = (ULO) i29dis;
      t[ind][2] = greg(1, reg1);
      t[ind][3] = greg(0, reg2);
      }
}

/* Instruction ext Dx
   Table-usage:

    0-Routinepointer 1-disasm routine  2-reg 3-cycle count  */

ULO i30dis(ULO prc,ULO opc,STR *st) {
  ULO o = get_bit6(opc), reg = get_sreg(opc);
  sprintf(st,"$%.6X %.4X                   EXT.%s   D%d",prc,opc,(o==0) ? "W":"L",reg);
  return prc+2;
}

void i30ini(void) {
  ULO op=0x4880,ind,o,regs;
  for (o = 0; o < 2; o++) 
    for (regs = 0; regs < 8; regs++) {
      ind = op|o<<6|regs;
      t[ind][0] = (o == 0) ? ((ULO) i30_W):((ULO) i30_L);
      t[ind][1] = greg(0, regs);
      cpu_dis_tab[ind] = (ULO) i30dis;
      }
}

/* Instruction jmp <ea>
   Table-usage:

    0-Routinepointer 1-disasm routine  2-sourreg 3-sourceread
                     4-cycle count                   */

ULO i31dis(ULO prc, ULO opc, STR *st) {
  return unarydis(prc, opc, st, 4);
}

void i31ini(void) {
  ULO op=0x4ec0,ind,modes,regs,flats;
  for (modes = 0; modes < 8; modes++) 
    for (regs = 0; regs < 8; regs++) {
      flats = modreg(modes, regs);
      if (control[flats]) {
        ind = op|modes<<3|regs;
	  if (usenew_clr && cpugentab[ind][0] != ((ULO) i00)) {
	    t[ind][0] = cpugentab[ind][0];
	    t[ind][1] = cpugentab[ind][1];
	    t[ind][2] = cpugentab[ind][2];
	    t[ind][3] = cpugentab[ind][3];
	  }
	  else if (usenew_clr) printf("JMP opcode missing %X\n", ind);
	  else {
        t[ind][0] = (ULO) i31;
        t[ind][2] = greg(1, regs);
        t[ind][3] = (ULO) eac[flats];
        t[ind][4] = (flats == 2) ? 8:
                      (flats == 5) ? 10:
                        (flats == 6) ? 14:
                          (flats == 7) ? 10:
                            (flats == 9) ? 12:
                              (flats == 10) ? 10:14;
        }
        cpu_dis_tab[ind] = (ULO) i31dis;
      }
      }
}

/* Instruction jsr <ea>
   Table-usage:

    0-Routinepointer 1-disasm routine  2-sourreg 3-sourceread
                     4-cycle count                   */

ULO i32dis(ULO prc, ULO opc, STR *st) {
  return unarydis(prc, opc, st, 5);
}

void i32ini(void) {
  ULO op=0x4e80,ind,modes,regs,flats;
  for (modes = 0; modes < 8; modes++) 
    for (regs = 0; regs < 8; regs++) {
      flats = modreg(modes, regs);
      if (control[flats]) {
        ind = op|modes<<3|regs;
	  if (usenew_clr && cpugentab[ind][0] != ((ULO) i00)) {
	    t[ind][0] = cpugentab[ind][0];
	    t[ind][1] = cpugentab[ind][1];
	    t[ind][2] = cpugentab[ind][2];
	    t[ind][3] = cpugentab[ind][3];
	  }
	  else if (usenew_clr) printf("JSR opcode missing %X\n", ind);
	  else {
        t[ind][0] = (ULO) i32;
        t[ind][2] = greg(1, regs);
        t[ind][3] = (ULO) eac[flats];
        t[ind][4] = (flats == 2) ? 8:
                      (flats == 5) ? 10:
                        (flats == 6) ? 14:
                          (flats == 7) ? 10:
                            (flats == 9) ? 12:
                              (flats == 10) ? 10:14;
        }
        cpu_dis_tab[ind] = (ULO) i32dis;
      }
      }
}

/* Instruction lea <ea>
   Table-usage:

    0-Routinepointer 1-disasm routine  2-sourreg 3-earead
                     4-Areg 5-cycle count                   */

ULO i33dis(ULO prc, ULO opc, STR *st) {
  return various1dis(prc, opc, st, 3);
}

void i33ini(void) {
  ULO op=0x41c0,ind,areg,modes,regs,flats;
  for (areg = 0; areg < 8; areg++)
  for (modes = 0; modes < 8; modes++)
    for (regs = 0; regs < 8; regs++) {
      flats = modreg(modes, regs);
      if (control[flats]) {
        ind = op|areg<<9|modes<<3|regs;
        t[ind][0] = (ULO) i33;
        cpu_dis_tab[ind] = (ULO) i33dis;
        t[ind][2] = greg(1, regs);
        t[ind][3] = (ULO) eac[flats];
        t[ind][4] = greg(1, areg);
        t[ind][5] = (flats == 2) ? 4:
                      (flats == 5) ? 8:
                        (flats == 6) ? 12:
                          (flats == 7) ? 8:
                            (flats == 8) ? 12:
                              (flats == 9) ? 8:12;
        }
      }
}

/* Instruction LINK An,#
   Table-usage:
     0-Routinepointer 1-disasm routine  2-reg */

ULO i34dis(ULO prc, ULO opc, STR *st) {
  ULO j, pos = 13, reg = get_sreg(opc);
  j = fetw(prc+2);
  sprintf(st,"$%.6X %.4X %.4X              LINK    A%1d,#$%.4X",prc,opc,j,reg,j);
  
  return prc+4;
}

void i34ini(void) {
  ULO op=0x4e50,ind,reg;
  for (reg = 0; reg < 8; reg++) {
    ind = op|reg;
    t[ind][0] = (ULO) i34;
    cpu_dis_tab[ind] = (ULO) i34dis;
    t[ind][2] = greg(1, reg);
    }    
}

/* Instruction LSL/LSR.X #i,<ea>
   3 versions: 
   Table-usage:

   LSX.X Dx,Dy
    0-Routinepointer 1-disasm routine  2-shcountreg 3-dreg
                4-cycle count               

   LSX.X #,Dy
    0-Routinepointer 1-disasm routine  2-shiftcount 3-dreg
                4-cycle count               

   LSX.X #1,<ea>
    0-Routinepointer 1-disasm routine  2-eareg 3-earead
                4-eawrite        5-cycle count           */

ULO i35dis(ULO prc, ULO opc, STR *st) {
  return shiftdis(prc, opc, st, 1);
}

void i35ini(void) {
  ULO op=0xe008,ind,dir,modes,regs,regc,flats,size,immreg;
  for (size = 0; size < 3; size++)
    for (regc = 0; regc < 8; regc++) 
      for (dir = 0; dir < 2; dir++) 
        for (regs = 0; regs < 8; regs++)
          for (immreg = 0; immreg < 2; immreg++) {
            ind = op|regc<<9|dir<<8|size<<6|immreg<<5|regs;
            t[ind][0] = (size == 0) ?
                           ((immreg==0) ?
                             ((dir==0) ?
                               (ULO) i35_RI_I_B:
                               (ULO) i35_LE_I_B):
                             ((dir==0) ?
                               (ULO) i35_RI_R_B:
                               (ULO) i35_LE_R_B)):
                           ((size == 1) ?
                             ((immreg==0) ?
                               ((dir==0) ?
                                 (ULO) i35_RI_I_W:
                                 (ULO) i35_LE_I_W):
                               ((dir==0) ?
                                 (ULO) i35_RI_R_W:
                                 (ULO) i35_LE_R_W)):
                             ((immreg==0) ?
                               ((dir==0) ?
                                 (ULO) i35_RI_I_L:
                                 (ULO) i35_LE_I_L):
                               ((dir==0) ?
                                 (ULO) i35_RI_R_L:
                                 (ULO) i35_LE_R_L)));
            cpu_dis_tab[ind] = (ULO) i35dis;
            t[ind][2] = (immreg == 0) ?
                          ((regc == 0) ?
                            8:
                            regc):
                          greg(0, regc);
            t[ind][3] = greg(0, regs);
            t[ind][4] = (size == 3) ?
                          ((immreg == 0) ?
                            (8+(t[ind][2]*2)):
                            8):
                          ((immreg == 0) ?
                            (6+(t[ind][2]*2)):
                            6);
            }


  op = 0xe2c0;
  for (dir = 0; dir < 2; dir++) 
    for (modes = 0; modes < 8; modes++) 
      for (regs = 0; regs < 8; regs++) {
        flats = modreg(modes, regs);
        if (memory[flats] && alterable[flats]) {
          ind = op|dir<<8|modes<<3|regs;
	  if (usenew_clr && cpugentab[ind][0] != ((ULO) i00)) {
	    t[ind][0] = cpugentab[ind][0];
	    t[ind][1] = cpugentab[ind][1];
	    t[ind][2] = cpugentab[ind][2];
	    t[ind][3] = cpugentab[ind][3];
	  }
	  else if (usenew_clr) printf("LSXM.W opcode missing %X\n", ind);
	  else {        
	    t[ind][0] = (dir == 0) ?
	      (ULO) i35_RI_M_W:
	      (ULO) i35_LE_M_W;
	    t[ind][2] = greg(modes, regs);
	    t[ind][3] = (ULO) parw[flats];
	    t[ind][4] = (ULO) aww[flats];
	    t[ind][5] = 8+tarw[flats];
          }
          cpu_dis_tab[ind] = (ULO) i35dis;
	}
      }
}

/* Instruction MOVE.X <ea>,<ea>
   Table usage: 2 - get src ea  3 - src reg  4 - set dst ea  5 - cycles
                6 - dst reg*/

ULO i37dis(ULO prc, ULO opc, STR *st) {
  ULO mode = get_smod(opc), i, pos = 13, reg = get_sreg(opc),
      size = get_size3(opc);
  sprintf(st,"$%.6X %.4X                   MOVE.%c  ", prc, opc, sizec(size));
  mode = modreg(mode, reg);
  prc = disAdrMode(reg,prc+2,st,size,mode,&pos);
  strcat(st,",");
  reg = get_dreg(opc);
  mode = modreg(get_dmod(opc), reg);
  prc = disAdrMode(reg,prc,st,size,mode,&pos);  
  return prc;
}

void i37ini(void) {
  ULO op=0x0000,ind,moded,regd,modes,regs,size,flatd,flats;
  
  size = 0x1000; /* Byte */
  for (moded = 0; moded < 8; moded++) {
    for (regd = 0; regd < 8; regd++) {
      flatd = modreg(moded, regd);
      if (data[flatd] && alterable[flatd]) {
        for (modes = 0; modes < 8; modes++) {
          for (regs = 0; regs < 8; regs++) {
	    flats = modreg(modes, regs);
            if (data[flats]) {
              ind = op|size|regd<<9|moded<<6|modes<<3|regs;
              if (usenew_move && cpugentab[ind][0] != ((ULO) i00)) {
		t[ind][0] = cpugentab[ind][0];
		t[ind][1] = cpugentab[ind][1];
		t[ind][2] = cpugentab[ind][2];
		t[ind][3] = cpugentab[ind][3];
	      }
	      else if (usenew_move) printf("MOVE.B opcode missing %X\n", ind);
	      else {
		t[ind][0] = (ULO) i37_B;
		t[ind][2] = (ULO) arb[flats];
		t[ind][3] = greg(modes, regs);
		t[ind][4] = (ULO) awb[flatd];
		t[ind][6] = greg(moded, regd);
		t[ind][5] = 4+tarb[flats]+tarb[flatd];
              }
	      cpu_dis_tab[ind] = (ULO) i37dis;
	    }
	  }
	}
      }
    }
  }
  size = 0x3000; /* Word */
  for (moded = 0; moded < 8; moded++) {
    for (regd = 0; regd < 8; regd++) {
      flatd = modreg(moded, regd);
      if (data[flatd] && alterable[flatd]) {
        for (modes = 0; modes < 8; modes++) {
          for (regs = 0; regs < 8; regs++) {
	    flats = modreg(modes, regs);
            if (allmodes[flats]) {
              ind = op|size|regd<<9|moded<<6|modes<<3|regs;
              if (usenew_move && cpugentab[ind][0] != ((ULO) i00)) {
		t[ind][0] = cpugentab[ind][0];
		t[ind][1] = cpugentab[ind][1];
		t[ind][2] = cpugentab[ind][2];
		t[ind][3] = cpugentab[ind][3];
	      }
	      else if (usenew_move) printf("MOVE.W opcode missing %X\n", ind);
	      else {
		t[ind][0] = (ULO) i37_W;
		t[ind][2] = (ULO) arw[flats];
		t[ind][3] = greg(modes, regs);
		t[ind][4] = (ULO) aww[flatd];
		t[ind][6] = greg(moded, regd);
		t[ind][5] = 4+tarw[flats]+tarw[flatd];
	      }
	      cpu_dis_tab[ind] = (ULO) i37dis;
	    }
	  }
	}
      }
    }
  }
  size = 0x2000; /* Long */
  for (moded = 0; moded < 8; moded++) {
    for (regd = 0; regd < 8; regd++) {
      flatd = modreg(moded, regd);
      if (data[flatd] && alterable[flatd]) {
        for (modes = 0; modes < 8; modes++) {
          for (regs = 0; regs < 8; regs++) {
	    flats = modreg(modes, regs);
            if (allmodes[flats]) {
              ind = op|size|regd<<9|moded<<6|modes<<3|regs;
              if (usenew_move && cpugentab[ind][0] != ((ULO) i00)) {
		t[ind][0] = cpugentab[ind][0];
		t[ind][1] = cpugentab[ind][1];
		t[ind][2] = cpugentab[ind][2];
		t[ind][3] = cpugentab[ind][3];
	      }
	      else if (usenew_move) printf("MOVE.L opcode missing %X\n", ind);
	      else {
		t[ind][0] = (ULO) i37_L;
		t[ind][3] = greg(modes, regs);
		t[ind][2] = (ULO) arl[flats];
		t[ind][6] = greg(moded, regd);
		t[ind][4] = (ULO) awl[flatd];
		t[ind][5] = 4+tarl[flats]+tarl[flatd];
	      }
	      cpu_dis_tab[ind] = (ULO) i37dis;
	    }
	  }
	}
      }
    }
  }
}


/* Instruction MOVE.B to CCR
   Table-usage:

    0-Routinepointer 1-disasm routine  2-sourcereg 3-sourceroutine
                     4-cycle count                   */

ULO i38dis(ULO prc, ULO opc, STR *st) {
  ULO pos = 13, reg = get_sreg(opc), mode = get_smod(opc);
  sprintf(st,"$%.6X %.4X                   MOVE.B  ",prc,opc);
  mode = modreg(mode, reg);
  prc = disAdrMode(reg,prc+2,st,8,mode,&pos);
  strcat(st,",CCR");  
  return prc;
}

void i38ini(void) {
  ULO op=0x44c0,ind,reg,mode,flat;
    for (reg = 0; reg < 8; reg++) 
      for (mode = 0; mode < 8; mode++) {
        flat = modreg(mode, reg);
        if (data[flat]) {
	  ind = op|mode<<3|reg;
	  if (usenew_clr && cpugentab[ind][0] != ((ULO) i00)) {
	    t[ind][0] = cpugentab[ind][0];
	    t[ind][1] = cpugentab[ind][1];
	    t[ind][2] = cpugentab[ind][2];
	    t[ind][3] = cpugentab[ind][3];
	  }
	  else if (usenew_clr) printf("MOVEtoCCR opcode missing %X\n", ind);
	  else {
            t[ind][0] = (ULO) i38;
            t[ind][2] = greg(mode, reg);
            t[ind][3] = (ULO) arw[flat];
            t[ind][4] = 12 + tarw[flat];
            }
            cpu_dis_tab[ind] = (ULO) i38dis;
	}
      }   
}

/* Instruction MOVE.W to SR
   Table-usage:

    0-Routinepointer 1-disasm routine  2-sourcereg 3-sourceroutine
                     4-cycle count                   */

ULO i39dis(ULO prc, ULO opc, STR *st) {
  ULO pos = 13, reg = get_sreg(opc), mode = get_smod(opc);
  sprintf(st,"$%.6X %.4X            (PRIV) MOVE.W  ",prc,opc);
  mode = modreg(mode, reg);
  prc = disAdrMode(reg,prc+2,st,16,mode,&pos);
  strcat(st,",SR");
  return prc;
}

void i39ini(void) {
  ULO op=0x46c0,ind,reg,mode,flat;
    for (reg = 0; reg < 8; reg++) 
      for (mode = 0; mode < 8; mode++) {
        flat = modreg(mode, reg);
        if (data[flat]) {
	  ind = op|mode<<3|reg;
	  if (usenew_clr && cpugentab[ind][0] != ((ULO) i00)) {
	    t[ind][0] = cpugentab[ind][0];
	    t[ind][1] = cpugentab[ind][1];
	    t[ind][2] = cpugentab[ind][2];
	    t[ind][3] = cpugentab[ind][3];
	  }
	  else if (usenew_clr) printf("MOVEtoSR opcode missing %X\n", ind);
	  else {
            t[ind][0] = (ULO) i39;
            t[ind][2] = greg(mode, reg);
            t[ind][3] = (ULO) arw[flat];
            t[ind][4] = 12 + tarw[flat];
	  }
	  cpu_dis_tab[ind] = (ULO) i39dis;
	}
      }    
}

/* Instruction MOVE.W from SR
   Table-usage:

    0-Routinepointer 1-disasm routine  2-destreg 3-destroutine
                     4-cycle count                   */

ULO i40dis(ULO prc,ULO opc,STR *st) {
  ULO pos = 13, reg = get_sreg(opc), mode = get_smod(opc);
  sprintf(st,"$%.6X %.4X                   MOVE.W  SR,",prc,opc);
  mode = modreg(mode, reg);
  prc = disAdrMode(reg,prc+2,st,16,mode,&pos);
  return prc;
}

void i40ini(void) {
  ULO op=0x40c0,ind,reg,mode,flat;
    for (reg = 0; reg < 8; reg++) 
      for (mode = 0; mode < 8; mode++) { 
        flat = modreg(mode, reg);
        if (data[flat] & alterable[flat]) {
            ind = op|mode<<3|reg;
	    if (usenew_clr && cpugentab[ind][0] != ((ULO) i00)) {
	      t[ind][0] = cpugentab[ind][0];
	      t[ind][1] = cpugentab[ind][1];
	      t[ind][2] = cpugentab[ind][2];
	      t[ind][3] = cpugentab[ind][3];
	    }
	    else if (usenew_clr) printf("MOVEfromSR opcode missing %X\n", ind);
	    else {
	      t[ind][0] = (ULO) i40;
	      cpu_dis_tab[ind] = (ULO) i40dis;
	      t[ind][2] = greg(mode, reg);
	      t[ind][3] = (ULO) aww[flat];
	      t[ind][4] = (flat < 2) ? 6:(8 + tarw[flat]);
            }
	      cpu_dis_tab[ind] = (ULO) i40dis;
	}
      }     
}

/* Instruction MOVE.L USP to/from Ax
   Table-usage:
   0-Routinepointer 1-disasm routine  2-reg */

ULO i41dis(ULO prc,ULO opc,STR *st) {
  ULO reg = get_sreg(opc), dir = get_bit3(opc);
  if (dir == 0)
    sprintf(st,"$%.6X %.4X            (PRIV) MOVE.L  A%1d,USP",prc,opc,reg);
  else
    sprintf(st,"$%.6X %.4X            (PRIV) MOVE.L  USP,A%1d",prc,opc,reg);
  return prc+2;
}

void i41ini(void) {
  ULO op=0x4e60,ind,reg,dir;
  for (dir = 0; dir < 2; dir++)
    for (reg = 0; reg < 8; reg++) {
      ind = op | reg | dir<<3;
      t[ind][0] = (dir == 0) ? (ULO) i41_2 : (ULO) i41_1;
      cpu_dis_tab[ind] = (ULO) i41dis;
      t[ind][2] = greg(1, reg);
      }
}

/* Instruction MOVEA.W/L <ea>,An
   Table-usage:

    0-Routinepointer 1-disasm routine  2-sourreg 3-sourceroutine
                     4-Areg        5-cycle count                   */

ULO i42dis(ULO prc, ULO opc, STR *st) {
  ULO pos = 13, reg = get_sreg(opc), dreg = get_dreg(opc), o = get_bit12(opc),
      mode = get_smod(opc), size = get_size3(opc);
  mode = modreg(mode, reg);
  sprintf(st,"$%.6X %.4X                   MOVEA.%c ", prc, opc, sizec(size));
  prc = disAdrMode(reg,prc+2,st,size,mode,&pos);
  strcat(st,",");
  disAdrMode(dreg,prc,st,size,1,&pos);
  return prc;
}

void i42ini(void) {
  ULO op=0x2040,ind,regd,modes,regs,flats,o;
  for (o = 0; o < 2; o++)
    for (regd = 0; regd < 8; regd++) 
      for (modes = 0; modes < 8; modes++) 
        for (regs = 0; regs < 8; regs++) {
          flats = modreg(modes, regs);
          if (allmodes[flats]) {
            ind = op|regd<<9|o<<12|modes<<3|regs;
            t[ind][0] = (o == 0) ?
                           (ULO) i42_L:
                           (ULO) i42_W;
            cpu_dis_tab[ind] = (ULO) i42dis;
            t[ind][2] = greg(modes, regs);
            t[ind][3] = (ULO)((o == 0) ?
                           arl[flats]:
                           arw[flats]);
            t[ind][4] = greg(1, regd);
            t[ind][5] = (o == 0) ?
                           (4 + tarl[flats]):
                           (4 + tarw[flats]);
            }
          }
}

/* Instruction MOVEM.W/L 
   Table-usage:

   0-Routinepointer 1-disasm routine 2-eareg 3-earead/write 4-base cycle time*/

ULO i43dis(ULO prc, ULO opc, STR *st) {
  char tmp[10];
  ULO i, first, pos = 18, reg = get_sreg(opc), mode = get_smod(opc), size,
      dir = get_bit10(opc), regmask, next = 1;
  size = (!get_bit6(opc)) ? 16:32;
  regmask = fetw(prc+2);
  mode = modreg(mode, reg);

  if (dir == 0 && mode == 4) {  /* Register to memory, predecrement */
    sprintf(st,"$%.6X %.4X %.4X              MOVEM.%s ",prc,opc,regmask,((size==16)?"W":"L"));
    first=TRUE;
    for (i=0;i<8;i++) {
      if ((regmask&(1<<i)) != 0)
        if (first) {
          sprintf(tmp,"A%d",(7-i));
          strcat(st,tmp);
          first = FALSE;
          }
        else {
          sprintf(tmp,"%d",(7-i));
          strcat(st,tmp);
          }
        }
    for (i=8;i<16;i++) {
      if ((regmask&(1<<i)) != 0)
        if (first) {
          sprintf(tmp,"D%d",(15-i));
          strcat(st,tmp);
          first = FALSE;
          next = FALSE;
          }
        else {
          if (next)
            sprintf(tmp,"D%d",(15-i));
          else
            sprintf(tmp,"%d",(15-i));
          next = FALSE;
          strcat(st,tmp);
          }
        }
      strcat(st,",");
      prc = disAdrMode(reg,prc+4,st,size,mode,&pos);
    }     
  else if (dir) { /* Memory to register, any legal adressmode */
    sprintf(st,"$%.6X %.4X %.4X              MOVEM.%s ",prc,opc,regmask,((size==16)?"W":"L"));

    prc = disAdrMode(reg,prc+4,st,size,mode,&pos);
    strcat(st,",");
    first=TRUE;
    for (i=0;i<8;i++) {
      if ((regmask&(1<<i)) != 0)
        if (first) {
          sprintf(tmp,"D%d",i);
          strcat(st,tmp);
          first = FALSE;
          }
        else {
          sprintf(tmp,"%d",i);
          strcat(st,tmp);
          }
        }
    for (i=8;i<16;i++) {
      if ((regmask&(1<<i)) != 0)
        if (first) {
          sprintf(tmp,"A%d",i-8);
          strcat(st,tmp);
          first = FALSE;
          next = FALSE;
          }
        else {
          if (next)
            sprintf(tmp,"A%d",i-8);
          else
            sprintf(tmp,"%d",i-8);
          next = FALSE;  
          strcat(st,tmp);
          }
        }
    }     
  else {  /* Register to memory, the rest of the adr.modes */
    sprintf(st,"$%.6X %.4X %.4X              MOVEM.%s ",prc,opc,regmask,((size==16)?"W":"L"));
    first=TRUE;
    for (i=0;i<8;i++) {
      if ((regmask&(1<<i)) != 0)
        if (first) {
          sprintf(tmp,"D%d",i);
          strcat(st,tmp);
          first = FALSE;
          }
        else {
          sprintf(tmp,"%d",i);
          strcat(st,tmp);
          }
        }
    for (i=8;i<16;i++) {
      if ((regmask&(1<<i)) != 0)
        if (first) {
          sprintf(tmp,"A%d",(i-8));
          strcat(st,tmp);
          first = FALSE;
          next = FALSE;
          }
        else {
          if (next)
            sprintf(tmp,"A%d",(i-8));
          else
            sprintf(tmp,"%d",(i-8));
          next = FALSE;
          strcat(st,tmp);
          }

        }
    strcat(st,",");
    prc = disAdrMode(reg,prc+4,st,size,mode,&pos);
    }     

  
  return prc;
}

void i43ini(void) {
  ULO op=0x4880,ind,modes,regs,flats,dir,sz;
  for (dir = 0; dir < 2; dir++)
    for (sz = 0; sz < 2; sz++) 
      for (modes = 0; modes < 8; modes++) 
        for (regs = 0; regs < 8; regs++) {
          flats = modreg(modes, regs);
          if (control[flats] || ((flats == 3) && (dir == 1)) || ((flats == 4) && (dir == 0))) {
            ind = op|dir<<10|sz<<6|modes<<3|regs;
            t[ind][0] = (sz == 0) ?
                           ((dir == 0) ?
                             ((flats == 4) ?
                               (ULO) i43_W_PREM:
                               (ULO) i43_W_CONM):
                             ((flats == 3) ?
                               (ULO) i43_W_POSTR:
                               (ULO) i43_W_CONR)):
                           ((dir == 0) ?
                             ((flats == 4) ?
                               (ULO) i43_L_PREM:
                               (ULO) i43_L_CONM):
                             ((flats == 3) ?
                               (ULO) i43_L_POSTR:
                               (ULO) i43_L_CONR));
            cpu_dis_tab[ind] = (ULO) i43dis;
            t[ind][2] = greg(1, regs);
            t[ind][3] = (ULO) eac[flats];
            t[ind][4] = (sz == 0) ?
                           (8 + tarw[flats]):
                           (8 + tarl[flats]);
            }
          }
}


/*===================*/
/* Instruction MOVEP */
/*===================*/

ULO i44dis(ULO prc,ULO opc,STR *st) {
  sprintf(st,"$%.6X %.4X                   MOVEP",prc,opc);  
  return prc + 4;
}

void i44ini(void) {
  ULO op = 0x0008, ind, dreg, areg, mode;

  for (areg = 0; areg < 8; areg++) 
   for (dreg = 0; dreg < 8; dreg++) 
    for (mode = 4; mode < 8; mode++) {
      ind = op | areg | mode<<6 | dreg<<9;
      if (mode == 4) t[ind][0] = (ULO) i44_W_1;
      else if (mode == 5) t[ind][0] = (ULO) i44_L_1;
      else if (mode == 6) t[ind][0] = (ULO) i44_W_2;
      else if (mode == 7) t[ind][0] = (ULO) i44_L_2;
      cpu_dis_tab[ind] = (ULO) i44dis;
      t[ind][2] = greg(1, areg);
      t[ind][3] = greg(0, dreg);
      }
}

/* Instruction MOVEQ.L #8 bit signed imm,Dn
   Table-usage:

    0-Routinepointer 1-disasm routine  2-reg 3-32 bit immediate
                     4-flag byte                          */

ULO i45dis(ULO prc, ULO opc, STR *st) {
  ULO i, reg = get_dreg(opc);

  if (get_bit8(opc) && ((prc & 0xf80000) != 0xf80000))
    sprintf(st,"$%.6X %.4X                   ILLEGAL INSTRUCTION",prc,opc);
  else 
    sprintf(st,"$%.6X %.4X                   MOVEQ.L #$%8.8X,D%d",prc,opc,t[opc][3],reg);
  return prc + 2;
}

void i45ini(void) {
  ULO op=0x7000,ind,reg;
  int imm;
  for (reg = 0; reg < 8; reg++) 
    for (imm = -128; imm < 128; imm++) {
      ind = op|reg<<9|imm&0xff;
      t[ind][0] = (ULO) i45;
      cpu_dis_tab[ind] = (ULO) i45dis;
      t[ind][2] = greg(0, reg);
      t[ind][3] = imm;
      t[ind][4] = 0 | ((imm < 0) ? 0x8:0) | ((imm == 0) ? 0x4:0);
      }
  op = 0x7100;
  for (reg = 0; reg < 8; reg++)
    for (imm = -128; imm < 128; imm++) {
      ind = op|reg<<9|imm&0xff;
      t[ind][0] = (ULO) i45;
      cpu_dis_tab[ind] = (ULO) i45dis;
      t[ind][2] = greg(0, reg);
      t[ind][3] = imm;
      t[ind][4] = 0 | ((imm < 0) ? 0x8:0) | ((imm == 0) ? 0x4:0);
      }
}

/* Instruction MULS.W <ea>,Dn
   Table-usage:

    0-Routinepointer 1-disasm routine  2-sourreg 3-sourceroutine
                     4-Dreg                          */

ULO i46dis(ULO prc, ULO opc, STR *st) {
  return various1dis(prc, opc, st, 4);
}

void i46ini(void) {
  ULO op=0xc1c0,ind,regd,modes,regs,flats;
  for (regd = 0; regd < 8; regd++) 
    for (modes = 0; modes < 8; modes++) 
      for (regs = 0; regs < 8; regs++) {
        flats = modreg(modes, regs);
        if (data[flats]) {
          ind = op|regd<<9|modes<<3|regs;
          t[ind][0] = (ULO) i46;
          cpu_dis_tab[ind] = (ULO) i46dis;
          t[ind][2] = greg(modes, regs);
          t[ind][3] = (ULO) arw[flats];
          t[ind][4] = greg(0, regd);
          }
       }
}

/* Instruction MULU.W <ea>,Dn
   Table-usage:

    0-Routinepointer 1-disasm routine  2-sourreg 3-sourceroutine
                     4-Dreg                          */

ULO i47dis(ULO prc, ULO opc, STR *st) {
  return various1dis(prc, opc, st, 5);
}

void i47ini(void) {
  ULO op=0xc0c0,ind,regd,modes,regs,flats;
  for (regd = 0; regd < 8; regd++) 
    for (modes = 0; modes < 8; modes++) 
      for (regs = 0; regs < 8; regs++) 
        if (data[(flats = modreg(modes, regs))]) {
          ind = op|regd<<9|modes<<3|regs;
          t[ind][0] = (ULO) i47;
          cpu_dis_tab[ind] = (ULO) i47dis;
          t[ind][2] = greg(modes, regs);
          t[ind][3] = (ULO) arw[flats];
          t[ind][4] = greg(0, regd);
          }
}

/* Instruction NBCD.B <ea>
   Table-usage:
    0-Routinepointer 1-disasm routine  2-sourreg 3-sourceroutine 4-eawrite
                     5-cycle count                   */

ULO i48dis(ULO prc, ULO opc, STR *st) {
  return unarydis(prc, opc, st, 8);
}

void i48ini(void) {
  ULO op = 0x4800, ind, modes, regs, flats, size;
    for (modes = 0; modes < 8; modes++) 
      for (regs = 0; regs < 8; regs++) {
        flats = modreg(modes, regs);
        if (data[flats] && alterable[flats]) {
          ind = op|modes<<3|regs;
	  if (usenew_clr && cpugentab[ind][0] != ((ULO) i00)) {
	    t[ind][0] = cpugentab[ind][0];
	    t[ind][1] = cpugentab[ind][1];
	    t[ind][2] = cpugentab[ind][2];
	    t[ind][3] = cpugentab[ind][3];
	  }
	  else if (usenew_clr) printf("NBCD opcode missing %X\n", ind);
	  else {        
	    t[ind][0] = (ULO) i48_B;
	    t[ind][2] = greg(modes, regs);
	    t[ind][3] = (ULO) parb[flats];
	    t[ind][4] = (ULO) awb[flats];
	    t[ind][5] = (modes == 0) ?
	      6:
	    (8+tarb[flats]);
          }
          cpu_dis_tab[ind] = (ULO) i48dis;
	}
      }
}

/* Instruction NEG.X <ea>
   Table-usage:
    0-Routinepointer 1-disasm routine  2-sourreg 3-sourceroutine 4-eawrite
                     5-cycle count                   */

ULO i49dis(ULO prc,ULO opc,STR *st) {
  return unarydis(prc, opc, st, 1);
}

void i49ini(void) {
  ULO op = 0x4400, ind, modes, regs, flats, size;
  for (size = 0; size < 3; size++)
    for (modes = 0; modes < 8; modes++) 
      for (regs = 0; regs < 8; regs++) {
        flats = modreg(modes, regs);
        if (data[flats] && alterable[flats]) {
          ind = op | size<<6 | modes<<3 | regs;
	if (usenew_clr && cpugentab[ind][0] != ((ULO) i00)) {
	  t[ind][0] = cpugentab[ind][0];
	  t[ind][1] = cpugentab[ind][1];
	  t[ind][2] = cpugentab[ind][2];
	  t[ind][3] = cpugentab[ind][3];
	}
	else if (usenew_clr) printf("NEG opcode missing %X\n", ind);
	else {
        t[ind][0] = (size == 0) ? (ULO) i49_B:
                      (size == 1) ? (ULO) i49_W:(ULO) i49_L;
        t[ind][2] = greg(modes, regs);
        t[ind][3] = (ULO)((size == 0) ?
                       parb[flats]:
                       ((size == 1) ?
                          parw[flats]:
                          parl[flats]));
        t[ind][4] = (ULO)((size == 0) ?
                       awb[flats]:
                       ((size == 1) ?
                          aww[flats]:
                          awl[flats]));
        t[ind][5] = (size == 0) ?
                       (4+tarb[flats]):
                       ((size == 1) ?
                          (4+tarw[flats]):
                          ((modes == 0) ?
                             6:
                             (4+tarl[flats])));
        }
        cpu_dis_tab[ind] = (ULO) i49dis;
	}
      }
}

/* Instruction NEGX.X <ea>
   Table-usage:
    0-Routinepointer 1-disasm routine  2-sourreg 3-sourceroutine 4-eawrite
                     5-cycle count                   */

ULO i50dis(ULO prc, ULO opc, STR *st) {
  return unarydis(prc, opc, st, 9);
}

void i50ini(void) {
  ULO op = 0x4000, ind, modes, regs, flats, size;
  for (size = 0; size < 3; size++)
    for (modes = 0; modes < 8; modes++) 
      for (regs = 0; regs < 8; regs++) {
        flats = modreg(modes, regs);
        if (data[flats] && alterable[flats]) {
          ind = op | size<<6 | modes<<3 | regs;
	if (usenew_clr && cpugentab[ind][0] != ((ULO) i00)) {
	  t[ind][0] = cpugentab[ind][0];
	  t[ind][1] = cpugentab[ind][1];
	  t[ind][2] = cpugentab[ind][2];
	  t[ind][3] = cpugentab[ind][3];
	}
	else if (usenew_clr) printf("NEGX opcode missing %X\n", ind);
	else {
        t[ind][0] = (size == 0) ? (ULO) i50_B:
                      (size == 1) ? (ULO) i50_W:(ULO) i50_L;
        t[ind][2] = greg(modes, regs);
        t[ind][3] = (ULO)((size == 0) ?
                       parb[flats]:
                       (size == 1) ?
                          parw[flats]:
                          parl[flats]);
        t[ind][4] = (ULO)((size == 0) ?
                       awb[flats]:
                       (size == 1) ?
                          aww[flats]:
                          awl[flats]);
        t[ind][5] = (size == 0) ?
                       (4+tarb[flats]):
                       (size == 1) ?
                          (4+tarw[flats]):
                          (modes == 0) ?
                             6:
                             (4+tarl[flats]);
        }
        cpu_dis_tab[ind] = (ULO) i50dis;
	}
      }
}

/* Instruction NOP
   Table-usage:
     0-Routinepointer 1-disasm routine */

ULO i51dis(ULO prc, ULO opc, STR *st) {
  return singledis(prc, opc, st, 0);
}

void i51ini(void) {
  ULO op = 0x4e71;
  t[op][0] = (ULO) i51;
  cpu_dis_tab[op] = (ULO) i51dis;
}

/* Instruction NOT.X <ea>
   Table-usage:
    0-Routinepointer 1-disasm routine  2-sourreg 3-sourceroutine 4-eawrite
                     5-cycle count                   */

ULO i52dis(ULO prc, ULO opc, STR *st) {
  return unarydis(prc, opc, st, 2);
}

void i52ini(void) {
  ULO op = 0x4600, ind, modes, regs, flats, size;
  for (size = 0; size < 3; size++)
    for (modes = 0; modes < 8; modes++) 
      for (regs = 0; regs < 8; regs++) {
        flats = modreg(modes, regs);
        if (data[flats] && alterable[flats]) {
          ind = op | size<<6 | modes<<3 | regs;
	if (usenew_clr && cpugentab[ind][0] != ((ULO) i00)) {
	  t[ind][0] = cpugentab[ind][0];
	  t[ind][1] = cpugentab[ind][1];
	  t[ind][2] = cpugentab[ind][2];
	  t[ind][3] = cpugentab[ind][3];
	}
	else if (usenew_clr) printf("NOT opcode missing %X\n", ind);
	else {
        t[ind][0] = (size == 0) ? (ULO) i52_B:
                      (size == 1) ? (ULO) i52_W:(ULO) i52_L;
        t[ind][2] = greg(modes, regs);
        t[ind][3] = (ULO)((size == 0) ?
                       parb[flats]:
                       (size == 1) ?
                          parw[flats]:
                          parl[flats]);
        t[ind][4] = (ULO)((size == 0) ?
                       awb[flats]:
                       (size == 1) ?
                          aww[flats]:
                          awl[flats]);
        t[ind][5] = (size == 0) ?
                       (4+tarb[flats]):
                       (size == 1) ?
                          (4+tarw[flats]):
                          (modes == 0) ?
                             6:
                             (4+tarl[flats]);
        }
        cpu_dis_tab[ind] = (ULO) i52dis;
	}
      }
}

/* Instruction OR.X <ea>,Dn / OR.X Dn,<ea>
   Table-usage:
   Type 1:  OR <ea>,Dn

    0-Routinepointer 1-disasm routine  2-sourreg 3-sourceroutine
                     4-Dreg        5-cycle count                   
   Type 2:  OR Dn,<ea>

    0-Routinepointer 1-disasm routine  2-<ea>reg 3-get <ea> routine
                     4-Dreg        5-cycle count   6-write<ea> routine  */

ULO i53dis(ULO prc, ULO opc, STR *st) {
  return arith1dis(prc, opc, st, 5);
}

void i53ini(void) {
  ULO op = 0x8000, ind, regd, modes, regs, flats, size, o;
  for (o = 0; o < 2; o++)
    for (size = 0; size < 3; size++)
      for (regd = 0; regd < 8; regd++) 
        for (modes = 0; modes < 8; modes++) 
          for (regs = 0; regs < 8; regs++) {
            flats = modreg(modes, regs);
            if ((o==0 && data[flats]) ||
                (o==1 && alterable[flats] && memory[flats])) {
              ind = op | regd<<9 | o<<8 | size<<6 | modes<<3 | regs;
              if (usenew_add && cpugentab[ind][0] != ((ULO) i00)) {
		t[ind][0] = cpugentab[ind][0];
		t[ind][1] = cpugentab[ind][1];
		t[ind][2] = cpugentab[ind][2];
		t[ind][3] = cpugentab[ind][3];
	      }
	      else if (usenew_add) printf("OR opcode missing %X\n", ind);
	      else {
              t[ind][0] = (o == 0) ?
                             (size == 0) ?
                                (ULO) i53_B_1:
                                (size == 1) ?
                                   (ULO) i53_W_1:
                                   (ULO) i53_L_1:
                             (size == 0) ?
                                (ULO) i53_B_2:
                                (size == 1) ?
                                   (ULO) i53_W_2:
                                   (ULO) i53_L_2;
              t[ind][2] = greg(modes, regs);
              t[ind][3] = (ULO)((o == 0) ?
                             (size == 0) ?
                                arb[flats]:
                                (size == 1) ?
                                   arw[flats]:
                                   arl[flats]:
                             (size == 0) ?
                                parb[flats]:
                                (size == 1) ?
                                   parw[flats]:
                                   parl[flats]);
              t[ind][4] = greg(0, regd);
              t[ind][5] = (o == 0) ?
                             (size == 0) ?
                                (4+tarb[flats]):
                                (size == 1) ?
                                   (4+tarw[flats]):
                                   (flats <= 1 || flats == 11) ?
                                      (8+tarl[flats]):
                                      (6+tarl[flats]):
                             (size == 0) ?
                                (8 + tarb[flats]):
                                (size == 1) ?
                                   (8 + tarw[flats]):
                                   (12 + tarl[flats]);
              if (o == 1) t[ind][6] = (ULO)((size == 0) ?
                                         awb[flats]:
                                         (size == 1) ?
                                            aww[flats]:
                                            awl[flats]);
	      }
              cpu_dis_tab[ind] = (ULO) i53dis;
	    }
	  }
}

/* Instruction ORI.X #i,<ea>
   Table-usage:

    0-Routinepointer 1-disasm routine  2-eareg 3-ea read routine
                     4-cycle count    5-ea write routine               */

ULO i54dis(ULO prc, ULO opc, STR *st) {
  return arith3dis(prc, opc, st, 5);
}

void i54ini(void) {
  ULO op = 0, ind, modes, regs, flats, size;
  for (size = 0; size < 3; size++)
    for (modes = 0; modes < 8; modes++) 
      for (regs = 0; regs < 8; regs++) {
        flats = modreg(modes, regs);
        if ((data[flats] && alterable[flats]) || (flats == 11 && size < 2)) {
          ind = op | size<<6 | modes<<3 | regs;
	  if (usenew_addi && cpugentab[ind][0] != ((ULO) i00)) {
	    t[ind][0] = cpugentab[ind][0];
	    t[ind][1] = cpugentab[ind][1];
	    t[ind][2] = cpugentab[ind][2];
	    t[ind][3] = cpugentab[ind][3];
	  }
	  else if (usenew_addi) printf("ORI opcode missing %X\n", ind);
	  else {
          t[ind][0] = (size == 0) ?
                         ((flats == 11) ?
                           (ULO) i54_B_CCR:
                           (ULO) i54_B):
                         (size == 1) ?
                            ((flats == 11) ?
                              (ULO) i54_W_SR:
                              (ULO) i54_W):
                            (ULO) i54_L; 
          t[ind][2] = greg(modes, regs);
          t[ind][3] = (ULO)((size == 0) ?
                         parb[flats]:
                         (size == 1) ?
                            parw[flats]:
                            parl[flats]);
          t[ind][4] = (flats == 11) ?
                        20:
                        (size == 0) ?
                         (flats == 0) ?
                            8:
                            (12 + tarb[flats]):
                         (size == 1)  ?
                            (flats == 0) ?
                               8:
                               (12 + tarw[flats]):
                            (flats == 0) ?
                               16:
                               (20 + tarl[flats]);
          t[ind][5] = (ULO)((size == 0) ?
                         awb[flats]:
                         (size == 1) ? 
                            aww[flats]:
                            awl[flats]);
          }
          cpu_dis_tab[ind] = (ULO) i54dis;
	}
      }
}

/* Instruction pea <ea>
   Table-usage:
    0-Routinepointer 1-disasm routine  2-sourreg 3-earead
                     4-cycle count                   */

ULO i55dis(ULO prc, ULO opc, STR *st) {
  return unarydis(prc, opc, st, 6);
}

void i55ini(void) {
  ULO op = 0x4840, ind, modes, regs, flats;
  UBY cyc[12] = {0,0,12,0,0,16,20,16,20,20,16,20};
  for (modes = 0; modes < 8; modes++)
    for (regs = 0; regs < 8; regs++) {
      flats = modreg(modes, regs);
      if (control[flats]) {
        ind = op | modes<<3 | regs;
	  if (usenew_clr && cpugentab[ind][0] != ((ULO) i00)) {
	    t[ind][0] = cpugentab[ind][0];
	    t[ind][1] = cpugentab[ind][1];
	    t[ind][2] = cpugentab[ind][2];
	    t[ind][3] = cpugentab[ind][3];
	  }
	  else if (usenew_clr) printf("PEA opcode missing %X\n", ind);
	  else {
        t[ind][0] = (ULO) i55;
        t[ind][2] = greg(1, regs);
        t[ind][3] = (ULO) eac[flats];
        t[ind][4] = cyc[flats];
        }
        cpu_dis_tab[ind] = (ULO) i55dis;
      }
      }
}

/* Instruction RESET
   Table-usage:
       0-Routinepointer 1-disasm routine */

ULO i56dis(ULO prc, ULO opc, STR *st) {
  return singledis(prc, opc, st, 1);
}

void i56ini(void) {
  ULO op = 0x4e70;
  t[op][0] = (ULO) i56;
  cpu_dis_tab[op] = (ULO) i56dis;
}

/* Instruction ROL/ROR.X #i,<ea>
   3 versions: 
   Table-usage:

   ROX.X Dx,Dy
    0-Routinepointer 1-disasm routine  2-shcountreg 3-dreg
                4-cycle count               

   ROX.X #,Dy
    0-Routinepointer 1-disasm routine  2-shiftcount 3-dreg
                4-cycle count               

   ROX.X #1,<ea>
    0-Routinepointer 1-disasm routine  2-eareg 3-earead
                4-eawrite        5-cycle count               */

ULO i57dis(ULO prc, ULO opc, STR *st) {
  return shiftdis(prc, opc, st, 2);
}

void i57ini(void) {
  ULO op = 0xe018, ind, dir, modes, regs, regc, flats, size, immreg;
  for (size = 0; size < 3; size++)
    for (regc = 0; regc < 8; regc++) 
      for (dir = 0; dir < 2; dir++) 
        for (regs = 0; regs < 8; regs++)
          for (immreg = 0; immreg < 2; immreg++) {
            ind = op | regc<<9 | dir<<8 | size<<6 | immreg<<5 | regs;
            t[ind][0] = (size == 0) ?
                           ((immreg==0) ?
                             ((dir==0) ?
                               (ULO) i57_RI_I_B:
                               (ULO) i57_LE_I_B):
                             ((dir==0) ?
                               (ULO) i57_RI_R_B:
                               (ULO) i57_LE_R_B)):
                           ((size == 1) ?
                             ((immreg==0) ?
                               ((dir==0) ?
                                 (ULO) i57_RI_I_W:
                                 (ULO) i57_LE_I_W):
                               ((dir==0) ?
                                 (ULO) i57_RI_R_W:
                                 (ULO) i57_LE_R_W)):
                             ((immreg==0) ?
                               ((dir==0) ?
                                 (ULO) i57_RI_I_L:
                                 (ULO) i57_LE_I_L):
                               ((dir==0) ?
                                 (ULO) i57_RI_R_L:
                                 (ULO) i57_LE_R_L)));
            cpu_dis_tab[ind] = (ULO) i57dis;
            t[ind][2] = (immreg == 0) ?
                          ((regc == 0) ?
                            8:
                            regc):
                          greg(0, regc);
            t[ind][3] = greg(0, regs);
            t[ind][4] = (size == 3) ?
                          ((immreg == 0) ?
                            (8+(t[ind][2]*2)):
                            8):
                          ((immreg == 0) ?
                            (6+(t[ind][2]*2)):
                            6);
            }

  op = 0xe6c0;
  for (dir = 0; dir < 2; dir++) 
    for (modes = 0; modes < 8; modes++) 
      for (regs = 0; regs < 8; regs++) {
        flats = modreg(modes, regs);
        if (memory[flats] && alterable[flats]) {
          ind = op | dir<<8 | modes<<3 | regs;
	  if (usenew_clr && cpugentab[ind][0] != ((ULO) i00)) {
	    t[ind][0] = cpugentab[ind][0];
	    t[ind][1] = cpugentab[ind][1];
	    t[ind][2] = cpugentab[ind][2];
	    t[ind][3] = cpugentab[ind][3];
	  }
	  else if (usenew_clr) printf("ROXM.W opcode missing %X\n", ind);
	  else {        
	    t[ind][0] = (dir == 0) ? (ULO) i57_RI_M_W : (ULO) i57_LE_M_W;
	    t[ind][2] = greg(modes, regs);
	    t[ind][3] = (ULO) parw[flats];
	    t[ind][4] = (ULO) aww[flats];
	    t[ind][5] = 8 + tarw[flats];
          }
          cpu_dis_tab[ind] = (ULO) i57dis;
	}
      }
}

/* Instruction ROXL/ROXR.X #i,<ea>
   3 versions: 
   Table-usage:

   ROXX.X Dx,Dy
    0-Routinepointer 1-disasm routine  2-shcountreg 3-dreg
                4-cycle count               

   ROXX.X #,Dy
    0-Routinepointer 1-disasm routine  2-shiftcount 3-dreg
                4-cycle count               

   ROXX.X #1,<ea>
    0-Routinepointer 1-disasm routine  2-eareg 3-earead
                4-eawrite        5-cycle count             */

ULO i59dis(ULO prc, ULO opc, STR *st) {
  return shiftdis(prc, opc, st, 3);
}

void i59ini(void) {
  ULO op = 0xe010, ind, dir, modes, regs, regc, flats, size, immreg;
  for (size = 0; size < 3; size++)
    for (regc = 0; regc < 8; regc++) 
      for (dir = 0; dir < 2; dir++) 
        for (regs = 0; regs < 8; regs++)
          for (immreg = 0; immreg < 2; immreg++) {
            ind = op | regc<<9 | dir<<8 | size<<6 | immreg<<5 | regs;
            t[ind][0] = (size == 0) ?
                           ((immreg==0) ?
                             ((dir==0) ?
                               (ULO) i59_RI_I_B:
                               (ULO) i59_LE_I_B):
                             ((dir==0) ?
                               (ULO) i59_RI_R_B:
                               (ULO) i59_LE_R_B)):
                           ((size == 1) ?
                             ((immreg==0) ?
                               ((dir==0) ?
                                 (ULO) i59_RI_I_W:
                                 (ULO) i59_LE_I_W):
                               ((dir==0) ?
                                 (ULO) i59_RI_R_W:
                                 (ULO) i59_LE_R_W)):
                             ((immreg==0) ?
                               ((dir==0) ?
                                 (ULO) i59_RI_I_L:
                                 (ULO) i59_LE_I_L):
                               ((dir==0) ?
                                 (ULO) i59_RI_R_L:
                                 (ULO) i59_LE_R_L)));
            cpu_dis_tab[ind] = (ULO) i59dis;
            t[ind][2] = (immreg == 0) ?
                          ((regc == 0) ?
                            8:
                            regc):
                          greg(0, regc);
            t[ind][3] = greg(0, regs);
            t[ind][4] = (size == 3) ?
                          ((immreg == 0) ?
                            (8+(t[ind][2]*2)):
                            8):
                          ((immreg == 0) ?
                            (6+(t[ind][2]*2)):
                            6);
            }

  op = 0xe4c0;
  for (dir = 0; dir < 2; dir++) 
    for (modes = 0; modes < 8; modes++) 
      for (regs = 0; regs < 8; regs++) {
        flats = modreg(modes, regs);
        if (memory[flats] && alterable[flats]) {
          ind = op | dir<<8 | modes<<3 | regs;
	  if (usenew_clr && cpugentab[ind][0] != ((ULO) i00)) {
	    t[ind][0] = cpugentab[ind][0];
	    t[ind][1] = cpugentab[ind][1];
	    t[ind][2] = cpugentab[ind][2];
	    t[ind][3] = cpugentab[ind][3];
	  }
	  else if (usenew_clr) printf("ROXXM.W opcode missing %X\n", ind);
	  else {        
	    t[ind][0] = (dir == 0) ? (ULO) i59_RI_M_W : (ULO) i59_LE_M_W;
	    t[ind][2] = greg(modes, regs);
	    t[ind][3] = (ULO) parw[flats];
	    t[ind][4] = (ULO) aww[flats];
	    t[ind][5] = 8 + tarw[flats];
          }
          cpu_dis_tab[ind] = (ULO) i59dis;
	}
      }
}

/* Instruction RTE
   Table-usage:
     0-Routinepointer 1-disasm routine */

ULO i61dis(ULO prc, ULO opc, STR *st) {
  return singledis(prc, opc, st, 2);
}

void i61ini(void) {
  ULO op = 0x4e73;
  t[op][0] = (ULO) i61;
  cpu_dis_tab[op] = (ULO) i61dis;
}

/* Instruction RTR
   Table-usage:
     0-Routinepointer 1-disasm routine */

ULO i62dis(ULO prc, ULO opc, STR *st) {
  return singledis(prc, opc, st, 3);
}

void i62ini(void) {
  ULO op = 0x4e77;
  t[op][0] = (ULO) i62;
  cpu_dis_tab[op] = (ULO) i62dis;
}    

/* Instruction RTS
   Table-usage:
     0-Routinepointer 1-disasm routine */

ULO i63dis(ULO prc, ULO opc, STR *st) {
  return singledis(prc, opc, st, 4);
}

void i63ini(void) {
  ULO op = 0x4e75;
  t[op][0] = (ULO) i63;
  cpu_dis_tab[op] = (ULO) i63dis;
}    


/*========================================================
   Instruction SBCD.B Ry,Rx / SBCD.B -(Ay),-(Ax)
   Table-usage: 0 -Routinepointer 1 - Rx*4(dest) 2 - Ry*4
  ========================================================*/

ULO i64dis(ULO prc, ULO opc, STR *st) {
  return arith5dis(prc, opc, st, 3);
}

void i64ini(void) {
  ULO op = 0x8100, ind, rm, rx, ry;

  for (rm = 0; rm < 2; rm++) 
    for (rx = 0; rx < 8; rx++) 
      for (ry = 0; ry < 8; ry++) {
        ind = op | ry | rx<<9 | rm<<3;
        t[ind][0] = (rm == 0) ? (ULO) i64_1 : (ULO) i64_2;
        cpu_dis_tab[ind] = (ULO) i64dis;
        t[ind][1] = greg(rm, rx);
        t[ind][2] = greg(rm, ry);
        }
}

/* Instruction Scc.B <ea>
   Table-usage:

    0-Routinepointer 1-disasm routine  2-reg*4+d  3-ea write routine
                4-handle routine 5-cyclecount not taken  6-cycle count taken */

ULO i65dis(ULO prc, ULO opc, STR *st) {
  ULO pos = 13, j, adr, mode = get_smod(opc), reg = get_sreg(opc),
      bratype = get_branchtype(opc);
  sprintf(st,"$%.6X %.4X                   S",prc,opc);
  if (bratype == 0) strcat(st, "T.B    ");
  else if (bratype == 1) strcat(st, "F.B    ");
  else {
    strcat(st, btab[bratype]);
    strcat(st, ".B   ");
  }
  mode = modreg(mode, reg);
  prc = disAdrMode(reg, prc + 2, st, 8, mode, &pos);
  return prc;
}

void i65ini(void) {
  ULO op = 0x50c0, c, ind, flat, mode, reg;
  ULO routines[16] = {(ULO) cc0,(ULO) cc1false,(ULO) cc2,(ULO) cc3,(ULO) cc4,
		      (ULO) cc5,(ULO) cc6,(ULO) cc7,(ULO) cc8,(ULO) cc9,
		      (ULO) cca,(ULO) ccb,(ULO) ccc,(ULO) ccd,(ULO) cce,
		      (ULO) ccf};
  for (c = 0; c < 16; c++)
    for (mode = 0; mode < 8; mode++) 
      for (reg = 0; reg < 8; reg++) {
        flat = modreg(mode, reg);
        if (data[flat] && alterable[flat]) {
          ind = op | c<<8 | mode<<3 | reg;
          t[ind][0] = (ULO) i65;
          cpu_dis_tab[ind] = (ULO) i65dis;
          t[ind][2] = greg(mode, reg);
          t[ind][3] = (ULO) awb[flat];
          t[ind][4] = routines[c];
          t[ind][5] = 4 + tarb[flat];
          t[ind][6] = (flat == 0) ? 6 : (4 + tarb[flat]);
          }
        }
}

/* Instruction STOP #
   Table-usage:
     0-Routinepointer 1-disasm routine */

ULO i66dis(ULO prc, ULO opc, STR *st) {
  sprintf(st, "$%.6X %.4X                   STOP #$%.4X", prc, opc,
	  fetw(prc + 2));
  return prc + 4;
}

void i66ini(void) {
  ULO op = 0x4e72;
  t[op][0] = (ULO) i66;
  cpu_dis_tab[op] = (ULO) i66dis;
}

/* Instruction SUB.X <ea>,Dn / SUB.X Dn,<ea>
   Table-usage:
   Type 1:  SUB <ea>,Dn

    0-Routinepointer 1-disasm routine  2-sourreg 3-sourceroutine
                     4-Dreg        5-cycle count                   
   Type 2:  SUB Dn,<ea>

    0-Routinepointer 1-disasm routine  2-<ea>reg 3-get <ea> routine
                     4-Dreg        5-cycle count   6-write<ea> routine   */

ULO i67dis(ULO prc, ULO opc, STR *st) {
  return arith1dis(prc, opc, st, 1);
}

void i67ini(void) {
  ULO op = 0x9000, ind, regd, modes, regs, flats, size, o;
  for (o = 0; o < 2; o++)
    for (size = 0; size < 3; size++)
      for (regd = 0; regd < 8; regd++) 
        for (modes = 0; modes < 8; modes++) 
          for (regs = 0; regs < 8; regs++) {
            flats = modreg(modes, regs);
            if ((o==0 && size == 0 && data[flats]) ||
                (o==0 && size != 0 && allmodes[flats]) ||
                (o==1 && alterable[flats] && memory[flats])) {
              ind = op | regd<<9 | o<<8 | size<<6 | modes<<3 | regs;
              if (usenew_add && cpugentab[ind][0] != ((ULO) i00)) {
		t[ind][0] = cpugentab[ind][0];
		t[ind][1] = cpugentab[ind][1];
		t[ind][2] = cpugentab[ind][2];
		t[ind][3] = cpugentab[ind][3];
	      }
	      else if (usenew_add) printf("SUB opcode missing %X\n", ind);
	      else {
		t[ind][0] = (o == 0) ?
                             (size == 0) ?
                                (ULO) i67_B_1:
                                (size == 1) ?
                                   (ULO) i67_W_1:
                                   (ULO) i67_L_1:
                             (size == 0) ?
                                (ULO) i67_B_2:
                                (size == 1) ?
                                   (ULO) i67_W_2:
                                   (ULO) i67_L_2;
              t[ind][2] = greg(modes, regs);
              t[ind][3] = (ULO)((o == 0) ?
                             (size == 0) ?
                                arb[flats]:
                                (size == 1) ?
                                   arw[flats]:
                                   arl[flats]:
                             (size == 0) ?
                                parb[flats]:
                                (size == 1) ?
                                   parw[flats]:
                                   parl[flats]);
              t[ind][4] = greg(0, regd);
              t[ind][5] = (o == 0) ?
                             (size == 0) ?
                                (4+tarb[flats]):
                                (size == 1) ?
                                   (4+tarw[flats]):
                                   (flats <= 1 || flats == 11) ?
                                      (8+tarl[flats]):
                                      (6+tarl[flats]):
                             (size == 0) ?
                                (8 + tarb[flats]):
                                (size == 1) ?
                                   (8 + tarw[flats]):
                                   (12 + tarl[flats]);
              if (o == 1) t[ind][6] = (ULO) ((size == 0) ?
                                         awb[flats]:
                                         (size == 1) ?
                                            aww[flats]:
                                            awl[flats]);
	      }
              cpu_dis_tab[ind] = (ULO) i67dis;
	    }
	  }
}


/*===============================================================
   Instruction SUBA.W/L <ea>,An
   Table-usage:

    0-Routinepointer 1-sourreg 2-sourceroutine
                     3-Areg        4-cycle count
  ===============================================================*/

ULO i68dis(ULO prc, ULO opc, STR *st) {
  return arith2dis(prc, opc, st, 1);
}

void i68ini(void) {
  ULO op = 0x90c0, ind, regd, modes, regs, flats, o;

  for (o = 0; o < 2; o++)
    for (regd = 0; regd < 8; regd++) 
      for (modes = 0; modes < 8; modes++) 
        for (regs = 0; regs < 8; regs++) 
          if (allmodes[(flats = modreg(modes, regs))]) {
            ind = op | regd<<9 | o<<8 | modes<<3 | regs;
	    t[ind][0] = (o == 0) ?
	      (ULO) i68_W:
	      (ULO) i68_L;
	    t[ind][1] = greg(modes, regs);
	    t[ind][2] = (ULO)((o == 0) ?
			      arw[flats]:
			      arl[flats]);
	    t[ind][3] = greg(1, regd);
	    t[ind][4] = (o==0) ?
	      (8 + tarw[flats]):
	      (flats <= 1 || flats == 11) ?
	      (8 + tarl[flats]):
	      (6 + tarl[flats]);
	    cpu_dis_tab[ind] = (ULO) i68dis;
	  }
}

/* Instruction SUBI.X #i,<ea>
   Table-usage:

    0-Routinepointer 1-disasm routine  2-eareg 3-ea read routine
                     4-cycle count    5-ea write routine               */

ULO i69dis(ULO prc, ULO opc, STR *st) {
  return arith3dis(prc, opc, st, 1);
}

void i69ini(void) {
  ULO op = 0x0400, ind, modes, regs, flats, size;
  for (size = 0; size < 3; size++)
    for (modes = 0; modes < 8; modes++) 
      for (regs = 0; regs < 8; regs++) {
        flats = modreg(modes, regs);
        if (data[flats] && alterable[flats]) {
          ind = op | size<<6 | modes<<3 | regs;
	  if (usenew_addi && cpugentab[ind][0] != ((ULO) i00)) {
	    t[ind][0] = cpugentab[ind][0];
	    t[ind][1] = cpugentab[ind][1];
	    t[ind][2] = cpugentab[ind][2];
	    t[ind][3] = cpugentab[ind][3];
	  }
	  else if (usenew_addi) printf("SUBI opcode missing %X\n", ind);
	  else {
          t[ind][0] = (size == 0) ?
                         (ULO) i69_B:
                         (size == 1) ?
                            (ULO) i69_W:
                            (ULO) i69_L; 
          t[ind][2] = greg(modes, regs);
          t[ind][3] = (ULO)((size == 0) ?
                         parb[flats]:
                         (size == 1) ?
                            parw[flats]:
                            parl[flats]);
          t[ind][4] = (size == 0) ?
                         (flats == 0) ?
                            8:
                            (12 + tarb[flats]):
                         (size == 1)  ?
                            (flats == 0) ?
                               8:
                               (12 + tarw[flats]):
                            (flats == 0) ?
                               16:
                               (20 + tarl[flats]);
          t[ind][5] = (ULO)((size == 0) ?
                         awb[flats]:
                         (size == 1) ? 
                            aww[flats]:
                            awl[flats]);
          }
          cpu_dis_tab[ind] = (ULO) i69dis;
	}
      }
}

/* Instruction SUBQ.X #i,<ea>
   Table-usage:

     0-Routinepointer 1-disasm routine  2-eareg 3-ea read routine
                      4-cycle count    5-ea write routine 6-SUB immediate */

ULO i70dis(ULO prc, ULO opc, STR *st) {
  return arith4dis(prc, opc, st, 1);
}

void i70ini(void) {
  ULO op = 0x5100, ind, imm, modes, regs, flats, size, o;
    for (size = 0; size < 3; size++)
      for (modes = 0; modes < 8; modes++) 
        for (regs = 0; regs < 8; regs++) 
          for (imm = 0; imm < 8; imm++) {
            flats = modreg(modes, regs);
            if ((size == 0 && alterable[flats] && modes != 1) ||
                (size != 0 && alterable[flats])) {
              ind = op | imm<<9 | size<<6 | modes<<3 | regs;
              t[ind][0] = (size == 0) ?
                             (ULO) i70_B:
                             (size == 1) ?
                                ((modes == 1) ? (ULO) i70_ADR:(ULO) i70_W):
                                ((modes == 1) ? (ULO) i70_ADR:(ULO) i70_L);
              cpu_dis_tab[ind] = (ULO) i70dis;
              t[ind][2] = greg(modes, regs);
              t[ind][3] = (ULO)((size == 0) ?
                             parb[flats]:
                             (size == 1) ?
                                parw[flats]:
                                parl[flats]);
              t[ind][4] = (size == 0) ?
                             (flats == 0) ?
                                (4+tarb[flats]):
                                (8+tarb[flats]):
                             (size == 1) ?
                                (flats == 0) ?
                                   (4+tarw[flats]):
                                   (8+tarw[flats]):
                                (flats < 2) ?
                                   (8+tarl[flats]):
                                   (12+tarl[flats]);
              t[ind][5] = (ULO)((size == 0) ?
                             awb[flats]:
                             (size == 1) ?
                                aww[flats]:
                                awl[flats]);
              t[ind][6] = (imm == 0) ?
                             8:
                             imm;
              }
            }
}

/* Instruction SUBX.X Ry,Rx / SUBX.X -(Ay),-(Ax)
   Table-usage: 0 -Routinepointer 1 - disasm routine 2 - Rx*4(dest) 3 - Ry*4 */

ULO i71dis(ULO prc, ULO opc, STR *st) {
  return arith5dis(prc, opc, st, 1);
}

void i71ini(void) {
  ULO op = 0x9100, ind, rm, rx, ry, sz;
  for (sz = 0; sz <= 2; sz++)
    for (rm = 0; rm <= 1; rm++)
      for (rx = 0; rx <= 7; rx++) 
        for (ry = 0; ry <= 7; ry++) {
          ind = op | ry | rx<<9 | rm<<3 | sz<<6;
          t[ind][0] = (rm == 0) ?
                         (sz == 0) ?
                            (ULO) i71_B_1:
                            (sz == 1) ?
                               (ULO) i71_W_1:
                               (ULO) i71_L_1:
                         (sz == 0) ?
                            (ULO) i71_B_2:
                            (sz == 1) ?
                               (ULO) i71_W_2:
                               (ULO) i71_L_2;
          cpu_dis_tab[ind] = (ULO) i71dis;
          t[ind][2] = greg(rm, rx);
          t[ind][3] = greg(rm, ry);
          }
}

/* Instruction SWAP.W Dn
   Table-usage:
     0-Routinepointer 1-disasm routine  2-reg */

ULO i72dis(ULO prc, ULO opc, STR *st) {
  return various2dis(prc, opc, st, 0);
}

void i72ini(void) {
  ULO op = 0x4840,ind,reg;
  for (reg = 0; reg < 8; reg++) {
    ind = op|reg;
    t[ind][0] = (ULO) i72;
    cpu_dis_tab[ind] = (ULO) i72dis;
    t[ind][2] = greg(0, reg);
    }    
}

/* Instruction TAS.B <ea>
   Table-usage:

    0-Routinepointer 1-disasm routine  2-eareg 3-ea read routine
                     4-ea write routine  5-cycle count             */

ULO i73dis(ULO prc, ULO opc, STR *st) {
  return unarydis(prc, opc, st, 7);
}

void i73ini(void) {
  ULO op = 0x4ac0, ind, modes, regs, flats;
  for (modes = 0; modes < 8; modes++) 
    for (regs = 0; regs < 8; regs++) {
      flats = modreg(modes, regs);
      if (data[flats] && alterable[flats]) {
        ind = op | modes<<3 | regs;
	if (usenew_clr && cpugentab[ind][0] != ((ULO) i00)) {
	  t[ind][0] = cpugentab[ind][0];
	  t[ind][1] = cpugentab[ind][1];
	  t[ind][2] = cpugentab[ind][2];
	  t[ind][3] = cpugentab[ind][3];
	}
	else if (usenew_clr) printf("TAS opcode missing %X\n", ind);
	else {
	  t[ind][0] = (ULO) i73;
	  t[ind][2] = greg(modes, regs);
	  t[ind][3] = (ULO) parb[flats];
	  t[ind][4] = (ULO) awb[flats];
	  t[ind][5] = (flats == 0) ? 4 : (10 + tarb[flats]);
        }
        cpu_dis_tab[ind] = (ULO) i73dis;
      }
      }
}

/* Instruction TRAP #
   Table-usage:
     0-Routinepointer 1-disasm routine  2-vector*4+80h */

ULO i74dis(ULO prc, ULO opc, STR *st) {
  sprintf(st, "$%.6X %.4X                   TRAP    #$%1X", prc, opc, opc&0xf);
  return prc + 2;
}

void i74ini(void) {
  ULO op = 0x4e40, ind, vektor;
  for (vektor = 0; vektor < 16; vektor++) {
    ind = op | vektor;
    t[ind][0] = (ULO) i74;
    cpu_dis_tab[ind] = (ULO) i74dis;
    t[ind][2] = vektor*4 + 0x80;
    }    
}

/* Instruction TRAPV
   Table-usage:
     0-Routinepointer 1-disasm routine */

ULO i75dis(ULO prc, ULO opc, STR *st) {
  return singledis(prc, opc, st, 5);
}

void i75ini(void) {
  ULO op = 0x4e76;
  t[op][0] = (ULO) i75;
  cpu_dis_tab[op] = (ULO) i75dis;
}

/* Instruction TST.X <ea>
   Table-usage:
    0-Routinepointer 1-disasm routine  2-sourreg 3-sourceroutine
                     4-cycle count                   */

ULO i76dis(ULO prc, ULO opc, STR *st) {
  return unarydis(prc, opc, st, 3);
}

void i76ini(void) {
  ULO op = 0x4a00, ind, modes, regs, flats, size;
  for (size = 0; size < 3; size++)
    for (modes = 0; modes < 8; modes++) 
      for (regs = 0; regs < 8; regs++) {
        flats = modreg(modes, regs);
        if ((data[flats] && alterable[flats]) ||
	    (config_cpu_type >= 2 && size >= 1 && flats == 1) ||
	    (config_cpu_type >= 2 && flats >= 9)) {
          ind = op | size<<6 | modes<<3 | regs;
	if (usenew_clr && cpugentab[ind][0] != ((ULO) i00)) {
	  t[ind][0] = cpugentab[ind][0];
	  t[ind][1] = cpugentab[ind][1];
	  t[ind][2] = cpugentab[ind][2];
	  t[ind][3] = cpugentab[ind][3];
	}
	else if (usenew_clr) printf("TST opcode missing %X\n", ind);
	else {
          t[ind][0] = (size == 0) ?
                       (ULO) i76_B:
                       (size == 1) ?
                          (ULO) i76_W:
                          (ULO) i76_L;
          t[ind][2] = greg(modes, regs);
          t[ind][3] = (ULO)((size == 0) ?
                       arb[flats]:
                       (size == 1) ?
                          arw[flats]:
                          arl[flats]);
          t[ind][4] = (size == 0) ?
                       (4+tarb[flats]):
                       (size == 1) ?
                          (4+tarw[flats]):
                          (4+tarl[flats]);
        }
          cpu_dis_tab[ind] = (ULO) i76dis;
	}
      }
}

/* Instruction UNLK An
   Table-usage:
       0-Routinepointer 1-disasm routine  2-reg */

ULO i77dis(ULO prc, ULO opc, STR *st) {
  return various2dis(prc, opc, st, 1);
}

void i77ini(void) {
  ULO op = 0x4e58, ind, reg;
  
  for (reg = 0; reg < 8; reg++) {
    ind = op | reg;
    t[ind][0] = (ULO) i77;
    cpu_dis_tab[ind] = (ULO) i77dis;
    t[ind][2] = greg(1, reg);
    }    
}

/* Instruction BKPT #  (ILLEGAL on all processors, included for disassembly)
   Table-usage:
       0-Routinepointer 1-disasm routine */

ULO i78dis(ULO prc, ULO opc, STR *st) {
  sprintf(st, "$%.6X %.4X                   BKPT    #$%1X", prc, opc, opc&0x7);
  return prc + 2;
}

void i78ini(void) {
  ULO op = 0x4848, ind, vector;

  for (vector = 0; vector < 8; vector++) {
    ind = op | vector;
    t[ind][0] = (ULO) i00;
    cpu_dis_tab[ind] = (ULO) i78dis;
    }
}

/* Log entry to instruction routines */

#ifdef CPU_LOG_INSTRUCTION_START

STR *cpuDisInstructionPrint(STR *s) {
  ULO mpc, opco;
  union { ULO lo; ULO (*fun)(); } yeah;
  
  mpc = get_pc(pc);
  opco = fetw(mpc);
  yeah.lo = cpu_dis_tab[opco];
  mpc = yeah.fun(mpc, opco, s);
  return s;
}


void cpuLogInstructionStart(ULO id) {
  STR s[80];

  addlog(cpuDisInstructionPrint(s));
  addlog("\n");
}

#endif


/*
   createstatustab
   Will translate the flags C X V N Z som the intel flag register
   X is set to the same as C since Intel doesn't have X
*/

void createstatustab(void) {
  ULO i;

  for (i = 0; i < 4096; i++)
    statustab[i]=(i&0x1)|((i&0x1)<<4)|((i&0xc0)>>4)|((i&0x800)>>10);
}


/* Make muls and mulu tables for clock calculations */

void makemultab(void) {
  ULO i, j, k;

  for (i = 0; i < 256; i++) {
    j = 0;
    for (k = 0; k < 8; k++)
      if (((i>>k) & 1) == 1)
	j++;
    mulutab[i] = j;
    j = 0;
    for (k = 0; k < 8; k++)
      if ((((i>>k) & 3) == 1) || (((i>>k) & 3) == 2))
	j++; 
    mulstab[i] = j;
  }
}

/* Sets the opcode table to illegal (i00) and similar disasm routine */

void clear_opcode_table(void) {
  ULO i, j;

  for (i = 0; i <= 65535; i++) {
    t[i][0] = (ULO) &i00;
    cpu_dis_tab[i] = (ULO) &i00dis;
    for (j = 2; j <= 7; j++)
      t[i][j] = 0;
  }
}

/* BCD number translation tables. */
/* NBCD can generate result 255, which must translate to 0x99 */
/* If the input is not a bcd number, the result is unpredictable.... */

void cpu_makebcdtabs(void) {
  ULO x;

  for (x = 0; x < 100; x++) hex2bcd[x] = x % 10 | (x / 10) << 4;
  for (x = 100; x < 255; x++) hex2bcd[x] = 0;
  hex2bcd[255] = 0x99;
  for (x = 0; x < 256; x++)
    bcd2hex[x] =(((x&0xf)<10)&&((x&0xf0)<0xa0)) ? ((x&0xf)+((x&0xf0)>>4)*10):0;
}

/* Irq table initialization */

static UBY cpu_irq_table_decide(ULO runlevel, ULO req) {
  LON actualrunlevel = -1;
  ULO i;

  for (i = 0; i < 14; i++) {
    if ((req & 1) && (int2int[i] > runlevel) && (actualrunlevel == -1))
      actualrunlevel = int2int[i];
    req >>= 1;
  }
  return actualrunlevel;
}	
  
void cpu_irq_table_init(void) {
  ULO runlevel, req;
  
  for (runlevel = 0; runlevel < 8; runlevel++)
    for (req = 0; req < 0x4000; req++)
      irq_table[req | (runlevel<<14)] = cpu_irq_table_decide(runlevel, req);
}      


/*============================*/
/* Init stack frame jmptables */
/*============================*/

void cpuStackFrameInit000(void) {
  ULO i;

  for (i = 0; i < 64; i++)
    cpu_stack_frame_gen[i] = cpuGroup1;/* Avoid NULL ptrs */
  cpu_stack_frame_gen[2] = cpuGroup2;  /* 2 - Bus error */
  cpu_stack_frame_gen[3] = cpuGroup2;  /* 3 - Address error */
}

void cpuStackFrameInit010(void) {
  ULO i;

  for (i = 0; i < 64; i++)
    cpu_stack_frame_gen[i] = cpuFrame0;/* Avoid NULL ptrs */
  cpu_stack_frame_gen[2] = cpuFrame8;  /* 2 - Bus error */
  cpu_stack_frame_gen[3] = cpuFrame8;  /* 3 - Address error */
}

void cpuStackFrameInit020(void) {
  ULO i;

  for (i = 0; i < 64; i++)
    cpu_stack_frame_gen[i] = cpuFrame0;/* Avoid NULL ptrs */
  cpu_stack_frame_gen[2] = cpuFrameA;  /* 2  - Bus Error */
  cpu_stack_frame_gen[3] = cpuFrameA;  /* 3  - Addrss Error */
  cpu_stack_frame_gen[5] = cpuFrame2;  /* 5  - Zero Divide */
  cpu_stack_frame_gen[6] = cpuFrame2;  /* 6  - CHK, CHK2 */
  cpu_stack_frame_gen[7] = cpuFrame2;  /* 7  - TRAPV, TRAPcc, cpTRAPcc */
  cpu_stack_frame_gen[9] = cpuFrame2;  /* 9  - Trace */
}

void cpuStackFrameInit030(void) {
  ULO i;

  for (i = 0; i < 64; i++)
    cpu_stack_frame_gen[i] = cpuFrame0;/* Avoid NULL ptrs */
  cpu_stack_frame_gen[2] = cpuFrameA;  /* 2  - Bus Error */
  cpu_stack_frame_gen[3] = cpuFrameA;  /* 3  - Addrss Error */
  cpu_stack_frame_gen[5] = cpuFrame2;  /* 5  - Zero Divide */
  cpu_stack_frame_gen[6] = cpuFrame2;  /* 6  - CHK, CHK2 */
  cpu_stack_frame_gen[7] = cpuFrame2;  /* 7  - TRAPV, TRAPcc, cpTRAPcc */
  cpu_stack_frame_gen[9] = cpuFrame2;  /* 9  - Trace */
}

void cpuStackFrameInit040(void) {
  ULO i;

  for (i = 0; i < 64; i++)
    cpu_stack_frame_gen[i] = cpuFrame0;/* Avoid NULL ptrs */
  cpu_stack_frame_gen[2] = cpuFrameA;  /* 2  - Bus Error */
  cpu_stack_frame_gen[3] = cpuFrameA;  /* 3  - Addrss Error */
  cpu_stack_frame_gen[5] = cpuFrame2;  /* 5  - Zero Divide */
  cpu_stack_frame_gen[6] = cpuFrame2;  /* 6  - CHK, CHK2 */
  cpu_stack_frame_gen[7] = cpuFrame2;  /* 7  - TRAPV, TRAPcc, cpTRAPcc */
  cpu_stack_frame_gen[9] = cpuFrame2;  /* 9  - Trace */
}

void cpuStackFrameInit060(void) {
  ULO i;

  for (i = 0; i < 64; i++)
    cpu_stack_frame_gen[i] = cpuFrame0;/* Avoid NULL ptrs */
  cpu_stack_frame_gen[2] = cpuFrame4;  /* 2  - Access Fault */
  cpu_stack_frame_gen[3] = cpuFrame2;  /* 3  - Addrss Error */
  cpu_stack_frame_gen[5] = cpuFrame2;  /* 5  - Zero Divide */
  cpu_stack_frame_gen[6] = cpuFrame2;  /* 6  - CHK, CHK2 */
  cpu_stack_frame_gen[7] = cpuFrame2;  /* 7  - TRAPV, TRAPcc, cpTRAPcc */
  cpu_stack_frame_gen[9] = cpuFrame2;  /* 9  - Trace */
  /* Unfinished */
}

void cpuStackFrameInit(void) {
  switch (config_cpu_type) {
    case 0:
      cpuStackFrameInit000();
      break;
    case 1:
      cpuStackFrameInit010();
      break;
    case 2:
      cpuStackFrameInit020();
      break;
    case 3:
      cpuStackFrameInit030();
      break;
    case 4:
      cpuStackFrameInit040();
      break;
    case 6:
      cpuStackFrameInit060();
      break;
  }
}


/*====================================*/
/* Set adressmode data to 68000 stubs */
/*====================================*/

void cpuAdrModeTablesInit000(void) {
  ULO i;

  for (i = 0; i < 12; i++) {
    arb[i] = arb68000[i];
    arw[i] = arw68000[i];
    arl[i] = arl68000[i];
    parb[i] = parb68000[i];
    parw[i] = parw68000[i];
    parl[i] = parl68000[i];
    awb[i] = awb68000[i];
    aww[i] = aww68000[i];
    awl[i] = awl68000[i];
    eac[i] = eac68000[i];
    tarb[i] = tarb68000[i];
    tarw[i] = tarw68000[i];
    tarl[i] = tarl68000[i];
  }
}


/*============================*/
/* Actually a Reset exception */
/*============================*/

void cpuReset000(void) {
  sr &= 0x271f;         /* T = 0 */
  sr |= 0x2700;         /* S = 1, ilvl = 7 */
  if (config_memory_kickbase < 0xf8) {
    ssp = fetl(0xf00000);        /* ssp = fake vector 0 */
    set_pc(fetl(0xf00004)); /* pc = fake vector 1 */
  }
  else {
    ssp = fetl(0xf80000);        /* ssp = fake vector 0 */
    set_pc(fetl(0xf80004)); /* pc = fake vector 1 */
  }
#ifdef PREFETCH
  prefetch_fill(pc);
#endif
}


/*=====================================*/
/* cpuReset performs a Reset exception */
/*=====================================*/

void cpureset(void) {
  ULO i;

  interruptflag = cpustopflag = FALSE;
  switch (config_cpu_type) {
    case 0:
      cpuReset000();
      break;
    case 1:
      cpuReset010();
      break;
    case 2:
      cpuReset020();
      break;
    case 3:
      cpuReset030();
      break;
    case 4:
      cpuReset040();
      break;
    case 6:
      cpuReset060();
      break;
  }
}


/*==================================================================*/
/* cpuInit is called whenever the opcode tables needs to be changed */
/* 1. At emulator startup or                                        */
/* 2. Cpu type has changed                                          */
/*==================================================================*/

void cpuInit() {
  ULO i;
  
  clear_opcode_table();
  for (i = 0; i < 8; i++)
    d[i] = a[i] = 0;

  /* For trackloaders, could be moved elsewhere */
  
  /*
  usp = a[7] = config_memory_chipsize;
  ssp = config_memory_chipsize - 0x2000;
  sr = 0x2000;
  set_pc(fetl(0xf80004));
#ifdef PREFETCH
  prefetch_fill(pc);
#endif
*/
  if (config_cpu_type < 2)
    cpuAdrModeTablesInit000();
  else
    cpuAdrModeTablesInit020();
  cpu_makebcdtabs();
  createstatustab();
  cpu_irq_table_init();  

  /* Common opcodes for all CPUs */
  
  i01ini();  /* ABCD */
  i02ini();
  i03ini();
  i04ini();
  i05ini();
  i06ini();
  i07ini();
  i08ini();
  i09ini();
  i11ini();
  i12ini();
  i18ini();
  i19ini();
  i20ini();
  i21ini();
  i22ini();
  i23ini();
  i24ini();
  i25ini();
  i26ini();
  i27ini();
  i28ini();
  i29ini();
  i30ini();
  i31ini();
  i32ini();
  i33ini();
  i34ini();
  i35ini();
  i37ini();
  i38ini();
  i39ini();
  i40ini();
  i41ini();
  i42ini();
  i43ini();
  i45ini();  /* MOVEQ */
  i46ini();
  i47ini();
  i48ini();
  i49ini();
  i50ini();
  i51ini();
  i52ini();
  i53ini();
  i54ini();
  i55ini();
  i56ini();
  i57ini();
  i59ini();
  i61ini();
  i62ini();
  i63ini();
  i64ini();
  i65ini();
  i66ini();
  i67ini();
  i68ini();
  i69ini();
  i70ini();
  i71ini();
  i72ini();
  i73ini();
  i74ini();
  i75ini();
  i76ini();
  i77ini();
  i78ini();  /* BKPT */

  if (config_cpu_type == 0) cpuInit000();
  else if (config_cpu_type == 1) cpuInit010();
  else if (config_cpu_type == 2) cpuInit020();
  else if (config_cpu_type == 3) cpuInit030();
  else if (config_cpu_type == 4) cpuInit040();
  else if (config_cpu_type == 6) cpuInit060();
  makemultab();  
  cpuStackFrameInit();
}

