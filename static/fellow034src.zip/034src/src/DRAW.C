/*============================================================*/
/* Fellow Amiga Emulator                                      */
/* Host screen drawing initialization and some implementation */
/* (C) 1998 Petter Schau                                      */
/*============================================================*/


#include <stdio.h>
#include "defs.h"
#include "fellow.h"
#include "inout.h"
#include "68000.h"
#include "memory.h"
#include "graphem.h"

#include "draw.h"


ULO bg2ddf;

/* Description of the framebuffer */

char *draw_framebuffer[3];
ULO draw_effectiveheight;
ULO draw_linefullwidth;
ULO config_draw_framebuffers;


/* REORG: 25/8-98 */

ULO draw_startoffset[3]; /* Bytes from buffer start until first pixel */
ULO draw_scanlinemodulo; /* Bytes from last pixel to first pixel on next line*/
ULO draw_buffershow, draw_bufferdraw;



/* Old description */

ULO scanlinelength; /* Total length in bytes for a line */

ULO lineflags[314];       /* Last color the line was drawn with */
UBY lineflagstimes[314];  /* Multi-buffer countdown for lineflags */


/* List of modes we can use */

struct gm_modelist *draw_modelist = NULL;

/* Clip positions for lores host screens */

ULO clipleftx = 120;
ULO cliprightx = 440;
ULO cliptop = 0x45;
ULO clipbot = 0x10d;

draw_routine_ptr drawptr;
draw_routine_ptr drawbgroutine;
draw_routine_ptr drawddfroutine;
draw_routine_ptr drawroutineptr;
draw_routine_ptr drawloresroutine,drawhiresroutine,drawdualloresroutine,
                 drawdualhiresroutine,drawhamroutine;



/* Used in translation of dual playfield
   syntax: dualtranslate[0 - PF1 behind, 1 - PF2 behind][PF1data][PF2data] */

UBY dualtranslate[2][256][256];




ULO config_draw_cycleexact = FALSE;

ULO frames, frameskip;


void set_displaybuffer(void) {
 ULO tmp;
 int heightmodifier = config_graphics_scaley + 1;

 if (heightmodifier == 3) heightmodifier = 1;
 if (config_graphics_mode == 6 || debugging) return;
 if (config_graphics_maxfps == 2)
   tmp = 1;
 else
   tmp = 0;

 /*

 {
   STR s[80];
   sprintf(s, "draw_buffershow %d  draw %d tmp %d\n", draw_buffershow, draw_bufferdraw, tmp);
   addlog(s);
 }*/

 
 switch (config_graphics_mode) {
   case 0:                                       
     switch (draw_buffershow) {
       case 0:  VBE_setDisplayStart(0,0,tmp);
                break;
       case 1:  VBE_setDisplayStart(0,600/heightmodifier,tmp);
                break;
       case 2:  VBE_setDisplayStart(0,1200/heightmodifier,tmp);
                break;
       }
       break;
   case 1:
     switch (draw_buffershow) {
       case 0:  VBE_setDisplayStart(0,0,tmp);
                break;
       case 1:  VBE_setDisplayStart(0,200,tmp);
                break;
       case 2:  VBE_setDisplayStart(0,400,tmp);
                break;
       }
       break;
   case 2:
     switch (draw_buffershow) {
       case 0:  VBE_setDisplayStart(0,0,tmp);
                break;
       case 1:  VBE_setDisplayStart(0,240,tmp);
                break;
       case 2:  VBE_setDisplayStart(0,480,tmp);
                break;
       }
       break;
   case 3:
     switch (draw_buffershow) {
       case 0:  VBE_setDisplayStart(0,0,tmp);
                break;
       case 1:  VBE_setDisplayStart(0,480/heightmodifier,tmp);
                break;
       case 2:  VBE_setDisplayStart(0,960/heightmodifier,tmp);
                break;
       }
       break;
   case 4:
     switch (draw_buffershow) {
       case 0:  VBE_setDisplayStart(0,0,tmp);
                break;
       case 1:  VBE_setDisplayStart(0,400/heightmodifier,tmp);
                break;
       case 2:  VBE_setDisplayStart(0,800/heightmodifier,tmp);
                break;
       }
       break;
   case 5:
     switch (draw_buffershow) {
       case 0:  VBE_setDisplayStart(0,0,tmp);
                break;
       case 1:  VBE_setDisplayStart(0,350/heightmodifier,tmp);
                break;
       case 2:  VBE_setDisplayStart(0,700/heightmodifier,tmp);
                break;
       }
       break;
   case 7:
     switch (draw_buffershow) {
       case 0:  VBE_setDisplayStart(0,0,tmp);
                break;
       case 1:  VBE_setDisplayStart(0,240,tmp);
                break;
       case 2:  VBE_setDisplayStart(0,480,tmp);
                break;
       }
       break;
   case 8:
   case 11:
     switch (draw_buffershow) {
       case 0:  VBE_setDisplayStart(0,0,tmp);
                break;
       case 1:  VBE_setDisplayStart(0,400,tmp);
                break;
       case 2:  VBE_setDisplayStart(0,800,tmp);
                break;
       }
       break;
   case 9:
   case 12:
     switch (draw_buffershow) {
       case 0:  VBE_setDisplayStart(0,0,tmp);
                break;
       case 1:  VBE_setDisplayStart(0,480,tmp);
                break;
       case 2:  VBE_setDisplayStart(0,960,tmp);
                break;
       }
       break;
   case 10:
   case 13:
     switch (draw_buffershow) {
       case 0:  VBE_setDisplayStart(0,0,tmp);
                break;
       case 1:  VBE_setDisplayStart(0,300,tmp);
                break;
       case 2:  VBE_setDisplayStart(0,600,tmp);
                break;
       }
       break;
   }


}




#ifdef DRAW_C

/* Check line against the defined clipping, and possibly adjust lineptr */

ULO clip_edges(UBY **lineptr) {
  ULO llim = DIWfirstvisiblepos, rlim = DIWlastvisiblepos, amount;

  if (bplcon0 & 0x8000) {
    llim >>= 1;
    rlim >>= 1;
  }
  if (rlim > cliprightx) amount = cliprightx;
  else amount = rlim;
  if (llim < clipleftx) {
    *lineptr = &linje[clipleftx];
    return (amount - clipleftx);
  }
  else {
    *lineptr = &linje[llim];
    return (amount - llim);
  }
}

int drawbgline_test(void) {
  if (shadcol[0] != lineflags[ypos]) {
    lineflags[ypos] = shadcol[0];
    lineflagstimes[ypos] = configdoublebuffer;
    return TRUE;
  }
  else {
    if (lineflagstimes[ypos] != 0) return lineflagstimes[ypos]--;
  }
  return FALSE;
}

void draw_invalidate_lineflag(void) {
  lineflags[ypos] = -1;
  lineflagstimes[ypos] = configdoublebuffer;
}  

/*---------------------------------*/
/* Width 640/800 pixels, 15/16 bpp */
/*---------------------------------*/

/* Draws amount bgpixels at screenptr, and updates the pointer   */
/* Pixels here counts as lores-pixels, which doubles */

#pragma aux fillbg800w parm [ebx];
void fillbg800w(ULO amount) {
  ULO i,j,bgcol = shadcol[0];
  ULO *spt = (ULO *) screenptr;

  screenptr += amount*4;
  j = amount & 0xfffffffc;
  for (i = 0; i < j; i+= 4) {
    spt[i] = bgcol;
    spt[1+i] = bgcol;
    spt[2+i] = bgcol;
    spt[3+i] = bgcol;
  }
  for (i = j; i < amount; i++) spt[i] = bgcol;
}

/* Draw bgcolor before the actual bitmap data */

void draw_clip_edge_before(void) {
  int pixels = DIWfirstvisiblepos;
  if (bplcon0 & 0x8000) pixels >>= 1;
  if ((pixels -= clipleftx) > 0) fillbg800w(pixels);
}

/* Draw bgcolor after the actual bitmap data */

void draw_clip_edge_after(void) {
  int pixels = DIWlastvisiblepos;
  if (bplcon0 & 0x8000) pixels >>= 1;
  if ((pixels = cliprightx - pixels) > 0) fillbg800w(pixels);
}

		     

/* Manages the drawing of a line with bitplane data into the framebuffer */

void drawddfline(void) {
  if (ypos >= cliptop) {
    ULO this_line_ptr = screenptr;
    draw_invalidate_lineflags();
    (*decoderoutineptr)();
    if (spritesonline) mergesprites();
    draw_clip_edge_before();
    (*drawptr)();
    draw_clip_edge_after();
    screenptr = this_line_ptr + scanlinelength;
  }
}
  
/* Manages the drawing of a line with bitplane data into the framebuffer */

void drawddfline320w(void) {
  if (ypos >= cliptop) {
    ULO this_line_ptr = screenptr;
    draw_invalidate_lineflags();
    (*decoderoutineptr)();
    if (spritesonline) mergesprites();
    draw_clip_edge_before();
    (*drawptr)();
    draw_clip_edge_after();
    screenptr = this_line_ptr + scanlinelength;
  }
}

/* Manages the drawing of a line with bitplane data into the framebuffer */

void drawddfline320b(void) {
  if (ypos >= cliptop) {
    ULO this_line_ptr = screenptr;
    draw_invalidate_lineflags();
    (*decoderoutineptr)();
    if (spritesonline) mergesprites();
    draw_clip_edge_before();
    (*drawptr)();
    draw_clip_edge_after();
    screenptr = this_line_ptr + scanlinelength;
  }
}
  
  
/* Draw a full blank line if this buffer hasn't been drawn with the color */
/* Width, 800 pixels 15/16 bit colors */

void drawbgline800w(void) {
  if ((ypos >= 0x1a) && drawbgline_test()) {
    ULO bgcol = shadcol[0];
    ULO *spt = (ULO *) screenptr, *spt_end = spt + 384;

    for (spt = spt; spt < spt_end; spt += 8) {
      *spt = bgcol;
      *(spt + 1) = bgcol;
      *(spt + 2) = bgcol;
      *(spt + 3) = bgcol;
      *(spt + 4) = bgcol;
      *(spt + 5) = bgcol;
      *(spt + 6) = bgcol;
      *(spt + 7) = bgcol;
    }
    screenptr += 1600 + draw_scanlinemodulo;
  }
}

/* Draw a line of lores data on a 800 pixels width VGA line */

void drawlores800w(void) {
  ULO i,j,amount = DIWlastvisiblepos - DIWfirstvisiblepos;
  UBY *lineptr = &linje[DIWfirstvisiblepos];
  ULO *spt = (ULO *) screenptr;
        
  if (amount <= 0) return;
  screenptr += amount*4;
  j = amount & 0xfffffffc;
  for (i = 0; i < j; i += 4) {
    spt[i]   = shadcol[lineptr[i]];
    spt[1+i] = shadcol[lineptr[i+1]];
    spt[2+i] = shadcol[lineptr[i+2]];
    spt[3+i] = shadcol[lineptr[i+3]];
  }
  for (i = j; i < amount; i++) spt[i] = shadcol[lineptr[i]];
}

/* Draw a line of hires data on a 800 pixels width VGA line */

void drawhires800w(void) {
  ULO i,j,amount = DIWlastvisiblepos - DIWfirstvisiblepos;
  UBY *lineptr = &linje[DIWfirstvisiblepos];
  ptunion upt;

  if (amount <= 0) return;
  upt.lptr = (ULO *) screenptr;
  screenptr += amount*2;
  j = (amount & 0xfffffffc)>>1;
  for (i = 0; i < j; i += 2) {
    upt.lptr[i]     = (shadcol[lineptr[i*2]] & 0xffff)
      | (shadcol[lineptr[i*2+1]] & 0xffff0000);
    upt.lptr[i+1]   = (shadcol[lineptr[i*2+2]] & 0xffff)
      | (shadcol[lineptr[i*2+3]] & 0xffff0000);
  }
  for (i = j*2; i < amount; i++) upt.wptr[i] = shadcol[lineptr[i]];
}

/* Draw a line of dual playfield lores data on a 800 pixels width VGA line */

void drawduallores800w(void) {
  ULO i,j,amount = DIWlastvisiblepos - DIWfirstvisiblepos;
  UBY *line1ptr = &linje[DIWfirstvisiblepos];
  UBY *line2ptr = &linje2[DIWfirstvisiblepos];
  ULO *spt = (ULO *) screenptr;
  UBY *dualxlat = (UBY *) dualtranslate;

  if (!(bplcon2 & 0x40)) dualxlat += 0x10000;

  if (amount <= 0) return;
  screenptr += amount*4;
  j = amount & 0xfffffffc;
  for (i = 0; i < j; i += 4) {
    spt[i]   = shadcol[dualxlat[(line1ptr[i]<<8)|line2ptr[i]]>>2];
    spt[1+i] = shadcol[dualxlat[(line1ptr[1+i]<<8)|line2ptr[1+i]]>>2];
    spt[2+i] = shadcol[dualxlat[(line1ptr[2+i]<<8)|line2ptr[2+i]]>>2];
    spt[3+i] = shadcol[dualxlat[(line1ptr[3+i]<<8)|line2ptr[3+i]]>>2];
  }
  for (i = j; i < amount; i++)
    spt[i]   = shadcol[dualxlat[(line1ptr[i]<<8)|line2ptr[i]]>>2];
}

/* Draw a line of dual playfield hires data on a 800 pixels width VGA line */

void drawdualhires800w(void) {
  ULO i,j,amount = DIWlastvisiblepos - DIWfirstvisiblepos;
  UBY *line1ptr = &linje[DIWfirstvisiblepos];
  UBY *line2ptr = &linje2[DIWfirstvisiblepos];
  ptunion upt;
  UBY *dualxlat = (UBY *) dualtranslate;
  upt.lptr = (ULO *) screenptr;

  if (bplcon2 & 0x4) dualxlat += 0x10000;

  if (amount <= 0) return;
  screenptr += amount*2;
  j = (amount & 0xfffffffc)>>1;
  for (i = 0; i < j; i += 2) {
    upt.lptr[i] = (shadcol[dualxlat[(line1ptr[i*2]<<8)|line2ptr[i*2]]>>2] & 0xffff)
      | ((shadcol[dualxlat[(line1ptr[1+i*2]<<8)|line2ptr[1+i*2]]>>2] & 0xffff)<<16);
    upt.lptr[1+i] = (shadcol[dualxlat[(line1ptr[2+i*2]<<8)|line2ptr[2+i*2]]>>2] & 0xffff)
      | ((shadcol[dualxlat[(line1ptr[3+i*2]<<8)|line2ptr[3+i*2]]>>2] & 0xffff)<<16);
  }
  for (i = j*2; i < amount; i++)
    upt.wptr[i] = shadcol[dualxlat[(line1ptr[i]<<8)|line2ptr[i]]>>2];
}

/*-----------------------------*/
/* Width 320 pixels, 15/16 bpp */
/*-----------------------------*/

/* Draws amount bgpixels at screenptr, and updates the pointer   */
/* Width, 320 pixels 15/16 bit colors */

#pragma aux fillbg320w parm [ebx];
void fillbg320w(ULO amount) {
  ULO i,j,bgcol = shadcol[0];
  ptunion upt;

  upt.lptr = (ULO *) screenptr;
  screenptr += amount*2;
  if ((upt.lval & 0x3) != 0) {   /* Align */
    *upt.wptr++ = bgcol;
    amount--;
  }

  j = amount & 0xfffffffe;
  for (i = 0; i < j; i+= 2) {
    upt.lptr[i] = bgcol;
    upt.lptr[1+i] = bgcol;
  }
  if ((amount & 0x1) == 1) upt.wptr[amount-1] = bgcol;
}

/* Draw a full blank line if this buffer hasn't been drawn with the color */
/* Width, 320 pixels 15/16 bit colors */

void drawbgline320w(void) {
  if ((ypos >= cliptop) && (ypos < clipbot)) {
    ULO *spt = (ULO *) screenptr, *spt_end = spt + 160;
    ULO bgcol = shadcol[0];

    screenptr += 640 + draw_scanlinemodulo;
    if (bgcol != lineflags[ypos]) {
      lineflags[ypos] = bgcol;
      lineflagstimes[ypos] = configdoublebuffer;
    }
    else {
      if (lineflagstimes[ypos] != 0) lineflagstimes[ypos]--;
      else return;
    }

    for (spt = spt; spt < spt_end; spt += 24) {
      *spt = bgcol;
      *(spt + 1) = bgcol;
      *(spt + 2) = bgcol;
      *(spt + 3) = bgcol;
      *(spt + 4) = bgcol;
      *(spt + 5) = bgcol;
      *(spt + 6) = bgcol;
      *(spt + 7) = bgcol;
      *(spt + 8) = bgcol;
      *(spt + 9) = bgcol;
      *(spt + 10) = bgcol;
      *(spt + 11) = bgcol;
      *(spt + 12) = bgcol;
      *(spt + 13) = bgcol;
      *(spt + 14) = bgcol;
      *(spt + 15) = bgcol;
    }
  }
}

/* Draw a line of lores data on a 320 pixels width VGA line */

void drawlores320w(void) {
  ULO i,j,amount;
  UBY *lineptr;
  ptunion upt;

  if ((amount = clip_edges(&lineptr)) <= 0) return;

  upt.lptr = (ULO *) screenptr;
  screenptr += amount*2;
  if ((upt.lval & 0x3) != 0) {                   /* Align */
    *upt.wptr++ = shadcol[(*lineptr++)>>2];
    amount--;
  }
  j = (amount & 0xfffffffc)>>1;
  for (i = 0; i < j; i += 2) {
    upt.lptr[i]   = (shadcol[lineptr[i*2]] & 0xffff)
      |(shadcol[lineptr[i*2+1]] & 0xffff0000);
    upt.lptr[1+i] = (shadcol[lineptr[i*2+2]] & 0xffff)
      |(shadcol[lineptr[i*2+3]] & 0xffff0000);
  }
  for (i = j*2; i < amount; i++) upt.wptr[i] = shadcol[lineptr[i]];
}

#endif

/*========================*/
/* Graphics Mode handling */
/*========================*/

struct gm_modelist *draw_alloc_modelist_node(void) {
  return (struct gm_modelist *) malloc(sizeof(struct gm_modelist));
}

void draw_add_modelist_node(struct gm_modelist *node) {
  struct gm_modelist *tmp;

  if (draw_modelist == NULL) {
    draw_modelist = node;
    node->next = NULL;
    }
  else {
    tmp = draw_modelist;
    while (tmp->next != NULL) tmp = tmp->next;
    tmp->next = node;
    node->next = NULL;
    }
}

/*=============================*/
/* Just for debugging purposes */
/*=============================*/

void draw_print_modelist(void) {
  struct gm_modelist *tmp = draw_modelist;

  while (tmp != NULL) {
    printf("%s\n",tmp->name);
    tmp = tmp->next;
    }
}


/*============================================================*/
/* Call graphics-driver to display the drawn buffer           */
/* Then prepare the buffer geometry for a drawing a new frame */ 
/*============================================================*/

void draw_switchbuffer(void) {
  if (++draw_buffershow > configdoublebuffer)
    draw_buffershow = 0;
  if (++draw_bufferdraw > configdoublebuffer)
    draw_bufferdraw = 0;
  screenptr = (ULO) ((UBY *) framebuffer) + bufferoffsets[draw_bufferdraw] +
	      draw_startoffset[draw_bufferdraw];
  if (configdoublebuffer != 0)
    set_displaybuffer();
  else if (config_graphics_flickerfree != 6 && config_graphics_flickerfree &&
	  !(lof & 0x8000))
    screenptr += scanlinelength;
}


/* Init tables */

void init_drawtables_320b(void) {
    int i;
    for (i = 0xc0; i < (0xc0 + 32); i++) iowrite[i] = wcolor;
    drawbgroutine = drawptr = drawbgline320b;
    drawddfroutine = drawddfline320b;
    drawloresroutine = drawlores320b;
    drawhiresroutine = drawlores320b;
    drawdualloresroutine = drawduallores320b;
    drawdualhiresroutine = drawduallores320b;
    drawhamroutine = drawham320b;
}

void init_drawtables_320w(void) {
    int i;
    for (i = 0xc0; i < (0xc0 + 32); i++) iowrite[i] = wcolor;
    drawbgroutine = drawptr = drawbgline320w;
    drawddfroutine = drawddfline320w;
    if (mmx_detected) {
      drawloresroutine = drawlores320wmmx;
      }
    else {
      drawloresroutine = drawlores320w;
      }
    drawhiresroutine = drawlores320w;
    drawdualloresroutine = drawduallores320w;
    drawdualhiresroutine = drawduallores320w;
    drawhamroutine = drawham320w;
}

void init_drawtables_640w(void) {
    int i;
    for (i = 0xc0; i < (0xc0 + 32); i++) iowrite[i] = wcolor;
    drawbgroutine = drawptr = drawbgline640w;
    drawddfroutine = drawddfline640w;
    drawloresroutine = drawlores640w;
    drawhiresroutine = drawhires640w;
    drawdualloresroutine = drawduallores640w;
    drawdualhiresroutine = drawdualhires640w;
    drawhamroutine = drawham640w;
}

void init_drawtables_800w(void) {
  int i;
  for (i = 0xc0; i < (0xc0 + 32); i++) iowrite[i] = wcolor; 
#ifndef DRAW_C
  if (config_draw_cycleexact) {       
    if (mmx_detected) {
      drawbgroutine = drawptr = drawbgline800wCC;
      drawloresroutine = drawlores800wmmxCC;
      drawhiresroutine = drawhires800wmmxCC;
      drawdualloresroutine = drawduallores800wmmx;
      }
    else {
      drawbgroutine = drawptr = drawbgline800wCC;
      drawloresroutine = drawlores800wCC;
      drawhiresroutine = drawhires800wCC;
      drawdualloresroutine = drawduallores800w;
      }
    for (i = 0xc0; i < (0xc0 + 32); i++) iowrite[i] = wcolorCC;
    }
  else if (mmx_detected) {
      drawbgroutine = drawptr = drawbgline800wmmx;
      drawloresroutine = drawlores800wmmx;
      drawhiresroutine = drawhires800wmmx;
      drawdualloresroutine = drawduallores800wmmx;
    }
  else
#endif
    {
    drawbgroutine = drawptr = drawbgline800w;
    drawloresroutine = drawlores800w;
    drawhiresroutine = drawhires800w;
    drawdualloresroutine = drawduallores800w;
    }
#ifndef DRAW_C
  if (config_draw_cycleexact) drawddfroutine = drawddfline800wCC;
  else
#endif
    drawddfroutine = drawddfline;
  drawdualhiresroutine = drawdualhires800w;
  drawhamroutine = drawham;
}

void draw_init_lineflagstables(void) {
  int i;

  for (i = 0; i < 314; i++) {
    lineflags[i] = 0xffff;
    lineflagstimes[i] = 10;
    }
}

void draw_init_dualtranslation_table(void) {
  int i,j,k,l;
  for (k = 0; k < 2; k++) {
    for (i = 0; i < 256; i++) {
      for (j = 0; j < 256; j++) {
        if (k == 0) { /* PF1 behind, PF2 in front */
          if (j == 0) l = i; /* PF2 transparent, PF1 visible */
          else { /* PF2 visible */
                 /* If color is higher than 0x3c it is a sprite */
            if (j < 0x40) l = j + 0x20;
            else l = j;
            }
          }
        else { /* PF1 in front, PF2 behind */
          if (i == 0) { /* PF1 transparent, PF2 visible */
            if (j == 0) l = 0;
            else {
              if (j < 0x40) l = j + 0x20;
              else l = j;
              }
            }
          else l = i; /* PF1 visible amd not transparent */
          }
        dualtranslate[k][i][j] = l;
        }
      }
    }
}

/* Things initialized once at startup */

void draw_init(void) {
  draw_init_lineflagstables();
  draw_init_dualtranslation_table();
  frameskip = 0;
}

