/*=================================================*/
/* Fellow Amiga Emulator                           */
/* Convert Amiga graphics data to temporary format */
/* suitable for fast drawing on a chunky display   */
/* Initialization and optional C implementation    */
/* (C) 1997-1998 Petter Schau                      */
/*=================================================*/


#include "defs.h"
#include "fellow.h"
#include "inout.h"
#include "68000.h"
#include "memory.h"
#include "keyboard.h"
#include "graphemm.h"            /* Macros used */
#include "draw.h"
#include "copper.h"
#include "blit.h"

#ifndef PLANAR_C

#include "graphema.h"

#endif

/* Lookup-table for planar to chunky routines */

planar2chunkyroutine decoderoutineptr;
planar2chunkyroutine decoderoutinetab[16];
planar2chunkyroutine decoderoutinedualtab[16];

/* Planar to chunky lookuptables */

extern ULO deco1[256][2];
extern ULO deco2[256][2];
extern ULO deco3[256][2];
extern ULO deco4[256][2];
extern ULO deco5[256][2];
extern ULO deco6[256][2];

ULO deco320hi1[256];
ULO deco320hi2[256];
ULO deco320hi3[256];
ULO deco320hi4[256];

UBY decosc01[256][8];
UBY decosc11[256][8];
UBY decosc21[256][8];
UBY decosc31[256][8];
UBY decosc02[256][8];
UBY decosc12[256][8];
UBY decosc22[256][8];
UBY decosc32[256][8];
UBY decosc03[256][8];
UBY decosc04[256][8];
UBY linje[1024],linje2[1024];  /* Playfield 1 and playfield 2 */

ULO decodetmp;
ULO config_graphics_mode;
ULO config_graphics_skiprate;
ULO config_graphics_maxfps;
ULO config_graphics_flickerfree;                /* De-interlace in hires */
ULO config_graphics_scaley;  /* 0 - Disabled, pure VESA  1 - Double lines with VGA */

/* Translation tables for colors */

ULO colortab[4096];   /* Translate Amiga 12-bit color to whatever color- */
                      /* format used by the graphics-driver. */
                      /* In 8-bit mode, the color is mapped to a register- */
                      /* number.  In truecolor mode, the color is mapped to */
                      /* a corresponding true-color bitpattern */
                      /* If the color does not match longword size, the */
                      /* color is repeated to fill the longword, that is */
                      /* 4 repeated color register numbers in 8-bit mode */
                      /* etc. */
                      /* In 24-bit mode, the last byte is blank */

ULO shadcol[64];      /* Colors corresponding to the different Amiga- */
                      /* registers.  Is initialized from colortab whenever */
                      /* WCOLORXX is written. */

ULO playfieldon;

/*  Used when sprites are merged with the linje arrays  
    syntax: spritetranslate[0 - behind, 1 - front][bitplanedata][spritedata] */

UBY spritetranslate[2][256][256];

/* Sprite data */

UBY sprite[8][16];
ULO spriteonline[8];
ULO spritesonline;
ULO spriteddfkill;
ULO sprite_delay;
ULO spritestateold[8];

/* Store delayed color-writes */
/* Color register writes are put in this table and processed when the */
/* line is drawn. */

UWO delay_color[200][4];      /* 0 - xposition  1 - address  2 - data */
ULO delay_color_total;        /* Total delayed writes in the table */
ULO delay_color_processed;    /* Number of first unprocessed delayed write */







#ifdef USE_NEW_SPRITE

/*========================================================*/
/* NEW SPRITE EMULATION                                   */
/* DATA DEFINITIONS                                       */
/* This is a clean C implementation to test a new concept */
/* It does a lot of extra testing which can be taken away */
/*                                                        */
/* Concept:                                               */
/* Initially we want to do all sprite calculation in the  */
/* end of the line handler.                               */
/* When sprite data are changed mid-line by Copper or CPU */
/* we do the things that should have been done at that    */
/* point in time for that particular sprite, creating a   */
/* list of instances for each sprite on the current line. */
/* Remaining work is done in the EOL.                     */
/*========================================================*/

#define NSPRITE_MAX_INSTANCES 8

/* The states sprites can be in, only used for DMA */

#define NSPRITE_STATE_CONTROL 0
#define NSPRITE_STATE_WAIT    1
#define NSPRITE_STATE_DATA    2

ULO nsprite_state[8];


/* When to perform Sprite DMA */

ULO nsprite_dmapos[8] = {0x1c, 0x20, 0x24, 0x28, 0x2c, 0x30, 0x34, 0x38};
ULO nsprite_dmaptr[8];
BOOLE nsprite_dmadone[8];


/* Positions and attach bit and current data words */

ULO nsprite_xstart[8];
ULO nsprite_xstart_use[8][NSPRITE_MAX_INSTANCES];
ULO nsprite_ystart[8];
ULO nsprite_ystop[8];
ULO nsprite_data[8];
ULO nsprite_data_use[8][NSPRITE_MAX_INSTANCES];
ULO nsprite_data_attached_use[8][NSPRITE_MAX_INSTANCES];
ULO nsprite_instances[8];
BOOLE nsprite_attached[8];
BOOLE nsprite_attached_use[8][NSPRITE_MAX_INSTANCES];
ULO nsprite_p2c[8][NSPRITE_MAX_INSTANCES];

/* Decoded sprites */

ULO nsprite_decoded[8][4];



void nspriteDMACheck(ULO sprno);


/*=============================*/
/* Reset sprites for new frame */
/*=============================*/

void nspriteEOF(void) {
  ULO i;

  for (i = 0; i < 8; i++) {
    nsprite_state[i] = NSPRITE_STATE_CONTROL;
    nsprite_instances[i] = 0;
    nsprite_dmadone[i] = FALSE;
  }
}


/*========================*/
/* New instance of sprite */
/*========================*/

/* If (even sprite) and odd counterpart is attached, don't make instance */

void nspriteInstanceNew(ULO sprno) {
  if (!(sprno & 1))
    nspriteDMACheck(sprno + 1);
  if ((!(sprno & 1)) && nsprite_attached[sprno + 1])
    return;
  nsprite_xstart_use[sprno][nsprite_instances[sprno]] = nsprite_xstart[sprno];
  nsprite_data_use[sprno][nsprite_instances[sprno]] = nsprite_data[sprno];
  nsprite_attached_use[sprno][nsprite_instances[sprno]] =
                                                       nsprite_attached[sprno];
  if ((sprno & 1) && (nsprite_attached[sprno]))
    nsprite_data_attached_use[sprno - 1][nsprite_instances[sprno]] =
                                                       nsprite_data[sprno - 1];
  nsprite_instances[sprno]++;
}


/*=============================*/
/* Read one word of sprite DMA */
/*=============================*/

ULO nspriteDMARead(ULO sprno) {
  ULO data;
  data = (cmem[nsprite_dmaptr[sprno] & 0x1fffff]<<8) ||
         (cmem[(nsprite_dmaptr[sprno] + 1) & 0x1fffff]);
  nsprite_dmaptr[sprno] = ((nsprite_dmaptr[sprno] + 2) & 0x1fffff);
  return data;
}


/*=============================*/
/* Do DMA for specified sprite */
/*=============================*/

void nspriteDMA(ULO sprno) {
  if (ypos >= 0x18)
    if (dmacon & 0x20) {
      nsprite_dmadone[sprno] = TRUE;
      switch (nsprite_state[sprno]) {
	case NSPRITE_STATE_CONTROL:  /* Read two control words */
	  nspritePosSet(sprno, nspriteDMARead(sprno));
	  nspriteCtlSet(sprno, nspriteDMARead(sprno));
	  nsprite_state[sprno] = NSPRITE_STATE_WAIT;
	  break;
	case NSPRITE_STATE_WAIT:
	  if (nsprite_ystart[sprno] != ypos)
	    break;
	  nsprite_state[sprno] = NSPRITE_STATE_DATA;
	case NSPRITE_STATE_DATA:
	  nspriteDatASet(sprno, nspriteDMARead(sprno));
	  nspriteDatBSet(sprno, nspriteDMARead(sprno));
	  if (nsprite_ystop[sprno] == ypos)
	    nsprite_state[sprno] = NSPRITE_STATE_CONTROL;
	  nspriteInstanceNew(sprno);
	  break;
      }
    }
}


/*========================================================================*/
/* Test if sprite DMA should have been done at a particular point in time */
/*========================================================================*/

void nspriteDMACheck(ULO sprno) {
  if (!nsprite_dmadone[sprno])
    if (nsprite_dmapos[sprno] <= xpos)
      nspriteDMA(sprno);
}


/*==============================*/
/* Write control and data words */
/*==============================*/

nspritePosSet(ULO sprno, ULO data) {
  nspriteDMACheck(sprno);
  nsprite_xstart[sprno] = (nsprite_xstart[sprno] & 1) | ((data & 0xff)<<1);
  nsprite_ystart[sprno] = (nsprite_ystart[sprno] & 0x100) | (data>>8);
}

nspriteCtlSet(ULO sprno, ULO data) {
  nspriteDMACheck(sprno);
  nsprite_xstart[sprno] = (nsprite_xstart[sprno] & 0x1fe) | (data & 1);
  nsprite_ystart[sprno] = (nsprite_ystart[sprno] & 0xff) | ((data & 4)<<6);
  nsprite_ystop[sprno]  = ((data>>8) & 0xff) | ((data & 2)<<7);
  if (sprno & 1)
    nsprite_attached[sprno & 6] = nsprite_attached[sprno] = !!(data & 0x80);
}

nspriteDatASet(ULO sprno, ULO data) {
  nspriteDMACheck(sprno);
  *((UWO *) &nsprite_data[sprno]) = data;
}

nspriteDatBSet(ULO sprno, ULO data) {
  nspriteDMACheck(sprno);
  *(((UWO *) &nsprite_data[sprno]) + 1) = data;
  nspriteInstanceNew(sprno);
}

/*====================*/
/* Write DMA pointers */
/*====================*/

void nspritePTHSet(ULO sprno, ULO data) {
  nspriteDMACheck(sprno);
  *(((UWO *) &nsprite_dmaptr[sprno]) + 1) = data & 0x1f;
}

void nspritePTLSet(ULO sprno, ULO data) {
  nspriteDMACheck(sprno);
  *((UWO *) &nsprite_dmaptr[sprno]) = data;
}


extern nspriteP2C4ASM(UBY *src, UBY *dst, ULO sprclass);
extern nspriteP2C16ASM(UBY *src1, UBY *src2, UBY *dst);


/*=============*/
/* 4 color P2C */
/*=============*/

void nspriteP2C4(ULO sprno, ULO i) {
  nspriteP2C4ASM((UBY *) &nsprite_data_use[sprno][i],
		 (UBY *) &nsprite_p2c[sprno][i],
		 sprno>>1);
}


/*==============*/
/* 16 color P2C */
/*==============*/

void nspriteP2C16(ULO sprno, ULO i) {
  nspriteP2C16ASM((UBY *) &nsprite_data_use[sprno][i],
		  (UBY *) &nsprite_data_attached_use[sprno][i],
		  (UBY *) &nsprite_p2c[sprno][i]);
}


/*===========================================*/
/* Do Planar to Chunky conversion on sprites */
/*===========================================*/

void nspriteInstancesP2C(ULO sprno) {
  ULO i;

  for (i = 0; i < nsprite_instances[sprno]; i++)
    if (nsprite_attached_use[i])
      nspriteP2C16(sprno, i);
    else
      nspriteP2C4(sprno, i);
}


/*===================================*/
/* End of line handler for sprites   */
/* Do all DMA that has not been done */
/* Then decode any sprites           */
/*===================================*/

void nspriteEOL(void) {
  ULO i;

  for (i = 0; i < 8; i++)     /* Two passes, attached sprites prevent one */
    if (!nsprite_dmadone[i])
      nspriteDMA(i);
  for (i = 0; i < 8; i++)
    nspriteInstancesP2C(i);  
}


#endif













#ifdef C_SPRITES

UBY sprite_dmadone[8];          /* Sprite dma has been read on this line */
ULO sprite_xstart[8];           /* x-position for sprite */
ULO sprite_ystart[8];           /* Y-positions only used by DMA */
ULO sprite_ystop[8];
ULO sprite_data[8];             /* Current data-words for sprite */
ULO sprite_dmaptr[8];           /* Sprite dma pointer */

/* Every hardware sprite can be displayed many times on each line */
/* Make room for 8 versions of the same sprite */

ULO sprite_decoded[8][8][4];
UBY sprite_decoded_amount[8];   /* Number of valid sprites for each sprite */
UBY sprite_attached[8];         /* Sprite is attached */

ULO sprite_dmalimit[8] = {0x1c,0x20,0x24,0x28,0x2c,0x30,0x34,0x38};



/* Called when sprpt is written, to decide if sprite_dma should have been */
/* performed with the old pointer */
/* Only called when dma has not been performed on this line */

void sprite_maybedma(ULO nr) {
  if (xpos > sprite_dmalimit[nr]) sprite_dodma(nr);
}


/*================================*/
/* Sprite register write routines */
/*================================*/


/* SprXpth $dff120 to $dff13c */

#pragma aux wsprxpth parm [ecx] [edx];
void wsprxpth(ULO address, ULO data) {
  ULO sprnr;

  sprnr = (wriorgadr>>2) & 7;
  if (!sprite_dmadone[sprnr]) sprite_maybedma(sprnr);
  *(((UWO *) &sprite_dmaptr[sprnr]) + 1) = data & 0x1f;
}

/* SprXpth $dff122 to $dff13e */

#pragma aux wsprxptl parm [ecx] [edx];
void wsprxptl(ULO address, ULO data) {
  ULO sprnr;

  sprnr = (wriorgadr>>2) & 7;
  if (!sprite_dmadone[sprnr]) sprite_maybedma(sprnr);
  *((UWO *) &sprite_dmaptr[sprnr]) = data & 0xfffe;
}

/* SprXpos $dff140 to $dff178 */

/* Two cases: */
/* 1. If we are before sprite_dma, just update the pointers */

/* 2. If we are after the sprite_dma, and it has not been performed, */
/*      perform sprite dma */
/*    If the old xposition means a sprite should have been displayed, */
/*      add this sprite to sprite_decoded */
/*    Update the sprite positions. */


#pragma aux wsprxpos parm [ecx] [edx];
void wsprxpos(ULO address, ULO data) {
  ULO sprnr;

  sprnr = (wriorgadr>>3) & 7;
  sprite_xstart[sprnr] = (sprite_xstart[sprnr] & 1) | ((data & 0xff)<<1);
//  sprite_ystart[sprnr] = (sprite_ystart[sprnr] & 0x100) | (data>>8);
}

/* SprXCTL $dff142 to $dff17a */

#pragma aux wsprxctl parm [ecx] [edx];
void wsprxctl(ULO address, ULO data) {
  ULO sprnr;

  sprnr = (wriorgadr>>3) & 7;
  sprite_xstart[sprnr] = (sprite_xstart[sprnr] & 0x1fe) | (data & 1);
  sprite_ystart[sprnr] = (sprite_ystart[sprnr] & 0xff) | ((data & 4)<<6;
  sprite_ystop[sprnr]  = ((data>>8) & 0xff) | ((data & 2)<<7);
  if (sprnr & 1)
    sprite_attached[sprnr & 6] = sprite_attached[sprnr] = !!(data & 0x80);
}

/* SprXDATA $dff144 to $dff17c */

#pragma aux wsprxdata parm [ecx] [edx];
void wsprxdata(ULO address, ULO data) {
  ULO sprnr;

  sprnr = (wriorgadr>>3) & 7;
  *((UWO *) &sprite_data[sprnr]) = data;
}

#pragma aux wsprxdatb parm [ecx] [edx];
void wsprxdatb(ULO address, ULO data) {
  ULO sprnr;

  sprnr = (wriorgadr>>3) & 7;
  *(((UWO *) &sprite_data[sprnr]) + 1) = data;
}






#endif



/*===================================*/
/* Graphics Register Access routines */
/*===================================*/

/* DMACONR - $dff002 Read */

#pragma aux rdmaconr parm [ecx] value [edx];
ULO rdmaconr(ULO address) {
  return dmaconr | ((!((WOR)bltzero))<<13);
}

/* VPOSR - $dff004 Read */

#pragma aux rvposr parm [ecx] value [edx];
ULO rvposr(ULO address) {
  return lof | (ypos>>8);
}

/* VHPOSR - $dff006 Read */

#pragma aux rvhposr parm [ecx] value [edx];
ULO rvhposr(ULO address) {
  return (xpos>>1) | ((ypos & 0xff)<<8);
}

/* ID - $dff07c Read */

#pragma aux rid parm [ecx] value [edx];
ULO rid(ULO address) {
  return 0xff;
}

/* VPOS - $dff02a Write */

#pragma aux wvpos parm [ecx] [edx];
void wvpos(ULO address, ULO data) {
  lof = data & 0x8000;
}

/* DIWSTRT - $dff08e Write */

#pragma aux wdiwstrt parm [ecx] [edx];
void wdiwstrt(ULO address, ULO data) {
  push_eax();
  diwstrt = data;
  diwytop = (data>>8) & 0xff;
  if (diwxright != 472) diwxleft = data & 0xff;
  else diwxleft = 88;
  calculate_window();
  pop_eax();
}

/* DIWSTOP - $dff090 Write */

#pragma aux wdiwstop parm [ecx] [edx];
void wdiwstop(ULO address, ULO data) {
  push_eax();
  diwybottom = (data>>8) & 0xff;
  diwstop = data;
  if (!(diwybottom & 0x80) /*&& (diwybottom <= 0x55)*/) diwybottom += 256;
  diwxright = (data & 0xff) + 256;
  if (diwxright >= 457) {
    diwxright = 472;
    diwxleft = 88;
    }
  else diwxleft = diwstrt & 0xff;
  calculate_window();
  pop_eax();
}
    
/* DDFSTRT - $dff092 Write */

#pragma aux wddfstrt parm [ecx] [edx];
void wddfstrt(ULO address, ULO data) {
  push_eax();
  ddfstrt = data & 0xfc;
  if (ddfstrt < 0x18) ddfstrt = 0x18;
  spriteddfkill = ddfstrt - 0x14;
  calculate_window();
  pop_eax();
}

/* DDFSTOP -  $dff094 Write */

#pragma aux wddfstop parm [ecx] [edx];
void wddfstop(ULO address, ULO data) {
  ddfstop = data & 0xfc;
  if (ddfstop > 0xd8) ddfstop = 0xd8;
  calculate_window();
}

/* BPL1PT - $dff0e0 */

#pragma aux wbpl1pth parm [ecx] [edx];
void wbpl1pth(ULO address, ULO data) {
  *(((UWO *)&bpl1pt)+1) = data & 0x1f;
}

#pragma aux wbpl1ptl parm [ecx] [edx];
void wbpl1ptl(ULO address, ULO data) {
  *((UWO *)&bpl1pt) = data & 0xfffe;
}

/* BPL2PT - $dff0e4 */

#pragma aux wbpl2pth parm [ecx] [edx];
void wbpl2pth(ULO address, ULO data) {
  *(((UWO *)&bpl2pt)+1) = data & 0x1f;
}

#pragma aux wbpl2ptl parm [ecx] [edx];
void wbpl2ptl(ULO address, ULO data) {
  *((UWO *)&bpl2pt) = data & 0xfffe;
}

/* bpl3PT - $dff0e8 */

#pragma aux wbpl3pth parm [ecx] [edx];
void wbpl3pth(ULO address, ULO data) {
  *(((UWO *)&bpl3pt)+1) = data & 0x1f;
}

#pragma aux wbpl3ptl parm [ecx] [edx];
void wbpl3ptl(ULO address, ULO data) {
  *((UWO *)&bpl3pt) = data & 0xfffe;
}

/* bpl4PT - $dff0ec */

#pragma aux wbpl4pth parm [ecx] [edx];
void wbpl4pth(ULO address, ULO data) {
  *(((UWO *)&bpl4pt)+1) = data & 0x1f;
}

#pragma aux wbpl4ptl parm [ecx] [edx];
void wbpl4ptl(ULO address, ULO data) {
  *((UWO *)&bpl4pt) = data & 0xfffe;
}

/* bpl5PT - $dff0f0 */

#pragma aux wbpl5pth parm [ecx] [edx];
void wbpl5pth(ULO address, ULO data) {
  *(((UWO *)&bpl5pt)+1) = data & 0x1f;
}

#pragma aux wbpl5ptl parm [ecx] [edx];
void wbpl5ptl(ULO address, ULO data) {
  *((UWO *)&bpl5pt) = data & 0xfffe;
}

/* bpl6PT - $dff0f4 */

#pragma aux wbpl6pth parm [ecx] [edx];
void wbpl6pth(ULO address, ULO data) {
  *(((UWO *)&bpl6pt)+1) = data & 0x1f;
}

#pragma aux wbpl6ptl parm [ecx] [edx];
void wbpl6ptl(ULO address, ULO data) {
  *((UWO *)&bpl6pt) = data & 0xfffe;
}

/* SPRXPOS - $dff140 to $dff178 */

#pragma aux wsprxpos parm [ecx] [edx];
void wsprxpos(ULO address, ULO data) {
  ULO sprnr;
  push_eax();
  sprnr = (address>>3) & 7;
  sprx[sprnr] = (sprx[sprnr] & 1) | ((data & 0xff)<<1);
  pop_eax();
}

/* SPRXCTL $dff142 to $dff17a */

#pragma aux wsprxctl parm [ecx] [edx];
void wsprxctl(ULO address, ULO data) {
  ULO sprnr;
  push_eax();
  sprnr = (address>>3) & 7;
  sprx[sprnr] = (sprx[sprnr] & 0x1fe) | (data & 1);
  if (sprnr & 1)
    spratt[sprnr & 6] = spratt[sprnr] = !!(data & 0x80);
  pop_eax();
}


/* SPRXDATA $dff144 to $dff17c */
/* The statestuff comes out pretty wrong..... */

#pragma aux wsprxdata parm [ecx] [edx];
void wsprxdata(ULO address, ULO data) {
  ULO sprnr;

  sprnr = (address>>3) & 7;
  *((UWO *) &sprdat[sprnr]) = data;
  if (ypos >= 0x1a) {
    if (spritestate[sprnr] <= 3)
      spritestateold[sprnr] = spritestate[sprnr];
    if (spritestate[sprnr] != 3 && spritestate[sprnr] != 5)
      spritestate[sprnr] = 4;
    else
      spritestate[sprnr] = 5;
    }
}

#pragma aux wsprxdatb parm [ecx] [edx];
void wsprxdatb(ULO address, ULO data) {
  ULO sprnr;

  sprnr = (address>>3) & 7;
  *(((UWO *) &sprdat[sprnr]) + 1) = data;
  if (ypos >= 0x1a) {
    if (spritestate[sprnr] <= 3)
      spritestateold[sprnr] = spritestate[sprnr];
    if (spritestate[sprnr] != 3 && spritestate[sprnr] != 5)
      spritestate[sprnr] = 4;
    else
      spritestate[sprnr] = 5;
    }
}



#ifdef GRAPHEM_C


/* COLOR - $dff180 to $dff1be */

#pragma aux wcolor parm [ecx] [edx];
void wcolor(ULO address, ULO data) {
  push_eax();
  data &= 0xfff;
  shadcol[(address - 0x180)>>1] = colortab[data];
  shadcol[((address - 0x180)>>1) + 32] = colortab[(data & 0xeee)>>1];
  pop_eax();
}

#pragma aux wcolorCC parm [ecx] [edx];
void wcolorCC(ULO address, ULO data) {
  int pos;
  push_eax();
  if (!cop_running_beyond_line) pos = xpos;
  else pos = xpos + 228;
  if ((pos*2) <= clipleftx || (ypos < cliptop) || (ypos >= clipbot))
    wcolor(address, data);
  else {
    delay_color[delay_color_total][0] = pos*2;
    delay_color[delay_color_total][1] = address;
    delay_color[delay_color_total++][2] = data;
    }
  pop_eax();
}

#else

#pragma aux wcolor parm [ecx] [edx];
extern void wcolor(ULO address, ULO data);

#endif

/* Really slow now, just to get the scheme working */

void process_delayed_colors(int untilpos) {
  while (delay_color_total != delay_color_processed &&
         delay_color[delay_color_processed][0] < untilpos) {
    wcolor(delay_color[delay_color_processed][1], delay_color[delay_color_processed][2]);
    delay_color_processed++;
    }
}

/* Used runtime to clear the counters for delayed writes */

void clear_delayed_colors(void) {
  delay_color_processed = delay_color_total = 0;
}




/* Routines optionally in assembler */

#ifdef PLANAR_C

/* Add modulo values */

void modulos(ULO planes) {
  switch (planes) {
    case 6: bpl6pt += bpl2mod;
    case 5: bpl5pt += bpl1mod;
    case 4: bpl4pt += bpl2mod;
    case 3: bpl3pt += bpl1mod;
    case 2: bpl2pt += bpl2mod;
    case 1: bpl1pt += bpl1mod;
    default:break;
  }
}


/* Planar to chunky conversion, these currently deals with complete lines */

/* Noop */

void decode0(void) {};

/* Lores, 1 plane */

void decode1(void) {
  UBY *b1p = cmem + bpl1pt;
  ptunion lp;
  UBY bdata;
  ULO chunky1,chunky2,i;

  if (DDFnumberofwords > 0) {
    lp.bptr = linje + DDFstartpos + ODDSHIFT;
    bpl1pt += DDFnumberofwords*2;
    for (i = 0; i < DDFnumberofwords; i++) {
      BCONVERT(chunky1,chunky2,bdata,(b1p++),deco1,P2C_SET);
      LINE_STORE(chunky1,chunky2,(lp.lptr + i*4));
      BCONVERT(chunky1,chunky2,bdata,(b1p++),deco1,P2C_SET);
      LINE_STORE(chunky1,chunky2,(lp.lptr + 2 + i*4));
    }
    modulos(1);
  }
}

/* Lores, 2 planes */

void decode2(void) {
  UBY *b1p = cmem + bpl1pt;
  UBY *b2p = cmem + bpl2pt;
  ptunion lp;
  UBY bdata;
  ULO chunky1,chunky2,i;

  if (DDFnumberofwords > 0) {
    lp.bptr = linje + DDFstartpos + ODDSHIFT;
    bpl1pt += DDFnumberofwords*2;
    bpl2pt += DDFnumberofwords*2;
    for (i = 0; i < DDFnumberofwords; i++) {
      BCONVERT(chunky1,chunky2,bdata,(b1p++),deco1,P2C_SET);
      LINE_STORE(chunky1,chunky2,(lp.lptr + i*4));
      BCONVERT(chunky1,chunky2,bdata,(b1p++),deco1,P2C_SET);
      LINE_STORE(chunky1,chunky2,(lp.lptr + 2 + i*4));
    }
    lp.bptr = linje + DDFstartpos + EVENSHIFT;
    for (i = 0; i < DDFnumberofwords; i++) {
      BCONVERT(chunky1,chunky2,bdata,(b2p++),deco2,P2C_SET);
      LINE_OR(chunky1,chunky2,(lp.lptr + i*4));
      BCONVERT(chunky1,chunky2,bdata,(b2p++),deco2,P2C_SET);
      LINE_OR(chunky1,chunky2,(lp.lptr + 2 + i*4));
    }
    modulos(2);
  }
}

/* Lores, 3 planes */

void decode3(void) {
  UBY *b1p = cmem + bpl1pt;
  UBY *b2p = cmem + bpl2pt;
  UBY *b3p = cmem + bpl3pt;
  ptunion lp;
  UBY bdata;
  ULO chunky1,chunky2,i;

  if (DDFnumberofwords > 0) {
    lp.bptr = linje + DDFstartpos + ODDSHIFT;
    bpl1pt += DDFnumberofwords*2;
    bpl2pt += DDFnumberofwords*2;
    bpl3pt += DDFnumberofwords*2;
    for (i = 0; i < DDFnumberofwords; i++) {
      BCONVERT(chunky1,chunky2,bdata,(b1p++),deco1,P2C_SET);
      BCONVERT(chunky1,chunky2,bdata,(b3p++),deco3,P2C_OR);
      LINE_STORE(chunky1,chunky2,(lp.lptr + i*4));
      BCONVERT(chunky1,chunky2,bdata,(b1p++),deco1,P2C_SET);
      BCONVERT(chunky1,chunky2,bdata,(b3p++),deco3,P2C_OR);
      LINE_STORE(chunky1,chunky2,(lp.lptr + 2 + i*4));
    }
    lp.bptr = linje + DDFstartpos + EVENSHIFT;
    for (i = 0; i < DDFnumberofwords; i++) {
      BCONVERT(chunky1,chunky2,bdata,(b2p++),deco2,P2C_SET);
      LINE_OR(chunky1,chunky2,(lp.lptr + i*4));
      BCONVERT(chunky1,chunky2,bdata,(b2p++),deco2,P2C_SET);
      LINE_OR(chunky1,chunky2,(lp.lptr + 2 + i*4));
    }
    modulos(3);
  }
}

/* Lores, 4 planes */

void decode4(void) {
  UBY *b1p = cmem + bpl1pt;
  UBY *b2p = cmem + bpl2pt;
  UBY *b3p = cmem + bpl3pt;
  UBY *b4p = cmem + bpl4pt;
  ptunion lp;
  UBY bdata;
  ULO chunky1,chunky2,i;

  if (DDFnumberofwords > 0) {
    lp.bptr = linje + DDFstartpos + ODDSHIFT;
    bpl1pt += DDFnumberofwords*2;
    bpl2pt += DDFnumberofwords*2;
    bpl3pt += DDFnumberofwords*2;
    bpl4pt += DDFnumberofwords*2;
    for (i = 0; i < DDFnumberofwords; i++) {
      BCONVERT(chunky1,chunky2,bdata,(b1p++),deco1,P2C_SET);
      BCONVERT(chunky1,chunky2,bdata,(b3p++),deco3,P2C_OR);
      LINE_STORE(chunky1,chunky2,(lp.lptr + i*4));
      BCONVERT(chunky1,chunky2,bdata,(b1p++),deco1,P2C_SET);
      BCONVERT(chunky1,chunky2,bdata,(b3p++),deco3,P2C_OR);
      LINE_STORE(chunky1,chunky2,(lp.lptr + 2 + i*4));
    }
    lp.bptr = linje + DDFstartpos + EVENSHIFT;
    for (i = 0; i < DDFnumberofwords; i++) {
      BCONVERT(chunky1,chunky2,bdata,(b2p++),deco2,P2C_SET);
      BCONVERT(chunky1,chunky2,bdata,(b4p++),deco4,P2C_OR);
      LINE_OR(chunky1,chunky2,(lp.lptr + i*4));
      BCONVERT(chunky1,chunky2,bdata,(b2p++),deco2,P2C_SET);
      BCONVERT(chunky1,chunky2,bdata,(b4p++),deco4,P2C_OR);
      LINE_OR(chunky1,chunky2,(lp.lptr + 2 + i*4));
    }
    modulos(4);
  }
}

/* Lores, 5 planes */

void decode5(void) {
  UBY *b1p = cmem + bpl1pt;
  UBY *b2p = cmem + bpl2pt;
  UBY *b3p = cmem + bpl3pt;
  UBY *b4p = cmem + bpl4pt;
  UBY *b5p = cmem + bpl5pt;
  ptunion lp;
  UBY bdata;
  ULO chunky1,chunky2,i;

  if (DDFnumberofwords > 0) {
    lp.bptr = linje + DDFstartpos + ODDSHIFT;
    bpl1pt += DDFnumberofwords*2;
    bpl2pt += DDFnumberofwords*2;
    bpl3pt += DDFnumberofwords*2;
    bpl4pt += DDFnumberofwords*2;
    bpl5pt += DDFnumberofwords*2;
    for (i = 0; i < DDFnumberofwords; i++) {
      BCONVERT(chunky1,chunky2,bdata,(b1p++),deco1,P2C_SET);
      BCONVERT(chunky1,chunky2,bdata,(b3p++),deco3,P2C_OR);
      BCONVERT(chunky1,chunky2,bdata,(b5p++),deco5,P2C_OR);
      LINE_STORE(chunky1,chunky2,(lp.lptr + i*4));
      BCONVERT(chunky1,chunky2,bdata,(b1p++),deco1,P2C_SET);
      BCONVERT(chunky1,chunky2,bdata,(b3p++),deco3,P2C_OR);
      BCONVERT(chunky1,chunky2,bdata,(b5p++),deco5,P2C_OR);
      LINE_STORE(chunky1,chunky2,(lp.lptr + 2 + i*4));
    }
    lp.bptr = linje + DDFstartpos + EVENSHIFT;
    for (i = 0; i < DDFnumberofwords; i++) {
      BCONVERT(chunky1,chunky2,bdata,(b2p++),deco2,P2C_SET);
      BCONVERT(chunky1,chunky2,bdata,(b4p++),deco4,P2C_OR);
      LINE_OR(chunky1,chunky2,(lp.lptr + i*4));
      BCONVERT(chunky1,chunky2,bdata,(b2p++),deco2,P2C_SET);
      BCONVERT(chunky1,chunky2,bdata,(b4p++),deco4,P2C_OR);
      LINE_OR(chunky1,chunky2,(lp.lptr + 2 + i*4));
    }
    modulos(5);
  }
}

/* Lores, 6 planes */

void decode6(void) {
  UBY *b1p = cmem + bpl1pt;
  UBY *b2p = cmem + bpl2pt;
  UBY *b3p = cmem + bpl3pt;
  UBY *b4p = cmem + bpl4pt;
  UBY *b5p = cmem + bpl5pt;
  UBY *b6p = cmem + bpl6pt;
  ptunion lp;
  UBY bdata;
  ULO chunky1,chunky2,i;

  if (DDFnumberofwords > 0) {
    lp.bptr = linje + DDFstartpos + ODDSHIFT;
    bpl1pt += DDFnumberofwords*2;
    bpl2pt += DDFnumberofwords*2;
    bpl3pt += DDFnumberofwords*2;
    bpl4pt += DDFnumberofwords*2;
    bpl5pt += DDFnumberofwords*2;
    bpl6pt += DDFnumberofwords*2;
    for (i = 0; i < DDFnumberofwords; i++) {
      BCONVERT(chunky1,chunky2,bdata,(b1p++),deco1,P2C_SET);
      BCONVERT(chunky1,chunky2,bdata,(b3p++),deco3,P2C_OR);
      BCONVERT(chunky1,chunky2,bdata,(b5p++),deco5,P2C_OR);
      LINE_STORE(chunky1,chunky2,(lp.lptr + i*4));
      BCONVERT(chunky1,chunky2,bdata,(b1p++),deco1,P2C_SET);
      BCONVERT(chunky1,chunky2,bdata,(b3p++),deco3,P2C_OR);
      BCONVERT(chunky1,chunky2,bdata,(b5p++),deco5,P2C_OR);
      LINE_STORE(chunky1,chunky2,(lp.lptr + 2 + i*4));
    }
    lp.bptr = linje + DDFstartpos + EVENSHIFT;
    for (i = 0; i < DDFnumberofwords; i++) {
      BCONVERT(chunky1,chunky2,bdata,(b2p++),deco2,P2C_SET);
      BCONVERT(chunky1,chunky2,bdata,(b4p++),deco4,P2C_OR);
      BCONVERT(chunky1,chunky2,bdata,(b6p++),deco6,P2C_OR);
      LINE_OR(chunky1,chunky2,(lp.lptr + i*4));
      BCONVERT(chunky1,chunky2,bdata,(b2p++),deco2,P2C_SET);
      BCONVERT(chunky1,chunky2,bdata,(b4p++),deco4,P2C_OR);
      BCONVERT(chunky1,chunky2,bdata,(b6p++),deco6,P2C_OR);
      LINE_OR(chunky1,chunky2,(lp.lptr + 2 + i*4));
    }
    modulos(6);
  }
}

/* Dual Lores, 2 planes */

void decodedual2(void) {
  UBY *b1p = cmem + bpl1pt;
  UBY *b2p = cmem + bpl2pt;
  ptunion lp;
  UBY bdata;
  ULO chunky1,chunky2,i;

  if (DDFnumberofwords > 0) {
    lp.bptr = linje + DDFstartpos + ODDSHIFT;
    bpl1pt += DDFnumberofwords*2;
    bpl2pt += DDFnumberofwords*2;
    for (i = 0; i < DDFnumberofwords; i++) {
      BCONVERT(chunky1,chunky2,bdata,(b1p++),deco1,P2C_SET);
      LINE_STORE(chunky1,chunky2,(lp.lptr + i*4));
      BCONVERT(chunky1,chunky2,bdata,(b1p++),deco1,P2C_SET);
      LINE_STORE(chunky1,chunky2,(lp.lptr + 2 + i*4));
    }
    lp.bptr = linje2 + DDFstartpos + EVENSHIFT;
    for (i = 0; i < DDFnumberofwords; i++) {
      BCONVERT(chunky1,chunky2,bdata,(b2p++),deco1,P2C_SET);
      LINE_STORE(chunky1,chunky2,(lp.lptr + i*4));
      BCONVERT(chunky1,chunky2,bdata,(b2p++),deco1,P2C_SET);
      LINE_STORE(chunky1,chunky2,(lp.lptr + 2 + i*4));
    }
    modulos(2);
  }
}

/* Lores, 3 planes */

void decodedual3(void) {
  UBY *b1p = cmem + bpl1pt;
  UBY *b2p = cmem + bpl2pt;
  UBY *b3p = cmem + bpl3pt;
  ptunion lp;
  UBY bdata;
  ULO chunky1,chunky2,i;

  if (DDFnumberofwords > 0) {
    lp.bptr = linje + DDFstartpos + ODDSHIFT;
    bpl1pt += DDFnumberofwords*2;
    bpl2pt += DDFnumberofwords*2;
    bpl3pt += DDFnumberofwords*2;
    for (i = 0; i < DDFnumberofwords; i++) {
      BCONVERT(chunky1,chunky2,bdata,(b1p++),deco1,P2C_SET);
      BCONVERT(chunky1,chunky2,bdata,(b3p++),deco2,P2C_OR);
      LINE_STORE(chunky1,chunky2,(lp.lptr + i*4));
      BCONVERT(chunky1,chunky2,bdata,(b1p++),deco1,P2C_SET);
      BCONVERT(chunky1,chunky2,bdata,(b3p++),deco2,P2C_OR);
      LINE_STORE(chunky1,chunky2,(lp.lptr + 2 + i*4));
    }
    lp.bptr = linje2 + DDFstartpos + EVENSHIFT;
    for (i = 0; i < DDFnumberofwords; i++) {
      BCONVERT(chunky1,chunky2,bdata,(b2p++),deco1,P2C_SET);
      LINE_STORE(chunky1,chunky2,(lp.lptr + i*4));
      BCONVERT(chunky1,chunky2,bdata,(b2p++),deco1,P2C_SET);
      LINE_STORE(chunky1,chunky2,(lp.lptr + 2 + i*4));
    }
    modulos(3);
  }
}

/* Lores, 4 planes */

void decodedual4(void) {
  UBY *b1p = cmem + bpl1pt;
  UBY *b2p = cmem + bpl2pt;
  UBY *b3p = cmem + bpl3pt;
  UBY *b4p = cmem + bpl4pt;
  ptunion lp;
  UBY bdata;
  ULO chunky1,chunky2,i;

  if (DDFnumberofwords > 0) {
    lp.bptr = linje + DDFstartpos + ODDSHIFT;
    bpl1pt += DDFnumberofwords*2;
    bpl2pt += DDFnumberofwords*2;
    bpl3pt += DDFnumberofwords*2;
    bpl4pt += DDFnumberofwords*2;
    for (i = 0; i < DDFnumberofwords; i++) {
      BCONVERT(chunky1,chunky2,bdata,(b1p++),deco1,P2C_SET);
      BCONVERT(chunky1,chunky2,bdata,(b3p++),deco2,P2C_OR);
      LINE_STORE(chunky1,chunky2,(lp.lptr + i*4));
      BCONVERT(chunky1,chunky2,bdata,(b1p++),deco1,P2C_SET);
      BCONVERT(chunky1,chunky2,bdata,(b3p++),deco2,P2C_OR);
      LINE_STORE(chunky1,chunky2,(lp.lptr + 2 + i*4));
    }
    lp.bptr = linje2 + DDFstartpos + EVENSHIFT;
    for (i = 0; i < DDFnumberofwords; i++) {
      BCONVERT(chunky1,chunky2,bdata,(b2p++),deco1,P2C_SET);
      BCONVERT(chunky1,chunky2,bdata,(b4p++),deco2,P2C_OR);
      LINE_STORE(chunky1,chunky2,(lp.lptr + i*4));
      BCONVERT(chunky1,chunky2,bdata,(b2p++),deco1,P2C_SET);
      BCONVERT(chunky1,chunky2,bdata,(b4p++),deco2,P2C_OR);
      LINE_STORE(chunky1,chunky2,(lp.lptr + 2 + i*4));
    }
    modulos(4);
  }
}

/* Lores, 5 planes */

void decodedual5(void) {
  UBY *b1p = cmem + bpl1pt;
  UBY *b2p = cmem + bpl2pt;
  UBY *b3p = cmem + bpl3pt;
  UBY *b4p = cmem + bpl4pt;
  UBY *b5p = cmem + bpl5pt;
  ptunion lp;
  UBY bdata;
  ULO chunky1,chunky2,i;

  if (DDFnumberofwords > 0) {
    lp.bptr = linje + DDFstartpos + ODDSHIFT;
    bpl1pt += DDFnumberofwords*2;
    bpl2pt += DDFnumberofwords*2;
    bpl3pt += DDFnumberofwords*2;
    bpl4pt += DDFnumberofwords*2;
    bpl5pt += DDFnumberofwords*2;
    for (i = 0; i < DDFnumberofwords; i++) {
      BCONVERT(chunky1,chunky2,bdata,(b1p++),deco1,P2C_SET);
      BCONVERT(chunky1,chunky2,bdata,(b3p++),deco2,P2C_OR);
      BCONVERT(chunky1,chunky2,bdata,(b5p++),deco3,P2C_OR);
      LINE_STORE(chunky1,chunky2,(lp.lptr + i*4));
      BCONVERT(chunky1,chunky2,bdata,(b1p++),deco1,P2C_SET);
      BCONVERT(chunky1,chunky2,bdata,(b3p++),deco2,P2C_OR);
      BCONVERT(chunky1,chunky2,bdata,(b5p++),deco3,P2C_OR);
      LINE_STORE(chunky1,chunky2,(lp.lptr + 2 + i*4));
    }
    lp.bptr = linje2 + DDFstartpos + EVENSHIFT;
    for (i = 0; i < DDFnumberofwords; i++) {
      BCONVERT(chunky1,chunky2,bdata,(b2p++),deco1,P2C_SET);
      BCONVERT(chunky1,chunky2,bdata,(b4p++),deco2,P2C_OR);
      LINE_STORE(chunky1,chunky2,(lp.lptr + i*4));
      BCONVERT(chunky1,chunky2,bdata,(b2p++),deco1,P2C_SET);
      BCONVERT(chunky1,chunky2,bdata,(b4p++),deco2,P2C_OR);
      LINE_STORE(chunky1,chunky2,(lp.lptr + 2 + i*4));
    }
    modulos(5);
  }
}

/* Lores, 6 planes */

void decodedual6(void) {
  UBY *b1p = cmem + bpl1pt;
  UBY *b2p = cmem + bpl2pt;
  UBY *b3p = cmem + bpl3pt;
  UBY *b4p = cmem + bpl4pt;
  UBY *b5p = cmem + bpl5pt;
  UBY *b6p = cmem + bpl6pt;
  ptunion lp;
  UBY bdata;
  ULO chunky1,chunky2,i;

  if (DDFnumberofwords > 0) {
    lp.bptr = linje + DDFstartpos + ODDSHIFT;
    bpl1pt += DDFnumberofwords*2;
    bpl2pt += DDFnumberofwords*2;
    bpl3pt += DDFnumberofwords*2;
    bpl4pt += DDFnumberofwords*2;
    bpl5pt += DDFnumberofwords*2;
    bpl6pt += DDFnumberofwords*2;
    for (i = 0; i < DDFnumberofwords; i++) {
      BCONVERT(chunky1,chunky2,bdata,(b1p++),deco1,P2C_SET);
      BCONVERT(chunky1,chunky2,bdata,(b3p++),deco2,P2C_OR);
      BCONVERT(chunky1,chunky2,bdata,(b5p++),deco3,P2C_OR);
      LINE_STORE(chunky1,chunky2,(lp.lptr + i*4));
      BCONVERT(chunky1,chunky2,bdata,(b1p++),deco1,P2C_SET);
      BCONVERT(chunky1,chunky2,bdata,(b3p++),deco2,P2C_OR);
      BCONVERT(chunky1,chunky2,bdata,(b5p++),deco3,P2C_OR);
      LINE_STORE(chunky1,chunky2,(lp.lptr + 2 + i*4));
    }
    lp.bptr = linje2 + DDFstartpos + EVENSHIFT;
    for (i = 0; i < DDFnumberofwords; i++) {
      BCONVERT(chunky1,chunky2,bdata,(b2p++),deco1,P2C_SET);
      BCONVERT(chunky1,chunky2,bdata,(b4p++),deco2,P2C_OR);
      BCONVERT(chunky1,chunky2,bdata,(b6p++),deco3,P2C_OR);
      LINE_STORE(chunky1,chunky2,(lp.lptr + i*4));
      BCONVERT(chunky1,chunky2,bdata,(b2p++),deco1,P2C_SET);
      BCONVERT(chunky1,chunky2,bdata,(b4p++),deco2,P2C_OR);
      BCONVERT(chunky1,chunky2,bdata,(b6p++),deco3,P2C_OR);
      LINE_STORE(chunky1,chunky2,(lp.lptr + 2 + i*4));
    }
    modulos(6);
  }
}

/* Hires on lores, 1 plane */

void decode320hi1(void) {
  UBY *b1p = cmem + bpl1pt;
  ptunion lp;
  UBY bdata;
  ULO chunky,i;

  if (DDFnumberofwords > 0) {
    lp.bptr = linje + (DDFstartpos>>1) + (oddhiscroll>>1);
    bpl1pt += DDFnumberofwords*2;
    for (i = 0; i < DDFnumberofwords; i++) {
      BCONVERT_320(chunky,bdata,(b1p++),deco320hi1,P2C_SET_320);
      LINE_STORE_320(chunky,(lp.lptr + i*2));
      BCONVERT_320(chunky,bdata,(b1p++),deco320hi1,P2C_SET_320);
      LINE_STORE_320(chunky,(lp.lptr + 1 + i*2));
    }
    modulos(1);
  }
}

/* Hires on Lores, 2 planes */

void decode320hi2(void) {
  UBY *b1p = cmem + bpl1pt;
  UBY *b2p = cmem + bpl2pt;
  ptunion lp;
  UBY bdata;
  ULO chunky,i;

  if (DDFnumberofwords > 0) {
    lp.bptr = linje + (DDFstartpos>>1) + (oddhiscroll>>1);
    bpl1pt += DDFnumberofwords*2;
    bpl2pt += DDFnumberofwords*2;
    for (i = 0; i < DDFnumberofwords; i++) {
      BCONVERT_320(chunky,bdata,(b1p++),deco320hi1,P2C_SET_320);
      LINE_STORE_320(chunky,(lp.lptr + i*2));
      BCONVERT_320(chunky,bdata,(b1p++),deco320hi1,P2C_SET_320);
      LINE_STORE_320(chunky,(lp.lptr + 1 + i*2));
    }
    lp.bptr = linje + (DDFstartpos>>1) + (evenhiscroll>>1);
    for (i = 0; i < DDFnumberofwords; i++) {
      BCONVERT_320(chunky,bdata,(b2p++),deco320hi2,P2C_SET_320);
      LINE_OR_320(chunky,(lp.lptr + i*2));
      BCONVERT_320(chunky,bdata,(b2p++),deco320hi2,P2C_SET_320);
      LINE_OR_320(chunky,(lp.lptr + 1 + i*2));
    }
    modulos(2);
  }
}

/* Hires on Lores, 3 planes */

void decode320hi3(void) {
  UBY *b1p = cmem + bpl1pt;
  UBY *b2p = cmem + bpl2pt;
  UBY *b3p = cmem + bpl3pt;
  ptunion lp;
  UBY bdata;
  ULO chunky,i;

  if (DDFnumberofwords > 0) {
    lp.bptr = linje + (DDFstartpos>>1) + (oddhiscroll>>1);
    bpl1pt += DDFnumberofwords*2;
    bpl2pt += DDFnumberofwords*2;
    bpl3pt += DDFnumberofwords*2;
    for (i = 0; i < DDFnumberofwords; i++) {
      BCONVERT_320(chunky,bdata,(b1p++),deco320hi1,P2C_SET_320);
      BCONVERT_320(chunky,bdata,(b3p++),deco320hi3,P2C_OR_320);
      LINE_STORE_320(chunky,(lp.lptr + i*2));
      BCONVERT_320(chunky,bdata,(b1p++),deco320hi1,P2C_SET_320);
      BCONVERT_320(chunky,bdata,(b3p++),deco320hi3,P2C_OR_320);
      LINE_STORE_320(chunky,(lp.lptr + 1 + i*2));
    }
    lp.bptr = linje + (DDFstartpos>>1) + (evenhiscroll>>1);
    for (i = 0; i < DDFnumberofwords; i++) {
      BCONVERT_320(chunky,bdata,(b2p++),deco320hi2,P2C_SET_320);
      LINE_OR_320(chunky,(lp.lptr + i*2));
      BCONVERT_320(chunky,bdata,(b2p++),deco320hi2,P2C_SET_320);
      LINE_OR_320(chunky,(lp.lptr + 1 + i*2));
    }
    modulos(3);
  }
}

/* Hires on Lores, 4 planes */

void decode320hi4(void) {
  UBY *b1p = cmem + bpl1pt;
  UBY *b2p = cmem + bpl2pt;
  UBY *b3p = cmem + bpl3pt;
  UBY *b4p = cmem + bpl4pt;
  ptunion lp;
  UBY bdata;
  ULO chunky,i;

  if (DDFnumberofwords > 0) {
    lp.bptr = linje + (DDFstartpos>>1) + (oddhiscroll>>1);
    bpl1pt += DDFnumberofwords*2;
    bpl2pt += DDFnumberofwords*2;
    bpl3pt += DDFnumberofwords*2;
    bpl4pt += DDFnumberofwords*2;
    for (i = 0; i < DDFnumberofwords; i++) {
      BCONVERT_320(chunky,bdata,(b1p++),deco320hi1,P2C_SET_320);
      BCONVERT_320(chunky,bdata,(b3p++),deco320hi3,P2C_OR_320);
      LINE_STORE_320(chunky,(lp.lptr + i*2));
      BCONVERT_320(chunky,bdata,(b1p++),deco320hi1,P2C_SET_320);
      BCONVERT_320(chunky,bdata,(b3p++),deco320hi3,P2C_OR_320);
      LINE_STORE_320(chunky,(lp.lptr + 1 + i*2));
    }
    lp.bptr = linje + (DDFstartpos>>1) + (evenhiscroll>>1);
    for (i = 0; i < DDFnumberofwords; i++) {
      BCONVERT_320(chunky,bdata,(b2p++),deco320hi2,P2C_SET_320);
      BCONVERT_320(chunky,bdata,(b4p++),deco320hi4,P2C_OR_320);
      LINE_OR_320(chunky,(lp.lptr + i*2));
      BCONVERT_320(chunky,bdata,(b2p++),deco320hi2,P2C_SET_320);
      BCONVERT_320(chunky,bdata,(b4p++),deco320hi4,P2C_OR_320);
      LINE_OR_320(chunky,(lp.lptr + 1 + i*2));
    }
    modulos(4);
  }
}

/* Dual Hires on Lores, 2 planes */

void decodedual320hi2(void) {
  UBY *b1p = cmem + bpl1pt;
  UBY *b2p = cmem + bpl2pt;
  ptunion lp;
  UBY bdata;
  ULO chunky,i;

  if (DDFnumberofwords > 0) {
    lp.bptr = linje + (DDFstartpos>>1) + (oddhiscroll>>1);
    bpl1pt += DDFnumberofwords*2;
    bpl2pt += DDFnumberofwords*2;
    for (i = 0; i < DDFnumberofwords; i++) {
      BCONVERT_320(chunky,bdata,(b1p++),deco320hi1,P2C_SET_320);
      LINE_STORE_320(chunky,(lp.lptr + i*2));
      BCONVERT_320(chunky,bdata,(b1p++),deco320hi1,P2C_SET_320);
      LINE_STORE_320(chunky,(lp.lptr + 1 + i*2));
    }
    lp.bptr = linje2 + (DDFstartpos>>1) + (evenhiscroll>>1);
    for (i = 0; i < DDFnumberofwords; i++) {
      BCONVERT_320(chunky,bdata,(b2p++),deco320hi1,P2C_SET_320);
      LINE_STORE_320(chunky,(lp.lptr + i*2));
      BCONVERT_320(chunky,bdata,(b2p++),deco320hi1,P2C_SET_320);
      LINE_STORE_320(chunky,(lp.lptr + 1 + i*2));
    }
    modulos(2);
  }
}

/* Dual Hires on Lores, 3 planes */

void decodedual320hi3(void) {
  UBY *b1p = cmem + bpl1pt;
  UBY *b2p = cmem + bpl2pt;
  UBY *b3p = cmem + bpl3pt;
  ptunion lp;
  UBY bdata;
  ULO chunky,i;

  if (DDFnumberofwords > 0) {
    lp.bptr = linje + (DDFstartpos>>1) + (oddhiscroll>>1);
    bpl1pt += DDFnumberofwords*2;
    bpl2pt += DDFnumberofwords*2;
    bpl3pt += DDFnumberofwords*2;
    for (i = 0; i < DDFnumberofwords; i++) {
      BCONVERT_320(chunky,bdata,(b1p++),deco320hi1,P2C_SET_320);
      BCONVERT_320(chunky,bdata,(b3p++),deco320hi2,P2C_OR_320);
      LINE_STORE_320(chunky,(lp.lptr + i*2));
      BCONVERT_320(chunky,bdata,(b1p++),deco320hi1,P2C_SET_320);
      BCONVERT_320(chunky,bdata,(b3p++),deco320hi2,P2C_OR_320);
      LINE_STORE_320(chunky,(lp.lptr + 1 + i*2));
    }
    lp.bptr = linje2 + (DDFstartpos>>1) + (evenhiscroll>>1);
    for (i = 0; i < DDFnumberofwords; i++) {
      BCONVERT_320(chunky,bdata,(b2p++),deco320hi1,P2C_SET_320);
      LINE_STORE_320(chunky,(lp.lptr + i*2));
      BCONVERT_320(chunky,bdata,(b2p++),deco320hi1,P2C_SET_320);
      LINE_STORE_320(chunky,(lp.lptr + 1 + i*2));
    }
    modulos(3);
  }
}

/* Dual Hires on Lores, 4 planes */

void decodedual320hi4(void) {
  UBY *b1p = cmem + bpl1pt;
  UBY *b2p = cmem + bpl2pt;
  UBY *b3p = cmem + bpl3pt;
  UBY *b4p = cmem + bpl4pt;
  ptunion lp;
  UBY bdata;
  ULO chunky,i;

  if (DDFnumberofwords > 0) {
    lp.bptr = linje + (DDFstartpos>>1) + (oddhiscroll>>1);
    bpl1pt += DDFnumberofwords*2;
    bpl2pt += DDFnumberofwords*2;
    bpl3pt += DDFnumberofwords*2;
    bpl4pt += DDFnumberofwords*2;
    for (i = 0; i < DDFnumberofwords; i++) {
      BCONVERT_320(chunky,bdata,(b1p++),deco320hi1,P2C_SET_320);
      BCONVERT_320(chunky,bdata,(b3p++),deco320hi2,P2C_OR_320);
      LINE_STORE_320(chunky,(lp.lptr + i*2));
      BCONVERT_320(chunky,bdata,(b1p++),deco320hi1,P2C_SET_320);
      BCONVERT_320(chunky,bdata,(b3p++),deco320hi2,P2C_OR_320);
      LINE_STORE_320(chunky,(lp.lptr + 1 + i*2));
    }
    lp.bptr = linje2 + (DDFstartpos>>1) + (evenhiscroll>>1);
    for (i = 0; i < DDFnumberofwords; i++) {
      BCONVERT_320(chunky,bdata,(b2p++),deco320hi1,P2C_SET_320);
      BCONVERT_320(chunky,bdata,(b4p++),deco320hi2,P2C_OR_320);
      LINE_STORE_320(chunky,(lp.lptr + i*2));
      BCONVERT_320(chunky,bdata,(b2p++),deco320hi1,P2C_SET_320);
      BCONVERT_320(chunky,bdata,(b4p++),deco320hi2,P2C_OR_320);
      LINE_STORE_320(chunky,(lp.lptr + 1 + i*2));
    }
    modulos(4);
  }
}

#endif

/* Centering changed */

void do_center(void) {
  if (center_code == 80) {
    if (cliptop > 0x1a) {
      cliptop--;
      clipbot--;
      draw_init_lineflagstables();
      }
    }
  else if (center_code == 72) {
    if (clipbot < 0x139) {
      cliptop++;
      clipbot++;
      draw_init_lineflagstables();
      }
    }
  else if (center_code == 75) {
    if (cliprightx < 472) {
      cliprightx++;
      clipleftx++;
      draw_init_lineflagstables();
      }
    }
  else if (center_code == 77) {
    if (clipleftx > 88) {
      cliprightx--;
      clipleftx--;
      draw_init_lineflagstables();
      }
    }
  center_code = 0;
}




/* Set up tables */

void graphem_init_delayed_colors(void) {
  int i;
  delay_color_total = delay_color_processed = 0;
  for (i = 0; i < 200; i++)
    delay_color[i][0] = delay_color[i][1] = delay_color[i][2] = 0;
}





void graphem_init_spritetranslation_table(void) {
  int i,j,k,l;
  for (k = 0; k < 2; k++) {
    for (i = 0; i < 256; i++) {
      for (j = 0; j < 256; j++) {
        if (k == 0) l = (i == 0) ? j:i;
        else l = (j == 0) ? i:j;
        spritetranslate[k][i][j] = l;
        }
      }
    }
}

void graphem_init_linearrays(void) {
  int i;
  for (i = 0; i < 1000; i++) linje[i] = linje2[i] = 0;
}

void graphem_init_p2c_tables(void) {
  ULO i,j,d[2];
  for(i = 0; i < 256; i++) {
    d[0] = d[1] = 0;
    for(j = 0; j < 4; j++) {
      d[0] |= ((i & (0x80>>j))>>(4 + 3 - j))<<(j*8);
      d[1] |= ((i & (0x8>>j))>>(3 - j))<<(j*8);
      }
    for (j = 0; j < 2; j++) {
      deco1[i][j] = d[j]<<2;
      deco2[i][j] = d[j]<<3;
      deco3[i][j] = d[j]<<4;
      deco4[i][j] = d[j]<<5;
      deco5[i][j] = d[j]<<6;
      deco6[i][j] = d[j]<<7;
      }
    deco320hi1[i] = ((d[0] & 0xff) | ((d[0] & 0xff0000)>>8) |
		     ((d[1] & 0xff)<<16) | ((d[1] & 0xff0000)<<8))<<2;
    deco320hi2[i] = deco320hi1[i]<<1;
    deco320hi3[i] = deco320hi1[i]<<2;
    deco320hi4[i] = deco320hi1[i]<<3;
    }
  for(i = 0; i < 256; i++) 
    for(j = 0; j < 8; j++) {
      decosc01[i][j] =  (i & (0x80>>j)) == 0 ? 0:0x44;
      decosc02[i][j] =  (i & (0x80>>j)) == 0 ? 0:0x48;
      decosc03[i][j] =  (i & (0x80>>j)) == 0 ? 0:0x50;
      decosc04[i][j] =  (i & (0x80>>j)) == 0 ? 0:0x60;
      decosc11[i][j] =  (i & (0x80>>j)) == 0 ? 0:0x54;
      decosc12[i][j] =  (i & (0x80>>j)) == 0 ? 0:0x58;
      decosc21[i][j] =  (i & (0x80>>j)) == 0 ? 0:0x64;
      decosc22[i][j] =  (i & (0x80>>j)) == 0 ? 0:0x68;
      decosc31[i][j] =  (i & (0x80>>j)) == 0 ? 0:0x74;
      decosc32[i][j] =  (i & (0x80>>j)) == 0 ? 0:0x78;
      }
}

/* Decode tables for lores size displays */

void graphem_init_p2c_320(void) {
  decoderoutinetab[0] = decode0;
  decoderoutinetab[1] = decode1;
  decoderoutinetab[2] = decode2;
  decoderoutinetab[3] = decode3;
  decoderoutinetab[4] = decode4;
  decoderoutinetab[5] = decode5;
  decoderoutinetab[6] = decode6;
  decoderoutinetab[7] = decode0;
  decoderoutinetab[8] = decode0;
  decoderoutinetab[9] = decode320hi1;
  decoderoutinetab[10] = decode320hi2;
  decoderoutinetab[11] = decode320hi3;
  decoderoutinetab[12] = decode320hi4;
  decoderoutinetab[13] = decode0;
  decoderoutinetab[14] = decode0;
  decoderoutinetab[15] = decode0;
  decoderoutinedualtab[0] = decode0;
  decoderoutinedualtab[1] = decode1;
  decoderoutinedualtab[2] = decodedual2;
  decoderoutinedualtab[3] = decodedual3;
  decoderoutinedualtab[4] = decodedual4;
  decoderoutinedualtab[5] = decodedual5;
  decoderoutinedualtab[6] = decodedual6;
  decoderoutinedualtab[7] = decode0;
  decoderoutinedualtab[8] = decode0;
  decoderoutinedualtab[9] = decode320hi1;
  decoderoutinedualtab[10] = decodedual320hi2;
  decoderoutinedualtab[11] = decodedual320hi3;
  decoderoutinedualtab[12] = decodedual320hi4;
  decoderoutinedualtab[13] = decode0;
  decoderoutinedualtab[14] = decode0;
  decoderoutinedualtab[15] = decode0;
}

/* Decode tables for hires size tables */

void graphem_init_p2c_800(void) {
  decoderoutinetab[0] = decode0;
  decoderoutinetab[1] = decode1;
  decoderoutinetab[2] = decode2;
  decoderoutinetab[3] = decode3;
  decoderoutinetab[4] = decode4;
  decoderoutinetab[5] = decode5;
  decoderoutinetab[6] = decode6;
  decoderoutinetab[7] = decode0;
  decoderoutinetab[8] = decode0;
  decoderoutinetab[9] = decode1;
  decoderoutinetab[10] = decode2;
  decoderoutinetab[11] = decode3;
  decoderoutinetab[12] = decode4;
  decoderoutinetab[13] = decode0;
  decoderoutinetab[14] = decode0;
  decoderoutinetab[15] = decode0;
  decoderoutinedualtab[0] = decode0;
  decoderoutinedualtab[1] = decode1;
  decoderoutinedualtab[2] = decodedual2;
  decoderoutinedualtab[3] = decodedual3;
  decoderoutinedualtab[4] = decodedual4;
  decoderoutinedualtab[5] = decodedual5;
  decoderoutinedualtab[6] = decodedual6;
  decoderoutinedualtab[7] = decode0;
  decoderoutinedualtab[8] = decode0;
  decoderoutinedualtab[9] = decode1;
  decoderoutinedualtab[10] = decodedual2;
  decoderoutinedualtab[11] = decodedual3;
  decoderoutinedualtab[12] = decodedual4;
  decoderoutinedualtab[13] = decode0;
  decoderoutinedualtab[14] = decode0;
  decoderoutinedualtab[15] = decode0;
}

void graphem_init_tables(void) {
  graphem_init_linearrays();
  graphem_init_p2c_tables();
  graphem_init_delayed_colors();
  graphem_init_spritetranslation_table();
  decoderoutineptr = decode0;
  spriteddfkill = 32;
  sprite_delay = 40;
  playfieldon = 0;
}

