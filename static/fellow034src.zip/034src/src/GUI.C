/*=============================*/
/* Fellow Amiga Emulator       */
/* GUI core                    */
/* (C) 1997-1998 Petter Schau  */
/*           and Roman Dolejsi */
/*=============================*/


#include <stdio.h>
#include <conio.h>
#include <direct.h>
#include <dos.h>
#include <string.h>

#include "defs.h"
#include "fellow.h"
#include "gui.h"

#ifdef USE_GUI


STR memnames[10][256];    /* Disk memories */
STR config_diskpath[256]; /* Saved disk path */
ULO config_altn_loop;      /* Alt-N drive cycling */
ULO config_store_mpos;     /* Menu position storing on exit */
ULO config_autorun;        /* Automatic Run after command */
STR *gui_horline;
STR *gui_spcline;
BOOLE gui_exitflag;


STR act_item[256];

STR gui_shortcut_global_want[256];
STR *gui_shortcut_global_next;
BOOLE gui_shortcut_global_selected, gui_shortcut_global_up;

/* text buffer for various operations */

static STR gtxt[256];


/*==========================*/
/* Window specific routines */
/*==========================*/


/*==============*/
/* Clear window */
/*==============*/

void guiWindowClear(struct gui_window *w, BOOLE borderclear) {
  conRectFill(w->x1 + (borderclear ? 0 : 1),
	      w->y1 + (borderclear ? 0 : 1),
	      w->x2 - w->x1 + 1 - (borderclear ? 0 : 2),
	      w->y2 - w->y1 + 1 - (borderclear ? 0 : 2),
	      w->bgcolor,
	      gui_spcline);
}


/*==========================*/
/* Draw borders of a window */
/*==========================*/

void guiWindowBorderPlot(struct gui_window *w) {
  ULO i;
  STR *horline = gui_horline + con_maxcols - w->x2 + w->x1 + 1;

  conTextPlot((w->cornerflags & TOPLEFT) ? CON_UP_RIGHT_DOWN : CON_RIGHT_DOWN,
	      w->x1, w->y1, BORDERCOL, w->bgcolor);
  conTextPlot((w->cornerflags & BOTLEFT) ? CON_UP_RIGHT_LEFT : CON_UP_RIGHT,
	      w->x1, w->y2, BORDERCOL, w->bgcolor);
  conTextPlot((w->cornerflags & TOPRIGHT) ? CON_UP_DOWN_LEFT : CON_DOWN_LEFT,
	      w->x2, w->y1, BORDERCOL, w->bgcolor);
  conTextPlot(CON_UP_LEFT, w->x2, w->y2, BORDERCOL, w->bgcolor);
  for (i = w->y1 + 1; i < w->y2; i++) {
    conTextPlot(CON_UP_DOWN, w->x1, i, BORDERCOL, w->bgcolor);
    conTextPlot(CON_UP_DOWN, w->x2, i, BORDERCOL, w->bgcolor);
    }
  conTextPlot(horline, w->x1 + 1, w->y1, BORDERCOL, w->bgcolor);
  conTextPlot(horline, w->x1 + 1, w->y2, BORDERCOL, w->bgcolor);
}


/*========================================*/
/* Plot text in window, normal or reverse */
/*========================================*/

void guiWindowTextPlot(struct gui_window *w, STR *s, ULO x, ULO y) {
  conTextPlot(s, x + w->x1, y + w->y1, w->fgcolor, w->bgcolor);
}

void guiWindowTextPlotShortcut(struct gui_window *w, STR *s, ULO x, ULO y,
			       ULO shortcutpos) {
  ULO i = s[shortcutpos];

  s[shortcutpos] = 0;
  conTextPlot(s, x + w->x1, y + w->y1, w->fgcolor, w->bgcolor);
  conTextPlot(&s[shortcutpos + 1], x + w->x1 + shortcutpos + 1, y + w->y1,
	      w->fgcolor, w->bgcolor);
  s[shortcutpos] = i;
  i = s[shortcutpos + 1];
  s[shortcutpos + 1] = 0;
  conTextPlot(&s[shortcutpos], x + w->x1 + shortcutpos, y + w->y1,
	      w->shortcutcolor, w->bgcolor);
  s[shortcutpos + 1] = i;
}

void guiWindowTextPlotReverse(struct gui_window *w, STR *s, ULO x, ULO y) {
  conTextPlot(s, x + w->x1, y + w->y1, w->fgcolor, 7);
}

void guiWindowTextPlotReverseShortcut(struct gui_window *w, STR *s, ULO x,
				      ULO y, ULO shortcutpos) {
  ULO i = s[shortcutpos];

  s[shortcutpos] = 0;
  conTextPlot(s, x + w->x1, y + w->y1, w->fgcolor, w->reversecolor);
  conTextPlot(&s[shortcutpos + 1], x + w->x1 + shortcutpos + 1, y + w->y1,
	      w->fgcolor, w->reversecolor);
  s[shortcutpos] = i;
  i = s[shortcutpos + 1];
  s[shortcutpos + 1] = 0;
  conTextPlot(&s[shortcutpos], x + w->x1 + shortcutpos, y + w->y1,
	      w->shortcutcolor, w->reversecolor);
  s[shortcutpos + 1] = i;
}


/*=================================================*/
/* Clear area to the right of a string in a window */
/*=================================================*/

void guiSpacesToEOL(struct gui_window *w, STR *s, ULO y) {
  ULO j = strlen(s);
  STR *spcline = gui_spcline + con_maxcols - j;
  
  guiWindowTextPlot(w, spcline, j + 1, y);
}


/*==============*/
/* Number field */
/*==============*/

/* A number field has 6 properties:
   --------------------------------
   struct gui_window hostwindow - Host window
   ULO               value      - Current value
   ULO               x          - X coordinate
   ULO               y          - Y coordinate
   BOOLE             hex        - Flag, value is hex  */


void guiFieldNumberInit(struct gui_numberfield *n, struct gui_window *w,
			 ULO v, ULO x, ULO y, ULO hex) {
  n->hostwindow = w;
  n->x = x;
  n->y = y;
  n->hex = hex;
  n->value = v;
}

void guiFieldCharRemove(STR *text) {
  text[strlen(text) - 1] = '\0';
}

void guiFieldCharAdd(STR *text, ULO c) {
  ULO len = strlen(text);
  
  text[len] = c;
  text[len + 1] = '\0';
}

void guiFieldPlot(struct gui_window *w, ULO x, ULO y, STR *current) {
  ULO len = strlen(current);
  
  current[len] = ' ';
  current[len + 1] = '\0';
  guiWindowTextPlot(w, current, x, y);
  current[len] = '\0';
}

BOOLE guiFieldNumberEnter(struct gui_numberfield *n) {
  STR number[10];
  BOOLE finished;
  ULO cursor, c;

  finished = FALSE;
  if (n->value == 0) number[0] = '\0';
  else sprintf(number, n->hex ? "%X" : "%d", n->value);
  cursor = strlen(number);
  while (!finished) {
    guiFieldPlot(n->hostwindow, n->x, n->y, number);
    c = getch();
    if (c == 13) finished = TRUE; /* RET */
    else if (c == 27) return FALSE;
    else if ((c >= '0' && c <= '9') || (n->hex && (c >= 'a' && c <= 'f'))) {
      if (cursor < 9) {
	guiFieldCharAdd(number, c);
	cursor++;
      }
    }
    else if (c == 8) {  /* DEL */
      if (cursor > 0) {
	guiFieldCharRemove(number);
	cursor--;
      }
    }
  }
  if (cursor == 0) n->value = 0;
  else sscanf(number, n->hex ? "%X" : "%d", &(n->value));
  return TRUE;
}


/*============*/
/* Text field */
/*============*/

/* A text field has 6 properties:
   ------------------------------
   struct gui_window* hostwindow - Host window
   STR*               value      - Current text
   ULO                x          - X coordinate
   ULO                y          - Y coordinate
   ULO                maxlen     - max length  */


void guiFieldTextInit(struct gui_textfield *n, struct gui_window *w,
			 STR *v, ULO x, ULO y, ULO maxlen) {
  n->hostwindow = w;
  n->x = x;
  n->y = y;
  n->maxlen = maxlen;
  strcpy(n->value, v);
}

BOOLE guiFieldTextEnter(struct gui_textfield *n) {
  STR text[80];
  ULO cursor, c;
  BOOLE finished;

  strcpy(text, n->value);
  cursor = strlen(text);
  finished = FALSE;
  while (!finished) {
    guiFieldPlot(n->hostwindow, n->x, n->y, text);
    c = getch();
    if (c == 13) finished = TRUE; /* RET */
    else if (c == 27) return FALSE;
    else if (c == 8) { /* DEL */
      if (cursor > 0) {
	guiFieldCharRemove(text);
	cursor--;
      }
    }
    else { 
      if (cursor < n->maxlen) {
	guiFieldCharAdd(text, c);
	cursor++;
      }
    }
  }
  strcpy(n->value, text);
  return TRUE;
}


/*===============================*/
/* Filerequester                 */
/* One directory entry in a list */
/*===============================*/

typedef struct dt_entstruct {
  struct dt_entstruct *next;
  struct dt_entstruct *prev;
  STR name[13];
  UBY dir;
} dt_filelist;

STR dt_path[256];          /* Current path */
STR dt_origpath[256];      /* Original path */
BOOLE dt_firsttime = TRUE; /* Flag to indicate the first time we enter */
unsigned dt_origdrv;
unsigned dt_curdrv;
UBY drivesavailable[27];
int drivesmap[51] = { 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
                      0, 0, 0, 0, 0, 0, 17, 23, 5, 18,
                      20, 25, 21, 9, 15, 16, 0, 0, 0, 0,
                      1, 19, 4, 6, 7, 8, 10, 11, 12, 0,
                      0, 0, 0, 0, 26, 24, 3, 22, 2, 14, 13 };

void dt_freefilelist(dt_filelist *fl) {
  dt_filelist *fl1, *fl2;

  for (fl1 = fl; fl1 != NULL; fl1 = fl2) {
    fl2 = fl1->next;
    free(fl1);
  }
}

dt_filelist *dt_allocitem(void) {
  dt_filelist *ftmp;

  ftmp = (dt_filelist*) malloc(sizeof(dt_filelist));
  if (ftmp == NULL) {
    printf("Malloc error\n");
    exit(1);
  }
  ftmp->prev = ftmp->next = NULL;
  return ftmp;
}

dt_filelist *dt_sortedinsert(dt_filelist *head,dt_filelist *fl) {
  dt_filelist *t;
  BOOLE done = FALSE;
  
  if (head == NULL) {                /* Empty list */
    head = fl;
    head->prev = head->next = NULL;
  }
  else {                                /* Not empty  */
    t = head;
    while (!done) {
      if (strcmp(fl->name,t->name) > 0) {   /* Check next */
	if (t->next != NULL) t = t->next;
	else {  /* End of list, insert item at tail */
	  fl->next = NULL;
	  fl->prev = t;
	  t->next = fl;
	  done = TRUE;
	}
      }
      else {        /* Insert before t */
	fl->next = t;
	fl->prev = t->prev;
	if (t->prev != NULL) t->prev->next = fl;
	else head = fl;
	t->prev = fl;
	done = TRUE;
      }
    }
  }
  return head;
}

dt_filelist *dt_joinlists(dt_filelist *first,dt_filelist *second) {
  dt_filelist *tmp;

  if (first == NULL) return second;
  else if (second == NULL) return first;
  else {
    tmp = first;
    while (tmp->next != NULL) tmp = tmp->next;
    tmp->next = second;
    second->prev = first;
  }
  return first;
}

/* Will return a directory listing of the directories in the path specified */

dt_filelist *dt_getdirs(char *path) {
  DIR *mydir;
  struct dirent *myent;
  dt_filelist *fl,*fltmp,*flist;

  flist = fl = fltmp = NULL;
  mydir = opendir(path);
  if (mydir != NULL) {
    while ((myent = readdir(mydir)) != NULL) {
      if (myent->d_attr & _A_SUBDIR) {
        fl = dt_allocitem();
        fl->dir = 1;
        strcpy(fl->name,myent->d_name);
        strlwr(fl->name);
        flist = dt_sortedinsert(flist,fl);
        }
      }
    closedir(mydir);
    }
  return flist;
}

dt_filelist *dt_getfiles(char *path,char *suffix) {
  DIR *mydir;
  struct dirent *myent;
  dt_filelist *fl,*fltmp,*tmplist,*newfl;
  char ourpath[256];
  int i,j;
  BOOLE romfiles;
  
  romfiles = !stricmp(suffix, "rom");
  if( !strcmpi( suffix, "adf" ) ) j = 7;
  else j = 1;
  if (romfiles)
    j = 2;
  
  for (i = 0; i < j; i++) {
    strcpy(&ourpath,path);

    if (ourpath[strlen(&ourpath)-1] != '\\') strcat(&ourpath,"\\*.");
    else strcat(&ourpath,"*.");
    if (romfiles && (i == 1)) strcat(&ourpath, "adf");
    else if (i == 6) strcat(&ourpath,"dms");
    else if (i == 5) strcat(&ourpath,"bz2");
    else if (i == 4) strcat(&ourpath,"bz");
    else if (i == 3) strcat(&ourpath,"gz");
    else if (i == 2) strcat(&ourpath,"z");
    else if (i == 1) strcat(&ourpath,"adz");
    else strcat(&ourpath,suffix);
    if (i == 0) tmplist = NULL;

    mydir = opendir(&ourpath);
    if (mydir != NULL) {
      while ((myent = readdir(mydir)) != NULL) {
        if (!(myent->d_attr & _A_SUBDIR) && !(myent->d_attr & _A_HIDDEN) &&
            !(myent->d_attr & _A_SYSTEM) && !(myent->d_attr & _A_VOLID)) {
          fl = dt_allocitem();
          fl->dir = 0;
          strcpy(fl->name,myent->d_name);
          strlwr(fl->name);

          tmplist = dt_sortedinsert(tmplist,fl);
          }
        }
      }
    closedir(mydir);
    }
  return tmplist;
}

dt_filelist *dt_drives(void) {
  dt_filelist *ftmp,*dl;
  int i;

  dl = NULL;
  for (i = 1; i < 27; i++) {
    if (drivesavailable[i]) {
      ftmp = dt_allocitem();
      ftmp->name[0] = i + 0x40;
      ftmp->name[1] = ':';
      ftmp->name[2] = 0;
      ftmp->dir = 2;
      dl = dt_sortedinsert(dl,ftmp);
    }
  }
  return dl;
}


int dt_countfilelist(dt_filelist *fl) {
  int i = 0;
  dt_filelist *t = fl;
  while (t != NULL) {
    i++;
    t = t->next;
    }
  return i;
}

void dt_Plot_entries( struct gui_window *w, dt_filelist *fl, char *fstr,
                       int max, int may, int x, int y, int numcols ) {
  dt_filelist *t;
  int i,j,firstvisible,lastvisible;
  char s[127];
  char fstr2[30];

  if (x < max) firstvisible = 0;
  else firstvisible = x - (x % max);
  if (x < max) lastvisible = max;
  else lastvisible = firstvisible + max;
  t = fl;
  for (i = 0; i < firstvisible + max; i++) {
    for (j = 0; j < may; j++) {
      if (t != NULL) {
	if (i >= firstvisible && i < lastvisible) {
	  if (t->dir == 1) {
	    strupr( t->name );
	    sprintf(&s,"%-12s DIR",t->name);
	    strlwr( t->name );
	  } else sprintf(&s,"%-12s    ",t->name);
	  if (x == i && y == j)
	    guiWindowTextPlotReverse(w,&s,(i-firstvisible)*17 + 6,j + 1);
	  else guiWindowTextPlot(w,&s,(i-firstvisible)*17 + 6,j + 1);
	}
	t = t->next;
      }
      else if (i >= firstvisible && i < lastvisible)
	guiWindowTextPlot(w,"                 ",(i-firstvisible)*17 + 6,j + 1);
    }
  }
  strcpy( &fstr2, fstr );
  while( strlen( &fstr2 ) < 8 ) strcat( &fstr2, "." );
  sprintf( &s, "Quickfind [%s] Path %s", &fstr2, dt_path );
  guiWindowTextPlot(w,&s,5,w->y2-w->y1);
  if (firstvisible != 0) guiWindowTextPlot(w,"<---",1,may);
  else guiWindowTextPlot(w,"    ",1,may);
  if ((firstvisible+max) < numcols) guiWindowTextPlot(w,"--->",w->x2-5,may);
  else guiWindowTextPlot(w,"    ",w->x2-5,may);
}

dt_filelist *dt_find_entry(dt_filelist *t,int x,int y,int may) {
  dt_filelist *i;
  int j;

  i = t;
  j = x*may+y;
  if (t == NULL) return NULL;
  else {
    while (j-- != 0) {
      i = i->next;
      if (i == NULL) return NULL;
      }
    }
  return i;
}

int dt_search_dups( dt_filelist *fl, char *fstr ) {
  int num = 0;

  while( fl != NULL ) {
    if( !strncmp( fl->name, fstr, strlen( fstr ) ) ) num++;
    fl = fl->next;
  };
  return num;
}

char *dt_search_first( dt_filelist *fl, char *fstr ) {
  int found = 0;

  while( fl != NULL && !found ) {
    if( !strncmp( fl->name, fstr, strlen( fstr ) ) ) found++;
    else fl = fl->next;
  };
  return fl->name;
}

void dt_Plot_msg( struct gui_window *w, char *str ) {
  char tmpstr[80];
  int i;

  tmpstr[0] = 0;
  guiWindowClear( w , FALSE);
  guiWindowTextPlot( w, str, ( 76 - strlen( str ) ) / 2, 10 );
  delay( 350 );
  for( i = 0; i < strlen( str ); i ++ ) strcat( &tmpstr, " " );
  guiWindowTextPlot( w, &tmpstr, ( 76 - strlen( str ) ) / 2, 10 );
}

int dt_search_entry( dt_filelist *fl, char *fstr ) {
  dt_filelist *flp = fl;
  int found, num;

  found = num = 0;
  while( flp != NULL && !found ) {
    if( !strncmp( flp->name, fstr, strlen( fstr ) ) ) {
      found++;
    } else {
      num++; flp = flp->next;
    };
  };
  if( !found ) num = -1;
  else {
    found = dt_search_dups( fl, fstr );
/*    while( dt_search_dups( fl, fstr ) == found ) {
      if( strlen( dt_search_first( fl, fstr ) ) > strlen( fstr ) )
        strncat( fstr, &(dt_search_first( fl, fstr )[ strlen( fstr ) ]), 1 );
      else strcat( fstr, " " ); */
    while( dt_search_dups( fl, fstr ) == found &&
           strcmp( dt_search_first( fl, fstr ), fstr ) ) {
      strncat( fstr, &(dt_search_first( fl, fstr )[ strlen( fstr ) ]), 1 );
      if( fstr[ strlen( fstr ) - 1 ] == '.' || strlen( fstr ) > 8 ) found = 0;
    };
    fstr[ strlen( fstr ) - 1 ] = 0;
  };
  return num;
}

dt_filelist *dt_Plot_and_select(struct gui_window *w,dt_filelist *fl,int presel) {
  int lasty,numcol,selection,key,x,y,maxcol,may,nument,esc;
  char fstr[30];
  char s[128];
  dt_filelist *fl2;

  /* Init */
  guiWindowClear(w,FALSE);
  x = y = fstr[0] = fstr[19] = selection = esc = 0;
  fstr[18] = ':';

  /* Find how many entries fit on one line */
  /* And how many lines of entries there are */

  maxcol = (w->x2 - w->x1) / 17;
  nument = dt_countfilelist(fl);
  if (nument < (w->y2 - w->y1 - 1)) may = nument;
  else may = (w->y2 - w->y1 - 1);
  if (nument != may) numcol = (nument / may)+1;
  else numcol = 1;
  lasty = nument - ((numcol-1)*may);
  if( presel == -1 ) presel++;
  x = presel / may;
  y = presel - x * may;

  /* Will loop until a file is selected or Esc is pressed */
    /* Select loop */

    while( !selection && !esc ) {
      dt_Plot_entries( w, fl, fstr, maxcol, may, x, y, numcol );
      key = getch();
      if (key == 0) {
        key = getch();
        if (key == 80) {                // Down
          if( x == numcol-1 ) {
            if( y < lasty-1 ) y++;
          } else {
            if( y < may-1 ) y++;
            else { x++; y = 0; };
          };
        } else if (key == 81) {         // PageDown
          if( x < numcol - 1 ) {
            if( y + 10 < may ) y += 10;
            else {
              x++;
              y = 10 - may + y;
              if( x == numcol - 1 && y > lasty - 1 ) y = lasty - 1;
            };
          } else {
            if( y + 10 < lasty ) y += 10;
            else y = lasty - 1;
          };
        } else if( key == 72 ) {        // Up
          if( y > 0 ) y--;
          else if( x > 0 ) {
            y = may - 1;
            x--;
          };
        } else if( key == 73 ) {        // PageUp
          if( y - 10 >= 0 ) y -= 10;
          else if( x > 0 ) {
            x--;
            y = may - 10 + y;
          } else y = 0;
        } else if( key == 75 ) {        // Left
          if( x > 0 ) x--;
          else y = 0;
        } else if( key == 77 ) {        // Right
          if( x == numcol - 1 ) y = lasty - 1;
          if( x < numcol - 1 ) x++;
          if( x == numcol - 1 && y > lasty - 1 ) y = lasty - 1;
        } else if( key == 71 ) {        // Home
          x = 0; y = 0;
        } else if( key == 79 ) {
          x = numcol - 1;
          y = lasty - 1;
        } else if( ( key > 15 && key < 26 ) ||  // Alt + drive letter
                   ( key > 29 && key < 39 ) ||
                   ( key > 43 && key < 51 ) ) {
          if( drivesavailable[ drivesmap[ key ] ] ) {
            fstr[ 18 ] = ':';
            fstr[ 17 ] = 'A' + drivesmap[ key ] - 1;
            selection = dt_search_entry( fl, &fstr[17] );
            if( selection == -1 ) selection++;
            x = selection / may;
            y = selection - x * may;
            selection = 1;
          }
        } else if( key > 119 && key < 130 ) {   // disk name memory
          strcpy( memnames[key - 120], dt_path );
          strcat( memnames[key - 120], "\\" );
          strcat( memnames[key - 120], dt_find_entry( fl, x, y, may )->name );
          sprintf( &s, "Disk memory %i updated to %s", ( key == 129 ) ? 0 : key - 119, memnames[key - 120] );
          dt_Plot_msg( w, &s );
          if( x == numcol-1 ) {                 // advance one item
            if( y < lasty-1 ) y++;
          } else {
            if( y < may-1 ) y++;
            else { x++; y = 0; };
          };
        } else if( key == 41 ) {                // disk name memory clear
          for( esc = 0; esc < 10; esc++ ) strcpy( memnames[esc], "__None__" );
          dt_Plot_msg( w, "All disk memory cleared" );
          esc = 0;
        }
      } else if( ( ( key > 0x30 && key < 0x3a ) ||    // quick find
                   ( key > 0x40 && key < 0x7b ) ) &&
                   strlen( &fstr ) < 8 ) {
        esc = strlen( &fstr );
        fstr[ esc ] = key;
        fstr[ esc + 1 ] = 0;
        strlwr( fstr );
        if( ( esc = dt_search_entry( fl, &fstr ) ) != -1 ) {
          x = esc / may;
          y = esc - x * may;
        } else fstr[ strlen( &fstr ) - 1 ] = 0;
        esc = 0;
      } else if( key == 8 && strlen( &fstr ) > 0 ) {   // BackSpace
        esc = dt_search_dups( fl, &fstr );
        fstr[ strlen( &fstr ) - 1 ] = 0;
        if( esc == dt_search_dups( fl, &fstr ) ) {
          if( strlen( &fstr ) > 0 ) {
            esc = dt_search_dups( fl, &fstr );
            while( dt_search_dups( fl, &fstr ) == esc && strlen( &fstr ) > 0 )
              fstr[ strlen( &fstr ) - 1 ] = 0;
          };
        }; esc = 0;
      } else if( key == 13 ) {
        selection++;                    // Enter => selection made
      } else if( key == 27 ) esc = 1;   // Esc => quit
    }

  fl2 = dt_find_entry( fl, x, y, may );
  strcpy( act_item, fl2->name );
  if( selection ) return fl2;
  return NULL;
}

/* This routine must preserve the path for any drive */
/* At entering the routine the first time, it will save the current path */
/* for the current drive */
/* Whenever the drive changes, it must restore the path, and save the */
/* original path of the new drive */
/* On exit, it must set the drive and path of the fellow homedirectory */

void dt_selectfile(struct gui_window *w, char *suffix, char *s) {
  int imageselected = FALSE;
  unsigned drv, tot, i, j, sel = 0;
  char *tmps;
  /* The directory list */

  dt_filelist *sent, *fl = NULL;

  /* Save our original path */

  if (dt_firsttime) {
    dt_firsttime = FALSE;
    strcpy( act_item, "." );
    getcwd( dt_origpath, 256 );
    _dos_getdrive(&dt_origdrv);
    if( config_diskpath[0] ) {
      if( ( tmps = (char *)strrchr( config_diskpath, '/' ) ) ) {
	strcpy( act_item, &tmps[1] );
	tmps[0] = 0;
      };
      if( !chdir(config_diskpath) )
	strcpy( dt_path, config_diskpath );
      else {
	strcpy( dt_path, dt_origpath );
	strcpy( act_item, "." );
      };
    } else strcpy( dt_path, dt_origpath );
    dt_curdrv = toupper( dt_path[0] ) - 'A' + 1;
    for (i = 1; i < 27; i++) {
      _dos_setdrive(i, &tot);
      _dos_getdrive(&j);
      if (j == i) drivesavailable[i] = TRUE;
      else drivesavailable[i] = FALSE;
    }
  }

  _dos_setdrive(dt_curdrv, &tot);
  getcwd(dt_origpath, 256);
  
  while (!imageselected) {
    chdir(dt_path);
    
    /* Build list of directories in current dir */
    
    fl = NULL;
    fl = dt_joinlists(fl, dt_getdirs(dt_path));
    fl = dt_joinlists(fl, dt_getfiles(dt_path, suffix));
    fl = dt_joinlists(fl, dt_drives());
    
    sent = dt_Plot_and_select(w, fl, dt_search_entry( fl, act_item ) );
    if (sent == NULL) {
      imageselected = TRUE;
    }
    else if (sent->dir == 1) {
      /* directory selected */
      
      if (dt_path[strlen(dt_path) - 1] != '\\')
	strcat(dt_path, "\\");
      strcat(dt_path, sent->name);
      chdir(dt_path);
      getcwd(dt_path, 256);
      strcpy( act_item, "." );
      dt_freefilelist(fl);
      guiWindowBorderPlot(w);
    }
    else if (sent->dir == 2) {
      /* new drive selected */
      drv = (ULO) sent->name[0] & 0x1f;
      chdir(dt_origpath);
      _dos_setdrive(drv, &tot);
      getcwd(dt_path, 256);
      getcwd(dt_origpath, 256);
      _dos_getdrive(&dt_curdrv);
      strcpy( act_item, "." );
      dt_freefilelist(fl);
      guiWindowBorderPlot(w);
    }
    else {
      /* Image selected */
      /* Copy name to string */
      if (strcmp(sent->name, "__None__")) {
	if (dt_path[strlen(dt_path) - 1] != '\\')
	  sprintf(s, "%s\\%s", dt_path, sent->name);
	else sprintf(s, "%s%s", dt_path, sent->name);
      }
      else strcpy(s, "__None__");
      imageselected = 1;
    }
  }
  strcpy( config_diskpath, dt_path );
  strcat( config_diskpath, "/" );
  strcat( config_diskpath, act_item );
  chdir(dt_origpath);
  _dos_setdrive(toupper(fellow_homedir[0]) - 'A' + 1, &tot);
  chdir(fellow_homedir);
  dt_freefilelist(fl);
  various_make_relative_path(s);
  guiWindowClear(w,FALSE);
  guiWindowBorderPlot(w);
}

/* End of file-requester */


/*======================*/
/* Generic menu support */
/*======================*/

ULO guiItemAdd(LON val, LON add, ULO numberofitems) {
  val = val + add;
  if (val < 0) val = 0;
  else if (val >= numberofitems)
    val = numberofitems - 1;
  return val;
}


/*=======================*/
/* Test global shortcuts */
/*=======================*/

BOOLE guiShortcutGlobalTest(ULO c) {
  switch (c) {
    case CON_KEY_F1:
      strcpy(gui_shortcut_global_want, "Configuration/");
      gui_shortcut_global_selected = TRUE;
      break;
    case CON_KEY_F3:
      strcpy(gui_shortcut_global_want, "Utilities/");
      gui_shortcut_global_selected = TRUE;
      break;
    case CON_KEY_F5:
      strcpy(gui_shortcut_global_want, "Hard Reset/");
      gui_shortcut_global_selected = TRUE;
      break;
    case CON_KEY_F7:
      strcpy(gui_shortcut_global_want, "Debugger/");
      gui_shortcut_global_selected = TRUE;
      break;
    case CON_KEY_F9:
      strcpy(gui_shortcut_global_want, "Start/");
      gui_shortcut_global_selected = TRUE;
      break;
    case CON_KEY_F11:
      strcpy(gui_shortcut_global_want, "About/");
      gui_shortcut_global_selected = TRUE;
      break;
    case CON_KEY_ALT_D:
      strcpy(gui_shortcut_global_want, "Configuration/Disk-Images/");
      gui_shortcut_global_selected = TRUE;
      break;
    case CON_KEY_ALT_F:
      strcpy(gui_shortcut_global_want,
	     "Configuration/Filesystems/");
      gui_shortcut_global_selected = TRUE;
      break;
    case CON_KEY_ALT_S:
      strcpy(gui_shortcut_global_want, "Configuration/Screen/");
      gui_shortcut_global_selected = TRUE;
      break;
    case CON_KEY_ALT_M:
      strcpy(gui_shortcut_global_want, "Configuration/Memory/");
      gui_shortcut_global_selected = TRUE;
      break;
    case CON_KEY_ALT_O:
      strcpy(gui_shortcut_global_want, "Configuration/Sound/");
      gui_shortcut_global_selected = TRUE;
      break;
    case CON_KEY_ALT_C:
      strcpy(gui_shortcut_global_want, "Configuration/CPU & Blitter/");
      gui_shortcut_global_selected = TRUE;
      break;
    case CON_KEY_ALT_H:
      strcpy(gui_shortcut_global_want, "Configuration/Hardfile/");
      gui_shortcut_global_selected = TRUE;
      break;
    case CON_KEY_ALT_V:
      strcpy(gui_shortcut_global_want, "Configuration/Various/");
      gui_shortcut_global_selected = TRUE;
      break;
    case CON_KEY_ALT_A:
      strcpy(gui_shortcut_global_want,
	     "Configuration/Filesystems/Add VFS Filesystem/");
      gui_shortcut_global_selected = TRUE;
      break;
    case CON_KEY_ALT_R:
      strcpy(gui_shortcut_global_want,
	     "Configuration/Filesystems/Remove Filesystem/");
      gui_shortcut_global_selected = TRUE;
      break;
    case CON_KEY_ALT_X:
    case CON_KEY_CTRL_Q:
      strcpy(gui_shortcut_global_want, "Quit/");
      gui_shortcut_global_selected = TRUE;
      break;
  }
  if (gui_shortcut_global_selected)
    gui_shortcut_global_next = gui_shortcut_global_want;
  gui_shortcut_global_up = gui_shortcut_global_selected;
  return gui_shortcut_global_selected;
}


/*=============*/
/* Optionmenus */
/*=============*/

/*====================================*/
/* Initialize an optionmenu structure */
/*====================================*/

void guiOptionmenuInit(struct gui_optionmenu *om, char *topheader,
		       char **headers, UBY *actions, void *vars,
		       char ***texts, void **vals, struct gui_window *w,
		       UBY *shortcuts) {
  om->topheader = topheader;
  om->headers = headers;
  om->actions = actions;
  om->vars = vars;
  om->texts = texts;
  om->vals = vals;
  om->w = w;
  om->shortcuts = shortcuts;
}


/*==============================*/
/* Some optionmenu info getters */
/*==============================*/

ULO guiOptionmenuTextCount(STR **headers) {
  ULO i = 0;

  while (headers[i] != NULL)
    i++;
  return i;
}

ULO guiOptionmenuHeadLenMax(struct gui_optionmenu *om, ULO n) {
  ULO i,j = 0,k;

  for (i = 0; i < n; i++) {
    k = strlen(om->headers[i]);
    if (k > j)
      j = k;
  }
  return j + 2;
}

ULO guiOptionmenuActiveValueGet(ULO *var, ULO *vals, ULO numberofvals) {
  ULO i = 0;

  while (i < numberofvals) {
    if (*var == vals[i])
      return i;
    else
      i++;
  }
  return 0;
}

STR *guiOptionmenuActiveTextGet(ULO *var, ULO *vals, STR **texts) {
  return texts[guiOptionmenuActiveValueGet(var, vals,
					   guiOptionmenuTextCount(texts))];
}


/*===========================*/
/* Print one optionmenu item */
/*===========================*/

void guiOptionmenuItemPrint(struct gui_optionmenu *om, ULO n, ULO optpos,
			    ULO activeflag, ULO yadjust) {
  guiWindowTextPlotShortcut(om->w, om->headers[n], 1, n + 3 + yadjust,
				om->shortcuts[n]);
  switch (om->actions[n]) {
    case GUI_FILEREQ_ROM:
    case GUI_FILEREQ_ADF:
    case GUI_FILEREQ_HDF:
    case GUI_FILEREQ_KEY:
      if (!activeflag)
	guiWindowTextPlot(om->w, ((STR **) om->vars)[n], optpos,
			     n + 3 + yadjust);
      else
	guiWindowTextPlotReverse(om->w, ((STR **) om->vars)[n], optpos,
				     n + 3 + yadjust);
      break;
    case GUI_VALUELIST:
      if (!activeflag)
	guiWindowTextPlot(om->w,
			     guiOptionmenuActiveTextGet(((ULO **) om->vars)[n],
							((ULO **) om->vals)[n],
							om->texts[n]),
			     optpos, n + 3 + yadjust);
      else
	guiWindowTextPlotReverse(om->w,
			     guiOptionmenuActiveTextGet(((ULO **) om->vars)[n],
							((ULO **) om->vals)[n],
							om->texts[n]),
				     optpos, n + 3 + yadjust);
      break;
  }
}


/*==================*/
/* Print optionmenu */
/*==================*/

void guiOptionmenuPlot(struct gui_optionmenu *om, ULO activeitem) {
  ULO itemcount = guiOptionmenuTextCount(om->headers);
  ULO itemmaxlen = guiOptionmenuHeadLenMax(om,itemcount);
  ULO j;
  LON yadjust = 0;

  if (om->topheader != NULL)
    guiWindowTextPlot(om->w, om->topheader, 1, 1);
  else
    yadjust = -2;
  for (j = 0; j < itemcount; j++)
    guiOptionmenuItemPrint(om, j, itemmaxlen, (j == activeitem) ? TRUE : FALSE,
			   yadjust);
}


/*================================*/
/* Handle an optionmenu selection */
/*================================*/

void guiOptionmenuSelection(struct gui_optionmenu *om, ULO activeitem,
			    ULO dirflag) {
  if (om->actions[activeitem] == GUI_VALUELIST) {
    ULO numberofvals = guiOptionmenuTextCount(om->texts[activeitem]);
    ULO activeval = guiOptionmenuActiveValueGet(((ULO **)om->vars)[activeitem],
						((ULO **)om->vals)[activeitem],
						numberofvals);

    switch (dirflag) {
      case GUI_OPTIONMENU_DEC:
	activeval--;
	if (activeval == -1)
	  activeval = numberofvals - 1;
	break;
      case GUI_OPTIONMENU_INC:
	activeval++;
	if (activeval >= numberofvals)
	  activeval = 0;
	break;
    }
    *(((ULO **)om->vars)[activeitem]) =
                                   (((ULO **)om->vals)[activeitem])[activeval];
  }
  else if (om->actions[activeitem] == GUI_FILEREQ_ADF)
    dt_selectfile(om->w, "ADF", ((STR **)om->vars)[activeitem]);
  else if (om->actions[activeitem] == GUI_FILEREQ_ROM)
    dt_selectfile(om->w, "ROM", ((STR **)om->vars)[activeitem]);
  else if (om->actions[activeitem] == GUI_FILEREQ_HDF)
    dt_selectfile(om->w, "*"  /*"HDF"*/, ((STR **)om->vars)[activeitem]);
  else if (om->actions[activeitem] == GUI_FILEREQ_KEY) 
    dt_selectfile(om->w, "KEY", ((STR **)om->vars)[activeitem]);
}


/*======================*/
/* Test local shortcuts */
/*======================*/

LON guiOptionmenuShortcutsTest(struct gui_optionmenu *om, ULO c,
			       ULO numberofentries) {
  ULO i;

  for (i = 0; i < numberofentries; i++) 
    if (toupper(c) == toupper(om->headers[i][om->shortcuts[i]]))
      return i;
  return -1;
}


/*===================================================*/
/* Resolve global shortcut selection for optionmenus */
/* IE: set activeitem                                */
/*===================================================*/

void guiOptionmenuShortcutGlobalResolve(struct gui_optionmenu *om, ULO *item,
					ULO numberofitems) {
  ULO i;

  for (i = 0; i < numberofitems; i++)
    if (stricmp(gui_shortcut_global_next, om->headers[i]) == 0) {
      *item = i;
      return;
    }
  return;
}


/*============================================================*/
/* Enter an optionmenu and let user edit until ESC is pressed */
/* Global shortcuts, optionmenus will always be on the end    */
/*============================================================*/

void guiOptionmenuRun(struct gui_optionmenu *om) {
  BOOLE ended = FALSE;
  ULO activeitem = 0, c, numberofitems = guiOptionmenuTextCount(om->headers);
  ULO lshortsel;

  guiOptionmenuShortcutGlobalResolve(om, &activeitem, numberofitems);
  guiWindowClear(om->w,TRUE);
  guiWindowBorderPlot(om->w);
  while (!ended) {
    guiOptionmenuPlot(om,activeitem);
    c = conKeyGet();
    if ((ended = guiShortcutGlobalTest(c)));
    else if ((lshortsel = guiOptionmenuShortcutsTest(om, c, numberofitems)) !=
	     -1)
      activeitem = lshortsel;
    else if (c == CON_KEY_ESC)
      ended = TRUE;
    else if (c == CON_KEY_RETURN)
      guiOptionmenuSelection(om, activeitem, GUI_OPTIONMENU_INC);
    else if (c == CON_KEY_UP)
      activeitem = guiItemAdd(activeitem, -1, numberofitems);
    else if (c == CON_KEY_DOWN)
      activeitem = guiItemAdd(activeitem, 1, numberofitems);
    else if (c == CON_KEY_LEFT)
      guiOptionmenuSelection(om, activeitem, GUI_OPTIONMENU_DEC);
    else if (c == CON_KEY_RIGHT)
      guiOptionmenuSelection(om, activeitem, GUI_OPTIONMENU_INC);
    else if (c == CON_KEY_HOME || c == CON_KEY_PAGEUP)
      activeitem = 0;
    else if (c == CON_KEY_END || c == CON_KEY_PAGEDOWN)
      activeitem = numberofitems - 1;
    else if (c >= CON_KEY_ALT_1 && c <= CON_KEY_ALT_0) {
      /* Alt-n (disk memory records) */
      /* NOTE: This code is not portable, dependent on consecutive */
      /*       ALT_1 to ALT_0 keycodes                             */
      if (om->actions[activeitem] == GUI_FILEREQ_ADF ||
	  om->actions[activeitem] == GUI_FILEREQ_HDF ||
	  om->actions[activeitem] == GUI_FILEREQ_ROM) {
	if (strcmpi(memnames[c - CON_KEY_ALT_1], "__None__")) {
	  strcpy(((STR **)om->vars)[activeitem], memnames[c - CON_KEY_ALT_1]);
	  if (activeitem < config_altn_loop)
	    activeitem++;
	  else
	    activeitem = 0;
	  guiWindowClear(om->w, FALSE);
	  if (config_autorun & 1) {
	    strcpy(gui_shortcut_global_want, "Start/");
	    gui_shortcut_global_selected = gui_shortcut_global_up = TRUE;
	    gui_shortcut_global_next = gui_shortcut_global_want;
	    ended = TRUE;
	  }
	}
      }
    }
    else if (c == CON_KEY_INSERT) { /* Insert */
      if (om->actions[activeitem] == GUI_FILEREQ_ADF ||
	  om->actions[activeitem] == GUI_FILEREQ_HDF ||
	  om->actions[activeitem] == GUI_FILEREQ_ROM)
	guiOptionmenuSelection(om, activeitem, GUI_OPTIONMENU_INC);
    }
    else if (c == CON_KEY_DELETE) { /* Del */
      if (om->actions[activeitem] == GUI_FILEREQ_ADF ||
	  om->actions[activeitem] == GUI_FILEREQ_HDF ||
	  om->actions[activeitem] == GUI_FILEREQ_ROM) {
	int stopit = FALSE, actitem2 = activeitem;
	strcpy(((char **)om->vars)[activeitem], "__None__");
	while((actitem2 + 1) < numberofitems && om->actions[actitem2 + 1] ==
	      GUI_FILEREQ_ADF && !stopit)
	  if (strcmp(((char **)om->vars)[++actitem2], "__None__" )) {
	    activeitem++;
	    stopit = TRUE;
	  }
	guiWindowClear(om->w,FALSE);
      }
    }
  }
  guiWindowClear(om->w,FALSE);
}

/*=======*/
/* Menus */
/*=======*/

/*==========================================*/
/* Prints the menu in the associated window */
/*==========================================*/

void guiMenuPrint(struct gui_menu *m) {
  ULO y, x, width;

  y = 0;
  width = m->w->x2 - m->w->x1;
  while (m->entrytext[y] != NULL) {
    x = ((width - strlen(m->entrytext[y]))/2) + 1;
    if (m->shortcuts != NULL) {
      if (m->activeentry == y)
	guiWindowTextPlotReverseShortcut(m->w, m->entrytext[y], x, y + 1,
					      m->shortcuts[y]);
      else
	guiWindowTextPlotShortcut(m->w, m->entrytext[y], x, y + 1,
				      m->shortcuts[y]);
    }
    else {
      if (m->activeentry == y)
	guiWindowTextPlotReverse(m->w, m->entrytext[y], x, y + 1);
      else
	guiWindowTextPlot(m->w, m->entrytext[y], x, y + 1);
    }
    y++;
  }
}


/*===================================*/
/* Count number of entries in a menu */
/*===================================*/

ULO guiMenuEntryCount(struct gui_menu *m) {
  ULO i = 0;

  while (m->entrytext[i] != NULL)
    i++;
  return i;
}


/*================================*/
/* Find max entry width in a menu */
/*================================*/

ULO guiMenuEntryWidth(struct gui_menu *m) {
  ULO width = 0, i = 0;
  
  while (m->entrytext[i] != NULL) {
    if (strlen(m->entrytext[i]) > width)
      width = strlen(m->entrytext[i]);
    i++;
  }
  return width + 1;
}

/*===================================================*/
/* Test keycode against defined shortcuts for a menu */
/*===================================================*/

LON guiMenuShortcutsTest(struct gui_menu *m, ULO c, ULO numberofentries) {
  ULO i;

  if (m->shortcuts != NULL)
    for (i = 0; i < numberofentries; i++)
      if (toupper(c) == toupper(m->entrytext[i][m->shortcuts[i]]))
	return i;
  return -1;
}


/*=============================================*/
/* Resolve global shortcut selection for menus */
/* Going up, return GUI_MENU_LEVEL_UP          */
/* Else, return selection, or -1 on any error  */
/*=============================================*/

LON guiMenuShortcutGlobalResolve(struct gui_menu *m, ULO numberofitems,
				 BOOLE toplevel) {
  ULO i;
  STR *slashpos;
  
  if (!gui_shortcut_global_selected)
    return -1;
  if (toplevel)
    gui_shortcut_global_up = FALSE;
  if (gui_shortcut_global_up)
    return GUI_MENU_LEVEL_UP;
  slashpos = strchr(gui_shortcut_global_next, '/');
  if (slashpos == NULL) {
    gui_shortcut_global_selected = FALSE;
    return -1;
  }
  *slashpos = '\0';
  i = 0;
  while (i < numberofitems)
    if (stricmp(gui_shortcut_global_next, m->entrytext[i]) == 0)
      break;
    else
      i++;
  if (i == numberofitems) {
    gui_shortcut_global_selected = FALSE;
    return -1;
  }
  gui_shortcut_global_next = slashpos + 1;
  gui_shortcut_global_selected = (gui_shortcut_global_next[0] != '\0');
  return i;
}


/*======================================================*/
/* Waits for a selection and returns the entry position */
/*======================================================*/

ULO guiMenuSelect(struct gui_menu *m, BOOLE toplevel) {
  ULO c, selection = -1, numberofentries = guiMenuEntryCount(m);
  ULO lshortsel;
  
  if ((selection = guiMenuShortcutGlobalResolve(m, numberofentries, toplevel))
      != -1)
    return selection;
  guiMenuPrint(m);
  while (selection == -1) {
    c = conKeyGet();
    if (guiShortcutGlobalTest(c) || c == CON_KEY_ESC)
      selection = GUI_MENU_LEVEL_UP;
    else if ((lshortsel = guiMenuShortcutsTest(m, c, numberofentries)) != -1)
      selection = m->activeentry = lshortsel;
    else if (c == CON_KEY_UP || c == CON_KEY_LEFT) {
      m->activeentry = guiItemAdd(m->activeentry, -1, numberofentries);
      guiMenuPrint(m);
    }
    else if (c == CON_KEY_DOWN || c == CON_KEY_RIGHT) {
      m->activeentry = guiItemAdd(m->activeentry, 1, numberofentries);
      guiMenuPrint(m);
    }
    else if (c == CON_KEY_HOME || c == CON_KEY_PAGEUP) {
      m->activeentry = 0;
      guiMenuPrint(m);
    }
    else if (c == CON_KEY_END || c == CON_KEY_PAGEDOWN) {
      m->activeentry = numberofentries - 1;
      guiMenuPrint(m);
    }
    else if (c == CON_KEY_RETURN)
      selection = m->activeentry;
  }
  return selection;
}


/*======================*/
/* Init a menu stucture */
/*======================*/

void guiMenuInit(struct gui_menu *m, STR *entries[], ULO activeentry,
		 struct gui_window *w, UBY *shortcuts) {
  m->entrytext = entries;
  m->activeentry = activeentry;
  m->w = w;
  m->shortcuts = shortcuts;
}


/*===============================*/
/* Initialize a window structure */
/*===============================*/

void guiWindowInit(struct gui_window *w, UBY x1, UBY x2, UBY y1, UBY y2,
		   UBY bgcolor, UBY fgcolor, UBY shortcutcolor,
		   UBY reversecolor, UBY cornerflags) {
  w->x1 = x1;
  w->x2 = x2;
  w->y1 = y1;
  w->y2 = y2;
  w->bgcolor = bgcolor;
  w->fgcolor = fgcolor;
  w->shortcutcolor = shortcutcolor;
  w->reversecolor = reversecolor;
  w->cornerflags = cornerflags;
}


/*====================================*/
/* Fill disk memories with dummy defs */
/*====================================*/

void guiMemnamesClear(void) {
  ULO i;

  for( i = 0; i < 10; i++ )
    strcpy(memnames[i], "__None__");
}


/*====================================================*/
/* Will set a textscreen, hide the cursor and no wrap */
/*====================================================*/

void guiScreenSetup(void) {
  STR *hlc = CON_RIGHT_LEFT;
  ULO i;
  
  conScreenSetup();
  gui_horline = (STR *) malloc(con_maxcols + 1);
  gui_spcline = (STR *) malloc(con_maxcols + 1);
  for (i = 0; i < con_maxcols; i++) {
    gui_horline[i] = hlc[0];
    gui_spcline[i] = ' ';
  }
  gui_horline[con_maxcols] = gui_spcline[con_maxcols] = '\0';
  gui_exitflag = FALSE;
}


/*=======================*/
/* Will set a textscreen */
/*=======================*/

void guiScreenClose(void) {
  free(gui_horline);
  free(gui_spcline);
  conScreenClose();
}


#endif /* USE_GUI */


