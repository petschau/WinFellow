/*=============================*/
/* Fellow Amiga Emulator       */
/* Dumps framebuffer to file   */
/* (C) 1997-1998 Petter Schau, */
/*               Roman Dolejsi */
/*           and David Voracek */
/*=============================*/

#include <stdio.h>

#include "defs.h"
#include "inout.h"
#include "draw.h"
#include "graphem.h"


ULO BMPnr = 0;
BOOLE BMPdumpflag;


void BMPMakeHeader(FILE *F, ULO resxa, ULO resya, ULO want256 ) {
  ULO t;

  fprintf(F,"BM");
  t = 0x36 + resxa * resya + want256 * 0x400; /* Length of the file */
  fwrite (&t,4,1,F);
  t = 0;               /* Reserved */
  fwrite (&t,4,1,F);
  t = 0x36 + want256 * 0x400;
  fwrite (&t,4,1,F);   /* Offset to bitmap */
  t = 0x28;
  fwrite (&t,4,1,F);   /* Length of this header */
  t = resxa;
  fwrite (&t,4,1,F);   /* Width */
  t = resya;
  fwrite (&t,4,1,F);   /* height */
  t = 1;
  fwrite (&t,2,1,F);   /* planes */
  t = ( want256 ) ? 8 : 24;
  fwrite (&t,2,1,F);   /* bits */
  t = 0;
  fwrite (&t,4,1,F);   /* Compression */
  fwrite (&t,4,1,F);   /* Size */
  t = 0x120b;
  fwrite (&t,4,1,F);   /* XPels */
  fwrite (&t,4,1,F);   /* YPels */
  t = 0;
  fwrite (&t,4,1,F);   /* ColUsed */
  fwrite (&t,4,1,F);   /* Colimportant */
}


/*========================================*/
/* This works on a 15-bit geometry        */
/* TODO: Use color pos and mask from VESA */
/* Will not work with VGA double-lines    */
/*========================================*/

void BMPmakeImage(FILE *F, ULO resx, ULO resxa, ULO resy, ULO resya ) {
  ULO x, y, red, blue, green;
  ULO rpos, rmsk, bpos, bmsk, gpos, gmsk, bits;
  UWO *b;
  ULO tmp;
  ULO linelength = resx + ( draw_scanlinemodulo >> 1 );

  bits = config_graphics_modebits[config_graphics_mode];
  bpos = 0;
  bmsk = 0x1f;
  gpos = 5;
  gmsk = ((bits == 15) ? 0x3e0 : 0x7e0);
  rpos = 10 + ((bits == 16) ? 1 : 0);
  rmsk = ((bits == 15) ? 0x7c00 : 0xf800);

  b = framebuffer + ( bufferoffsets[ draw_buffershow ] / 2 );
  b += ( resx > resxa ) ? ( resx - resxa ) / 2 : 0;
  b += ( resy > resya ) ? ( resy - resya - 1 ) * linelength / 2 : 0;
  b += resya * linelength;

  for( y = 0 ; y < resya; y++ ) {
    for( x = 0; x < resxa; x++ ) {
      tmp = *( b + x );
      blue = ( tmp & bmsk ) << 3;
      green = ( tmp & gmsk ) >> (2 + (rpos - 10));
      red = ( tmp & rmsk ) >> (rpos - 3);
      fputc( blue, F );
      fputc( green, F );
      fputc( red, F );
    }
    b -= linelength;
  }
}


/*============================================*/
/* This works on a 256 color palette geometry */
/*============================================*/

void BMPmakeImage256(FILE *F, ULO resx, ULO resxa, ULO resy, ULO resya ) {
  ULO x, y, red, blue, green;
  UBY *b;
  ULO tmp;
  ULO linelength = resx + ( draw_scanlinemodulo >> 1 );

  b = (UBY *)( framebuffer + bufferoffsets[ draw_buffershow ] );
  b += ( resx > resxa ) ? ( resx - resxa ) / 2 : 0;
  b += ( resy > resya ) ? ( resy - resya - 1 ) * linelength / 2 : 0;
  b += resya * linelength;

  for( y = 0 ; y < resya; y++ ) {
    for( x = 0; x < resxa; x++ ) fputc( *( b + x ), F );
    b -= linelength;
  }
}


void BMPmakePalette( FILE *F ) {
  LON i;

  for( i = 0; i < 0x100; i++ ) {
    fputc( graph256_palette[i][2] << 2, F );
    fputc( graph256_palette[i][1] << 2, F );
    fputc( graph256_palette[i][0] << 2, F );
    fputc( 0, F );
  }
};


void BMPImageDump(void) {
  FILE *F;
  STR imnam[80];
  ULO want256 = (config_graphics_modebits[config_graphics_mode] == 8);
  ULO resx = config_graphics_moderesx[config_graphics_mode];
  ULO resxa= (resx == 800) ? 752 : resx;
  ULO resy = config_graphics_moderesy[config_graphics_mode];
  ULO resya= (resy == 300 || resy == 350 || resy == 400 || resy == 480) ? 287
             : (resy == 600) ? 574 : resy;

  sprintf(imnam,"img%d.bmp",BMPnr++);
  if( ( F = fopen( imnam, "wb" ) ) != NULL ) {
    BMPmakeHeader( F, resxa, resya, want256 );
    if( want256 ) {
      BMPmakePalette( F );
      BMPmakeImage256( F, resx, resxa, resy, resya );
    } else
      BMPmakeImage( F, resx, resxa, resy, resya );
    fclose(F);
  }
  BMPdumpflag = FALSE;
}


void BMPStartup(void) {
  BMPdumpflag = FALSE;
}






