/*====================================*/
/* Fellow Amiga Emulator              */
/* Bus Event Scheduler Initialization */
/* (C) 1997-1998 Petter Schau         */
/*====================================*/


#include <stdio.h>
#include "defs.h"
#include "68000.h"
#include "cianew.h"
#include "copper.h"
#include "memory.h"
#include "keyboard.h"
#include "blit.h"
#include "busa.h"

ULO debugging;
ULO curcycle;
ULO eol_next, eof_next;
ULO lvl2_next, lvl3_next, lvl4_next, lvl5_next, lvl6_next, lvl7_next;
buseventfunc lvl2_ptr, lvl3_ptr, lvl4_ptr, lvl5_ptr, lvl6_ptr, lvl7_ptr; 

UWO bus_cycle_to_ypos[0x20000];
UBY bus_cycle_to_xpos[0x20000];

void bus_init_cycle_to_table(void) {
  int i;
  for (i = 0; i < 0x20000; i++) {
    bus_cycle_to_ypos[i] = i / 228;
    bus_cycle_to_xpos[i] = i % 228;
  }
}

#ifdef TEST_EVENTS_SANITY

void events_messed_up(void) {
  int i;
  screenclose();
  printf("Event table is completely messed up!\n\n");
  printf("Lvl2_next: %.8X  Lvl2_ptr:  %.8X\n",lvl2_next, lvl2_ptr);
  printf("Lvl3_next: %.8X  Lvl3_ptr:  %.8X\n",lvl3_next, lvl3_ptr);
  printf("Lvl4_next: %.8X  Lvl4_ptr:  %.8X\n",lvl4_next, lvl4_ptr);
  printf("Lvl5_next: %.8X  Lvl5_ptr:  %.8X\n",lvl5_next, lvl5_ptr);
  printf("Lvl6_next: %.8X  Lvl6_ptr:  %.8X\n\n",lvl6_next, lvl6_ptr);
  fellow_nasty_exit();
}

#endif

/* Set up events for initial execution */

void bus_clear_eventlist(void) {
  lvl7_next = CYCLESPERFRAME;
  lvl7_ptr = end_of_frame;
  lvl6_next = CYCLESPERFRAME;
  lvl6_ptr = end_of_frame;
  lvl5_next = CYCLESPERFRAME;
  lvl5_ptr = end_of_frame;
  lvl4_next = CYCLESPERFRAME;
  lvl4_ptr = end_of_frame;
  lvl3_next = CYCLESPERLINE - 1;
  lvl3_ptr = end_of_line;
  lvl2_next = CYCLESPERLINE - 1;
  lvl2_ptr = end_of_line;
}

void bus_init(void) {
  bus_init_cycle_to_table();
}
