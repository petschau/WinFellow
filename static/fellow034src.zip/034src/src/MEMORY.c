/*=============================*/
/* Fellow Amiga Emulator       */
/* Virtual Memory System       */
/* (C) 1994-1998 Petter Schau  */
/*           and Roman Dolejsi */
/*=============================*/


#include <stdio.h>
#include <stdlib.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <string.h>

#include "defs.h"
#include "fellow.h"
#include "inout.h"
#include "68000.h"
#include "draw.h"
#include "memorya.h"
#include "fhfile.h"
#include "graphem.h"
#include "floppy.h"
#include "copper.h"
#include "led.h"
#include "cianew.h"
#include "blit.h"
#include "memory.h"

BOOLE meminitfirsttime = TRUE;
ULO config_memory_fast_allocated = 0;

/* Configuration for rom */

BOOLE config_memory_nokick;
STR config_memory_kickname[256];
STR config_memory_kicknameloaded[256];
STR config_memory_kick2name[256];
ULO config_memory_kicksize;
ULO config_memory_romversion;
STR kickstart_idstring[80];
STR config_memory_keyname[256];
ULO config_memory_kickbase;


/* Configuration for memory sizes */

ULO config_memory_chipsize,config_memory_bogosize;
ULO config_memory_fastsize;
BOOLE config_memory_space_32bit;

ULO spritewritebuffer[128][2];
ULO spritewritenext;
ULO spritewritereal;
ULO screenmode;

/* Declare functions in this file */

ULO meminit(void);
void dumpioblock(void);
void hexdump(ULO wher);

/* Fault info */

BOOLE memory_fault_read;
ULO memory_fault_address;

/* Table of register read/write functions */

regreadfunc ioread[256] = {rdefault,rdmaconr,rvposr,rvhposr,
                           rdefault,rdefault,rdefault,rdefault,
                           rdefault,rdefault,rdefault,rdefault,
                           rserdatr,rdefault,rintenar,rintreqr,
                           rdefault,rdefault,rdefault,rdefault,
                           rdefault,rdefault,rdefault,rdefault,
                           rdefault,rdefault,rdefault,rdefault,
                           rdefault,rdefault,rdefault,rdefault,
                           rdefault,rdefault,rdefault,rdefault,
                           rdefault,rdefault,rdefault,rdefault,
                           rdefault,rdefault,rdefault,rdefault,
                           rdefault,rdefault,rdefault,rdefault,
                           rdefault,rdefault,rdefault,rdefault,
                           rdefault,rdefault,rdefault,rdefault,
                           rdefault,rdefault,rdefault,rdefault,
                           rdefault,rdefault,rid,rdefault,
                           rdefault,rdefault,rdefault,rdefault,
                           rcopjmp1,rcopjmp2,rdefault,rdefault,
                           rdefault,rdefault,rdefault,rdefault,
                           rdefault,rdefault,rdefault,rdefault,
                           rdefault,rdefault,rdefault,rdefault,
                           rdefault,rdefault,rdefault,rdefault,
                           rdefault,rdefault,rdefault,rdefault,
                           rdefault,rdefault,rdefault,rdefault,
                           rdefault,rdefault,rdefault,rdefault,
                           rdefault,rdefault,rdefault,rdefault,
                           rdefault,rdefault,rdefault,rdefault,
                           rdefault,rdefault,rdefault,rdefault,
                           rdefault,rdefault,rdefault,rdefault,
                           rdefault,rdefault,rdefault,rdefault,
                           rdefault,rdefault,rdefault,rdefault,
                           rdefault,rdefault,rdefault,rdefault,
                           rdefault,rdefault,rdefault,rdefault,
                           rdefault,rdefault,rdefault,rdefault,
                           rdefault,rdefault,rdefault,rdefault,
                           rdefault,rdefault,rdefault,rdefault,
                           rdefault,rdefault,rdefault,rdefault,
                           rdefault,rdefault,rdefault,rdefault,
                           rdefault,rdefault,rdefault,rdefault,
                           rdefault,rdefault,rdefault,rdefault,
                           rdefault,rdefault,rdefault,rdefault,
                           rdefault,rdefault,rdefault,rdefault,
                           rdefault,rdefault,rdefault,rdefault,
                           rdefault,rdefault,rdefault,rdefault,
                           rdefault,rdefault,rdefault,rdefault,
                           rdefault,rdefault,rdefault,rdefault,
                           rdefault,rdefault,rdefault,rdefault,
                           rdefault,rdefault,rdefault,rdefault,
                           rdefault,rdefault,rdefault,rdefault,
                           rdefault,rdefault,rdefault,rdefault,
                           rdefault,rdefault,rdefault,rdefault,
                           rdefault,rdefault,rdefault,rdefault,
                           rdefault,rdefault,rdefault,rdefault,
                           rdefault,rdefault,rdefault,rdefault,
                           rdefault,rdefault,rdefault,rdefault,
                           rdefault,rdefault,rdefault,rdefault,
                           rdefault,rdefault,rdefault,rdefault,
                           rdefault,rdefault,rdefault,rdefault,
                           rdefault,rdefault,rdefault,rdefault,
                           rdefault,rdefault,rdefault,rdefault,
                           rdefault,rdefault,rdefault,rdefault,
                           rdefault,rdefault,rdefault,rdefault,
                           rdefault,rdefault,rdefault,rdefault,
                           rdefault,rdefault,rdefault,rdefault};

regwritefunc iowrite[256]={wdefault,wdefault,wdefault,wdefault,
                           wdefault,wdefault,wdefault,wdefault,
                           wdefault,wdefault,wdefault,wdefault,
                           wdefault,wdefault,wdefault,wdefault,
                           wdefault,wdefault,wdefault,wdefault,
                           wdefault,wdefault,wvpos,wcopcon,
                           wdefault,wdefault,wdefault,wdefault,
                           wdefault,wdefault,wdefault,wdefault,
                           wdefault,wdefault,wdefault,wdefault,
                           wdefault,wdefault,wdefault,wdefault,
                           wdefault,wdefault,wdefault,wdefault,
                           wdefault,wdefault,wdefault,wdefault,
                           wdefault,wdefault,wdefault,wdefault,
                           wdefault,wdefault,wdefault,wdefault,
                           wbltcdat,wbltbdat,wbltadat,wdefault,
                           wdefault,wdefault,wdefault,wdefault,
                           wcop1lch,wcop1lcl,wcop2lch,wcop2lcl,
                           wcopjmp1,wcopjmp2,wdefault,wdiwstrt,
                           wdiwstop,wddfstrt,wddfstop,wdmacon,
                           wdefault,wintena,wintreq,wadcon,
                           wdefault,wdefault,wdefault,wdefault,
                           wdefault,wdefault,wdefault,wdefault,
                           wdefault,wdefault,wdefault,wdefault,
                           wdefault,wdefault,wdefault,wdefault,
                           wdefault,wdefault,wdefault,wdefault,
                           wdefault,wdefault,wdefault,wdefault,
                           wdefault,wdefault,wdefault,wdefault,
                           wdefault,wdefault,wdefault,wdefault,
                           wbpl1pth,wbpl1ptl,wbpl2pth,wbpl2ptl,
                           wbpl3pth,wbpl3ptl,wbpl4pth,wbpl4ptl,
                           wbpl5pth,wbpl5ptl,wbpl6pth,wbpl6ptl,
                           wdefault,wdefault,wdefault,wdefault,
                           wbplcon0,wbplcon1,wbplcon2,wdefault,
                           wbpl1mod,wbpl2mod,wdefault,wdefault,
                           wdefault,wdefault,wdefault,wdefault,
                           wdefault,wdefault,wdefault,wdefault,
                           wspr0pth,wspr0ptl,wspr1pth,wspr1ptl,
                           wspr2pth,wspr2ptl,wspr3pth,wspr3ptl,
                           wspr4pth,wspr4ptl,wspr5pth,wspr5ptl,
                           wspr6pth,wspr6ptl,wspr7pth,wspr7ptl,
                           wsprxpos,wsprxctl,wsprxdata,wsprxdatb,
                           wsprxpos,wsprxctl,wsprxdata,wsprxdatb,
                           wsprxpos,wsprxctl,wsprxdata,wsprxdatb,
                           wsprxpos,wsprxctl,wsprxdata,wsprxdatb,
                           wsprxpos,wsprxctl,wsprxdata,wsprxdatb,
                           wsprxpos,wsprxctl,wsprxdata,wsprxdatb,
                           wsprxpos,wsprxctl,wsprxdata,wsprxdatb,
                           wsprxpos,wsprxctl,wsprxdata,wsprxdatb,
                           wcolor,wcolor,wcolor,wcolor,
                           wcolor,wcolor,wcolor,wcolor,
                           wcolor,wcolor,wcolor,wcolor,
                           wcolor,wcolor,wcolor,wcolor,
                           wcolor,wcolor,wcolor,wcolor,
                           wcolor,wcolor,wcolor,wcolor,
                           wcolor,wcolor,wcolor,wcolor,
                           wcolor,wcolor,wcolor,wcolor,
                           wdefault,wdefault,wdefault,wdefault,
                           wdefault,wdefault,wdefault,wdefault,
                           wdefault,wdefault,wdefault,wdefault,
                           wdefault,wdefault,wdefault,wdefault,
                           wdefault,wdefault,wdefault,wdefault,
                           wdefault,wdefault,wdefault,wdefault,
                           wdefault,wdefault,wdefault,wdefault,
                           wdefault,wdefault,wdefault,wdefault};

/* Different variables used by the decode routines to scroll bitplanes */

ULO evenscroll,evenhiscroll,oddscroll,oddhiscroll;

/* Variables that correspond to various registers */

ULO dmaconr,dmacon;
ULO intenar,intena,intreq;

/* Screen related registers */

ULO bpl1pt,bpl2pt,bpl3pt,bpl4pt,bpl5pt,bpl6pt;

ULO lof,xpos,ypos,diwxleft,diwxright,diwytop,diwybottom,ddfstrt,
    ddfstop,
    bplcon0,bplcon1,bplcon2,bpl1mod,bpl2mod,diwstrt,diwstop;

/* Helpers for the screen emulation */

ULO screenptr;

/* Global line specific data */

ULO DDFstartpos,DDFnumberofwords,DIWfirstvisiblepos,DIWlastvisiblepos;
ULO DIWfirstposonline,DIWlastposonline;

/* Copper registers */

ULO copcon,cop1lc,cop2lc;

/* Blitter registers */

ULO linenum,linecount,linelength,blitterdmawaiting,
    bltadatoff,bltbdatoff,bltadattmp,bltbdattmp,
    bltcdattmp;

/* Sprite registers */

ULO sprpt[8],sprx[8],spry[8],sprly[8],spratt[8];
ULO spritestate[8];
ULO sprite16col[8];
UWO sprdat[8][2];

/* Actual memory */

UBY cmem[CHIPMEM+32];
UBY bmem[BOGOMEM+32];
UBY kmem[KICKMEM+32];
UBY emem[65536];
UBY *fmem = NULL;
UBY *k2mem = NULL;
UBY dmem[4096];
ULO dmemcounter;
ULO wriorgadr;


/*=======================*/
/* Memory mapping tables */
/*=======================*/

readfunc memory_bank_readbyte[65536];
readfunc memory_bank_readword[65536];
readfunc memory_bank_readlong[65536];
writefunc memory_bank_writebyte[65536];
writefunc memory_bank_writeword[65536];
writefunc memory_bank_writelong[65536];
UBY *memory_bank_pointer[65536];        /* Used to get opcodewords */
UBY *memory_bank_datapointer[65536];    /* Used to access data */


/*==========================*/
/* Memory mapping functions */
/*==========================*/


/*=====================================================================*/
/* Set read and write stubs for a bank, as well as a direct pointer to */
/* its memory. NULL pointer is passed when the memory must always be   */
/* read through the stubs, like in a bank of regsters where writing    */
/* or reading the value generates side-effects.                        */
/* Datadirect is TRUE when data accesses can be made through a pointer */
/*=====================================================================*/

void memoryBankSet(readfunc rb, readfunc rw, readfunc rl, writefunc wb,
		   writefunc ww, writefunc wl, UBY *basep, ULO bank,
		   ULO basebank, BOOLE datadirect) {
  ULO i, j;

  j = (config_memory_space_32bit) ? 65536 : 256;
  for (i = bank; i < 65536; i += j) {
    memory_bank_readbyte[i] = rb;
    memory_bank_readword[i] = rw;
    memory_bank_readlong[i] = rl;
    memory_bank_writebyte[i] = wb;
    memory_bank_writeword[i] = ww;
    memory_bank_writelong[i] = wl;
    if (basep != NULL) {
      memory_bank_pointer[i] = basep - (basebank<<16);
      if (datadirect)
	memory_bank_datapointer[i] = memory_bank_pointer[i];
      else
	memory_bank_datapointer[i] = NULL;
    }
    else
      memory_bank_pointer[i] = memory_bank_datapointer[i] = NULL;
    basebank += j;
  }
}


/*=============================================*/
/* Clear bank data to safe "do-nothing" values */
/*=============================================*/

void memoryBankClear(ULO bank) {
  memoryBankSet(readNAbyte, readNAword,
		readNAlong, writeNAbyte,
		writeNAword, writeNAlong, NULL, bank, 0, FALSE);
}


/*=================================================*/
/* Clear all bank data to safe "do-nothing" values */
/*=================================================*/

void memoryBankClearAll(void) {
  ULO bank, hilim;

  hilim = (config_memory_space_32bit) ? 65536 : 256;
  for (bank = 0; bank < hilim; bank++)
    memoryBankClear(bank);
}


/*=======================*/
/* Expansion card config */
/*=======================*/


#define EMEM_MAX_CARDS 4


/*=================================*/
/* Card init and map functiontable */
/*=================================*/

ememinitfunc emem_card_initfunc[EMEM_MAX_CARDS];
ememmapfunc emem_card_mapfunc[EMEM_MAX_CARDS];
ULO emem_cards;                                  /* Number of cards */
ULO emem_cards_finished;                         /* Current card */


/*=================================*/
/* Clear the expansion config bank */
/*=================================*/

void memoryEmemClear(void) {
  memset(emem, 0xff, 65536);
}


/*===================*/
/* Add card to table */
/*===================*/

void memoryEmemCardAdd(ememinitfunc cardinit, ememmapfunc cardmap) {
  if (emem_cards < EMEM_MAX_CARDS) {
    emem_card_initfunc[emem_cards] = cardinit;
    emem_card_mapfunc[emem_cards] = cardmap;
    emem_cards++;
  }
}


/*==========================*/
/* Advance the card pointer */
/*==========================*/

void memoryEmemCardNext(void) {
  emem_cards_finished++;
}


/*================*/
/* Init this card */
/*================*/

void memoryEmemCardInit(void) {
  memoryEmemClear();
  if (emem_cards_finished != emem_cards)
    emem_card_initfunc[emem_cards_finished]();
} 


/*=======================================*/
/* Map this card                         */
/* mapping is bank number set by AmigaOS */
/*=======================================*/

void memoryEmemCardMap(ULO mapping) {
  if (emem_cards_finished == emem_cards)
    memoryEmemClear();
  else
    emem_card_mapfunc[emem_cards_finished](mapping);
} 


/*==================*/
/* Reset card setup */
/*==================*/

void memoryEmemCardsReset(void) {
  emem_cards_finished = 0;
  memoryEmemCardInit();
}


/*======================*/
/* Clear the card table */
/*======================*/

void memoryEmemCardsRemove(void) {
  emem_cards = emem_cards_finished = 0;
}


/*=======================================================*/
/* Set a byte in autoconfig space, for initfunc routines */
/* so they can make their configuration visible          */
/*=======================================================*/

void memoryEmemSet(ULO index, ULO value) {
  index &= 0xffff;
  switch (index) {
    case 0:
    case 2:
    case 0x40:
    case 0x42:
      emem[index] = value & 0xf0;
      emem[index + 2] = (value & 0xf)<<4;
      break;
    default:
      emem[index] = ~(value & 0xf0);
      emem[index + 2] = ~((value & 0xf)<<4);
      break;
    }
}


/*===========================*/
/* Read stubs for autoconfig */
/*===========================*/

#pragma aux ememByteRead parm [ecx] value [edx];
ULO ememByteRead(ULO address) {
  return emem[address & 0xffff];
}

#pragma aux ememWordRead parm [ecx] value [edx];
ULO ememWordRead(ULO address) {
  return (emem[address & 0xffff]<<8) | emem[(address & 0xffff) + 1];
}

#pragma aux ememLongRead parm [ecx] value [edx];
ULO ememLongRead(ULO address) {
  return (ememWordRead(address)<<16) | ememWordRead(address + 2);
}


/*============================*/
/* Write stubs for autoconfig */
/*============================*/

#pragma aux ememByteWrite parm [ecx] [edx];
void ememByteWrite(ULO address, ULO data) {
  static ULO mapping;

  push_eax();
  data &= 0xff;
  switch (wriorgadr & 0xffff) {
    case 0x30:
    case 0x32:
      mapping = data = 0;
    case 0x48:
      mapping = (mapping & 0xff) | ((data & 0xff)<<8);
      memoryEmemCardMap(mapping);
      memoryEmemCardNext();
      memoryEmemCardInit();
      break;
    case 0x4a:
      mapping = (mapping & 0xff00) | (data & 0xff);
      break;
    case 0x4c:
      memoryEmemCardNext();
      memoryEmemCardInit();
      break;
    }
  pop_eax();
  restore_ecx();
}

#pragma aux ememWordWrite parm [ecx] [edx];
void ememWordWrite(ULO address, ULO data) {
  restore_ecx();
}

#pragma aux ememLongWrite parm [ecx] [edx];
void ememLongWrite(ULO address, ULO data) {
  restore_ecx();
}


/*============================================*/
/* Map the autoconfig memory bank into memory */
/*============================================*/

void memoryEmemMap(void) {
  if (config_memory_kickbase >= 0xf8)
    memoryBankSet(ememByteRead, ememWordRead, ememLongRead,
		  ememByteWrite, ememWordWrite, ememLongWrite,
		  NULL, 0xe8, 0xe8, FALSE);
}


/*===================*/
/* End of autoconfig */
/*===================*/


/*===================================================*/
/* dmem is the data area used by the hardfile device */
/*===================================================*/

/*=======================*/
/* Functions to set dmem */
/*=======================*/

void dmem_clear(void) {
  memset(dmem, 0, 4096);
}

void dmem_setcounter(ULO c) {
  dmemcounter = c;
}

ULO dmem_getcounter(void) {
  return dmemcounter + 0xf40000;
}

void dsets(char *st) {
  strcpy(dmem+dmemcounter,st);
  dmemcounter += strlen(st)+1;
  if (dmemcounter & 0x1) dmemcounter++;
}

void dsetb(UBY data) {
  dmem[dmemcounter++] = data;
}

void dsetw(UWO data) {
  dmem[dmemcounter++] = (data&0xff00)>>8;
  dmem[dmemcounter++] = data&0xff;
}

void dsetl(ULO data) {
  dmem[dmemcounter++] = (data&0xff000000)>>24;
  dmem[dmemcounter++] = (data&0xff0000)>>16;
  dmem[dmemcounter++] = (data&0xff00)>>8;
  dmem[dmemcounter++] = data&0xff;
}

#pragma aux readdmembyte parm [ecx] value [edx];
ULO readdmembyte(ULO address){
  ULO tmpval = 0;

  push_ecx();
  if ((address&0xffffff) < 0xf41000) tmpval = dmem[address&0xfff];
  pop_ecx();
  return tmpval;
}

#pragma aux readdmemword parm [ecx] value [edx];
ULO readdmemword(ULO address){
  ULO tmpval = 0;

  push_ecx();
  if ((address&0xffffff) < 0xf41000)
    tmpval = (dmem[address&0xfff]<<8) | dmem[(address&0xfff)+1];
  pop_ecx();
  return tmpval;
}

#pragma aux readdmemlong parm [ecx] value [edx];
ULO readdmemlong(ULO address){
  ULO tmpval = 0;
  push_ecx();

  if ((address&0xffffff) < 0xf41000)
    tmpval = (dmem[address&0xfff]<<24) | (dmem[(address&0xfff)+1]<<16) | (dmem[(address&0xfff)+2]<<8) | dmem[(address&0xfff)+3];
  pop_ecx();
  return tmpval;
}

#pragma aux writedmemlong parm [ecx] [edx];
void writedmemlong(ULO address, ULO data){
  push_ad();
  if ((wriorgadr & 0xffffff) == 0xf40000) {
    switch (data>>16) {
      case 0x0001:    fhfileDo(data);
                      break;
      default:        break;
      }
    }
  pop_ad();
  restore_ecx();
}

void memoryDmemMap(void) {
  ULO bank = 0xf40000>>16;

  if (config_fhfile_enabled && (config_memory_kickbase >= 0xf8))
    memoryBankSet(readdmembyte, readdmemword, readdmemlong,
		  writeNAbyte, writeNAword,
		  writedmemlong, dmem, bank, bank, FALSE);
}

/*==================*/
/* Used by hardfile */
/*==================*/

UBY *address_to_ptr(ULO address) {
  UBY *result;

  if ((result = memory_bank_pointer[address>>16]) != NULL)
    result += address;
  return result;
}


/*=============*/
/* Chip memory */
/*=============*/

void memoryChipClear(void) {
  memset(cmem, 0, config_memory_chipsize);
}

void memoryChipMap(void) {
  ULO bank, lastbank;

  if (config_memory_chipsize > 0x200000) lastbank = 0x200000>>16;
  else lastbank = config_memory_chipsize>>16;
  for (bank = 0; bank < lastbank; bank++)
    memoryBankSet(readchipbyte, readchipword, readchiplong,
		  writechipbyte, writechipword, writechiplong,
		  cmem, bank, 0, TRUE);
  for (bank = lastbank; bank < (0x200000>>16); bank++) memoryBankClear(bank);
  memoryChipClear();
}


/*===========================================*/
/* Set up autoconfig values for fastmem card */
/*===========================================*/

void memoryFastCardInit(void) {
  if (config_memory_fastsize == 0x100000) memoryEmemSet(0, 0xe5);
  else if (config_memory_fastsize == 0x200000) memoryEmemSet(0, 0xe6);
  else if (config_memory_fastsize == 0x400000) memoryEmemSet(0, 0xe7);
  else if (config_memory_fastsize == 0x800000) memoryEmemSet(0, 0xe0);
  memoryEmemSet(8, 128);
  memoryEmemSet(4, 1);
  memoryEmemSet(0x10, 2011>>8);
  memoryEmemSet(0x14, 2011 & 0xf);
  memoryEmemSet(0x18, 0);
  memoryEmemSet(0x1c, 0);
  memoryEmemSet(0x20, 0);
  memoryEmemSet(0x24, 1);
  memoryEmemSet(0x28, 0);
  memoryEmemSet(0x2c, 0);
  memoryEmemSet(0x40, 0);
}


/*=====================================================================*/
/* Map fastcard, should really map it to the address amigados tells us */
/* but assume it is 0x200000 for now                                   */
/*=====================================================================*/

void memoryFastCardMap(ULO mapping) {
  ULO bank, lastbank, i;

  if (config_memory_fastsize > 0x800000) lastbank = 0xa00000>>16;
  else lastbank = (0x200000 + config_memory_fastsize)>>16;
  for (bank = 0x200000>>16; bank < lastbank; bank++)
    memoryBankSet(readfastbyte, readfastword, readfastlong,
		  writefastbyte, writefastword, writefastlong,
		  fmem, bank, 0x200000>>16, TRUE);
  memset(fmem, 0, config_memory_fastsize);
}


/*====================================*/
/* Clear fastmem address space tables */
/*====================================*/

void memoryFastClear(void) {
  ULO bank;

  for (bank = 0x200000>>16; bank < (0xa00000>>16); bank++)
    memoryBankClear(bank);
}


/*===================================================================*/
/* Allocate fastmemory, and if successful, enter the fastcard in the */
/* autoconfig tables                                                 */
/*===================================================================*/

void memoryFastInitFirst(void) {
  ULO origmem = config_memory_fastsize;

  if (config_memory_fast_allocated != config_memory_fastsize) {
    if (fmem != NULL) free(fmem); /* Free previously used memory */
    if (config_memory_fastsize == 0) {
      config_memory_fast_allocated = 0;
      memoryFastClear();
      return;
    }
    fmem = (UBY *) malloc(config_memory_fastsize);
    if (fmem == NULL) {
      /* Failed, tell user it happened, set fastsize to 0 */
      config_memory_fastsize = 0;
#ifdef USE_GUI
      fguiRequester("Not enough memory available for the current fast-memory setting", "", "Fast-memory setting adjusted to 0 bytes");
#endif
    }
  }
  config_memory_fast_allocated = config_memory_fastsize;
  memoryFastClear();
  if (config_memory_fastsize > 0)
    memoryEmemCardAdd(memoryFastCardInit, memoryFastCardMap);
}

void memoryBogoMap(void) {
  ULO bank, lastbank, i;
  
  if (config_memory_bogosize > 0x1c0000) lastbank = 0xdc0000>>16;
  else lastbank = (0xc00000 + config_memory_bogosize)>>16;
  for (bank = 0xc00000>>16; bank < lastbank; bank++)
    memoryBankSet(readbogobyte, readbogoword, readbogolong,
		  writebogobyte, writebogoword, writebogolong,
		  bmem, bank, 0xc00000>>16, TRUE);
  memset(bmem, 0, config_memory_bogosize);
}


/*============================*/
/* Probably a disk controller */
/*============================*/

void memoryMysteryMap(void) {
  memoryBankSet(readMysterybyte, readMysteryword, readMysterylong,
		writeMysterybyte, writeMysteryword, writeMysterylong,
		NULL, 0xe9, 0, FALSE);
  memoryBankSet(readMysterybyte, readMysteryword, readMysterylong,
		writeMysterybyte, writeMysteryword, writeMysterylong,
		NULL, 0xde, 0, FALSE);
}


/*==============*/
/* IO Registers */
/*==============*/

void memoryRegisterMap(void) {
  ULO bank, lastbank;

  if (config_memory_bogosize > 0x1c0000) lastbank = 0xdc0000>>16;
  else lastbank = (0xc00000 + config_memory_bogosize)>>16;
  for (bank = lastbank; bank < 0xe00000>>16; bank++)
    memoryBankSet(readregisterbyte, readregisterword, readregisterlong,
		  writeregisterbyte, writeregisterword, writeregisterlong,
		  NULL, bank, 0, FALSE);
}

/*=============*/
/* ROM support */
/*=============*/

void memoryRomMap(void) {
  ULO bank, basebank;

  basebank = config_memory_kickbase & 0xf8;
  for (bank = AF_MAP_ROM>>16; bank < ((AF_MAP_ROM + 0x80000)>>16); bank++)
    memoryBankSet(readkickbyteaf, readkickwordaf, readkicklongaf,
		  writekickbyte, writekickword,
		  writekicklong, kmem, bank, AF_MAP_ROM>>16, FALSE);
  if (basebank == 0xf8)
    for (bank = basebank; bank < (basebank + 8); bank++)
      memoryBankSet(readkickbyte, readkickword, readkicklong,
		    writekickbyte, writekickword,
		    writekicklong, kmem, bank, basebank, TRUE);
  else
    for (bank = basebank; bank < (basebank + 8); bank++)
      memoryBankSet(readlkickbyte, readlkickword, readlkicklong,
		    writekickbyte, writekickword,
		    writekicklong, kmem, bank, basebank, TRUE);
}

void memoryRomError(ULO errorcode, ULO data) {
#ifdef USE_GUI
  static STR error1[80], error2[160], error3[160];
  
  sprintf(error1, "Kickstart file could not be loaded");
  sprintf(error2, "%s", config_memory_kickname);
  error3[0] = '\0';
  switch (errorcode) {
    case MEMORY_ROM_ERROR_SIZE:
      sprintf(error3,
	      "Illegal size: %d bytes, size must be either 256K or 512K",
	      data);
      break;
    case MEMORY_ROM_ERROR_AMIROM_VERSION:
      sprintf(error3, "Unsupported encryption method, version found was %d",
	      data);
      break;
    case MEMORY_ROM_ERROR_AMIROM_READ:
      sprintf(error3, "Read error in encrypted Kickstart or keyfile");
      break;
    case MEMORY_ROM_ERROR_KEYFILE:
      sprintf(error3, "Unable to access keyfile %s", config_memory_keyname);
      break;
    case MEMORY_ROM_ERROR_EXISTS_NOT:
      sprintf(error3, "File does not exist");
      break;
    case MEMORY_ROM_ERROR_FILE:
      sprintf(error3, "File is a directory");
      break;
    case MEMORY_ROM_ERROR_KICKDISK_NOT:
      sprintf(error3, "The ADF-image is not a kickdisk");
      break;
    case MEMORY_ROM_ERROR_CHECKSUM:
      sprintf(error3,
	      "The Kickstart image has a checksum error, checksum is %X",
	      data);
      break;
    case MEMORY_ROM_ERROR_KICKDISK_SUPER:
      sprintf(error3,
	 "The ADF-image contains a superkickstart. Fellow can not handle it.");
      break;
    case MEMORY_ROM_ERROR_BAD_BANK:
      sprintf(error3, "The ROM has a bad baseaddress: %X",
	      config_memory_kickbase*0x10000);
      break;
  }
  fguiRequester(error1, error2, error3);
#endif /* USE_GUI */
  config_memory_nokick = TRUE;
  config_memory_romversion = 0;
  config_memory_kickbase = 0xf8;
  strcpy(config_memory_kicknameloaded, "__None__");
  strcpy(config_memory_kickname, "__None__");
}


ULO memoryRomChksum(void) {
  ULO sum, lastsum;
  ULO start, i;

  return 0;

  start = (kmem[5] == 0xfc) ? 0xfc0000 : 0xf80000;
  sum = lastsum = 0;
  for (i = start; i < 0x1000000; i += 4) {
    sum += fetl(i);
    if (sum < lastsum)
      sum++;
    lastsum = sum;
  }
  return ~sum;
}


void memoryRomOK(void) {
  ULO chksum, basebank;
  
  if ((chksum = memoryRomChksum()) != 0)
    memoryRomError(MEMORY_ROM_ERROR_CHECKSUM, chksum);
  else {
    basebank = kmem[5];
    {
      STR s[80];

      sprintf(s, "basebank: %X\n", basebank);
      addlog(s);
    }
	      
    if ((basebank == 0xf0) || (basebank == 0xf4) || (basebank == 0xf8) ||
        (basebank == 0xfc)) {
      config_memory_kickbase = basebank;
      config_memory_nokick = FALSE;
      strcpy(config_memory_kicknameloaded, config_memory_kickname);
      memoryRomIdentify(kickstart_idstring);
    }
    else
      memoryRomError(MEMORY_ROM_ERROR_BAD_BANK, basebank);
  }
}


const STR *romversions[14] = {"Kickstart, version information unavailable",
                              "Kickstart Pre-V1.0",
			      "Kickstart V1.0",
			      "Kickstart V1.1 (NTSC)",
			      "Kickstart V1.1 (PAL)",
			      "Kickstart V1.2",
			      "Kickstart V1.3",
			      "Kickstart V1.3",
			      "Kickstart V2.0",
			      "Kickstart V2.04",
			      "Kickstart V2.1",
			      "Kickstart V3.0",
			      "Kickstart V3.1",
			      "Kickstart Post-V3.1"};
/* Taken out in 034
ULO memoryRomExecStr(UBY *rom) {
  ULO i;

  i = 0;

  while (i < 0x200) {
    if (rom[i] == 'e')
      if (strncmp(&rom[i], "exec", 4) == 0)
	if (strncmp(&rom[i], "exec.library", 13) != 0)
	  return i;
    i++;
  }
  return -1;
}
*/

STR *memoryRomIdentify(STR *s) {
  ULO i = 0;
  UBY *rom = kmem;
  UBY saved;
  ULO ver, rev;
  
  /* New code for 034 */

  ver = (rom[12] << 8) | rom[13];
  rev = (rom[14] << 8) | rom[15];
  if (ver == 65535) config_memory_romversion = 28;
  else if (ver < 29) config_memory_romversion = 29;
  else if (ver > 41) config_memory_romversion = 41;
  else config_memory_romversion = ver;
  sprintf(s, "%s (%d.%d)", romversions[config_memory_romversion - 28],ver,rev);
  return s;
}


/*===================================*/
/* Returns size of decoded kickstart */
/*===================================*/
      
int memoryRomDecodeAF(STR *filename, STR *keyfile) {
  STR *keybuffer;
  ULO keysize, filesize = 0, keypos = 0, c;
  FILE *KF, *RF;

  /* Read key */
  
  if ((KF = fopen(keyfile, "rb")) != NULL) {
    fseek(KF, 0, SEEK_END);
    keysize = ftell(KF);
    keybuffer = malloc(keysize);
    fseek(KF, 0, SEEK_SET);
    fread(keybuffer, 1, keysize, KF);
    fclose(KF);
  }
  else
    return -1;
  if (!keybuffer)
    return -1;  

  /* Read file */

  if ((RF = fopen(filename, "rb")) != NULL) {
    fseek(RF, 11, SEEK_SET);
    while (((c = fgetc(RF)) != EOF) && filesize < 524288) {
      if (keysize != 0)
	c ^= keybuffer[keypos++];
      if (keypos == keysize)
	keypos = 0;
      kmem[filesize++] = c;
    }
    while ((c = fgetc(RF)) != EOF)
      filesize++;
    fclose(RF);
    free(keybuffer);
    return filesize;
  }
  free(keybuffer);
  return -1;
}
  

/*==============================================================*/
/* Load Amiga Forever encrypted ROM-files                       */
/* Return TRUE if file was handled, that is both if the file is */
/* valid, or has wrong version                                  */
/*==============================================================*/

int memoryRomLoadAF2(FILE *F) {
  ULO version,i;
  STR *temppath;
  STR IDString[12];
  FILE *keyfile;
  
  fread(IDString, 11, 1, F);
  version = IDString[10] - '0';
  IDString[10] = '\0';
  if (stricmp(IDString, "AMIROMTYPE") == 0) { /* Header seems OK */
    if (version != 1) {
      memoryRomError(MEMORY_ROM_ERROR_AMIROM_VERSION, version);
      return TRUE;  /* File was handled */
    }
    else { /* Seems to be a file we can handle */
      ULO size;

      fclose(F);

      /* Test if keyfile exists */

      if ((keyfile = fopen(config_memory_keyname, "rb")) == NULL) {
	memoryRomError(MEMORY_ROM_ERROR_KEYFILE, 0);
	return TRUE;
      }
      else {
	fclose(keyfile);
	size = memoryRomDecodeAF(config_memory_kickname,
				 config_memory_keyname);
	if (size == -1) {
	  memoryRomError(MEMORY_ROM_ERROR_AMIROM_READ, 0);
	  return TRUE;
	}
	if (size != 262144 && size != 524288) {
	  memoryRomError(MEMORY_ROM_ERROR_SIZE, size);
	  return TRUE;
	}
	if (size == 262144)
	  memcpy(kmem + 262144, kmem, 262144);
	config_memory_nokick = FALSE;
	strcpy(config_memory_kicknameloaded,
	       config_memory_kickname);
	memoryRomIdentify(kickstart_idstring);
	return TRUE;
      }
    }
  }
  /* Here, header was not recognized */
  return FALSE;
}


/*=================================================*/
/* Detect and load kickdisk                        */
/* Based on information provided by Jerry Lawrence */
/*=================================================*/

void memoryRomKickdiskLoad(FILE *F) {
  STR head[5];
 
  /* Check header */

  fseek(F, 0, SEEK_SET);
  fread(head, 4, 1, F);
  head[4] = '\0';
  if (strcmp(head, "KICK") != 0) {
    memoryRomError(MEMORY_ROM_ERROR_KICKDISK_NOT, 0);
    return;
  }
  fread(head, 3, 1, F);
  head[3] = '\0';
  if (strcmp(head, "SUP") == 0) {
    memoryRomError(MEMORY_ROM_ERROR_KICKDISK_SUPER, 0);
    return;
  }
  fseek(F, 512, SEEK_SET); /* Load image */
  fread(kmem, 262144, 1, F);
  memcpy(kmem + 262144, kmem, 262144);
}


/*======================================================================*/
/* config_memory_kickname is the file we want to load                   */
/* config_memory_kicknameloaded is the file we currently have in memory */
/* Initially kickname is set to kick.rom                                */
/*======================================================================*/

void memoryRomLoad(void) {
  FILE *F;
  ULO i;
  struct stat mystat;
  BOOLE kickdisk = FALSE;
  STR *suffix, *lastsuffix;
  BOOLE afkick = FALSE;
  
  if (stricmp(config_memory_kickname, config_memory_kicknameloaded) != 0) {

    /* New file is different from previous */
    /* Must load file */

    config_memory_nokick = FALSE;         /* Initially Kickstart is OK */
    if (stat(config_memory_kickname, &mystat) != 0)
      memoryRomError(MEMORY_ROM_ERROR_EXISTS_NOT, 0);
    else if (!S_ISREG(mystat.st_mode))
      memoryRomError(MEMORY_ROM_ERROR_FILE, 0);
    else { /* File passed initial tests */
      if ((F = fopen(config_memory_kickname, "rb")) == NULL)
	memoryRomError(MEMORY_ROM_ERROR_EXISTS_NOT, 0);
    }

    /* Either the file is open, or config_memory_nokick is TRUE */ 

    if (!config_memory_nokick) {

      /* File opened successfully */

      /* Kickdisk flag */

      suffix = strchr(config_memory_kickname, '.');
      if (suffix != NULL) {
	lastsuffix = suffix;
	while ((suffix = strchr(lastsuffix + 1, '.')) != NULL)
	  lastsuffix = suffix;
	kickdisk = (stricmp(lastsuffix + 1, "ADF") == 0);
      }
      /* mem_loadrom_af2 will return TRUE if file was handled */
      /* Handled also means any error conditions */
      /* The result can be that no kickstart was loaded */

      if (kickdisk)
	memoryRomKickdiskLoad(F);
      else
	afkick = memoryRomLoadAF2(F);
      if (!kickdisk && !afkick) { /* Normal kickstart image */
	fseek(F, 0, SEEK_SET);
	config_memory_kicksize = mystat.st_size;
	if (config_memory_kicksize < 262144) { /* Assume bootrom */
	  fread(kmem, 1, 8192, F);
	}
	else if (config_memory_kicksize < 524288) {   /* Load 256k ROM */
	  fread(kmem, 1, 262144, F);
	  memcpy(kmem + 262144, kmem, 262144);
	}
	else if (config_memory_kicksize >= 524288)/* Load 512k ROM */
	  fread(kmem, 1, 524288, F);
	else {                                     /* Rom size is wrong */
	  memoryRomError(MEMORY_ROM_ERROR_SIZE, config_memory_kicksize);
	}
	fclose(F);
      }
    }
    if (!config_memory_nokick)
      memoryRomOK();
  }
}


/*==============*/
/* Generic init */
/*==============*/

void memoryRegInit(void) {
  ULO k,m;
  
  /* Initialize Screen Registers*/
  lof = 0x8000;       /* Always long frame, or maybe not...*/
  bpl1mod = 0;
  bpl2mod = 0;
  diwxleft = 0;
  diwxright = 0; 
  diwytop = 0;   
  diwybottom = 0;
  bpl1pt = 0;
  bpl2pt = 0;
  bpl3pt = 0;
  bpl4pt = 0;
  bpl5pt = 0;
  bpl6pt = 0;
  bplcon0 = 0;
  bplcon1 = 0;
  bplcon2 = 0;
  ddfstrt = 0;
  ddfstop = 0;
  diwstrt = 0;
  diwstop = 0;
  intena = 0;
  intreq = 0;
  
  /* Initialize the helpers for screenemulation */
  /* Assume no bitplanes on */

  DDFstartpos = 0;
  DDFnumberofwords = 0;
  DIWfirstvisiblepos = 256;
  DIWlastvisiblepos = 256;
  DIWfirstposonline = 88;

  /* Initialize various registers*/
  dmaconr = 0;
  dmacon = 0;

  /* Zero the shadow color registers */
  for (k=0; k<64; k++) shadcol[k] = 0;
  spritewritenext = 0;
  spritewritereal = 0;
}


/*===========================================*/
/* Color translation initialization          */
/* Definetly ended up in the wrong place.... */
/*===========================================*/

ULO vgareg2color[256];

void memoryColorTranslationInit(void) {
  ULO k,r,g,b;

  /* Create color translation table */

  if (config_graphics_modebits[config_graphics_mode] == 8) {
    ULO rbt[16] = { 0,0,1,1,1,2,2,2,3,3,3,4,4,4,5,5};
    ULO gt[16] = { 0,0,1,1,1,2,2,3,3,3,4,4,5,5,6,6};
    /* Use 6 levels of red and blue, 7 levels of green */
    for (k=0; k<4096;k++) {
      colortab[k] = rbt[k & 0xf] + gt[(k & 0xf0)>>4]*6 + rbt[(k & 0xf00)>>8]*42;
      vgareg2color[colortab[k]] = k;
      colortab[k] = colortab[k]<<24 |colortab[k]<<16 |colortab[k]<<8 | colortab[k];
    }
    for (r = 0; r < 6; r++) 
      for (g = 0; g < 7; g++)
	for (b = 0; b < 6; b++)
	  set_VGAcolor(b+(g*6)+(r*42),b*11+b,g*10,r*11+r);

  }
  else if (config_graphics_modebits[config_graphics_mode] == 15) {
    for (k=0; k<4096;k++) {
      colortab[k] = ((k & 0xf)<<1) | ((k & 0xf0)<<2) | ((k & 0xf00)<<3);
      colortab[k] = colortab[k]<<16 | colortab[k];
    }
    powerledcolor = 0x7c007c00;
    drivemotorcolor = 0x03e003e0;
    hdledcolor = 0x73807380;
  }
  else {
    for (k=0; k<4096;k++) {
      colortab[k] = ((k & 0xf)<<1) | ((k & 0xf0)<<3) | ((k & 0xf00)<<4);
      colortab[k] = colortab[k]<<16 | colortab[k];
    }
    powerledcolor = 0xf800f800;
    drivemotorcolor = 0x07e007e0;
    hdledcolor = 0x0e700e700;
  }   
}

extern readk2byte();
extern readk2word();
extern readk2long();


void memoryKick2Load(void) {
  FILE *F;
  
  if (k2mem == NULL) {
    k2mem = malloc(0x80000);
    if (k2mem == NULL) addlog("NULL!\n");
    if ((F = fopen(config_memory_kick2name, "rb")) != NULL) {
      fread(k2mem, 0x40000, 1, F);
      fclose(F);
      memcpy(k2mem + 262144, k2mem, 0x40000);
    }
  }
}


void memoryKick2Map(void) {
  ULO bank;
  
  for (bank = 0xf8; bank < (0x100); bank++)
      memoryBankSet(readk2byte, readk2word, readk2long,
		    writekickbyte, writekickword,
		    writekicklong, k2mem, bank, 0xf8, TRUE);
}

/* Must be called every time memory sizes change */

void memoryInit(void) {
  memoryRegInit();

  /* Initialize the jumptables */
  /* There is some redundancy here, but just make sure there are no */
  /* NULL ptrs in the tables, clear it all to a default value */

  memoryEmemCardsRemove();
  memoryBankClearAll();
  memoryChipMap();
  memoryFastInitFirst();
  cia_map();
  memoryBogoMap();
  memoryRegisterMap();
  memoryEmemMap();
  memoryRomLoad();
  memoryRomMap();
  memoryDmemMap();
  memoryMysteryMap();
  if (config_memory_kickbase < 0xf8) {
    memoryKick2Load();
    memoryKick2Map();
  }
  meminitfirsttime = FALSE;

}

void memoryShutdown(void) {
  if (fmem != NULL) free(fmem);
}




