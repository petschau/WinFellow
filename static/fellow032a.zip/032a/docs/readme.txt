This archive contains Fellow V0.3.2a:
-------------------------------------

Always read the documentation.


About V0.3.2a:
--------------

Added in V0.3.2a is Rainer Sinsch's low-pass filter implementation +
his correction to the Wav-file header. (In Wav-capture.)
