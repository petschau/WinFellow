This archive contains Fellow V0.3.3:
------------------------------------

Fellow is an Amiga Emulator for DOS.

Please always read the documentation first.


Finally after spending half of the year doing other things, there
are some new emulation material to present.


Summary of major user-visible changes:
--------------------------------------

-68010, 68020, 68030 instruction set emulation now capable of running
 some programs. 

-MOD Ripper (contributed by Rainer Sinsch)

-Virtual Filesystem driver (included by kind permission from UAE)

-Added some new user manual translations.

-Lots of smaller changes, download the source-code archive and read
 fixes.txt to look for anything interesting. (Or simply read the
 updated docs).


Files in this archive:
----------------------

Fellow.exe                         - Emulator binary
docs\                              - Documentation directory
docs\Readme.txt                    - This overall description
docs\Demos.txt                     - Configuration settings for some
                                     popular Amiga demos.
docs\Credits.txt                   - Full list of credits for Fellow
docs\Fellow.faq                    - Collection of Frequently Asked Questions
docs\Fellow.txt                    - Fellow User Manual in english
docs\Ledboard.txt                  - Circuit Schematics for a led-board.
docs\tech.txt                      - Technical information about the
                                     capabilites and have not's of the
                                     emulation model used in Fellow.
docs\national\                     - Directory with User Manual translations
docs\national\fellowno.txt         - fellow.txt (Norsk)
docs\national\fellowdk.txt         - fellow.txt (Dansk)
docs\national\fellowse.txt         - fellow.txt (Svensk)
docs\national\fellowde.txt         - fellow.txt (Deutsch)
docs\national\fellowfr.txt         - fellow.txt (French)
docs\national\fellowit.txt         - fellow.txt (Italian)
docs\national\fellowes.txt         - fellow.txt (Spanish)




