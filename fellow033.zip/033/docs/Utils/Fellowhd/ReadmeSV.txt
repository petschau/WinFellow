FellowHD Version 1.0

Copyrights
Detta program �r FreeWare (grattis) s� l�nge att ingen tar betalt f�r det.
Om du vill l�gga in det i en FreeWare ShareWare Diskett eller CD-ROM, 
d� m�ste du ha ett skrivligt tillst�nd f�r det.
Upphvsr�ttskyddat av Magnus Olsen 1998
   

Vad �r detta program tillf�r ?
Om du vill g�ra en h�rd diskdriver fil till Fellow. D� kan du anv�nda 
detta program.

Hur anv�nder jag det ?
Det �r inst s� sv�rt att anv�nda det.
Skriv : Fellowhd.exe (namnet p� HD filen) (hur stor ska den vara i Mb)

exampel :
I DOS prompten skriv:
FellowHD.exe AmigaHD 50 (enter)
Den skapar en fil som heter  AmigaHD.ADF och  �r 50 Mb stor.

System krav.
CPU :  386 eller h�gre
Opreation System MS-DOS 5.0 eller h�gre

Buggar:
Jag kan inte hitta n�gra i denna version.