This archive contains Fellow V0.3.3:
------------------------------------

Fellow is an emulation of the Amiga computer for DOS.

Please always read the documentation first.

Refer to the "licence" section in docs\UserManual.html
for useage and distribution guidelines. 


Summary of major user-visible changes:
--------------------------------------

- 68010, 68020 and 68030 instruction set emulation now capable of running
  some programs. 
- MOD Ripper (contributed by Rainer Sinsch)
- Virtual Filesystem handler
- Added some new user manual translations, as well as converted some
  of it to HTML.

Smaller changes:
----------------

- Better virtual CPU speed configuration
- "Scanline" mode option for software aspect correction.
- bzipped ADF handling now depends on external utility "bzip",
  not compiled in anymore.
- dms files now recognized using external utlility "xdms.exe"
  (Users must get xdms themselves.)
- BMP dump now works in all host-resolutions
- WAV dump now a transparent layer in sound emulation, can dump in
  any sound quality
- Tighter synchronization possible on fast machines
- Blitter speed and long blits options added
- Kickdisk images can be used
- Better ROM version autodetection
- A second ROM-image is allowed
- And probably more I can not remember right now.


Files in this archive:
----------------------

Fellow.exe                         - Emulator binary
Makeadf.exe                        - ADF create utility
Fellowhd.exe                       - Hardfile create utility
Readme.txt                         - This overall description
docs\                              - Documentation directory
docs\index.html                    - Page which links all the documentation
docs\Credits.txt                   - Full list of credits for Fellow
docs\Fellow.faq                    - Collection of Frequently Asked Questions
docs\UserManual.html               - Fellow User Manual in english
docs\Ledboard.txt                  - Circuit Schematics for a led-board.
docs\tech.txt                      - Technical information about the
                                     capabilites and have not's of the
                                     emulation model used in Fellow.
docs\license.txt                   - Terms for use and distribution
docs\national\                     - Directory with User Manual translations
docs\national\dk\fellowdk.txt      - User Manual (Dansk)
docs\national\se\fellowse.doc      - User Manual (Svensk)
docs\national\se\techse.doc        - Technical specification (Svensk)
docs\national\de\fellowde.txt      - User Manual (Deutsch)
docs\national\fr\fellowfr.txt      - User Manual (French)
docs\national\it\fellowit.txt      - User Manual (Italian)
docs\national\es\fellowes.txt      - User Manual (Spanish)
docs\national\pl\fellowpl.txt      - User Manual (Polish)
docs\national\no\techno.txt        - Technical specification (Norsk)
docs\utils\fellowhd\readmeen.txt   - Fellowhd english release notes
docs\utils\fellowhd\readmesv.txt   - Fellowhd swedish release notes
utils\amiga\note.txt               - Note about amiga utlities
utils\amiga\transdis               - Transdisk utility for Amiga
utils\amiga\transrom               - Transrom utility for Amiga

