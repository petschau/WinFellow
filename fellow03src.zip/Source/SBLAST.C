/*================================*/
/* Fellow Amiga Emulator          */
/* Soundblaster specific routines */
/*================================*/

#include <stdio.h>
#include <dos.h>
#include <stdlib.h>
#include <conio.h>
#include "defs.h"
#include "sound.h"
#include "memory.h"
#include "chip.h"
#include "keyboard.h"

#include "sblasta.h"            /* Symbols defined in sblasta.asm */


ULO auddmaptr;                  /* pointer to dma buffer */
ULO config_sb_forceV1;          /* Force using soundblaster V1 code */
ULO stereo;                     /* Stereo sound (playing) */
ULO bits16;                     /* 16bit sound (playing) */
ULO playbuffer,editbuffer;      /* Doublebuffered sound */
ULO sb_irqbufferfinished;       /* Flag set when irq occurs */

ULO emuspeed;
ULO sbxpos,sbypos,sbframe;

ULO sbio;
ULO sbirq;
ULO sbdma8;
ULO sbdma16;
ULO dspmajor;
ULO dspminor;
ULO sbversion;
void (__interrupt __far *sboldirqvector)();
ULO sbsamplerate;

ULO irq1,irq2;  // irq masks

ULO dmasize;
ULO dmaselector;
ULO dmaaddress;
ULO dmapage;
ULO dmaflataddr;



ULO sbcmdread(void) {
        while (!(inp(sbio + 0xe) & 0x80));
        return inp(sbio + 0xa);
}

void sbcmdwrite(UBY val) {
        while ((inp(sbio + 0xc) & 0x80));
        outp(sbio + 0xc, val);
}

ULO sbmixread(ULO reg) {
        outp(4, reg);
        return inp(5);
}

void sbmixwrite(ULO reg, ULO val) {
        outp(4, reg);
        outp(5, val);
}

void dmaclear(int ch) {
        if (ch < 4) outp(0xc, 0);
        else outp(0xd8, 0);
}

void dmadisable(int ch) {
        if (ch < 4) outp(0xa, ch + 0x04);
        else outp(0xd4, (ch & 3) + 0x04);
}

void dmaenable(int ch) {
        if (ch < 4) outp(0xa, ch);
        else outp(0xd4, (ch & 3));
}


/* Use AIREAD */

void dmasetmode(int ch) {
        if (ch < 4) outp(0xb, ch + 0x18);
        else outp(0xd6, (ch & 3) + 0x18);
}

void dmasetoffset(int ch) {
        UWO address=((((ch < 4) ? (dmaflataddr): (dmaflataddr>>1)) & 0xffff));

        if (ch < 4) {
                if (playbuffer == 1) address += 20000;
                outp(ch<<1, address & 0xFF);
                outp(ch<<1, address>>8);
                }
        else {
                if (playbuffer == 1) address += 10000;
                outp(0xc0 | ((ch & 3)<<2), address & 0xFF);
                outp(0xc0 | ((ch & 3)<<2), address>>8);
    }

}

void dmasetpage(int ch) {
        switch(ch) {
                case 0: outp(0x87,dmapage);
                        break;
                case 1: outp(0x83,dmapage);
                        break;
                case 3: outp(0x82,dmapage);
                        break;
                case 5: outp(0x8B,dmapage);
                        break;
                case 6: outp(0x89,dmapage);
                        break;
                case 7: outp(0x8A,dmapage);
                        break;
                }
}

void dmasetlength(int ch) {
        if (ch < 4) {
                outp((ch<<1)|1,(dmasize-1)&0xff);
                outp((ch<<1)|1,(dmasize-1)>>8);
                }
        else {
                outp(0xc2|((ch&3)<<2),(dmasize-1)&0xff);
                outp(0xc2|((ch&3)<<2),(dmasize-1)>>8);
                }
}

/* 16-bit : use sb 16 commands */

void dmastarttransfer(void) {

  /* This should work on all soundblasters */

        sbcmdwrite(0x40);        // Samplerate using timeconstant
        sbcmdwrite(sbsamplerate);

        /* Any 16 bit mode can use native SB16 commands */

        if (bits16) {
                // stereo, signed, 16bit
                if (stereo) {
                        sbcmdwrite(0xb0);
                        sbcmdwrite(0x30);
                        sbcmdwrite((dmasize-1)&0xff);
                        sbcmdwrite((dmasize-1)>>8);
                        }
                else {
                        sbcmdwrite(0xb0);
                        sbcmdwrite(0x10);
                        sbcmdwrite((dmasize-1)&0xff);
                        sbcmdwrite((dmasize-1)>>8);
                        }
                }
        else {   /* 8 bit commands, must consider the old SB models */
                if (dspmajor == 4) {  /* Use generic for SB 16 */
                        if (stereo) {
                                sbcmdwrite(0xc0);
                                sbcmdwrite(0x20);
                                sbcmdwrite((dmasize-1)&0xff);
                                sbcmdwrite((dmasize-1)>>8);
                                }
                        else {
                                sbcmdwrite(0xc0);
                                sbcmdwrite(0x00); /* 8 bit is unsigned */
                                sbcmdwrite((dmasize-1)&0xff);
                                sbcmdwrite((dmasize-1)>>8);
                                }
                        }
                else if (dspmajor == 3) {  /* SB pro */
                        if (stereo) {                /* Set stereo */
                                sbmixwrite(0x0e, sbmixread(0x0e) | 0x2);
                                sbcmdwrite(0x48); /* dma size */
                                sbcmdwrite((dmasize-1)&0xff);
                                sbcmdwrite((dmasize-1)>>8);
                                sbcmdwrite(0x90); /* Auto init */
                                }
                        else {
                                sbmixwrite(0x0e, sbmixread(0x0e) & 0xfd);
                                sbcmdwrite(0x48); /* dma size */
                                sbcmdwrite((dmasize-1)&0xff);
                                sbcmdwrite((dmasize-1)>>8);
                                sbcmdwrite(0x90); /* Auto init */
                                }
                        }
                else { /* SB 1.0 and 2 */
                        sbcmdwrite(0x14); /* dma size */
                        sbcmdwrite((dmasize-1)&0xff);
                        sbcmdwrite((dmasize-1)>>8);
                        }
                }
}


void dmainittransfer(void) {
        if (bits16) {
                dmadisable(sbdma16);
                dmaclear(sbdma16);
                dmasetmode(sbdma16);
                dmasetoffset(sbdma16);
                dmasetpage(sbdma16);
                dmasetlength(sbdma16);
                dmaenable(sbdma16);
                }
        else {
                dmadisable(sbdma8);
                dmaclear(sbdma8);
                dmasetmode(sbdma8);
                dmasetoffset(sbdma8);
                dmasetpage(sbdma8);
                dmasetlength(sbdma8);
                dmaenable(sbdma8);
                }
}

void freedma (void) {
        static union REGS reg;
        reg.x.eax = 0x0101;
        reg.x.edx = dmaselector;
        int386(0x31, &reg, &reg);
}

int allocatedma(int size) {
        ULO addr;
        static union REGS reg;

        reg.x.eax = 0x0100;                      // DPMI Mem. Allocation
        reg.x.ebx = ((size*2) + 15>>4);    // # of paragraphs to alloc.
        int386(0x31, &reg, &reg);      // do it!!
        if (reg.x.cflag) return 1;    // error alloc. mem.

        dmaselector = reg.x.edx;  // get the base selector
        addr=(reg.x.eax&0xFFFF)<<4;      // get the real segment adress
        if ((addr>>16) != ((addr+size-1)>>16))
                addr = (addr+size)&0xffff0000;

        dmaflataddr = addr;// get the 20 bit real adress
        dmapage = dmaflataddr>>16;
        return 0;
}

void __interrupt __far sbinterrupt() {
        emuspeed = ((frames-sbframe)*71364)+(ypos*228)+xpos;
        emuspeed = (emuspeed*10000)/356820;
        if (emuspeed > 10000) emuspeed = 10000;
        sb_irqbufferfinished = 1;
        if (!bits16) inp(sbio+0xe);
        else inp(sbio+0xf);
        if (sbirq > 7) outp(0xA0,0x20);          /* Clear irq */
        outp(0x20,0x20);
}


int resetdsp() {
        ULO j;
        char s[20];
        outp(sbio + 0x6, 1);   /* write 1 to reset port */
        delay(100);
        outp(sbio + 0x6, 0);   /* write 0 to reset port */
        delay(100);
        j = inp(sbio + 0xa);
        sprintf(s,"reset: %X\n",j);
        addlog(s);
        return !(j == 0xaa); //;(inp(sbio + 0xe) == 0xaa);
}

void setupsbirq(void) {
        irq1=inp(0x21);  // Get irq masks
        irq2=inp(0xa1);

        // Set irq vector
        if (sbirq < 8) {
                sboldirqvector = _dos_getvect(sbirq+0x8);
                _dos_setvect(sbirq+0x8,sbinterrupt);
                }
        else {
                sboldirqvector = _dos_getvect(sbirq+0x72);
                _dos_setvect(sbirq+0x72,sbinterrupt);
                }

        // Enable irq
        if (sbirq < 8)
                outp(0x21,(irq1 & ~(1<<sbirq)));
        else
                outp(0xa1,(irq2 & ~(1<<(sbirq-8))));
}

/* Disable irq, set old vector */

void stopsbirq(void) {
        if (sbirq < 8) outp(0x21, irq1);
        else outp(0xa1, irq2);

        if (sbirq < 8) _dos_setvect(sbirq + 0x8, sboldirqvector);
        else _dos_setvect(sbirq + 0x72, sboldirqvector);
}

int scan_blaster(char tmp, char *env) {
        char cpy[5];
        int i = 0;

        while (*(env + i) != 0 && toupper(*(env + i)) != toupper(tmp)) i++;
        if (*(env+i) == 0) return -1;
        else {
                env += i + 1; i = 0;
                while ( *(env+i) != 0 && *(env+i) != ' ' ) {
                        cpy[i] = *(env+i);
                        i++;
                        }
                cpy[i] = 0;
                return (atoi(cpy));
                }
}


int examine_blaster_var(void) {
        char *envvar;
        char trans[20];
        char o[80];

        if ((envvar = getenv("BLASTER")) != NULL) {
                sbio = scan_blaster('A', envvar);
                sbirq = scan_blaster('I', envvar);
                sbdma8 = scan_blaster('D', envvar);
                sbdma16 = scan_blaster('H', envvar);

                sprintf(trans,"%d\n",sbio);
                sscanf(trans,"%X\n",&sbio);

                addlog("Result of BLASTER search:\n");
                sprintf(o,"sbio = %X\n",sbio);
                addlog(o);
                sprintf(o,"sbirq = %d\n",sbirq);
                addlog(o);
                sprintf(o,"sbdma8 = %d\n",sbdma8);
                addlog(o);
                sprintf(o,"sbdma16 = %d\n",sbdma16);
                addlog(o);

                if (sbio != -1 && sbirq != -1 && sbdma8 != -1) return 1;
                else {
                        addlog("Error in BLASTER variable\n");
                        return -1;
                        }
                }
        else return -1;      /* Blaster var not found */
}


void clear_dmabuffer(void) {
        int i;

        if (config_soundcard_found)
                for (i = 0; i < 40000; i++) *((char *)(dmaflataddr+i)) = 0;
}


/* Test irq, switch buffers and play */

void sb_testirqflag(void);
#pragma aux sb_testirqflag=\
        "lab:   test    dword ptr [f12pressed],1",\
        "       jnz     lab2",\
        "       test    dword ptr [sb_irqbufferfinished],1", \
        "       jz      lab",\
        "lab2:";

void sb_play(void) {
        ULO tmp;
        addlog("sb_play\n");
        tmp = editbuffer;
        editbuffer = playbuffer;
        playbuffer = tmp;
        auddmaptr = dmaflataddr + ((editbuffer == 1) ? 20000:0);
        dmainittransfer();
        dmastarttransfer();
        sb_irqbufferfinished = FALSE;
}

void sb_test_and_play(void) {
        addlog("sb_testirqflag\n");
        sb_testirqflag();
        sb_play();
}


/* Called before emulation is started */
/* Maybe overly careful about things... */

/* This is possibly where the mysterious sound-failures can be prevented */
/* Some actions here: */

/* 1. Make sure the SB is not already playing something, or was playing */
/*    something (when F12 is pressed and emulation started again.) */
/*    Resetting the DSP could make sure? */
/* 2. Start playing a buffer */

void sb_before_emu(void) {
        addlog("before emu\n");
        clear_dmabuffer();
        resetdsp();
        sb_play();
}

/* Called after emulation is stopped */

void sb_after_emu(void) {
        clear_dmabuffer();
        addlog("After emu\n");
}

void sb_set_global_callbacks(void) {
        /* Install callback for playing a buffer */

        sound_playbuffer = sb_test_and_play;

        /* Install callbacks for before and after emulation setup */

        sound_before_emu = sb_before_emu;
        sound_after_emu = sb_after_emu;
}

/* 234 = 45454 stereo and mono (on SB16) and mono on pro*/
/* 224 = 31300 stereo and mono (on SB16) and mono on pro*/
/* 210 = 21739 stereo and mono (on SB16) and mono on any*/
/* 192 = 15650 stereo and mono (on SB16) and mono on any*/
/* 233 = 21739 stereo on SB pro */
/* 224 = 15650 stereo on SB pro */

/* Returns the frequency to use in the period-table */

ULO sb_mode_setup(void) {
        char s[80];

        sb_set_global_callbacks();
        auddmaptr = dmaflataddr;
        stereo = !(config_sound_mode & 0x4);
        bits16 = !(config_sound_mode & 0x8);
        editbuffer = 0;
        playbuffer = 1;

        sprintf(s,"Stereo: %d, bits15 : %d\n",stereo,bits16);
        addlog(s);

        switch (config_sound_mode) {
                case 0:
                        sbsamplerate = 234;
                        dmasize = 9109;
                        break;
                case 1:
                        sbsamplerate = 224;
                        dmasize = 6260;
                        break;
                case 2:
                        sbsamplerate = 210;
                        dmasize = 9109/2;
                        break;
                case 3:
                        sbsamplerate = 192;
                        dmasize = 6260/2;
                        break;
                case 4:
                        sbsamplerate = 234;
                        dmasize = 9109/2;
                        break;
                case 5:
                        sbsamplerate = 224;
                        dmasize = 6260/2;
                        break;
                case 6:
                        sbsamplerate = 210;
                        dmasize = 9109/4;
                        break;
                case 7:
                        sbsamplerate = 192;
                        dmasize = 6260/4;
                        break;
                case 8:
                        sbsamplerate = 234;
                        dmasize = 9109;
                        break;
                case 9:
                        sbsamplerate = 224;
                        dmasize = 6260;
                        break;
                case 10:
                        if (dspmajor == 4) sbsamplerate = 210;
                        else sbsamplerate = 233;
                        dmasize = 9109/2;
                        break;
                case 11:
                        if (dspmajor == 4) sbsamplerate = 192;
                        else sbsamplerate = 224;
                        dmasize = 6260/2;
                        break;
                case 12:
                        sbsamplerate = 234;
                        dmasize = 9109/2;
                        break;
                case 13:
                        sbsamplerate = 224;
                        dmasize = 3130;
                        break;
                case 14:
                        sbsamplerate = 210;
                        dmasize = 9109/4;
                        break;
                case 15:
                        sbsamplerate = 192;
                        dmasize = 3130/2;
                        break;
                }

        switch (config_sound_mode & 0x3) {
                case 0: return 45454;
                case 1: return 31300;
                case 2: return 43478;
                case 3: return 31300;
                }

        return 31300;
}

void sb_setcallback(ULO i) {
        config_sound_setuproutines[i] = sb_mode_setup;
        if (i & 0x8) {
                if (i & 0x4)
                        config_sound_bufferroutines[i] = sb_8bit_mono_put_in_buffer;
                else 
                        config_sound_bufferroutines[i] = sb_8bit_stereo_put_in_buffer;
                }
        else {
                if (i & 0x4)
                        config_sound_bufferroutines[i] = sb_16bit_mono_put_in_buffer;
                else 
                        config_sound_bufferroutines[i] = sb_16bit_stereo_put_in_buffer;
                }
}

void iddsp(void) {
        int i, default_mode;

        sbcmdwrite(0xe1);
        dspmajor = sbcmdread();
        dspminor = sbcmdread();
        if (dspmajor == 1 || dspmajor > 4 || config_sb_forceV1) {
                addlog("Soundblaster 1.0 or 1.5!\n");
                config_soundcard_found = TRUE;
                for (i = 14; i < 16; i++) {
                        config_soundmodes[i] = TRUE;
                        sb_setcallback(i);
                        }
                default_mode = 14;
                dspmajor = 1;
                }
        else if (dspmajor == 2) {
                addlog("Soundblaster 2!\n");
                config_soundcard_found = TRUE;
                for (i = 14; i < 16; i++) {
                        config_soundmodes[i] = TRUE;
                        sb_setcallback(i);
                        }
                default_mode = 14;
                }
        else if (dspmajor == 3) {
                addlog("Soundblaster PRO!\n");
                config_soundcard_found = TRUE;   
                for (i = 10; i < 16; i++) {
                        config_soundmodes[i] = TRUE;
                        sb_setcallback(i);
                        }
                default_mode = 10;
                }
        else if (dspmajor == 4) {
                addlog("Soundblaster 16\n");
                for (i = 0; i < 16; i++) {
                        config_soundmodes[i] = TRUE;
                        sb_setcallback(i);
                        }
                config_soundcard_found = TRUE;
                default_mode = 0;
                }
        if (!configaudiomodesetbylog)
                config_sound_mode = default_mode;
        else if (!config_soundmodes[config_sound_mode])
                config_sound_mode = default_mode;
}



void sbinit(void) {
        int i,j;

        if (examine_blaster_var() == -1) {
                addlog("No BLASTER variable, sound off\n");
                return;
                }

        if (resetdsp() == 1) {
                addlog("Didn't find DSP\n");
                return;
                }
        iddsp();
        if (allocatedma(40000) == 1) {
                        addlog("Error while allocating DMA buffer");
                        config_soundcard_found = FALSE;
                        return;
                        }
        clear_dmabuffer();
        setupsbirq();
        sound_initmode();
}

void sbclose(void) {
        stopsbirq();
        freedma();
        resetdsp();
}


