/* Fellow 1997 Petter Schau */

/* Clean C-implementation of the planar 2 chunky routines */
/* No optimization issues considered */

/* This file is also the home of generic variables for anything */
/* related to the graphics-emulation, except the actual VGA-drawing */
/* routines. (Soon) */

#include "defs.h"
#include "fellow.h"
#include "inout.h"
#include "68000.h"
#include "memory.h"
#include "chip.h"
#include "keyboard.h"
#include "graphemm.h"            /* Macros used */
#ifndef USE_C
#include "graphem.h"
#endif

/* Lookup-table for planar to chunky routines */

planar2chunkyroutine decoderoutinetab[16];
planar2chunkyroutine decoderoutinedualtab[16];

/* Planar to chunky lookuptables */

ULO deco1[256][2];
ULO deco2[256][2];
ULO deco3[256][2];
ULO deco4[256][2];
ULO deco5[256][2];
ULO deco6[256][2];

ULO deco320hi1[256];
ULO deco320hi2[256];
ULO deco320hi3[256];
ULO deco320hi4[256];

UBY decosc01[256][8];
UBY decosc11[256][8];
UBY decosc21[256][8];
UBY decosc31[256][8];
UBY decosc02[256][8];
UBY decosc12[256][8];
UBY decosc22[256][8];
UBY decosc32[256][8];
UBY decosc03[256][8];
UBY decosc04[256][8];
UBY linje[1024],linje2[1024];

ULO decodetmp;
ULO config_graphics_mode;
ULO config_graphics_skiprate;
ULO config_graphics_maxfps;
ULO config_graphics_flickerfree;                /* De-interlace in hires */


/* Routines optionally in assembler */

#ifdef USE_C

/* Add modulo values */

void modulos(ULO planes) {
        switch (planes) {
                case 6: bpl6pt += bpl2mod;
                case 5: bpl5pt += bpl1mod;
                case 4: bpl4pt += bpl2mod;
                case 3: bpl3pt += bpl1mod;
                case 2: bpl2pt += bpl2mod;
                case 1: bpl1pt += bpl1mod;
                default:break;
                }
}


/* Planar to chunky conversion, these currently deals with complete lines */

/* Noop */

void decode0(void) {};

/* Lores, 1 plane */

void decode1(void) {
        UBY *b1p = cmem + bpl1pt;
        ptunion lp;
        UBY bdata;
        ULO chunky1,chunky2,i;

        if (DDFnumberofwords > 0) {
                lp.bptr = linje + DDFstartpos + ODDSHIFT;
                bpl1pt += DDFnumberofwords*2;
                for (i = 0; i < DDFnumberofwords; i++) {
                        BCONVERT(chunky1,chunky2,bdata,(b1p++),deco1,P2C_SET);
                        LINE_STORE(chunky1,chunky2,(lp.lptr + i*4));
                        BCONVERT(chunky1,chunky2,bdata,(b1p++),deco1,P2C_SET);
                        LINE_STORE(chunky1,chunky2,(lp.lptr + 2 + i*4));
                        }
                modulos(1);
                }
}

/* Lores, 2 planes */

void decode2(void) {
        UBY *b1p = cmem + bpl1pt;
        UBY *b2p = cmem + bpl2pt;
        ptunion lp;
        UBY bdata;
        ULO chunky1,chunky2,i;

        if (DDFnumberofwords > 0) {
                lp.bptr = linje + DDFstartpos + ODDSHIFT;
                bpl1pt += DDFnumberofwords*2;
		bpl2pt += DDFnumberofwords*2;
                for (i = 0; i < DDFnumberofwords; i++) {
                        BCONVERT(chunky1,chunky2,bdata,(b1p++),deco1,P2C_SET);
                        LINE_STORE(chunky1,chunky2,(lp.lptr + i*4));
                        BCONVERT(chunky1,chunky2,bdata,(b1p++),deco1,P2C_SET);
                        LINE_STORE(chunky1,chunky2,(lp.lptr + 2 + i*4));
                        }
                lp.bptr = linje + DDFstartpos + EVENSHIFT;
                for (i = 0; i < DDFnumberofwords; i++) {
                        BCONVERT(chunky1,chunky2,bdata,(b2p++),deco2,P2C_SET);
                        LINE_OR(chunky1,chunky2,(lp.lptr + i*4));
                        BCONVERT(chunky1,chunky2,bdata,(b2p++),deco2,P2C_SET);
                        LINE_OR(chunky1,chunky2,(lp.lptr + 2 + i*4));
                        }
                modulos(2);
                }
}

/* Lores, 3 planes */

void decode3(void) {
        UBY *b1p = cmem + bpl1pt;
        UBY *b2p = cmem + bpl2pt;
        UBY *b3p = cmem + bpl3pt;
        ptunion lp;
        UBY bdata;
        ULO chunky1,chunky2,i;

        if (DDFnumberofwords > 0) {
                lp.bptr = linje + DDFstartpos + ODDSHIFT;
                bpl1pt += DDFnumberofwords*2;
		bpl2pt += DDFnumberofwords*2;
		bpl3pt += DDFnumberofwords*2;
                for (i = 0; i < DDFnumberofwords; i++) {
                        BCONVERT(chunky1,chunky2,bdata,(b1p++),deco1,P2C_SET);
                        BCONVERT(chunky1,chunky2,bdata,(b3p++),deco3,P2C_OR);
                        LINE_STORE(chunky1,chunky2,(lp.lptr + i*4));
                        BCONVERT(chunky1,chunky2,bdata,(b1p++),deco1,P2C_SET);
                        BCONVERT(chunky1,chunky2,bdata,(b3p++),deco3,P2C_OR);
                        LINE_STORE(chunky1,chunky2,(lp.lptr + 2 + i*4));
                        }
                lp.bptr = linje + DDFstartpos + EVENSHIFT;
                for (i = 0; i < DDFnumberofwords; i++) {
                        BCONVERT(chunky1,chunky2,bdata,(b2p++),deco2,P2C_SET);
                        LINE_OR(chunky1,chunky2,(lp.lptr + i*4));
                        BCONVERT(chunky1,chunky2,bdata,(b2p++),deco2,P2C_SET);
                        LINE_OR(chunky1,chunky2,(lp.lptr + 2 + i*4));
                        }
                modulos(3);
                }
}

/* Lores, 4 planes */

void decode4(void) {
        UBY *b1p = cmem + bpl1pt;
        UBY *b2p = cmem + bpl2pt;
        UBY *b3p = cmem + bpl3pt;
        UBY *b4p = cmem + bpl4pt;
        ptunion lp;
        UBY bdata;
        ULO chunky1,chunky2,i;

        if (DDFnumberofwords > 0) {
                lp.bptr = linje + DDFstartpos + ODDSHIFT;
                bpl1pt += DDFnumberofwords*2;
		bpl2pt += DDFnumberofwords*2;
		bpl3pt += DDFnumberofwords*2;
		bpl4pt += DDFnumberofwords*2;
                for (i = 0; i < DDFnumberofwords; i++) {
                        BCONVERT(chunky1,chunky2,bdata,(b1p++),deco1,P2C_SET);
                        BCONVERT(chunky1,chunky2,bdata,(b3p++),deco3,P2C_OR);
                        LINE_STORE(chunky1,chunky2,(lp.lptr + i*4));
                        BCONVERT(chunky1,chunky2,bdata,(b1p++),deco1,P2C_SET);
                        BCONVERT(chunky1,chunky2,bdata,(b3p++),deco3,P2C_OR);
                        LINE_STORE(chunky1,chunky2,(lp.lptr + 2 + i*4));
                        }
                lp.bptr = linje + DDFstartpos + EVENSHIFT;
                for (i = 0; i < DDFnumberofwords; i++) {
                        BCONVERT(chunky1,chunky2,bdata,(b2p++),deco2,P2C_SET);
                        BCONVERT(chunky1,chunky2,bdata,(b4p++),deco4,P2C_OR);
                        LINE_OR(chunky1,chunky2,(lp.lptr + i*4));
                        BCONVERT(chunky1,chunky2,bdata,(b2p++),deco2,P2C_SET);
                        BCONVERT(chunky1,chunky2,bdata,(b4p++),deco4,P2C_OR);
                        LINE_OR(chunky1,chunky2,(lp.lptr + 2 + i*4));
                        }
                modulos(4);
                }
}

/* Lores, 5 planes */

void decode5(void) {
        UBY *b1p = cmem + bpl1pt;
        UBY *b2p = cmem + bpl2pt;
        UBY *b3p = cmem + bpl3pt;
        UBY *b4p = cmem + bpl4pt;
        UBY *b5p = cmem + bpl5pt;
        ptunion lp;
        UBY bdata;
        ULO chunky1,chunky2,i;

        if (DDFnumberofwords > 0) {
                lp.bptr = linje + DDFstartpos + ODDSHIFT;
                bpl1pt += DDFnumberofwords*2;
		bpl2pt += DDFnumberofwords*2;
		bpl3pt += DDFnumberofwords*2;
		bpl4pt += DDFnumberofwords*2;
		bpl5pt += DDFnumberofwords*2;
                for (i = 0; i < DDFnumberofwords; i++) {
                        BCONVERT(chunky1,chunky2,bdata,(b1p++),deco1,P2C_SET);
                        BCONVERT(chunky1,chunky2,bdata,(b3p++),deco3,P2C_OR);
                        BCONVERT(chunky1,chunky2,bdata,(b5p++),deco5,P2C_OR);
                        LINE_STORE(chunky1,chunky2,(lp.lptr + i*4));
                        BCONVERT(chunky1,chunky2,bdata,(b1p++),deco1,P2C_SET);
                        BCONVERT(chunky1,chunky2,bdata,(b3p++),deco3,P2C_OR);
                        BCONVERT(chunky1,chunky2,bdata,(b5p++),deco5,P2C_OR);
                        LINE_STORE(chunky1,chunky2,(lp.lptr + 2 + i*4));
                        }
                lp.bptr = linje + DDFstartpos + EVENSHIFT;
                for (i = 0; i < DDFnumberofwords; i++) {
                        BCONVERT(chunky1,chunky2,bdata,(b2p++),deco2,P2C_SET);
                        BCONVERT(chunky1,chunky2,bdata,(b4p++),deco4,P2C_OR);
                        LINE_OR(chunky1,chunky2,(lp.lptr + i*4));
                        BCONVERT(chunky1,chunky2,bdata,(b2p++),deco2,P2C_SET);
                        BCONVERT(chunky1,chunky2,bdata,(b4p++),deco4,P2C_OR);
                        LINE_OR(chunky1,chunky2,(lp.lptr + 2 + i*4));
                        }
                modulos(5);
                }
}

/* Lores, 6 planes */

void decode6(void) {
        UBY *b1p = cmem + bpl1pt;
        UBY *b2p = cmem + bpl2pt;
        UBY *b3p = cmem + bpl3pt;
        UBY *b4p = cmem + bpl4pt;
        UBY *b5p = cmem + bpl5pt;
        UBY *b6p = cmem + bpl6pt;
        ptunion lp;
        UBY bdata;
        ULO chunky1,chunky2,i;

        if (DDFnumberofwords > 0) {
                lp.bptr = linje + DDFstartpos + ODDSHIFT;
                bpl1pt += DDFnumberofwords*2;
		bpl2pt += DDFnumberofwords*2;
		bpl3pt += DDFnumberofwords*2;
		bpl4pt += DDFnumberofwords*2;
		bpl5pt += DDFnumberofwords*2;
		bpl6pt += DDFnumberofwords*2;
                for (i = 0; i < DDFnumberofwords; i++) {
                        BCONVERT(chunky1,chunky2,bdata,(b1p++),deco1,P2C_SET);
                        BCONVERT(chunky1,chunky2,bdata,(b3p++),deco3,P2C_OR);
                        BCONVERT(chunky1,chunky2,bdata,(b5p++),deco5,P2C_OR);
                        LINE_STORE(chunky1,chunky2,(lp.lptr + i*4));
                        BCONVERT(chunky1,chunky2,bdata,(b1p++),deco1,P2C_SET);
                        BCONVERT(chunky1,chunky2,bdata,(b3p++),deco3,P2C_OR);
                        BCONVERT(chunky1,chunky2,bdata,(b5p++),deco5,P2C_OR);
                        LINE_STORE(chunky1,chunky2,(lp.lptr + 2 + i*4));
                        }
                lp.bptr = linje + DDFstartpos + EVENSHIFT;
                for (i = 0; i < DDFnumberofwords; i++) {
                        BCONVERT(chunky1,chunky2,bdata,(b2p++),deco2,P2C_SET);
                        BCONVERT(chunky1,chunky2,bdata,(b4p++),deco4,P2C_OR);
                        BCONVERT(chunky1,chunky2,bdata,(b6p++),deco6,P2C_OR);
                        LINE_OR(chunky1,chunky2,(lp.lptr + i*4));
                        BCONVERT(chunky1,chunky2,bdata,(b2p++),deco2,P2C_SET);
                        BCONVERT(chunky1,chunky2,bdata,(b4p++),deco4,P2C_OR);
                        BCONVERT(chunky1,chunky2,bdata,(b6p++),deco6,P2C_OR);
                        LINE_OR(chunky1,chunky2,(lp.lptr + 2 + i*4));
                        }
                modulos(6);
                }
}

/* Dual Lores, 2 planes */

void decodedual2(void) {
        UBY *b1p = cmem + bpl1pt;
        UBY *b2p = cmem + bpl2pt;
        ptunion lp;
        UBY bdata;
        ULO chunky1,chunky2,i;

        if (DDFnumberofwords > 0) {
                lp.bptr = linje + DDFstartpos + ODDSHIFT;
                bpl1pt += DDFnumberofwords*2;
		bpl2pt += DDFnumberofwords*2;
                for (i = 0; i < DDFnumberofwords; i++) {
                        BCONVERT(chunky1,chunky2,bdata,(b1p++),deco1,P2C_SET);
                        LINE_STORE(chunky1,chunky2,(lp.lptr + i*4));
                        BCONVERT(chunky1,chunky2,bdata,(b1p++),deco1,P2C_SET);
                        LINE_STORE(chunky1,chunky2,(lp.lptr + 2 + i*4));
                        }
                lp.bptr = linje2 + DDFstartpos + EVENSHIFT;
                for (i = 0; i < DDFnumberofwords; i++) {
                        BCONVERT(chunky1,chunky2,bdata,(b2p++),deco1,P2C_SET);
                        LINE_STORE(chunky1,chunky2,(lp.lptr + i*4));
                        BCONVERT(chunky1,chunky2,bdata,(b2p++),deco1,P2C_SET);
                        LINE_STORE(chunky1,chunky2,(lp.lptr + 2 + i*4));
                        }
                modulos(2);
                }
}

/* Lores, 3 planes */

void decodedual3(void) {
        UBY *b1p = cmem + bpl1pt;
        UBY *b2p = cmem + bpl2pt;
        UBY *b3p = cmem + bpl3pt;
        ptunion lp;
        UBY bdata;
        ULO chunky1,chunky2,i;

        if (DDFnumberofwords > 0) {
                lp.bptr = linje + DDFstartpos + ODDSHIFT;
                bpl1pt += DDFnumberofwords*2;
		bpl2pt += DDFnumberofwords*2;
		bpl3pt += DDFnumberofwords*2;
                for (i = 0; i < DDFnumberofwords; i++) {
                        BCONVERT(chunky1,chunky2,bdata,(b1p++),deco1,P2C_SET);
                        BCONVERT(chunky1,chunky2,bdata,(b3p++),deco2,P2C_OR);
                        LINE_STORE(chunky1,chunky2,(lp.lptr + i*4));
                        BCONVERT(chunky1,chunky2,bdata,(b1p++),deco1,P2C_SET);
                        BCONVERT(chunky1,chunky2,bdata,(b3p++),deco2,P2C_OR);
                        LINE_STORE(chunky1,chunky2,(lp.lptr + 2 + i*4));
                        }
                lp.bptr = linje2 + DDFstartpos + EVENSHIFT;
                for (i = 0; i < DDFnumberofwords; i++) {
                        BCONVERT(chunky1,chunky2,bdata,(b2p++),deco1,P2C_SET);
                        LINE_STORE(chunky1,chunky2,(lp.lptr + i*4));
                        BCONVERT(chunky1,chunky2,bdata,(b2p++),deco1,P2C_SET);
                        LINE_STORE(chunky1,chunky2,(lp.lptr + 2 + i*4));
                        }
                modulos(3);
                }
}

/* Lores, 4 planes */

void decodedual4(void) {
        UBY *b1p = cmem + bpl1pt;
        UBY *b2p = cmem + bpl2pt;
        UBY *b3p = cmem + bpl3pt;
        UBY *b4p = cmem + bpl4pt;
        ptunion lp;
        UBY bdata;
        ULO chunky1,chunky2,i;

        if (DDFnumberofwords > 0) {
                lp.bptr = linje + DDFstartpos + ODDSHIFT;
                bpl1pt += DDFnumberofwords*2;
		bpl2pt += DDFnumberofwords*2;
		bpl3pt += DDFnumberofwords*2;
		bpl4pt += DDFnumberofwords*2;
                for (i = 0; i < DDFnumberofwords; i++) {
                        BCONVERT(chunky1,chunky2,bdata,(b1p++),deco1,P2C_SET);
                        BCONVERT(chunky1,chunky2,bdata,(b3p++),deco2,P2C_OR);
                        LINE_STORE(chunky1,chunky2,(lp.lptr + i*4));
                        BCONVERT(chunky1,chunky2,bdata,(b1p++),deco1,P2C_SET);
                        BCONVERT(chunky1,chunky2,bdata,(b3p++),deco2,P2C_OR);
                        LINE_STORE(chunky1,chunky2,(lp.lptr + 2 + i*4));
                        }
                lp.bptr = linje2 + DDFstartpos + EVENSHIFT;
                for (i = 0; i < DDFnumberofwords; i++) {
                        BCONVERT(chunky1,chunky2,bdata,(b2p++),deco1,P2C_SET);
                        BCONVERT(chunky1,chunky2,bdata,(b4p++),deco2,P2C_OR);
                        LINE_STORE(chunky1,chunky2,(lp.lptr + i*4));
                        BCONVERT(chunky1,chunky2,bdata,(b2p++),deco1,P2C_SET);
                        BCONVERT(chunky1,chunky2,bdata,(b4p++),deco2,P2C_OR);
                        LINE_STORE(chunky1,chunky2,(lp.lptr + 2 + i*4));
                        }
                modulos(4);
                }
}

/* Lores, 5 planes */

void decodedual5(void) {
        UBY *b1p = cmem + bpl1pt;
        UBY *b2p = cmem + bpl2pt;
        UBY *b3p = cmem + bpl3pt;
        UBY *b4p = cmem + bpl4pt;
        UBY *b5p = cmem + bpl5pt;
        ptunion lp;
        UBY bdata;
        ULO chunky1,chunky2,i;

        if (DDFnumberofwords > 0) {
                lp.bptr = linje + DDFstartpos + ODDSHIFT;
                bpl1pt += DDFnumberofwords*2;
		bpl2pt += DDFnumberofwords*2;
		bpl3pt += DDFnumberofwords*2;
		bpl4pt += DDFnumberofwords*2;
		bpl5pt += DDFnumberofwords*2;
                for (i = 0; i < DDFnumberofwords; i++) {
                        BCONVERT(chunky1,chunky2,bdata,(b1p++),deco1,P2C_SET);
                        BCONVERT(chunky1,chunky2,bdata,(b3p++),deco2,P2C_OR);
                        BCONVERT(chunky1,chunky2,bdata,(b5p++),deco3,P2C_OR);
                        LINE_STORE(chunky1,chunky2,(lp.lptr + i*4));
                        BCONVERT(chunky1,chunky2,bdata,(b1p++),deco1,P2C_SET);
                        BCONVERT(chunky1,chunky2,bdata,(b3p++),deco2,P2C_OR);
                        BCONVERT(chunky1,chunky2,bdata,(b5p++),deco3,P2C_OR);
                        LINE_STORE(chunky1,chunky2,(lp.lptr + 2 + i*4));
                        }
                lp.bptr = linje2 + DDFstartpos + EVENSHIFT;
                for (i = 0; i < DDFnumberofwords; i++) {
                        BCONVERT(chunky1,chunky2,bdata,(b2p++),deco1,P2C_SET);
                        BCONVERT(chunky1,chunky2,bdata,(b4p++),deco2,P2C_OR);
                        LINE_STORE(chunky1,chunky2,(lp.lptr + i*4));
                        BCONVERT(chunky1,chunky2,bdata,(b2p++),deco1,P2C_SET);
                        BCONVERT(chunky1,chunky2,bdata,(b4p++),deco2,P2C_OR);
                        LINE_STORE(chunky1,chunky2,(lp.lptr + 2 + i*4));
                        }
                modulos(5);
                }
}

/* Lores, 6 planes */

void decodedual6(void) {
        UBY *b1p = cmem + bpl1pt;
        UBY *b2p = cmem + bpl2pt;
        UBY *b3p = cmem + bpl3pt;
        UBY *b4p = cmem + bpl4pt;
        UBY *b5p = cmem + bpl5pt;
        UBY *b6p = cmem + bpl6pt;
        ptunion lp;
        UBY bdata;
        ULO chunky1,chunky2,i;

        if (DDFnumberofwords > 0) {
                lp.bptr = linje + DDFstartpos + ODDSHIFT;
                bpl1pt += DDFnumberofwords*2;
		bpl2pt += DDFnumberofwords*2;
		bpl3pt += DDFnumberofwords*2;
		bpl4pt += DDFnumberofwords*2;
		bpl5pt += DDFnumberofwords*2;
		bpl6pt += DDFnumberofwords*2;
                for (i = 0; i < DDFnumberofwords; i++) {
                        BCONVERT(chunky1,chunky2,bdata,(b1p++),deco1,P2C_SET);
                        BCONVERT(chunky1,chunky2,bdata,(b3p++),deco2,P2C_OR);
                        BCONVERT(chunky1,chunky2,bdata,(b5p++),deco3,P2C_OR);
                        LINE_STORE(chunky1,chunky2,(lp.lptr + i*4));
                        BCONVERT(chunky1,chunky2,bdata,(b1p++),deco1,P2C_SET);
                        BCONVERT(chunky1,chunky2,bdata,(b3p++),deco2,P2C_OR);
                        BCONVERT(chunky1,chunky2,bdata,(b5p++),deco3,P2C_OR);
                        LINE_STORE(chunky1,chunky2,(lp.lptr + 2 + i*4));
                        }
                lp.bptr = linje2 + DDFstartpos + EVENSHIFT;
                for (i = 0; i < DDFnumberofwords; i++) {
                        BCONVERT(chunky1,chunky2,bdata,(b2p++),deco1,P2C_SET);
                        BCONVERT(chunky1,chunky2,bdata,(b4p++),deco2,P2C_OR);
                        BCONVERT(chunky1,chunky2,bdata,(b6p++),deco3,P2C_OR);
                        LINE_STORE(chunky1,chunky2,(lp.lptr + i*4));
                        BCONVERT(chunky1,chunky2,bdata,(b2p++),deco1,P2C_SET);
                        BCONVERT(chunky1,chunky2,bdata,(b4p++),deco2,P2C_OR);
                        BCONVERT(chunky1,chunky2,bdata,(b6p++),deco3,P2C_OR);
                        LINE_STORE(chunky1,chunky2,(lp.lptr + 2 + i*4));
                        }
                modulos(6);
                }
}

/* Hires on lores, 1 plane */

void decode320hi1(void) {
        UBY *b1p = cmem + bpl1pt;
        ptunion lp;
        UBY bdata;
        ULO chunky,i;

        if (DDFnumberofwords > 0) {
                lp.bptr = linje + (DDFstartpos>>1) + (oddhiscroll>>1);
                bpl1pt += DDFnumberofwords*2;
                for (i = 0; i < DDFnumberofwords; i++) {
                        BCONVERT_320(chunky,bdata,(b1p++),deco320hi1,P2C_SET_320);
                        LINE_STORE_320(chunky,(lp.lptr + i*2));
                        BCONVERT_320(chunky,bdata,(b1p++),deco320hi1,P2C_SET_320);
                        LINE_STORE_320(chunky,(lp.lptr + 1 + i*2));
                        }
                modulos(1);
                }
}

/* Hires on Lores, 2 planes */

void decode320hi2(void) {
        UBY *b1p = cmem + bpl1pt;
        UBY *b2p = cmem + bpl2pt;
        ptunion lp;
        UBY bdata;
        ULO chunky,i;

        if (DDFnumberofwords > 0) {
                lp.bptr = linje + (DDFstartpos>>1) + (oddhiscroll>>1);
                bpl1pt += DDFnumberofwords*2;
		bpl2pt += DDFnumberofwords*2;
                for (i = 0; i < DDFnumberofwords; i++) {
                        BCONVERT_320(chunky,bdata,(b1p++),deco320hi1,P2C_SET_320);
                        LINE_STORE_320(chunky,(lp.lptr + i*2));
                        BCONVERT_320(chunky,bdata,(b1p++),deco320hi1,P2C_SET_320);
                        LINE_STORE_320(chunky,(lp.lptr + 1 + i*2));
                        }
                lp.bptr = linje + (DDFstartpos>>1) + (evenhiscroll>>1);
                for (i = 0; i < DDFnumberofwords; i++) {
                        BCONVERT_320(chunky,bdata,(b2p++),deco320hi2,P2C_SET_320);
                        LINE_OR_320(chunky,(lp.lptr + i*2));
                        BCONVERT_320(chunky,bdata,(b2p++),deco320hi2,P2C_SET_320);
                        LINE_OR_320(chunky,(lp.lptr + 1 + i*2));
                        }
                modulos(2);
                }
}

/* Hires on Lores, 3 planes */

void decode320hi3(void) {
        UBY *b1p = cmem + bpl1pt;
        UBY *b2p = cmem + bpl2pt;
        UBY *b3p = cmem + bpl3pt;
        ptunion lp;
        UBY bdata;
        ULO chunky,i;

        if (DDFnumberofwords > 0) {
                lp.bptr = linje + (DDFstartpos>>1) + (oddhiscroll>>1);
                bpl1pt += DDFnumberofwords*2;
		bpl2pt += DDFnumberofwords*2;
		bpl3pt += DDFnumberofwords*2;
                for (i = 0; i < DDFnumberofwords; i++) {
                        BCONVERT_320(chunky,bdata,(b1p++),deco320hi1,P2C_SET_320);
                        BCONVERT_320(chunky,bdata,(b3p++),deco320hi3,P2C_OR_320);
                        LINE_STORE_320(chunky,(lp.lptr + i*2));
                        BCONVERT_320(chunky,bdata,(b1p++),deco320hi1,P2C_SET_320);
                        BCONVERT_320(chunky,bdata,(b3p++),deco320hi3,P2C_OR_320);
                        LINE_STORE_320(chunky,(lp.lptr + 1 + i*2));
                        }
                lp.bptr = linje + (DDFstartpos>>1) + (evenhiscroll>>1);
                for (i = 0; i < DDFnumberofwords; i++) {
                        BCONVERT_320(chunky,bdata,(b2p++),deco320hi2,P2C_SET_320);
                        LINE_OR_320(chunky,(lp.lptr + i*2));
                        BCONVERT_320(chunky,bdata,(b2p++),deco320hi2,P2C_SET_320);
                        LINE_OR_320(chunky,(lp.lptr + 1 + i*2));
                        }
                modulos(3);
                }
}

/* Hires on Lores, 4 planes */

void decode320hi4(void) {
        UBY *b1p = cmem + bpl1pt;
        UBY *b2p = cmem + bpl2pt;
        UBY *b3p = cmem + bpl3pt;
        UBY *b4p = cmem + bpl4pt;
        ptunion lp;
        UBY bdata;
        ULO chunky,i;

        if (DDFnumberofwords > 0) {
                lp.bptr = linje + (DDFstartpos>>1) + (oddhiscroll>>1);
                bpl1pt += DDFnumberofwords*2;
		bpl2pt += DDFnumberofwords*2;
		bpl3pt += DDFnumberofwords*2;
		bpl4pt += DDFnumberofwords*2;
                for (i = 0; i < DDFnumberofwords; i++) {
                        BCONVERT_320(chunky,bdata,(b1p++),deco320hi1,P2C_SET_320);
                        BCONVERT_320(chunky,bdata,(b3p++),deco320hi3,P2C_OR_320);
                        LINE_STORE_320(chunky,(lp.lptr + i*2));
                        BCONVERT_320(chunky,bdata,(b1p++),deco320hi1,P2C_SET_320);
                        BCONVERT_320(chunky,bdata,(b3p++),deco320hi3,P2C_OR_320);
                        LINE_STORE_320(chunky,(lp.lptr + 1 + i*2));
                        }
                lp.bptr = linje + (DDFstartpos>>1) + (evenhiscroll>>1);
                for (i = 0; i < DDFnumberofwords; i++) {
                        BCONVERT_320(chunky,bdata,(b2p++),deco320hi2,P2C_SET_320);
                        BCONVERT_320(chunky,bdata,(b4p++),deco320hi4,P2C_OR_320);
                        LINE_OR_320(chunky,(lp.lptr + i*2));
                        BCONVERT_320(chunky,bdata,(b2p++),deco320hi2,P2C_SET_320);
                        BCONVERT_320(chunky,bdata,(b4p++),deco320hi4,P2C_OR_320);
                        LINE_OR_320(chunky,(lp.lptr + 1 + i*2));
                        }
                modulos(4);
                }
}

/* Dual Hires on Lores, 2 planes */

void decodedual320hi2(void) {
        UBY *b1p = cmem + bpl1pt;
        UBY *b2p = cmem + bpl2pt;
        ptunion lp;
        UBY bdata;
        ULO chunky,i;

        if (DDFnumberofwords > 0) {
                lp.bptr = linje + (DDFstartpos>>1) + (oddhiscroll>>1);
                bpl1pt += DDFnumberofwords*2;
		bpl2pt += DDFnumberofwords*2;
                for (i = 0; i < DDFnumberofwords; i++) {
                        BCONVERT_320(chunky,bdata,(b1p++),deco320hi1,P2C_SET_320);
                        LINE_STORE_320(chunky,(lp.lptr + i*2));
                        BCONVERT_320(chunky,bdata,(b1p++),deco320hi1,P2C_SET_320);
                        LINE_STORE_320(chunky,(lp.lptr + 1 + i*2));
                        }
                lp.bptr = linje2 + (DDFstartpos>>1) + (evenhiscroll>>1);
                for (i = 0; i < DDFnumberofwords; i++) {
                        BCONVERT_320(chunky,bdata,(b2p++),deco320hi1,P2C_SET_320);
                        LINE_STORE_320(chunky,(lp.lptr + i*2));
                        BCONVERT_320(chunky,bdata,(b2p++),deco320hi1,P2C_SET_320);
                        LINE_STORE_320(chunky,(lp.lptr + 1 + i*2));
                        }
                modulos(2);
                }
}

/* Dual Hires on Lores, 3 planes */

void decodedual320hi3(void) {
        UBY *b1p = cmem + bpl1pt;
        UBY *b2p = cmem + bpl2pt;
        UBY *b3p = cmem + bpl3pt;
        ptunion lp;
        UBY bdata;
        ULO chunky,i;

        if (DDFnumberofwords > 0) {
                lp.bptr = linje + (DDFstartpos>>1) + (oddhiscroll>>1);
                bpl1pt += DDFnumberofwords*2;
		bpl2pt += DDFnumberofwords*2;
		bpl3pt += DDFnumberofwords*2;
                for (i = 0; i < DDFnumberofwords; i++) {
                        BCONVERT_320(chunky,bdata,(b1p++),deco320hi1,P2C_SET_320);
                        BCONVERT_320(chunky,bdata,(b3p++),deco320hi2,P2C_OR_320);
                        LINE_STORE_320(chunky,(lp.lptr + i*2));
                        BCONVERT_320(chunky,bdata,(b1p++),deco320hi1,P2C_SET_320);
                        BCONVERT_320(chunky,bdata,(b3p++),deco320hi2,P2C_OR_320);
                        LINE_STORE_320(chunky,(lp.lptr + 1 + i*2));
                        }
                lp.bptr = linje2 + (DDFstartpos>>1) + (evenhiscroll>>1);
                for (i = 0; i < DDFnumberofwords; i++) {
                        BCONVERT_320(chunky,bdata,(b2p++),deco320hi1,P2C_SET_320);
                        LINE_STORE_320(chunky,(lp.lptr + i*2));
                        BCONVERT_320(chunky,bdata,(b2p++),deco320hi1,P2C_SET_320);
                        LINE_STORE_320(chunky,(lp.lptr + 1 + i*2));
                        }
                modulos(3);
                }
}

/* Dual Hires on Lores, 4 planes */

void decodedual320hi4(void) {
        UBY *b1p = cmem + bpl1pt;
        UBY *b2p = cmem + bpl2pt;
        UBY *b3p = cmem + bpl3pt;
        UBY *b4p = cmem + bpl4pt;
        ptunion lp;
        UBY bdata;
        ULO chunky,i;

        if (DDFnumberofwords > 0) {
                lp.bptr = linje + (DDFstartpos>>1) + (oddhiscroll>>1);
                bpl1pt += DDFnumberofwords*2;
		bpl2pt += DDFnumberofwords*2;
		bpl3pt += DDFnumberofwords*2;
		bpl4pt += DDFnumberofwords*2;
                for (i = 0; i < DDFnumberofwords; i++) {
                        BCONVERT_320(chunky,bdata,(b1p++),deco320hi1,P2C_SET_320);
                        BCONVERT_320(chunky,bdata,(b3p++),deco320hi2,P2C_OR_320);
                        LINE_STORE_320(chunky,(lp.lptr + i*2));
                        BCONVERT_320(chunky,bdata,(b1p++),deco320hi1,P2C_SET_320);
                        BCONVERT_320(chunky,bdata,(b3p++),deco320hi2,P2C_OR_320);
                        LINE_STORE_320(chunky,(lp.lptr + 1 + i*2));
                        }
                lp.bptr = linje2 + (DDFstartpos>>1) + (evenhiscroll>>1);
                for (i = 0; i < DDFnumberofwords; i++) {
                        BCONVERT_320(chunky,bdata,(b2p++),deco320hi1,P2C_SET_320);
                        BCONVERT_320(chunky,bdata,(b4p++),deco320hi2,P2C_OR_320);
                        LINE_STORE_320(chunky,(lp.lptr + i*2));
                        BCONVERT_320(chunky,bdata,(b2p++),deco320hi1,P2C_SET_320);
                        BCONVERT_320(chunky,bdata,(b4p++),deco320hi2,P2C_OR_320);
                        LINE_STORE_320(chunky,(lp.lptr + 1 + i*2));
                        }
                modulos(4);
                }
}

#endif

/* Centering changed */

void do_center(void) {
        if (center_code == 80) {
                if (config_graphics_mode == 1 || config_graphics_mode == 2 || config_graphics_mode == 6) {
                        if (cliptop > 0x1a) {
                                cliptop--;
                                clipbot--;
                                init_lineflagstables();
                                }
                        }
                }
        else if (center_code == 72) {
                if (config_graphics_mode == 1 || config_graphics_mode == 2 || config_graphics_mode == 6) {
                        if (clipbot < 0x139) {
                                cliptop++;
                                clipbot++;
                                init_lineflagstables();
                                }
                        }
                }
        else if (center_code == 75) {
                if (config_graphics_mode >= 1 && config_graphics_mode <= 6) {
                        if (cliprightx < 467) {
                                cliprightx++;
                                clipleftx++;
                                }
                        }
                }
        else if (center_code == 77) {
                if (config_graphics_mode >= 1 && config_graphics_mode <= 6) {
                        if (clipleftx > 88) {
                                cliprightx--;
                                clipleftx--;
                                }
                        }
                }
        center_code = 0;
}




/* Set up tables */

void init_linearrays(void) {
        ULO i;
        for (i=0; i< 1000; i++) linje[i] = linje2[i] = 0;
}

void init_planar_convertion_tables(void) {
        ULO i,j,d[2];

        for(i = 0; i < 256; i++) {
                d[0] = d[1] = 0;
                for(j = 0; j < 4; j++) {
                        d[0] |= ((i&(0x80>>j))>>(4+3-j))<<(j*8);
                        d[1] |= ((i&(0x8>>j))>>(3-j))<<(j*8);
                        }
                for (j = 0; j < 2; j++) {
                        deco1[i][j] = d[j]<<2;
                        deco2[i][j] = d[j]<<3;
                        deco3[i][j] = d[j]<<4;
                        deco4[i][j] = d[j]<<5;
                        deco5[i][j] = d[j]<<6;
                        deco6[i][j] = d[j]<<7;
                        }
                deco320hi1[i] = ((d[0]&0xff) | ((d[0]&0xff0000)>>8) | ((d[1]&0xff)<<16) | ((d[1]&0xff0000)<<8))<<2;
                deco320hi2[i] = deco320hi1[i]<<1;
                deco320hi3[i] = deco320hi1[i]<<2;
                deco320hi4[i] = deco320hi1[i]<<3;
                }

        for(i = 0; i < 256; i++) 
                for(j = 0; j < 8; j++) {
                        decosc01[i][j] =  (i&(0x80>>j)) == 0 ? 0:0x44;
                        decosc02[i][j] =  (i&(0x80>>j)) == 0 ? 0:0x48;
                        decosc03[i][j] =  (i&(0x80>>j)) == 0 ? 0:0x50;
                        decosc04[i][j] =  (i&(0x80>>j)) == 0 ? 0:0x60;
                        decosc11[i][j] =  (i&(0x80>>j)) == 0 ? 0:0x54;
                        decosc12[i][j] =  (i&(0x80>>j)) == 0 ? 0:0x58;
                        decosc21[i][j] =  (i&(0x80>>j)) == 0 ? 0:0x64;
                        decosc22[i][j] =  (i&(0x80>>j)) == 0 ? 0:0x68;
                        decosc31[i][j] =  (i&(0x80>>j)) == 0 ? 0:0x74;
                        decosc32[i][j] =  (i&(0x80>>j)) == 0 ? 0:0x78;
                        }
}

void init_decodetables_320(void) {
    decoderoutinetab[0] = decode0;
    decoderoutinetab[1] = decode1;
    decoderoutinetab[2] = decode2;
    decoderoutinetab[3] = decode3;
    decoderoutinetab[4] = decode4;
    decoderoutinetab[5] = decode5;
    decoderoutinetab[6] = decode6;
    decoderoutinetab[7] = decode0;
    decoderoutinetab[8] = decode0;
    decoderoutinetab[9] = decode320hi1;
    decoderoutinetab[10] = decode320hi2;
    decoderoutinetab[11] = decode320hi3;
    decoderoutinetab[12] = decode320hi4;
    decoderoutinetab[13] = decode0;
    decoderoutinetab[14] = decode0;
    decoderoutinetab[15] = decode0;
    decoderoutinedualtab[0] = decode0;
    decoderoutinedualtab[1] = decode1;
    decoderoutinedualtab[2] = decodedual2;
    decoderoutinedualtab[3] = decodedual3;
    decoderoutinedualtab[4] = decodedual4;
    decoderoutinedualtab[5] = decodedual5;
    decoderoutinedualtab[6] = decodedual6;
    decoderoutinedualtab[7] = decode0;
    decoderoutinedualtab[8] = decode0;
    decoderoutinedualtab[9] = decode320hi1;
    decoderoutinedualtab[10] = decodedual320hi2;
    decoderoutinedualtab[11] = decodedual320hi3;
    decoderoutinedualtab[12] = decodedual320hi4;
    decoderoutinedualtab[13] = decode0;
    decoderoutinedualtab[14] = decode0;
    decoderoutinedualtab[15] = decode0;
}

void init_decodetables_800(void) {
    decoderoutinetab[0] = decode0;
    decoderoutinetab[1] = decode1;
    decoderoutinetab[2] = decode2;
    decoderoutinetab[3] = decode3;
    decoderoutinetab[4] = decode4;
    decoderoutinetab[5] = decode5;
    decoderoutinetab[6] = decode6;
    decoderoutinetab[7] = decode0;
    decoderoutinetab[8] = decode0;
    decoderoutinetab[9] = decode1;
    decoderoutinetab[10] = decode2;
    decoderoutinetab[11] = decode3;
    decoderoutinetab[12] = decode4;
    decoderoutinetab[13] = decode0;
    decoderoutinetab[14] = decode0;
    decoderoutinetab[15] = decode0;
    decoderoutinedualtab[0] = decode0;
    decoderoutinedualtab[1] = decode1;
    decoderoutinedualtab[2] = decodedual2;
    decoderoutinedualtab[3] = decodedual3;
    decoderoutinedualtab[4] = decodedual4;
    decoderoutinedualtab[5] = decodedual5;
    decoderoutinedualtab[6] = decodedual6;
    decoderoutinedualtab[7] = decode0;
    decoderoutinedualtab[8] = decode0;
    decoderoutinedualtab[9] = decode1;
    decoderoutinedualtab[10] = decodedual2;
    decoderoutinedualtab[11] = decodedual3;
    decoderoutinedualtab[12] = decodedual4;
    decoderoutinedualtab[13] = decode0;
    decoderoutinedualtab[14] = decode0;
    decoderoutinedualtab[15] = decode0;
}

void graphem_init_tables(void) {
        init_linearrays();
        init_planar_convertion_tables();
}
