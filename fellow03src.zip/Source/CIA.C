/*=======================*/
/* Cia emulation         */
/* Petter Schau 1997     */
/*=======================*/

#include "defs.h"
#include "memorya.h"

ULO config_enableleds;

/* Table of CIA read/write functions */

ciareadfunc ciaaread[16] = {rciaapra,rciaaprb,rciaaddra,rciaaddrb,rciaatalo,
                            rciaatahi,rciaatblo,rciaatbhi,rciaaevlo,
                            rciaaevmi,rciaaevhi,rcianothing,rciaasp,rciaaicr,
                            rciaacra,rciaacrb};
ciareadfunc ciabread[16] = {rciabpra,rciabprb,rciabddra,rciabddrb,rciabtalo,
                            rciabtahi,rciabtblo,rciabtbhi,rciabevlo,
                            rciabevmi,rciabevhi,rcianothing,rciabsp,rciabicr,
                            rciabcra,rciabcrb};
ciawritefunc ciaawrite[16]={wciaapra,wciaaprb,wciaaddra,wciaaddrb,wciaatalo,
                            wciaatahi,wciaatblo,wciaatbhi,wciaaevlo,
                            wciaaevmi,wciaaevhi,wcianothing,wciaasp,wciaaicr,
                            wciaacra,wciaacrb};
ciawritefunc ciabwrite[16]={wciabpra,wciabprb,wciabddra,wciabddrb,wciabtalo,
                            wciabtahi,wciabtblo,wciabtbhi,wciabevlo,
                            wciabevmi,wciabevhi,wcianothing,wciabsp,wciabicr,
                            wciabcra,wciabcrb};

/* Data for the CIAs */

ULO ciaeventtime;

ULO led;
ULO ciaata;
ULO ciaatb;               
ULO ciaatalatch;
ULO ciaatblatch;          
ULO ciaataleft;
ULO ciaatbleft;
ULO ciaaicrreq;
ULO ciaaicrmsk;           
ULO ciaaevalarm;          
ULO ciaaevlatch;               
ULO ciaaevlatching;
ULO ciaaevwritelatch;               
ULO ciaaevwritelatching;               
ULO ciaaevalarmlatch;
ULO ciaaevalarmlatching;

ULO ciaaev;
ULO ciaacra;              
ULO ciaacrb;              
ULO ciaapra = 0xff;
ULO ciaaprb;              
ULO ciaaddra;             
ULO ciaaddrb;             
ULO ciaasp;               

ULO ciabta;               
ULO ciabtb;               
ULO ciabtalatch;          
ULO ciabtblatch;          
ULO ciabtaleft;
ULO ciabtbleft;
ULO ciabicrreq;           
ULO ciabicrmsk;           
ULO ciabevalarm;
ULO ciabevlatch;               
ULO ciabevlatching;               
ULO ciabevwritelatch;
ULO ciabevwritelatching;               
ULO ciabevalarmlatch;
ULO ciabevalarmlatching;
ULO ciabev;               
ULO ciabcra;              
ULO ciabcrb;              
ULO ciabpra = 0xff;
ULO ciabprb;              
ULO ciabddra;             
ULO ciabddrb;             
ULO ciabsp;               


void mem_initcia(void) {
  ciaaev = 0;
  ciaaevlatch = 0;
  ciaaevlatching = 0;
  ciaaevalarm = 0;
  ciaaevalarmlatch = 0;
  ciaaevalarmlatching = 0;
  ciaaevwritelatch = 0;
  ciaaevwritelatching = 0;
  ciabev = 0;
  ciabevlatch = 0;
  ciabevlatching = 0;
  ciabevalarm = 0;
  ciabevalarmlatch = 0;
  ciabevalarmlatching = 0;
  ciabevwritelatch = 0;
  ciabevwritelatching = 0;

  ciaataleft = -1;
  ciaatbleft = -1;
  ciaata = 0xffff; // Just for safety, don't know if its necesary
  ciaatb = 0xffff;
  ciaatalatch = 0xffff;
  ciaatblatch = 0xffff;

  ciabtaleft = -1;
  ciabtbleft = -1;
  ciabta = 0xffff; // Just for safety, don't know if its necesary
  ciabtb = 0xffff;
  ciabtalatch = 0xffff;
  ciabtblatch = 0xffff;
  ciaeventtime = -1;
}


