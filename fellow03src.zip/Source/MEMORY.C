#include <stdio.h>
#include "defs.h"
#include "fellow.h"
#include "inout.h"
#include "chip.h"
#include "68000.h"
#include "draw.h"
#include "memorya.h"
#include "fhfile.h"
#include "graphem.h"
#include "floppy.h"

extern ULO blitterused;
extern ULO nxtcopaccess;

int meminitfirsttime = TRUE;
ULO config_memory_fast_allocated = 0;

/* Configuration for rom */

ULO config_memory_nokick;
UBY config_memory_kickname[256];
ULO config_memory_kicksize;
ULO config_memory_romversion;
char kickstart_idstring[80];

/* Color for led-symbols */

ULO powerledcolor;
ULO drivemotorcolor;
ULO hdledcolor;

/* Configuration for memory sizes */

ULO config_memory_chipsize,config_memory_bogosize;
ULO config_memory_fastsize;

extern FILE *LOG;

extern ULO interruptflag;
extern ULO interruptadress;
extern ULO interruptlevel;
extern ULO cpustopflag;


extern ULO eventcount;

extern ULO eventlog[16384];
extern ULO eventptr;

/* AD hoc */
extern ULO frames;


ULO spritewritebuffer[128][2];
ULO spritewritenext;
ULO spritewritereal;

ULO screenmode;
ULO decoderoutineptr;
ULO drawroutineptr;
extern void drawbgline();



/* Declare functions in this file */

ULO meminit(void);
void dumpioblock(void);
void hexdump(ULO wher);

/* Table of register read/write functions */

regreadfunc ioread[256] = {rdefault,rdmaconr,rvposr,rvhposr,
                           rdefault,rjoy0dat,rjoy1dat,rdefault,
                           rdefault,rpot0dat,rpot1dat,rpotgor,
                           rdefault,rdefault,rintenar,rintreqr,
                           rdefault,rdefault,rdefault,rdefault,
                           rdefault,rdefault,rdefault,rdefault,
                           rdefault,rdefault,rdefault,rdefault,
                           rdefault,rdefault,rdefault,rdefault,
                           rdefault,rdefault,rdefault,rdefault,
                           rdefault,rdefault,rdefault,rdefault,
                           rdefault,rdefault,rdefault,rdefault,
                           rdefault,rdefault,rdefault,rdefault,
                           rdefault,rdefault,rdefault,rdefault,
                           rdefault,rdefault,rdefault,rdefault,
                           rdefault,rdefault,rdefault,rdefault,
                           rdefault,rdefault,rid,rdefault,
                           rdefault,rdefault,rdefault,rdefault,
                           wcopjmp1,wcopjmp2,rdefault,rdefault,
                           rdefault,rdefault,rdefault,rdefault,
                           rdefault,rdefault,rdefault,rdefault,
                           rdefault,rdefault,rdefault,rdefault,
                           rdefault,rdefault,rdefault,rdefault,
                           rdefault,rdefault,rdefault,rdefault,
                           rdefault,rdefault,rdefault,rdefault,
                           rdefault,rdefault,rdefault,rdefault,
                           rdefault,rdefault,rdefault,rdefault,
                           rdefault,rdefault,rdefault,rdefault,
                           rdefault,rdefault,rdefault,rdefault,
                           rdefault,rdefault,rdefault,rdefault,
                           rdefault,rdefault,rdefault,rdefault,
                           rdefault,rdefault,rdefault,rdefault,
                           rdefault,rdefault,rdefault,rdefault,
                           rdefault,rdefault,rdefault,rdefault,
                           rdefault,rdefault,rdefault,rdefault,
                           rdefault,rdefault,rdefault,rdefault,
                           rdefault,rdefault,rdefault,rdefault,
                           rdefault,rdefault,rdefault,rdefault,
                           rdefault,rdefault,rdefault,rdefault,
                           rdefault,rdefault,rdefault,rdefault,
                           rdefault,rdefault,rdefault,rdefault,
                           rdefault,rdefault,rdefault,rdefault,
                           rdefault,rdefault,rdefault,rdefault,
                           rdefault,rdefault,rdefault,rdefault,
                           rdefault,rdefault,rdefault,rdefault,
                           rdefault,rdefault,rdefault,rdefault,
                           rdefault,rdefault,rdefault,rdefault,
                           rdefault,rdefault,rdefault,rdefault,
                           rdefault,rdefault,rdefault,rdefault,
                           rdefault,rdefault,rdefault,rdefault,
                           rdefault,rdefault,rdefault,rdefault,
                           rdefault,rdefault,rdefault,rdefault,
                           rdefault,rdefault,rdefault,rdefault,
                           rdefault,rdefault,rdefault,rdefault,
                           rdefault,rdefault,rdefault,rdefault,
                           rdefault,rdefault,rdefault,rdefault,
                           rdefault,rdefault,rdefault,rdefault,
                           rdefault,rdefault,rdefault,rdefault,
                           rdefault,rdefault,rdefault,rdefault,
                           rdefault,rdefault,rdefault,rdefault,
                           rdefault,rdefault,rdefault,rdefault,
                           rdefault,rdefault,rdefault,rdefault,
                           rdefault,rdefault,rdefault,rdefault,
                           rdefault,rdefault,rdefault,rdefault,
                           rdefault,rdefault,rdefault,rdefault};

regwritefunc iowrite[256]={wdefault,wdefault,wdefault,wdefault,
                           wdefault,wdefault,wdefault,wdefault,
                           wdefault,wdefault,wdefault,wdefault,
                           wdefault,wdefault,wdefault,wdefault,
                           wdefault,wdefault,wdefault,wdefault,
                           wdefault,wdefault,wvpos,wcopcon,
                           wdefault,wdefault,wdefault,wdefault,
                           wdefault,wdefault,wdefault,wdefault,
                           wbltcon0,wbltcon1,wbltafwm,wbltalwm,
                           wbltcpth,wbltcptl,wbltbpth,wbltbptl,
                           wbltapth,wbltaptl,wbltdpth,wbltdptl,
                           wbltsize,wdefault,wdefault,wdefault,
                           wbltcmod,wbltbmod,wbltamod,wbltdmod,
                           wdefault,wdefault,wdefault,wdefault,
                           wbltcdat,wbltbdat,wbltadat,wdefault,
                           wdefault,wdefault,wdefault,wdefault,
                           wcop1lch,wcop1lcl,wcop2lch,wcop2lcl,
                           wcopjmp1,wcopjmp2,wdefault,wdiwstrt,
                           wdiwstop,wddfstrt,wddfstop,wdmacon,
                           wdefault,wintena,wintreq,wadcon,
                           wdefault,wdefault,wdefault,wdefault,
                           wdefault,wdefault,wdefault,wdefault,
                           wdefault,wdefault,wdefault,wdefault,
                           wdefault,wdefault,wdefault,wdefault,
                           wdefault,wdefault,wdefault,wdefault,
                           wdefault,wdefault,wdefault,wdefault,
                           wdefault,wdefault,wdefault,wdefault,
                           wdefault,wdefault,wdefault,wdefault,
                           wbpl1pth,wbpl1ptl,wbpl2pth,wbpl2ptl,
                           wbpl3pth,wbpl3ptl,wbpl4pth,wbpl4ptl,
                           wbpl5pth,wbpl5ptl,wbpl6pth,wbpl6ptl,
                           wdefault,wdefault,wdefault,wdefault,
                           wbplcon0,wbplcon1,wbplcon2,wdefault,
                           wbpl1mod,wbpl2mod,wdefault,wdefault,
                           wdefault,wdefault,wdefault,wdefault,
                           wdefault,wdefault,wdefault,wdefault,
                           wspr0pth,wspr0ptl,wspr1pth,wspr1ptl,
                           wspr2pth,wspr2ptl,wspr3pth,wspr3ptl,
                           wspr4pth,wspr4ptl,wspr5pth,wspr5ptl,
                           wspr6pth,wspr6ptl,wspr7pth,wspr7ptl,
                           wdefault,wdefault,wdefault,wdefault,
                           wdefault,wdefault,wdefault,wdefault,
                           wdefault,wdefault,wdefault,wdefault,
                           wdefault,wdefault,wdefault,wdefault,
                           wdefault,wdefault,wdefault,wdefault,
                           wdefault,wdefault,wdefault,wdefault,
                           wdefault,wdefault,wdefault,wdefault,
                           wdefault,wdefault,wdefault,wdefault,
                           wcolor,wcolor,wcolor,wcolor,
                           wcolor,wcolor,wcolor,wcolor,
                           wcolor,wcolor,wcolor,wcolor,
                           wcolor,wcolor,wcolor,wcolor,
                           wcolor,wcolor,wcolor,wcolor,
                           wcolor,wcolor,wcolor,wcolor,
                           wcolor,wcolor,wcolor,wcolor,
                           wcolor,wcolor,wcolor,wcolor,
                           wdefault,wdefault,wdefault,wdefault,
                           wdefault,wdefault,wdefault,wdefault,
                           wdefault,wdefault,wdefault,wdefault,
                           wdefault,wdefault,wdefault,wdefault,
                           wdefault,wdefault,wdefault,wdefault,
                           wdefault,wdefault,wdefault,wdefault,
                           wdefault,wdefault,wdefault,wdefault,
                           wdefault,wdefault,wdefault,wdefault};


/* Different variables used by the decode routines to scroll bitplanes */

ULO evenscroll,evenhiscroll,oddscroll,oddhiscroll;

/* Variables that correspond to various registers */

ULO dmaconr,dmacon;
ULO intenar,intena,intreq;

/* Screen related registers */

ULO bpl1pt,bpl2pt,bpl3pt,bpl4pt,bpl5pt,bpl6pt;

ULO lof,xpos,ypos,diwxleft,diwxright,diwytop,diwybottom,ddfstrt,
    ddfstop,
    bplcon0,bplcon1,bplcon2,bpl1mod,bpl2mod,diwstrt,diwstop;

/* Helpers for the screen emulation */

ULO screenptr,lineflags[314];

// Global line specific data

ULO DDFstartpos,DDFnumberofwords,DIWfirstvisiblepos,DIWlastvisiblepos;
ULO DIWfirstposonline,DIWlastposonline;

// Data for the current line

ULO LINEposition;

/* Copper registers */

ULO copcon,cop1lc,cop2lc;

/* Blitter registers */

ULO bltcon,bltafwm,bltalwm,bltapt,bltbpt,bltcpt,bltdpt,bltamod,
    bltbmod,bltcmod,bltdmod,bltadat,bltbdat,bltcdat,blitteraccess=FALSE,
    linenum,linecount,linelength,bltdesc,blitterdmawaiting,
    blitterstatus,blitend,bltadatoff,bltbdatoff,bltadattmp,bltbdattmp,
    bltcdattmp,bltminterm;

/* Sprite registers */
ULO sprpt[8],sprx[8],spry[8],sprly[8],spratt[8];
ULO spritestate[8];
ULO sprite16col[8];
UWO sprdat[8][2];


/****************************************************************************
 MEMORY RELATED DATA
 ****************************************************************************/
 
UBY cmem[CHIPMEM+32];
UBY bmem[BOGOMEM+32];
UBY kmem[KICKMEM+32];
UBY emem[256];
UBY *fmem = NULL;
UBY dmem[4096];
ULO dmemcounter;

/* ------------------- */
/* DEFINE LOOKUPTABLES */
/* ------------------- */
/* Table of fetch-functions using 256K banks */
/* Byte/word/long read */

readfunc readbyte[64];
readfunc readword[64];
readfunc readlong[64];

/* Table of write-functions using 256K banks */
/* Byte/word/long read */

writefunc writebyte[64];
writefunc writeword[64];
writefunc writelong[64];


/* Translation tables for colors */

ULO colortab[4096];
ULO shadcol[64];

/* Expansion card init */

void set_emem(ULO address, ULO value) {
        address &= 0xff;
        switch (address) {
                case 0:
                case 2:
                case 0x40:
                case 0x42:
                        emem[address] = value & 0xf0;
                        emem[address+2] = (value & 0xf)<<4;
                        break;
                default:
                        emem[address] = ~(value & 0xf0);
                        emem[address+2] = ~((value & 0xf)<<4);
                        break;
                        }
}

#pragma aux reademembyte parm [ecx] value [edx];
ULO reademembyte(ULO address) {
        return emem[address&0xff];
}

#pragma aux readememword parm [ecx] value [edx];
ULO readememword(ULO address) {
        return 0xffff;
}

#pragma aux readememlong parm [ecx] value [edx];
ULO readememlong(ULO address) {
        return 0xffffffff;
}

#pragma aux writeemembyte parm [ecx] [edx];
void writeemembyte(ULO address, ULO data) {
        push_eax();
        data &= 0xff;
        switch (wriorgadr&0xff) {
                case 0x30:
                case 0x32:
                        data = 0;
                case 0x48:
                        mem_inittables_fast_runtime();
                        prepare_emem_clear();
                        break;
                case 0x4a:
                        break;
                case 0x4c:
                        prepare_emem_clear();
                        break;
                        }
        pop_eax();
}

#pragma aux writeememword parm [ecx] [edx];
void writeememword(ULO address, ULO data) {
}

#pragma aux writeememlong parm [ecx] [edx];
void writeememlong(ULO address, ULO data) {
}

void prepare_emem_clear(void) {
        int i;
        for (i = 0; i < 256; i++) emem[i] = 0xff;
}

void prepare_fastmem_init(void) {
        char s[10];

        if (config_memory_fastsize == 0x100000) set_emem(0,0xe5);
        else if (config_memory_fastsize == 0x200000) set_emem(0,0xe6);
        else if (config_memory_fastsize == 0x400000) set_emem(0,0xe7);
        else if (config_memory_fastsize == 0x800000) set_emem(0,0xe0);
        set_emem(8,128);
        set_emem(4,1);
        set_emem(0x10,2011>>8);
        set_emem(0x14,2011&0xf);
        set_emem(0x18,0);
        set_emem(0x1c,0);
        set_emem(0x20,0);
        set_emem(0x24,1);
        set_emem(0x28,0);
        set_emem(0x2c,0);
        set_emem(0x40,0);
}


/* Functions to set dmem */

void dmem_clear(void) {
        int i;
        for (i = 0; i < 4096; i++) dmem[i] = 0;
}

void dmem_setcounter(ULO c) {
        dmemcounter = c;
}

ULO dmem_getcounter(void) {
        return dmemcounter + 0xf40000;
}

void dsets(char *st) {
        strcpy(dmem+dmemcounter,st);
        dmemcounter += strlen(st)+1;
        if (dmemcounter & 0x1) dmemcounter++;
}

void dsetb(UBY data) {
        dmem[dmemcounter++] = data;
}

void dsetw(UWO data) {
        dmem[dmemcounter++] = (data&0xff00)>>8;
        dmem[dmemcounter++] = data&0xff;
}

void dsetl(ULO data) {
        dmem[dmemcounter++] = (data&0xff000000)>>24;
        dmem[dmemcounter++] = (data&0xff0000)>>16;
        dmem[dmemcounter++] = (data&0xff00)>>8;
        dmem[dmemcounter++] = data&0xff;
}

#pragma aux readdmembyte parm [ecx] value [edx];
ULO readdmembyte(ULO address){
        ULO tmpval = 0;

        push_ecx();
        if ((address&0xffffff) < 0xf41000) {
                tmpval = dmem[address&0xfff];
                }
        pop_ecx();
        return tmpval;
}

#pragma aux readdmemword parm [ecx] value [edx];
ULO readdmemword(ULO address){
        ULO tmpval = 0;

        push_ecx();
        if ((address&0xffffff) < 0xf41000) {
                tmpval = (dmem[address&0xfff]<<8) | dmem[(address&0xfff)+1];
                }
        pop_ecx();
        return tmpval;
}

#pragma aux readdmemlong parm [ecx] value [edx];
ULO readdmemlong(ULO address){
        ULO tmpval = 0;
        push_ecx();

        if ((address&0xffffff) < 0xf41000) {
                tmpval = (dmem[address&0xfff]<<24) | (dmem[(address&0xfff)+1]<<16) | (dmem[(address&0xfff)+2]<<8) | dmem[(address&0xfff)+3];
                }
        pop_ecx();
        return tmpval;
}

#pragma aux writedmemlong parm [ecx] [edx];
void writedmemlong(ULO address, ULO data){
        push_eax();
        if ((wriorgadr & 0xffffff) == 0xf40000) {
                switch (data>>16) {
                        case 0x0001:    fhfile_do(data);
                                                break;
                        default:                break;
                        }
                }
        pop_eax();
}

/* Used by hardfile, assume AmigaDOS never gives us a faulty address */

UBY *address_to_ptr(ULO address) {
        address &= 0xffffff;
        if (address < 0x200000) return &cmem[address];
        else if (address < 0xa00000) return fmem + (address - 0x200000);
        return &bmem[address - 0xc00000];
}


/* Some useful functions */

void setNAjumptable(ULO m)
{
    readbyte[m] = readnotavailablebyte;
    readword[m] = readnotavailableword;
    readlong[m] = readnotavailablelong;
    writebyte[m] = writenotavailablebyte;
    writeword[m] = writenotavailableword;
    writelong[m] = writenotavailablelong;
}

void mem_inittables_clear(void) {
        ULO i;

        for (i = 0; i < 64; i++) setNAjumptable(i);
}

void mem_inittables_chip(void) {
  ULO m,n;

  if (config_memory_chipsize > 0x200000) n = 0x200000>>18;
  else n = config_memory_chipsize>>18;
  for (m = 0; m < n; m++) {
    readbyte[m] = readchipbyte;
    readword[m] = readchipword;
    readlong[m] = readchiplong;
    writebyte[m] = writechipbyte;
    writeword[m] = writechipword;
    writelong[m] = writechiplong;
    }

  for (m = n; m < 0x200000>>18; m++) setNAjumptable(m);
  for (m = 0; m < config_memory_chipsize; m++) cmem[m] = 0;

}

void mem_inittables_fast_clear(void) {
  ULO m;

  for (m = 0x200000>>18; m < 0xa00000>>18; m++) setNAjumptable(m);
}

void mem_inittables_fast_first(void) {
        ULO origmem = config_memory_fastsize;
        char s[80];

        addlog ("In fast first\n");
        sprintf(s,"Fast size: %d   Allocated=%d\n",config_memory_fastsize,config_memory_fast_allocated);
        addlog(s);
        if (config_memory_fast_allocated != config_memory_fastsize) {
                addlog("Need to allocate\n");
                if (fmem != NULL) free(fmem);
                if (config_memory_fastsize == 0) {
                        addlog("Fastsize is 0, no alloc\n");
                        config_memory_fast_allocated = 0;
                        mem_inittables_fast_clear();
                        return;
                        }
                addlog("Allocating\n");
                fmem = (UBY *) malloc(config_memory_fastsize);
                if (fmem == NULL) {
                        addlog("Alloc failed\n");
                        if (!meminitfirsttime) freeadfcache();
                        fmem = (UBY *) malloc(config_memory_fastsize);
                        if (fmem == NULL) {
                                addlog("Disalloc of adf-cache, still bad\n");
                                config_memory_fastsize >>= 1;
                                while (config_memory_fastsize >= 0x100000 && fmem == NULL) {
                                        fmem = (UBY *) malloc(config_memory_fastsize);
                                        if (fmem == NULL) config_memory_fastsize >>= 1;
                                        }
                                }
                        if (!meminitfirsttime) {
                                if (config_memory_fastsize < 0x100000 || fmem == NULL) config_memory_fastsize = 0;
                                fgui_fastmemAllocFail(origmem>>20, config_memory_fastsize>>20);
                                disk_initinmem();
                                disk_reinsertImages();
                                if (fmem == NULL) {
                                        /* Something is very wrong */
                                        config_memory_fastsize = config_memory_fast_allocated = 0;
                                        mem_inittables_fast_clear();
                                        return;
                                        }
                                }
                        }
                }
        addlog("Ending fast-alloc\n");
        config_memory_fast_allocated = config_memory_fastsize;
        mem_inittables_fast_clear();
}

void mem_inittables_fast_runtime(void) {
        ULO m,n;

        addlog("Fast runtime\n");
        if (config_memory_fastsize > 0x800000) n = 0xa00000>>18;
        else n = (0x200000 + config_memory_fastsize)>>18;

        for (m = 0x200000>>18; m < n; m++) {
                readbyte[m] = readfastbyte;
                readword[m] = readfastword;
                readlong[m] = readfastlong;
                writebyte[m] = writefastbyte;
                writeword[m] = writefastword;
                writelong[m] = writefastlong;
                }
        for (m = 0; m < config_memory_fastsize; m++) fmem[m] = 0;
}

void mem_inittables_cia(void) {
        ULO m;

        for (m = 0xa00000>>18; m < (0xc00000>>18); m++) {
                readbyte[m] = readciabyte;
                readword[m] = readciaword;
                readlong[m] = readcialong;
                writebyte[m] = writeciabyte;
                writeword[m] = writeciaword;
                writelong[m] = writecialong;
                }
}

void mem_inittables_bogo(void) {
        ULO m,n;

        if (config_memory_bogosize > 0x1c0000) n = 0xdc0000>>18;
        else n = (0xc00000+config_memory_bogosize)>>18;
        for (m = 0xc00000>>18; m < n; m++) {
                readbyte[m] = readbogobyte;
                readword[m] = readbogoword;
                readlong[m] = readbogolong;
                writebyte[m] = writebogobyte;
                writeword[m] = writebogoword;
                writelong[m] = writebogolong;
                }
        for (m = 0; m < config_memory_bogosize; m++) bmem[m] = 0;
}

void mem_inittables_reg(void) {
  ULO m,n;

  if (config_memory_bogosize > 0x1c0000) n = 0xdc0000>>18;
  else n = (0xc00000+config_memory_bogosize)>>18;
  for (m = n; m < 0xe00000>>18; m++) {
    readbyte[m] = readregisterbyte;
    readword[m] = readregisterword;
    readlong[m] = readregisterlong;
    writebyte[m] = writeregisterbyte;
    writeword[m] = writeregisterword;
    writelong[m] = writeregisterlong;
    }
}

void mem_inittables_exp(void) {
        ULO m;

        for (m = 0xe00000>>18; m < 0xf80000>>18; m++) setNAjumptable(m);

        m = 0xe80000>>18;
        readbyte[m] = reademembyte;
        readword[m] = readememword;
        readlong[m] = readememlong;
        writebyte[m] = writeemembyte;
        writeword[m] = writeememword;
        writelong[m] = writeememlong;

        prepare_emem_clear();
        if (config_memory_fastsize != 0) prepare_fastmem_init();
}

void mem_inittables_devicemem(void) {
        ULO m;

        if (config_fhfile_enabled) {
                m = 0xf40000>>18;
                readbyte[m] = readdmembyte;
                readword[m] = readdmemword;
                readlong[m] = readdmemlong;
                writebyte[m] = writenotavailablebyte;
                writeword[m] = writenotavailableword;
                writelong[m] = writedmemlong;
                }
}

void mem_inittables_rom(void) {
  ULO m;

  for (m = 0xf80000>>18; m < 0x1000000>>18; m++) {
    readbyte[m] = readkickbyte;
    readword[m] = readkickword;
    readlong[m] = readkicklong;
    writebyte[m] = writenotavailablebyte;
    writeword[m] = writenotavailableword;
    writelong[m] = writenotavailablelong;
    }
}


char *rom_identify( char *s ) {
  int i = 0;

  if( !strncmp( &kmem[0x88], "exec", 4 ) ) {
    strcpy( s, "Kickstart 1.1 [" );
    strncat( s, &kmem[0x88], strlen( &kmem[0x88] )  - 2 );
    strcat( s, "]" );
    config_memory_romversion = 0x101;
    return s;
  };
  if( !strncmp( &kmem[0x3b], "AMIGA ROM", 9 ) ) {
    strcpy( s, "Kickstart 1.3 [" );
    strncat( s, &kmem[0x18], strlen( &kmem[0x18] ) - 2 );
    strcat( s, "]" );
    if( kmem[0x1e] == '3' ) {
        s[12] = '2';
        config_memory_romversion = 0x102;
        }
    else config_memory_romversion = 0x103;
    return s;
  };
  if( !strncmp( &kmem[0x31], "AMIGA ROM", 9 ) ) {
    strcpy( s, "Kickstart 2.0 [" );
    strncat( s, &kmem[0x18], strlen( &kmem[0x18] )  - 2 );
    strcat( s, "]" );
    config_memory_romversion = 0x200;
    return s;
  };
  if( !strncmp( &kmem[0x9c], "exec", 4 ) ) {
    strcpy( s, "Kickstart " );
    while( kmem[i+0x85] != ' ' ) { strncat( s, &kmem[i+0x85], 1 ); i++; };
    strcat( s, " [" );
    strncat( s, &kmem[0x9c], strlen( &kmem[0x9c] )  - 2 );
    strcat( s, "]" );
    config_memory_romversion = 0x300;
    return s;
  };
  if( !strncmp( &kmem[0x9b], "exec", 4 ) ) {
    strcpy( s, "Kickstart " );
    while( kmem[i+0x85] != ' ' ) { strncat( s, &kmem[i+0x85], 1 ); i++; };
    strcat( s, " [" );
    strncat( s, &kmem[0x9b], strlen( &kmem[0x9b] )  - 2 );
    strcat( s, "]" );
    config_memory_romversion = 0x301;
    return s;
  };
  strcpy( s, "unknown" );
  config_memory_romversion = 0x102;
  return s;
};


void mem_loadrom(void) {
        FILE *F;
        ULO i;

        config_memory_nokick = FALSE;
        if ((F = fopen(config_memory_kickname,"rb")) == NULL) {
                if ((F = fopen("kick.rom","rb")) == NULL)
                        config_memory_nokick = TRUE;
                else strcpy(config_memory_kickname,"kick.rom");
                }
        if (!config_memory_nokick) {
                fseek(F,0,SEEK_END);
                config_memory_kicksize = ftell(F);
                fseek(F,0,SEEK_SET);
                if (config_memory_kicksize == 262144) {
                        fread(kmem,1,262144,F);
                        for (i=0; i < 262144; i++) kmem[i+262144] = kmem[i];
                        }
                else if (config_memory_kicksize == 524288) 
                        fread(kmem,1,524288,F);
                else config_memory_nokick = TRUE;
                fclose(F);
                }
        else config_memory_romversion = 0;
        rom_identify(kickstart_idstring);
}




void mem_initreg(void) {
  ULO k,m;
/* Initialize Screen Registers*/
  lof = 0x8000;       /* Always long frame, or maybe not...*/
  bpl1mod = 0;
  bpl2mod = 0;
  diwxleft = 0;
  diwxright = 0; 
  diwytop = 0;   
  diwybottom = 0;
  bpl1pt = 0;
  bpl2pt = 0;
  bpl3pt = 0;
  bpl4pt = 0;
  bpl5pt = 0;
  bpl6pt = 0;
  bplcon0 = 0;
  bplcon1 = 0;
  bplcon2 = 0;
  ddfstrt = 0;
  ddfstop = 0;
  diwstrt = 0;
  diwstop = 0;
  intena = 0;
  intreq = 0;
  


/* Initialize the helpers for screenemulation */
/* Assume no bitplanes on */

  screenptr = (ULO) framebuffer + 12832 + (scanlineadd*8);

  DDFstartpos = 0;
  DDFnumberofwords = 0;
  DIWfirstvisiblepos = 256;
  DIWlastvisiblepos = 256;
  DIWfirstposonline = 88;

  /* Clear the speedup table for blank lines.*/
  for (m=0; m < 314; m++) lineflags[m] = -1;


/* Initialize various registers*/
  dmaconr = 0;
  dmacon = 0;

/* Copper registers */
  curcopptr = 0;
  nxtcopaccess = 6;
  cop1lc = 0;
  cop2lc = 0;

  bltminterm = 0;
  blitend = blitterstatus = 0;
  bltapt = 0;
  bltbpt = 0;
  bltcpt = 0;
  bltdpt = 0;
  bltcon = 0;
  bltafwm = bltalwm = 0;
  bltamod = 0;
  bltbmod = 0;
  bltcmod = 0;
  bltdmod = 0;
  bltadat = 0;
  bltbdat = 0;
  bltcdat = 0;

/* Zero the shadow color registers */
  for (k=0; k<64; k++) shadcol[k] = 0;


  spritewritenext = 0;
  spritewritereal = 0;
}

ULO vgareg2color[256];

void mem_initcolortranslation(void) {
  ULO k,r,g,b;
/* Create color translation table */
  if (config_graphics_modebits[config_graphics_mode] == 8) {
      ULO rbt[16] = { 0,0,1,1,1,2,2,2,3,3,3,4,4,4,5,5};
      ULO gt[16] = { 0,0,1,1,1,2,2,3,3,3,4,4,5,5,6,6};
      /* Use 6 levels of red and blue, 7 levels of green */
      for (k=0; k<4096;k++) {
          colortab[k] = rbt[k & 0xf] + gt[(k & 0xf0)>>4]*6 + rbt[(k & 0xf00)>>8]*42;
          vgareg2color[colortab[k]] = k;
          colortab[k] = colortab[k]<<24 |colortab[k]<<16 |colortab[k]<<8 | colortab[k];
          }
      for (r = 0; r < 6; r++) 
        for (g = 0; g < 7; g++)
          for (b = 0; b < 6; b++)
            set_VGAcolor(b+(g*6)+(r*42),b*11+b,g*10,r*11+r);

      }
  else if (config_graphics_modebits[config_graphics_mode] == 15) {
      for (k=0; k<4096;k++) {
          colortab[k] = ((k & 0xf)<<1) | ((k & 0xf0)<<2) | ((k & 0xf00)<<3);
          colortab[k] = colortab[k]<<16 | colortab[k];
          }
       powerledcolor = 0x7c007c00;
       drivemotorcolor = 0x03e003e0;
       hdledcolor = 0x73807380;
      }
  else {
      for (k=0; k<4096;k++) {
          colortab[k] = ((k & 0xf)<<1) | ((k & 0xf0)<<3) | ((k & 0xf00)<<4);
          colortab[k] = colortab[k]<<16 | colortab[k];
          }
       powerledcolor = 0xf800f800;
       drivemotorcolor = 0x07e007e0;
       hdledcolor = 0x0e700e700;
      }   
}

// The memory module holds all registers (IO and CIA) and
// handles all memory banks.  Loads kickstart from file.
// Meminit initializes these to default values
// Returns true or false when done
// ======================================================

/* Must be called every time memory sizes change */

ULO mem_init(void)
{
  mem_initcia();
  mem_initreg();

/* Initialize the jumptables */
/* There is some redundancy here, but just make sure there are no */
/* NULL ptrs in the tables, clear it all to a default value */

  mem_inittables_clear();
  mem_inittables_chip();
  mem_inittables_fast_first();
  mem_inittables_cia();
  mem_inittables_bogo();
  mem_inittables_reg();
  mem_inittables_exp();
  mem_inittables_rom();
  mem_loadrom();
  mem_inittables_devicemem();

#ifdef CYCLE_EXACT
  if (configcycleexact) iowrite[0x180/2] = (ULO) wcolorcycleexact;
#endif
  meminitfirsttime = FALSE;
  return 1;
}

void mem_cleanup(void) {
        if (fmem != NULL) free(fmem);
}

