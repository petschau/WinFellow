/*===========================*/
/* Keyboard emulation        */
/* Petter Schau 1997         */
/*===========================*/

#include "defs.h"
#include "fellow.h"
#include "keycodes.h"
#include "inout.h"
#include "joymouse.h"
#include "graphem.h"
#include "sddsdk\\pmpro.h"

/* Keyboard buffer data */

PMFARPTR kbdirqorgvect;
UBY keybuffer[512];
ULO keybufferconsumepos, keytimetowait, keybufferproducepos;
ULO lastwase0 = 0;
ULO center_screen = 0;
ULO center_code = 0;
ULO newvmode = 0;
ULO f12pressed;

/* First level translation table */

unsigned char kbd1stlevel[0x58] = {
 A_NOKEY, /* pc none code 0x00 - Amiga none */
 A_ESC  , /* pc esc  code 0x01 - Amiga esc  */
 A_1    , /* pc 1    code 0x02 - Amiga 1    */
 A_2    , /* pc 2    code 0x03 - Amiga 2    */
 A_3    , /* pc 3    code 0x04 - Amiga 3    */
 A_4    , /* pc 4    code 0x05 - Amiga 4    */
 A_5    , /* pc 5    code 0x06 - Amiga 5    */
 A_6    , /* pc 6    code 0x07 - Amiga 6    */
 A_7    , /* pc 7    code 0x08 - Amiga 7    */
 A_8    , /* pc 8    code 0x09 - Amiga 8    */
 A_9    , /* pc 9    code 0x0a - Amiga 9    */
 A_0    , /* pc 0    code 0x0b - Amiga 0    */
 A_PLUS , /* pc +    code 0x0c - Amiga +    */
 A_BSLA , /* pc \    code 0x0d - Amiga \    */
 A_BSPA , /* pc bspa code 0x0e - Amiga bspace*/
 A_TAB  , /* pc tab  code 0x0f - Amiga tab  */
 A_Q    , /* pc q    code 0x10 - Amiga q    */
 A_W    , /* pc w    code 0x11 - Amiga w    */
 A_E    , /* pc e    code 0x12 - Amiga e    */
 A_R    , /* pc r    code 0x13 - Amiga r    */
 A_T    , /* pc t    code 0x14 - Amiga t    */
 A_Y    , /* pc y    code 0x15 - Amiga y    */
 A_U    , /* pc u    code 0x16 - Amiga u    */
 A_I    , /* pc i    code 0x17 - Amiga i    */
 A_O    , /* pc o    code 0x18 - Amiga o    */
 A_P    , /* pc p    code 0x19 - Amiga p    */
 A_AA   , /* pc aa   code 0x1a - Amiga aa   */
 A_HAT  , /* pc hat  code 0x1b - Amiga hat  */
 A_RET  , /* pc ret  code 0x1c - Amiga ret  */
 A_CTRL , /* pc rctrlcode 0x1d - Amiga ctrl */
 A_A    , /* pc a    code 0x1e - Amiga a    */
 A_S    , /* pc a    code 0x1f - Amiga s    */
 A_D    , /* pc a    code 0x20 - Amiga d    */
 A_F    , /* pc a    code 0x21 - Amiga f    */
 A_G    , /* pc a    code 0x22 - Amiga g    */
 A_H    , /* pc a    code 0x23 - Amiga h    */
 A_J    , /* pc a    code 0x24 - Amiga j    */
 A_K    , /* pc a    code 0x25 - Amiga k    */
 A_L    , /* pc a    code 0x26 - Amiga l    */
 A_OE   , /* pc oe   code 0x27 - Amiga oe   */
 A_AE   , /* pc ae   code 0x28 - Amiga ae   */
 A_TILDE, /* pc or   code 0x29 - Amiga tilde*/
 A_RSHIFT,/* pc rshifcode 0x2a - Amiga rshift*/
 A_STAR , /* pc star code 0x2b - Amiga star */
 A_Z    , /* pc z    code 0x2c - Amiga z    */
 A_X    , /* pc x    code 0x2d - Amiga x    */
 A_C    , /* pc c    code 0x2e - Amiga c    */
 A_V    , /* pc v    code 0x2f - Amiga v    */
 A_B    , /* pc b    code 0x30 - Amiga b    */
 A_N    , /* pc n    code 0x31 - Amiga n    */
 A_M    , /* pc m    code 0x32 - Amiga m    */
 A_COMMA, /* pc ,    code 0x33 - Amiga ,    */
 A_DOT  , /* pc .    code 0x34 - Amiga .    */
 A_QUEST, /* pc -    code 0x35 - Amiga ?    */
 A_LSHIFT,/* pc lshifcode 0x36 - Amiga lshift*/
 A_KPDIV ,/* pc kp*  code 0x37 - Amiga kpdiv*/
 A_RALT  ,/* pc ralt code 0x38 - Amiga ralt */
 A_SPACE ,/* pc space code 0x39 - Amiga space */
 A_CAPS  ,/* pc caps code 0x3a - Amiga caps */
 A_F1    ,/* pc f1   code 0x3B - Amiga f1   */
 A_F2    ,/* pc f2   code 0x3C - Amiga f2   */
 A_F3    ,/* pc f3   code 0x3D - Amiga f3   */
 A_F4    ,/* pc f4   code 0x3E - Amiga f4   */
 A_F5    ,/* pc f5   code 0x3F - Amiga f5   */
 A_F6    ,/* pc f6   code 0x40 - Amiga f6   */
 A_F7    ,/* pc f7   code 0x41 - Amiga f7   */
 A_F8    ,/* pc f8   code 0x42 - Amiga f8   */
 A_F9    ,/* pc f9   code 0x43 - Amiga f9   */
 A_F10   ,/* pc f10  code 0x44 - Amiga f10  */
 A_KPLBRA,/* pc nlockcode 0x45 - Amiga keypad right backet */
 A_NOKEY ,/* pc scrolllock 0x46- Amiga none */
 A_KP7   ,/* pc kp 7 code 0x47 - Amiga kp 7 */
 A_KP8   ,/* pc kp 8 code 0x48 - Amiga kp 8 */
 A_KP9   ,/* pc kp 9 code 0x49 - Amiga kp 9 */
 A_KPSTAR,/* pc kp - code 0x4a - Amiga kp * */
 A_KP4   ,/* pc kp 4 code 0x4b - Amiga kp 4 */
 A_KP5   ,/* pc kp 5 code 0x4c - Amiga kp 5 */
 A_KP6   ,/* pc kp 6 code 0x4d - Amiga kp 6 */
 A_KPPLUS,/* pc kp + code 0x4e - Amiga kp plus */
 A_KP1   ,/* pc kp 1 code 0x4f - Amiga kp 1 */
 A_KP2   ,/* pc kp 2 code 0x50 - Amiga kp 2 */
 A_KP3   ,/* pc kp 3 code 0x51 - Amiga kp 3 */
 A_KP0   ,/* pc kp 0 code 0x52 - Amiga kp 0 */
 A_KPDOT ,/* pc kp . code 0x53 - Amiga kp . */
 A_NOKEY ,/* pc none code 0x54 - Amiga none */
 A_NOKEY ,/* pc none code 0x55 - Amiga none */
 A_BRAC  ,/* pc <    code 0x56 - Amiga <    */
 A_NOKEY};  /* code 0x57 */



// Keyboard routines
// -----------------

// Interrupt handler
// -----------------
// - Translate scancode to the corresponding amiga scancode
// - Check press and release bit
// - Add key to keybuffer
// - Set keytimetowait if buffer was empty
// - keytimetowait is horisontal blanks before key is visible
//   to the CIA serial port.

UBY tmpcode;

void interrupt kbdirqhandler(void) {
        int scancode,i;

        scancode = inp(0x60);

        if (lastwase0) {
                lastwase0 = FALSE;
                if (config_joyA == 1 || config_joyB == 1) { /* Joystick, arrowkeys */
                        if (joy_keyreplacement1(scancode)) {
                                outp(0x20,0x20);
                                return;
                                }
                        }

        /* Generate keycode for used keys with E0 prefix */

                switch (scancode & 0x7f) {
                        case 0x1d:      tmpcode = 0x67 | (scancode & 0x80);  /* Right CTRL is Right Amiga */
                                        break;
                        case 0x38:      tmpcode = 0x65 | (scancode & 0x80);  /* Right Alt */
                                        break;
                        case 0x1c:      tmpcode = 0x43 | (scancode & 0x80);  /* Keypad enter */
                                        break;
                        case 0x48:      tmpcode = 0x4c | (scancode & 0x80);  /* up */
                                        break;
                        case 0x4b:      tmpcode = 0x4f | (scancode & 0x80);  /* left */
                                        break;
                        case 0x4d:      tmpcode = 0x4e | (scancode & 0x80);  /* right */
                                        break;
                        case 0x50:      tmpcode = 0x4d | (scancode & 0x80);  /* down */
                                        break;
                        case 0x52:      tmpcode = 0x66| (scancode & 0x80); /* Ins is left amiga */
                                        break;
                        case 0x47:      tmpcode = 0x5f|(scancode & 0x80); /* Home is HELP */
                                        break;
                        case 0x53:      tmpcode = 0x46|(scancode & 0x80); /* Del is Del */
                                        break;
                        case 0x4f:      if (scancode == (0x4f|0x80)) center_screen ^= 1;
                                        outp(0x20,0x20);
                                        return;
                                        break;
                        case 0x49:      if (scancode == (0x49|0x80)) {
                                                config_graphics_mode++;
                                                if (config_graphics_mode > (NROFMODES-1))
                                                        config_graphics_mode = 0;
                                                for (i = 0; i < (NROFMODES-1); i++)
                                                        if (!config_graphics_modeavailable[config_graphics_mode]) {
                                                                config_graphics_mode++;
                                                                if (config_graphics_mode > (NROFMODES-1))
                                                                        config_graphics_mode = 0;
                                                                }
                                                newvmode = 1;
                                                gmodefirsttime[config_graphics_mode] = 1;
                                                }
                                        outp(0x20,0x20);
                                        return;
                                        break;
                        case 0x51:      if (scancode == (0x51|0x80)) {
                                                config_graphics_mode--;
                                                if (config_graphics_mode == 0xffffffff) config_graphics_mode = NROFMODES-1;
                                                for (i = 0; i < (NROFMODES-1); i++)
                                                        if (!config_graphics_modeavailable[config_graphics_mode]) {
                                                                config_graphics_mode--;
                                                                if (config_graphics_mode == 0xffffffff) config_graphics_mode = NROFMODES-1;
                                                                }
                                                newvmode = 1;
                                                gmodefirsttime[config_graphics_mode] = 1;
                                                } 
                                        outp(0x20,0x20);
                                        return;
                                        break;
                        default:        outp(0x20,0x20);
                                        return;
                        }
                }
        else {
                /* Last was not 0xe0 */

                if (scancode == 0xe0) {
                        lastwase0 = 1;
                        outp(0x20,0x20);
                        return;
                        }
                if (scancode == (0x58 | 0x80)) {
                        f12pressed = 1; // F12 - exit to GUI
                        outp(0x20,0x20);
                        return;
                        }
                if (scancode == (0x57 | 0x80)) {
                        BMPdumpflag = 1;
                        outp(0x20,0x20);
                        return;
                        }
                if (config_joyA == 2 || config_joyB == 2) { /* Joystick, DFG R Left CTRL */
                        if (joy_keyreplacement2(scancode)) {
                                outp(0x20,0x20);
                                return;
                                }
                        }

       if (center_screen) {
         if (scancode == 80) {
                if (config_graphics_mode == 1 || config_graphics_mode == 2 || config_graphics_mode == 6) center_code = 80;
                outp(0x20,0x20);
                return;
                }
         else if (scancode == 72) {
                if (config_graphics_mode == 1 || config_graphics_mode == 2 || config_graphics_mode == 6) center_code = 72;
                outp(0x20,0x20);
                return;
                }
         else if (scancode == 75) {
                if (config_graphics_mode >= 1 && config_graphics_mode <= 6) center_code = 75;
                outp(0x20,0x20);
                return;
                }
         else if (scancode == 77) {
                if (config_graphics_mode >= 1 && config_graphics_mode <= 6) center_code = 77;
                outp(0x20,0x20);
                return;
                }
         }

       if ((scancode & 0x7f) >= 87) {
         outp(0x20,0x20);
         return; // Illegal scancode, simply ignore
         }

       tmpcode = kbd1stlevel[scancode&0x7f];
       if (tmpcode == 0xff) { 
         outp(0x20,0x20);
         return;  // Scancode for nonmapped key
         }
   } /* End of not E0 */

   // Here we've got a mapped scancode, set press/release bit

   tmpcode |= (scancode & 0x80);

   // Add scancode to end of keybuffer

   keybuffer[(keybufferproducepos) & 511] = tmpcode;
   keybufferproducepos++;

   outp(0x20,0x20);
}

/* Set keyboard irq vector to our irq handler */

void init_kbdirq(void) {
  lastwase0 = 0;
  PM_getPMvect(9,&kbdirqorgvect);
  PM_setPMvect(9,(PM_intHandler) kbdirqhandler);
}

/* Uninstall our keyboard irq handler */

void restore_kbdirq(void) {
  PM_restorePMvect(9,kbdirqorgvect);
}

/* Called every time we reset */

void reset_keyboard(void) {
  keybufferconsumepos = 0;
  keytimetowait = 10;
  keybufferproducepos = 2;
  keybuffer[0] = 0xfd;
  keybuffer[1] = 0xfe;
  f12pressed = 0;
  lastwase0 = 0;
}

