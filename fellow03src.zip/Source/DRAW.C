/* Fellow 1997 Petter Schau */

/* Clean C-implementation of the VGA-drawing routines */
/* No optimization issues considered */
/* The routines that writes words to VGA-memory compiles badly */
/* Those writing longwords are compiled by Watcom into code that */
/* is almost the same as my handwritten assembly-code :-) */


#include "defs.h"
#include "fellow.h"
#include "inout.h"
#include "68000.h"
#include "memory.h"
#include "chip.h"
#include "graphem.h"

#ifndef USE_C
#include "draw.h"
#endif

ULO bg2ddf;


#ifdef USE_C

/* Check line against the defined clipping, and possibly adjust lineptr */
/* Does not belong in this file, it is system-independent */

ULO clip_edges(UBY **lineptr) {
        ULO llim = DIWfirstvisiblepos, rlim = DIWlastvisiblepos, amount;

        if (bplcon0 & 0x8000) {
                llim >>= 1;
                rlim >>= 1;
                }
        if (rlim > cliprightx) amount = cliprightx;
        else amount = rlim;
        if (llim < clipleftx) {
                *lineptr = &linje[clipleftx];
                return (amount - clipleftx);
                }
        else {
                *lineptr = &linje[llim];
                return (amount - llim);
                }
}

int drawbgline_test(void) {
        if (bgcol != lineflags[ypos]) {
                lineflags[ypos] = bgcol;
                lineflagstimes[ypos] = configdoublebuffer;
                return TRUE;
                }
        else {
                if (lineflagstimes[ypos] != 0) return lineflagstimes[ypos]--;
                }
        return FALSE;
}

/*---------------------------------*/
/* Width 640/800 pixels, 15/16 bpp */
/*---------------------------------*/

/* Draws amount bgpixels at screenptr, and updates the pointer   */
/* Pixels here counts as lores-pixels, which doubles */

#pragma aux fillbg800w parm [ebx];
void fillbg800w(ULO amount) {
        ULO i,j,bgcol = shadcol[0];
        ULO *spt = (ULO *) screenptr;

        screenptr += amount*4;
        j = amount & 0xfffffffc;
        for (i = 0; i < j; i+= 4) {
                spt[i] = bgcol;
                spt[1+i] = bgcol;
                spt[2+i] = bgcol;
                spt[3+i] = bgcol;
                }
        for (i = j; i < amount; i++) spt[i] = bgcol;
}

/* Draw a full blank line if this buffer hasn't been drawn with the color */
/* Width, 800 pixels 15/16 bit colors */

void drawbgline800w(void) {
        if ((ypos >= 0x1a) && drawbgline_test()) {
                ULO bgcol = shadcol[0];
                ULO *spt = (ULO *) screenptr, *spt_end = spt + 384;

                for (spt = spt; spt < spt_end; spt += 8) {
                        *spt = bgcol;
                        *(spt + 1) = bgcol;
                        *(spt + 2) = bgcol;
                        *(spt + 3) = bgcol;
                        *(spt + 4) = bgcol;
                        *(spt + 5) = bgcol;
                        *(spt + 6) = bgcol;
                        *(spt + 7) = bgcol;
                        }
                screenptr += 1600 + scanlineadd;
                }
}

/* Draw a line of lores data on a 800 pixels width VGA line */

void drawlores800w(void) {
        ULO i,j,amount = DIWlastvisiblepos - DIWfirstvisiblepos;
        UBY *lineptr = &linje[DIWfirstvisiblepos];
        ULO *spt = (ULO *) screenptr;
        
        if (amount <= 0) return;
        screenptr += amount*4;
        j = amount & 0xfffffffc;
        for (i = 0; i < j; i += 4) {
                spt[i]   = shadcol[lineptr[i]];
                spt[1+i] = shadcol[lineptr[i+1]];
                spt[2+i] = shadcol[lineptr[i+2]];
                spt[3+i] = shadcol[lineptr[i+3]];
                }
        for (i = j; i < amount; i++) spt[i] = shadcol[lineptr[i]];
}

/* Draw a line of hires data on a 800 pixels width VGA line */

void drawhires800w(void) {
        ULO i,j,amount = DIWlastvisiblepos - DIWfirstvisiblepos;
        UBY *lineptr = &linje[DIWfirstvisiblepos];
        ptunion upt;

        if (amount <= 0) return;
        upt.lptr = (ULO *) screenptr;
        screenptr += amount*2;
        j = (amount & 0xfffffffc)>>1;
        for (i = 0; i < j; i += 2) {
                upt.lptr[i]     = (shadcol[lineptr[i*2]] & 0xffff)
                                | (shadcol[lineptr[i*2+1]] & 0xffff0000);
                upt.lptr[i+1]   = (shadcol[lineptr[i*2+2]] & 0xffff)
                                | (shadcol[lineptr[i*2+3]] & 0xffff0000);
                }
        for (i = j*2; i < amount; i++) upt.wptr[i] = shadcol[lineptr[i]];
}

/* Draw a line of dual playfield lores data on a 800 pixels width VGA line */

void drawduallores800w(void) {
        ULO i,j,amount = DIWlastvisiblepos - DIWfirstvisiblepos;
        UBY *line1ptr = &linje[DIWfirstvisiblepos];
        UBY *line2ptr = &linje2[DIWfirstvisiblepos];
        ULO *spt = (ULO *) screenptr;
        UBY *dualxlat = (UBY *) dualtranslate;

        if (!(bplcon2 & 0x40)) dualxlat += 0x10000;

        if (amount <= 0) return;
        screenptr += amount*4;
        j = amount & 0xfffffffc;
        for (i = 0; i < j; i += 4) {
                spt[i]   = shadcol[dualxlat[(line1ptr[i]<<8)|line2ptr[i]]>>2];
                spt[1+i] = shadcol[dualxlat[(line1ptr[1+i]<<8)|line2ptr[1+i]]>>2];
                spt[2+i] = shadcol[dualxlat[(line1ptr[2+i]<<8)|line2ptr[2+i]]>>2];
                spt[3+i] = shadcol[dualxlat[(line1ptr[3+i]<<8)|line2ptr[3+i]]>>2];
                }
        for (i = j; i < amount; i++)
                spt[i]   = shadcol[dualxlat[(line1ptr[i]<<8)|line2ptr[i]]>>2];
}

/* Draw a line of dual playfield hires data on a 800 pixels width VGA line */

void drawdualhires800w(void) {
        ULO i,j,amount = DIWlastvisiblepos - DIWfirstvisiblepos;
        UBY *line1ptr = &linje[DIWfirstvisiblepos];
        UBY *line2ptr = &linje2[DIWfirstvisiblepos];
        ptunion upt;
        UBY *dualxlat = (UBY *) dualtranslate;
        upt.lptr = (ULO *) screenptr;

        if (bplcon2 & 0x4) dualxlat += 0x10000;

        if (amount <= 0) return;
        screenptr += amount*2;
        j = (amount & 0xfffffffc)>>1;
        for (i = 0; i < j; i += 2) {
                upt.lptr[i]   = (shadcol[dualxlat[(line1ptr[i*2]<<8)|line2ptr[i*2]]>>2] & 0xffff)
                                | ((shadcol[dualxlat[(line1ptr[1+i*2]<<8)|line2ptr[1+i*2]]>>2] & 0xffff)<<16);
                upt.lptr[1+i] = (shadcol[dualxlat[(line1ptr[2+i*2]<<8)|line2ptr[2+i*2]]>>2] & 0xffff)
                                | ((shadcol[dualxlat[(line1ptr[3+i*2]<<8)|line2ptr[3+i*2]]>>2] & 0xffff)<<16);
                }
        for (i = j*2; i < amount; i++)
                upt.wptr[i] = shadcol[dualxlat[(line1ptr[i]<<8)|line2ptr[i]]>>2];
}

/*-----------------------------*/
/* Width 320 pixels, 15/16 bpp */
/*-----------------------------*/

/* Draws amount bgpixels at screenptr, and updates the pointer   */
/* Width, 320 pixels 15/16 bit colors */

#pragma aux fillbg320w parm [ebx];
void fillbg320w(ULO amount) {
        ULO i,j,bgcol = shadcol[0];
        ptunion upt;

        upt.lptr = (ULO *) screenptr;
        screenptr += amount*2;
        if ((upt.lval & 0x3) != 0) {   /* Align */
             *upt.wptr++ = bgcol;
             amount--;
             }

        j = amount & 0xfffffffe;
        for (i = 0; i < j; i+= 2) {
                upt.lptr[i] = bgcol;
                upt.lptr[1+i] = bgcol;
                }
        if ((amount & 0x1) == 1) upt.wptr[amount-1] = bgcol;
}

/* Draw a full blank line if this buffer hasn't been drawn with the color */
/* Width, 320 pixels 15/16 bit colors */

void drawbgline320w(void) {
        if ((ypos >= cliptop) && (ypos < clipbot)) {
                ULO *spt = (ULO *) screenptr, *spt_end = spt + 160;
                ULO bgcol = shadcol[0];

                screenptr += 640 + scanlineadd;
                if (bgcol != lineflags[ypos]) {
                        lineflags[ypos] = bgcol;
                        lineflagstimes[ypos] = configdoublebuffer;
                        }
                else {
                        if (lineflagstimes[ypos] != 0) lineflagstimes[ypos]--;
                        else return;
                        }

                for (spt = spt; spt < spt_end; spt += 24) {
                        *spt = bgcol;
                        *(spt + 1) = bgcol;
                        *(spt + 2) = bgcol;
                        *(spt + 3) = bgcol;
                        *(spt + 4) = bgcol;
                        *(spt + 5) = bgcol;
                        *(spt + 6) = bgcol;
                        *(spt + 7) = bgcol;
                        *(spt + 8) = bgcol;
                        *(spt + 9) = bgcol;
                        *(spt + 10) = bgcol;
                        *(spt + 11) = bgcol;
                        *(spt + 12) = bgcol;
                        *(spt + 13) = bgcol;
                        *(spt + 14) = bgcol;
                        *(spt + 15) = bgcol;
                        }
                }
}

/* Draw a line of lores data on a 320 pixels width VGA line */

void drawlores320w(void) {
        ULO i,j,amount;
        UBY *lineptr;
        ptunion upt;

        if ((amount = clip_edges(&lineptr)) <= 0) return;

        upt.lptr = (ULO *) screenptr;
        screenptr += amount*2;
        if ((upt.lval & 0x3) != 0) {                   /* Align */
             *upt.wptr++ = shadcol[(*lineptr++)>>2];
             amount--;
             }
        j = (amount & 0xfffffffc)>>1;
        for (i = 0; i < j; i += 2) {
                upt.lptr[i]   = (shadcol[lineptr[i*2]] & 0xffff)
                                  |(shadcol[lineptr[i*2+1]] & 0xffff0000);
                upt.lptr[1+i] = (shadcol[lineptr[i*2+2]] & 0xffff)
                                  |(shadcol[lineptr[i*2+3]] & 0xffff0000);
                }
        for (i = j*2; i < amount; i++) upt.wptr[i] = shadcol[lineptr[i]];
}

#endif

/* Init tables */

void init_drawtables_320b(void) {
    drawbgroutine = drawptr = drawbgline320b;
    drawddfroutine = drawddfline320b;
    drawloresroutine = drawlores320b;
    drawhiresroutine = drawlores320b;
    drawdualloresroutine = drawduallores320b;
    drawdualhiresroutine = drawduallores320b;
    drawhamroutine = drawham320b;
}

void init_drawtables_320w(void) {
    drawbgroutine = drawptr = drawbgline320w;
    drawddfroutine = drawddfline320w;
    drawloresroutine = drawlores320w;
    drawhiresroutine = drawlores320w;
    drawdualloresroutine = drawduallores320w;
    drawdualhiresroutine = drawduallores320w;
    drawhamroutine = drawham320w;
}

void init_drawtables_640w(void) {
    drawbgroutine = drawptr = drawbgline640w;
    drawddfroutine = drawddfline640w;
    drawloresroutine = drawlores640w;
    drawhiresroutine = drawhires640w;
    drawdualloresroutine = drawduallores640w;
    drawdualhiresroutine = drawdualhires640w;
    drawhamroutine = drawham640w;
}

void init_drawtables_800w(void) {
        if (mmx_detected) {
                drawbgroutine = drawptr = drawbgline800wmmx;
                drawloresroutine = drawlores800wmmx;
                drawhiresroutine = drawhires800wmmx;
                drawdualloresroutine = drawduallores800wmmx;
                }
        else {
                drawbgroutine = drawptr = drawbgline800w;
                drawloresroutine = drawlores800w;
                drawhiresroutine = drawhires800w;
                drawdualloresroutine = drawduallores800w;
                }
        drawddfroutine = drawddfline;
        drawdualhiresroutine = drawdualhires800w;
        drawhamroutine = drawham;
}
