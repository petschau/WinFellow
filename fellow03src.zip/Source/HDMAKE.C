#include <stdio.h>

/* Make a hardfile */
/* P.Schau */

void print_usage(void) {
        fprintf(stderr,"hdmake filename size(in bytes)\n");
        exit(1);
}

void main(int argc, char *argv[]) {
        FILE *O;
        int i,size;

        if (argc == 3) {
                if ((size = atoi(argv[2])) > 0) {
                        if ((O=fopen(argv[1],"wb"))) {
                                fprintf(stdout,"Generating hardfile called %s , size %d\n",argv[1],size);
                                for (i = 0; i < size; i++) fputc(0,O);
                                fclose(O);
                                }
                        else {
                                fprintf(stderr,"Error: Could not open file: %s\n",argv[1]);
                                print_usage();
                                }
                        }
                else {
                        fprintf(stderr,"Error: Wrong size.\n");
                        print_usage();
                        }
                }
         else {
                fprintf(stderr,"Error: Wrong number of arguments\n");
                print_usage();
                }
}



