#include <stdio.h>
#include "defs.h"
#include "cia.h"
#include "memory.h"
#include "inout.h"
#include "68000.h"

/*====================*/
/* fhfile.device      */
/*====================*/

/* references for the hardfile device: */
/* The device driver source found on Fish 39 */


ULO fhfile_tracks;
ULO fhfile_size;
FILE *fhfile_hardfile;

char config_fhfile_name[256];
ULO config_fhfile_enabled = TRUE;
ULO config_fhfile_init = 0;

char hfs[100];

/*==========================*/
/* fhfile_open              */
/*==========================*/

void fhfile_open(void) {
        if (d[0] == 0) {                        /* Only 1 unit now */
                wrib(7, a[1] + 8);              /* ln_type (NT_REPLYMSG) */
                wrib(0, a[1] + 31);             /* io_error */
                wril(0, a[1] + 24);             /* io_unit */
                wril(fetl(a[6] + 32) + 1, a[6] + 32);  /* LIB_OPENCNT */
                d[0] = 0;  /* ? */
                }
        else {
                wril(-1, a[1] + 20);            
                wrib(-1, a[1] + 31);            /* io_error */
                d[0] = -1;  /* ? */
                }
}

/*==========================*/
/* fhfile_close             */
/*==========================*/

void fhfile_close(void) {
        wril(fetl(a[6] + 32) - 1, a[6] + 32);   /* LIB_OPENCNT */
        d[0] = 0;  /* ? */
}

/*==========================*/
/* fhfile_expunge           */
/*==========================*/

void fhfile_expunge(void) {
        d[0] = 0;  /* ? */
}

/*==========================*/
/* fhfile_null              */
/*==========================*/

void fhfile_null(void) {
}

/*==================*/
/* BeginIO Commands */
/*==================*/

void fhfile_ignore(void) {
        wril(0, a[1] + 32);
        d[0] = 0;
}

void fhfile_getnumberoftracks(void) {
        wril(fhfile_tracks, a[1] + 32);
}

void fhfile_getdrivetype(void) {
        wril(1, a[1] + 32);
}

int fhfile_read(void) {
        ULO dest = fetl(a[1] + 40), offset = fetl(a[1] + 44),
            length = fetl(a[1] + 36);

        if ((dest & 1) || (offset + length > fhfile_size)) return -3;
        if( config_enableleds & 0x40 || config_enableleds < 0x10 ) {
          ledbyte |= (config_enableleds & 0x10) ? 0x4 : 0x20; // update leds
          if( config_enableleds < 0x10 ) drawledhdscr();
          else drawledlpt();
        }
        fseek(fhfile_hardfile, offset, SEEK_SET);
        fread(address_to_ptr(dest), 1, length, fhfile_hardfile);
        wril(length, a[1] + 32);
        if( config_enableleds & 0x40 || config_enableleds < 0x10 ) {
          ledbyte &= (config_enableleds & 0x10) ? 0xfb : 0xdf; // update leds
          if( config_enableleds < 0x10 ) drawledhdscr();
          else drawledlpt();
        }
        return 0;
}

int fhfile_write(void) {
        ULO dest = fetl(a[1] + 40), offset = fetl(a[1] + 44),
            length = fetl(a[1] + 36);

        if ((dest & 1) || (offset + length > fhfile_size)) return -3;
        if( config_enableleds & 0x40 || config_enableleds < 0x10 ) {
          ledbyte |= (config_enableleds & 0x10) ? 0x4 : 0x20; // update leds
          if( config_enableleds < 0x10 ) drawledhdscr();
          else drawledlpt();
        }
        fseek(fhfile_hardfile, offset, SEEK_SET);
        fwrite(address_to_ptr(dest),1, length, fhfile_hardfile);
        wril(length, a[1] + 32);
        if( config_enableleds & 0x40 || config_enableleds < 0x10 ) {
          ledbyte &= (config_enableleds & 0x10) ? 0xfb : 0xdf; // update leds
          if( config_enableleds < 0x10 ) drawledhdscr();
          else drawledlpt();
        }
        return 0;
}


/*==========================*/
/* fhfile_beginio           */
/*==========================*/

void fhfile_beginio(void) {
        int error = 0;
        char s[20];

        switch (fetw(a[1] + 28)) {
                case 2:         error = fhfile_read();
                                break;
                case 3:
                case 11:        error = fhfile_write();
                                break;
                case 18:        fhfile_getdrivetype();
                                break;
                case 19:        fhfile_getnumberoftracks();
                                break;
                case 4:
                case 5:
                case 9:
                case 10:
                case 12:
                case 13:
                case 14:
                case 15:
                case 20:
                case 21:        fhfile_ignore();
                                break;
                default:        error = -3;
                                d[0] = 0;
                                break;
                }
        wrib(5, a[1] + 8);      /* ln_type */
        wrib(error, a[1] + 31); /* ln_error */
}

/*==========================*/
/* fhfile_abortio           */
/*==========================*/

void fhfile_abortio(void) {
        d[0] = -3;
}

/*=================================================*/
/* fhfile_do                                       */
/* The M68000 stubs entered in the device tables   */
/* write a longword to $f40000, which is forwarded */
/* by the memory system to this procedure.         */
/* Hardfile commands are issued by 0x0001XXXX      */
/*=================================================*/

void fhfile_do(ULO data) {
        switch (data & 0xffff) {
                case 1:         addlog("hardfile boot\n");
                                break;
                case 2:         fhfile_open();
                                break;
                case 3:         fhfile_close();
                                break;
                case 4:         fhfile_expunge();
                                break;
                case 5:         fhfile_null();
                                break;
                case 6:         fhfile_beginio();
                                break;
                case 7:         fhfile_abortio();
                                break;
                default:        break;
                }
}

void fhfile_init_open(void) {
        int size;

        if ((fhfile_hardfile = fopen(config_fhfile_name, "r+b")) != NULL) {
                fseek(fhfile_hardfile, 0, SEEK_END);
                size = ftell(fhfile_hardfile);
                if (size < (32*512)) {
                        fclose(fhfile_hardfile);
                        fhfile_hardfile = NULL;
                        return;
                        }
                fhfile_tracks = size/(32*512);
                fhfile_size = fhfile_tracks*32*512;
                }
}

/*===========================================================*/
/* fhfile_setup                                              */
/* This will set up the device structures and stubs          */
/* Can be called at every reset, but really only needed once */
/*===========================================================*/

void fhfile_setup(void) {
      ULO devicename,idstr;
      ULO romtagstart;
      ULO initstruct,functable,datatable;
      ULO fhfile_t_init = 0;
      ULO fhfile_t_open = 0;
      ULO fhfile_t_close = 0;
      ULO fhfile_t_expunge = 0;
      ULO fhfile_t_null = 0;
      ULO fhfile_t_beginio = 0;
      ULO fhfile_t_abortio = 0;
      ULO mkdosdev_packet;
      ULO dosdevicename;

      if (config_fhfile_enabled && (config_memory_romversion >= 0x200)) {
        fhfile_init_open();

        if (fhfile_hardfile == NULL) return;

        dmem_setcounter(0);

        /* Device-name and ID string */

        devicename = dmem_getcounter();
        dsets("fhfile.device");
        idstr = dmem_getcounter();
        dsets("Fellow Hardfile device");

        /* Device name as seen in Amiga DOS */

        dosdevicename = dmem_getcounter();
        dsets("FELLOW");

        /* fhfile.open */

        fhfile_t_open = dmem_getcounter();
        dsetw(0x23fc);
        dsetl(0x00010002); dsetl(0xf40000);     /* move.l #$00010002,$f40000 */
        dsetw(0x4e75);                          /* rts */

        /* fhfile.close */

        fhfile_t_close = dmem_getcounter();
        dsetw(0x23fc);
        dsetl(0x00010003); dsetl(0xf40000);     /* move.l #$00010003,$f40000 */
        dsetw(0x4e75);                          /* rts */

        /* fhfile.expunge */

        fhfile_t_expunge = dmem_getcounter();
        dsetw(0x23fc);
        dsetl(0x00010004); dsetl(0xf40000);     /* move.l #$00010004,$f40000 */
        dsetw(0x4e75);                          /* rts */

        /* fhfile.null */

        fhfile_t_null = dmem_getcounter();
        dsetw(0x23fc);
        dsetl(0x00010005); dsetl(0xf40000);     /* move.l #$00010005,$f40000 */
        dsetw(0x4e75);                          /* rts */

        /* fhfile.beginio */

        fhfile_t_beginio = dmem_getcounter();
        dsetw(0x23fc);
        dsetl(0x00010006); dsetl(0xf40000);     /* move.l #$00010006,$f40000 */
        dsetl(0x48e78002);                      /* movem.l d0/a6,-(a7) */
        dsetl(0x08290000); dsetw(0x001e);       /* btst   #$0,30(a1)   */
        dsetw(0x6608);                          /* bne    (to rts)     */
        dsetl(0x2c780004);                      /* move.l $4.w,a6      */
        dsetl(0x4eaefe86);                      /* jsr    -378(a6)     */
        dsetl(0x4cdf4001);                      /* movem.l (a7)+,d0/a6 */
        dsetw(0x4e75);                          /* rts */

        /* fhfile.abortio */

        fhfile_t_abortio = dmem_getcounter();
        dsetw(0x23fc);
        dsetl(0x00010007); dsetl(0xf40000);     /* move.l #$00010007,$f40000 */
        dsetw(0x4e75);                          /* rts */

        /* Func-table */

        functable = dmem_getcounter();
        dsetl(fhfile_t_open);
        dsetl(fhfile_t_close);
        dsetl(fhfile_t_expunge);
        dsetl(fhfile_t_null);
        dsetl(fhfile_t_beginio);
        dsetl(fhfile_t_abortio);
        dsetl(0xffffffff);

        /* Data-table */

        datatable = dmem_getcounter();
        dsetw(0xE000);          /* INITBYTE */
        dsetw(0x0008);          /* LN_TYPE */
        dsetw(0x0300);          /* NT_DEVICE */
        dsetw(0xC000);          /* INITLONG */
        dsetw(0x000A);          /* LN_NAME */
        dsetl(devicename);
        dsetw(0xE000);          /* INITBYTE */
        dsetw(0x000E);          /* LIB_FLAGS */
        dsetw(0x0600);          /* LIBF_SUMUSED+LIBF_CHANGED */
        dsetw(0xD000);          /* INITWORD */
        dsetw(0x0014);          /* LIB_VERSION */
        dsetw(0x0001);
        dsetw(0xD000);          /* INITWORD */
        dsetw(0x0016);          /* LIB_REVISION */
        dsetw(0x0000);
        dsetw(0xC000);          /* INITLONG */
        dsetw(0x0018);          /* LIB_IDSTRING */
        dsetl(idstr);
        dsetl(0);               /* END */


        /* fhfile.init */

        fhfile_t_init = dmem_getcounter();

  dsetb(0x48); dsetb(0xE7); dsetb(0xFF); dsetb(0xFE); dsetb(0x2C); dsetb(0x78);
  dsetb(0x00); dsetb(0x04); dsetb(0x43); dsetb(0xFA); dsetb(0x00); dsetb(0x8E);
  dsetb(0x4E); dsetb(0xAE); dsetb(0xFE); dsetb(0x68); dsetb(0x28); dsetb(0x40);
  dsetb(0x20); dsetb(0x3C); dsetb(0x00); dsetb(0x00); dsetb(0x00); dsetb(0x58);
  dsetb(0x72); dsetb(0x01); dsetb(0x2C); dsetb(0x78); dsetb(0x00); dsetb(0x04);
  dsetb(0x4E); dsetb(0xAE); dsetb(0xFF); dsetb(0x3A); dsetb(0x2A); dsetb(0x40);
  dsetb(0x41); dsetb(0xFA); dsetb(0x00); dsetb(0x84); dsetb(0x70); dsetb(0x54);
  dsetb(0x2B); dsetb(0xB0); dsetb(0x08); dsetb(0x00); dsetb(0x08); dsetb(0x00);
  dsetb(0x59); dsetb(0x80); dsetb(0x64); dsetb(0xF6); dsetb(0x20); dsetb(0x4D);
  dsetb(0x4E); dsetb(0xAC); dsetb(0xFF); dsetb(0x70); dsetb(0x24); dsetb(0x40);
  dsetb(0x72); dsetb(0x00); dsetb(0x25); dsetb(0x41); dsetb(0x00); dsetb(0x08);
  dsetb(0x25); dsetb(0x41); dsetb(0x00); dsetb(0x10); dsetb(0x25); dsetb(0x41);
  dsetb(0x00); dsetb(0x20); dsetb(0x2C); dsetb(0x78); dsetb(0x00); dsetb(0x04);
  dsetb(0x70); dsetb(0x14); dsetb(0x4E); dsetb(0xAE); dsetb(0xFF); dsetb(0x3A);
  dsetb(0x22); dsetb(0x40); dsetb(0x70); dsetb(0x00); dsetb(0x22); dsetb(0x80);
  dsetb(0x23); dsetb(0x40); dsetb(0x00); dsetb(0x04); dsetb(0x33); dsetb(0x40);
  dsetb(0x00); dsetb(0x0E); dsetb(0x33); dsetb(0x7C); dsetb(0x10); dsetb(0xFE);
  dsetb(0x00); dsetb(0x08); dsetb(0x41); dsetb(0xFA); dsetb(0x00); dsetb(0x22);
  dsetb(0x23); dsetb(0x48); dsetb(0x00); dsetb(0x0A); dsetb(0x23); dsetb(0x4A);
  dsetb(0x00); dsetb(0x10); dsetb(0x41); dsetb(0xEC); dsetb(0x00); dsetb(0x4A);
  dsetb(0x4E); dsetb(0xAE); dsetb(0xFE); dsetb(0xF2); dsetb(0x2C); dsetb(0x78);
  dsetb(0x00); dsetb(0x04); dsetb(0x22); dsetb(0x4C); dsetb(0x4E); dsetb(0xAE);
  dsetb(0xFE); dsetb(0x62); dsetb(0x4C); dsetb(0xDF); dsetb(0x7F); dsetb(0xFF);
  dsetb(0x4E); dsetb(0x75); dsetb(0x23); dsetb(0xFC); dsetb(0x00); dsetb(0x01);
  dsetb(0x00); dsetb(0x01); dsetb(0x00); dsetb(0xF4); dsetb(0x00); dsetb(0x00);
  dsetb(0x4E); dsetb(0x75); dsetb(0x65); dsetb(0x78); dsetb(0x70); dsetb(0x61);
  dsetb(0x6E); dsetb(0x73); dsetb(0x69); dsetb(0x6F); dsetb(0x6E); dsetb(0x2E);
  dsetb(0x6C); dsetb(0x69); dsetb(0x62); dsetb(0x72); dsetb(0x61); dsetb(0x72);
  dsetb(0x79); dsetb(0x00);

        /* The mkdosdev packet */

        mkdosdev_packet = dmem_getcounter();
        dsetl(dosdevicename);           /*  0 Device driver name "FELLOW" */
        dsetl(devicename);              /*  4 Device name "fhfile.device" */
        dsetl(0);                       /*  8 Unit # */
        dsetl(0);                       /* 12 OpenDevice flags */
        dsetl(16);                      /* 16 Environment size */
        dsetl(128);                     /* 20 Longwords in a block */
        dsetl(0);                       /* 24 sector origin (unused) */
        dsetl(1);                       /* 28 Heads */
        dsetl(1);                       /* 32 Sectors per logical block (unused) */
        dsetl(32);                      /* 36 Sectors per track */
        dsetl(1);                       /* 40 Reserved blocks, min. 1 */
        dsetl(0);                       /* 44 mdn_prefac - Unused */
        dsetl(0);                       /* 48 Interleave */
        dsetl(0);                       /* 52 Lower cylinder */
        dsetl(fhfile_tracks-1);         /* 56 Upper cylinder */
        dsetl(0);                       /* 60 Number of buffers */
        dsetl(0);                       /* 64 Type of memory for buffers */
        dsetl(0x7fffffff);              /* 68 Largest transfer */
        dsetl(~1);                      /* 72 Add mask */
        dsetl(-2);                      /* 76 Boot priority */
        dsetl(0x444f5300);              /* 80 DOS file handler name */
        dsetl(0);

        /* Init-struct */

        initstruct = dmem_getcounter();
        dsetl(0x100);                   /* Data-space size, min LIB_SIZE */
        dsetl(functable);               /* Function-table */
        dsetl(datatable);               /* Data-table */
        dsetl(fhfile_t_init);           /* Init-routine */

        /* RomTag structure */

        romtagstart = dmem_getcounter();
        dsetw(0x4afc);                  /* Start of structure */
        dsetl(romtagstart);             /* Pointer to start of structure */
        dsetl(romtagstart+26);          /* Pointer to end of code */
        dsetb(0x81);                    /* Flags, AUTOINIT+COLDSTART */
        dsetb(0x1);                     /* Version */
        dsetb(3);                       /* DEVICE */
        dsetb(0);                       /* Priority */
        dsetl(devicename);              /* Pointer to name (used in opendev)*/
        dsetl(idstr);                   /* ID string */
        dsetl(initstruct);              /* Init_struct */
        }
      else dmem_clear();
}

/*==========================*/
/* fhfile_create            */
/*==========================*/

void fhfile_create( void ) {
  int i;
  FILE *fout;
  char *buffer = (char *)malloc( 1024*1024 ); // 1MB buffer

  if( config_fhfile_name[0] != 0 && buffer != NULL ) {
    printf( "Creating fhfile...\n" );
    for( i = 0; i < 1024*1024; i++ ) buffer[i] = 0;
    if( ( fout = fopen( config_fhfile_name, "wb" ) ) != NULL ) {
      for( i = 0; i < config_fhfile_init; i++ )
        fwrite( buffer, 1, 1024*1024, fout );
      fclose( fout );
    }
  }
}

