/* Fellow Amiga Emulator */
/* Petter Schau          */
/* David Voracek,        */
/* Roman Doljesi         */
/* Setup for videomodes  */


#define DPMI32

#include <dos.h>
#include <stdio.h>
#include "defs.h"
#include "fellow.h"
#include "sddsdk\\vesavbe.h"
#include "memory.h"
#include "sddsdk\\pmpro.h"
#include "chip.h"
#include "sblast.h"
#include "sound.h"
#include "fonts.h"
#include "graphem.h"

/* Memory to build the speedomeeter image */

UWO speedbuffer[8][16];

// Data, constants and pointers for VESA & VGA graphic routines

UWO *framebufferunmodified; /* Unmodified pointer to framebuffer memory */
UWO *framebuffer; /* Pointer to framebuffer when mapped to our memory */

/* These are updated when a new mode is set */

ULO scanlineadd;  /* Excess bytes when virtual size is bigger than phys. */
ULO scanlinelength; /* Total length in bytes for a line */
ULO framebuffermapped; /* Flag to avoid mapping the framebuffer twice */
ULO startoffset;
ULO bufferoffsets[3];
UBY graph256_palete[256][3];

/*---*/

UBY config_graphics_modeavailable[NROFMODES];
UBY config_graphics_modebits[NROFMODES];
ULO config_graphics_moderesx[NROFMODES] = { 800, 320, 320, 640, 640, 640, 320 };
ULO config_graphics_moderesy[NROFMODES] = { 300, 200, 240, 480, 400, 350, 200 };




/* The timer-routines */

ULO tick;
ULO tick2;
ULO lastcc;
ULO newcc;

void timer_routineC(void) {
  newcc = (frames*71364)+(ypos*228)+xpos;
  emuspeed = (newcc-lastcc)*10000;
  emuspeed = emuspeed/71364;
  lastcc = newcc;
}

void start_timerirq(void) {
  tick = 0;
  if (config_sound == 2) {
    PM_setTimerHandler((PM_intHandler) timer_routine_continuous);
    outp(0x43,0xb6);    /* Set timer to expire 31300/5 times per second */
    outp(0x40,0x7d);    /* Used to run sound-emulation in real-time */
    outp(0x40,0x01);
    }
  else {
    PM_setTimerHandler((PM_intHandler) timer_routine);
    outp(0x43,0xb6);    /* Set timer to expire 50 times per second */
    outp(0x40,0x37);
    outp(0x40,0x5d);
    }
  lastcc = frames*71364+ypos*228+xpos;
}

void stop_timerirq(void) {
  outp(0x43,0xb6);      /* Set slowest timer rate */
  outp(0x40,0xff);
  outp(0x40,0xff);
  PM_restoreTimerHandler();
}

void set_VGAcolor(UBY col,UBY b,UBY g,UBY r) {
  outp(0x3c8,col);
  outp(0x3c9,r);
  outp(0x3c9,g);
  outp(0x3c9,b);
  graph256_palete[col][0] = r;
  graph256_palete[col][1] = g;
  graph256_palete[col][2] = b;
};


int BMPnr = 0;
int BMPdumpflag = 0;

void BMPmakeHeader(FILE *F, ULO resxa, ULO resya, ULO want256 ) {
  unsigned int t;

  fprintf(F,"BM");

  t = 0x36 + resxa * resya + want256 * 0x400; /* Length of the file */
  fwrite (&t,4,1,F);
  t = 0;               /* Reserved */
  fwrite (&t,4,1,F);
  t = 0x36 + want256 * 0x400;
  fwrite (&t,4,1,F);   /* Offset to bitmap */
  t = 0x28;
  fwrite (&t,4,1,F);   /* Length of this header */
  t = resxa;
  fwrite (&t,4,1,F);   /* Width */
  t = resya;
  fwrite (&t,4,1,F);   /* height */
  t = 1;
  fwrite (&t,2,1,F);   /* planes */
  t = ( want256 ) ? 8 : 24;
  fwrite (&t,2,1,F);   /* bits */
  t = 0;
  fwrite (&t,4,1,F);   /* Compression */
  fwrite (&t,4,1,F);   /* Size */
  t = 0x120b;
  fwrite (&t,4,1,F);   /* XPels */
  fwrite (&t,4,1,F);   /* YPels */
  t = 0;
  fwrite (&t,4,1,F);   /* ColUsed */
  fwrite (&t,4,1,F);   /* Colimportant */
}


void BMPmakeImage(FILE *F, ULO resx, ULO resxa, ULO resy, ULO resya ) {
  unsigned int x, y, red, blue, green;
  UWO *b;
  ULO tmp;
  ULO linelength = resx + ( scanlineadd >> 1 );

  b = framebuffer + ( bufferoffsets[ showbuffer ] / 2 );
  b += ( resx > resxa ) ? ( resx - resxa ) / 2 : 0;
  b += ( resy > resya ) ? ( resy - resya - 1 ) * linelength / 2 : 0;
  b += resya * linelength;

  for( y = 0 ; y < resya; y++ ) {
    for( x = 0; x < resxa; x++ ) {
      tmp = *( b + x );
      blue = ( tmp & 0x1f ) << 3;
      green = ( tmp & 0x3e0 ) >> 2;
      red = ( tmp & 0x7c00 ) >> 7;
      fputc( blue, F );
      fputc( green, F );
      fputc( red, F );
    }
    b -= linelength;
  }
}


void BMPmakeImage256(FILE *F, ULO resx, ULO resxa, ULO resy, ULO resya ) {
  unsigned int x, y, red, blue, green;
  UBY *b;
  ULO tmp;
  ULO linelength = resx + ( scanlineadd >> 1 );

  b = (UBY *)( framebuffer + bufferoffsets[ showbuffer ] );
  b += ( resx > resxa ) ? ( resx - resxa ) / 2 : 0;
  b += ( resy > resya ) ? ( resy - resya - 1 ) * linelength / 2 : 0;
  b += resya * linelength;

  for( y = 0 ; y < resya; y++ ) {
    for( x = 0; x < resxa; x++ ) fputc( *( b + x ), F );
    b -= linelength;
  }
}


void BMPmakePalete( FILE *F ) {
  int i;

  for( i = 0; i < 0x100; i++ ) {
    fputc( graph256_palete[i][2] << 2, F );
    fputc( graph256_palete[i][1] << 2, F );
    fputc( graph256_palete[i][0] << 2, F );
    fputc( 0, F );
  }
};

void BMPImageDump(void) {
  FILE *F;
  char imnam[80];
  ULO want256 = (config_graphics_mode == 6) ? 1 : 0;
  ULO resx = config_graphics_moderesx[config_graphics_mode];
  ULO resxa= (resx == 800) ? 752 : resx;
  ULO resy = config_graphics_moderesy[config_graphics_mode];
  ULO resya= (resy == 300 || resy == 350 || resy == 400 || resy == 480) ? 287
             : (resy == 600) ? 574 : resy;

  sprintf(imnam,"img%d.bmp",BMPnr++);
  if( ( F = fopen( imnam, "wb" ) ) != NULL ) {
    BMPmakeHeader( F, resxa, resya, want256 );
    if( want256 ) {
      BMPmakePalete( F );
      BMPmakeImage256( F, resx, resxa, resy, resya );
    } else
      BMPmakeImage( F, resx, resxa, resy, resya );
    fclose(F);
  }
  BMPdumpflag = 0;
}


// oldmode stores the screenmode present when the emulator was started
// screenclose() returns the screen to this mode
// -------------------------------------------------------------------

ULO oldmode;

// Variables and function provided for the VESA code
// -------------------------------------------------

uint             VESABuf_len = 1024;    /* Length of the VESABuf buffer         */
uint             VESABuf_sel = 0;    /* Selector for VESABuf                         */
uint             VESABuf_off;    /* Offset for VESABuf                           */
uint             VESABuf_rseg;   /* Real mode segment of VESABuf         */
uint             VESABuf_roff;   /* Real mode offset of VESABuf          */

// ===================================================
// Some routines grabbed from some VBE library I found
// The Scitech SDK
// ===================================================

static void ExitVBEBuf(void)
{ PM_freeRealSeg(VESABuf_sel,VESABuf_off); }

/****************************************************************************
*
* Function:             VBE_initRMBuf
*
* Description:  Initialises the VBE transfer buffer in real mode memory.
*                               This routine is called by the VESAVBE module every time
*                               it needs to use the transfer buffer, so we simply allocate
*                               it once and then return.
*
****************************************************************************/
void _PUBAPI VBE_initRMBuf(void)
{
	if (!VESABuf_sel) {
		/* Allocate a global buffer for communicating with the VESA VBE */
		if (!PM_allocRealSeg(VESABuf_len, &VESABuf_sel, &VESABuf_off,
				&VESABuf_rseg, &VESABuf_roff))
			exit(1);
		atexit(ExitVBEBuf);
		}
}



void plot_char_speedbuffer(UBY character, ULO x,UWO fgcolor, UWO bgcolor) {
        int i,j;

        for (i = 0; i < 5; i++) 
                for (j = 0; j < 4; j++) {
                        if (speedfont[character][i][j] == 1) 
                                speedbuffer[i][x*4+j] = fgcolor; 
                        else                    /* Clear point */
                                speedbuffer[i][x*4+j] = bgcolor; 
                        }
}

void plot_text_speedbuffer(char *text, UWO fgcolor, UWO bgcolor) {
  int i,c,fg;
  static ULO blue=0x1f,red=0x1f,green=0x1f;
  static ULO bluedir=0,reddir=0,greendir=0;
  static count = 0;

  count++;
  if ((count % 2) == 0) {
    switch (bluedir) {
      case 0:  blue--;
               if (blue == 0x10) bluedir++;
               break;
      case 1:  blue++;
               if (blue == 0x1f) bluedir--;
               break;
               }
     }
  if ((count % 4) == 0) {
    switch (reddir) {
      case 0:  red--;
               if (red == 0x10) reddir++;
               break;
      case 1:  red++;
               if (red == 0x1f) reddir--;
               break;
               }
     }

  if ((count % 8) == 0) {
    switch (greendir) {
      case 0:  green--;
               if (green == 0x10) greendir++;
               break;
      case 1:  green++;
               if (green == 0x1f) greendir--;
               break;
               }
     }

  fg = blue | (green<<5) | (red<<10);

  for (i = 0; i< 4; i++) {
   c = *text++;
   switch (c) {
     case '0': plot_char_speedbuffer(9,i,fg,bgcolor);
               break;
     case '1': plot_char_speedbuffer(0,i,fg,bgcolor);
               break;
     case '2': plot_char_speedbuffer(1,i,fg,bgcolor);
               break;
     case '3': plot_char_speedbuffer(2,i,fg,bgcolor);
               break;
     case '4': plot_char_speedbuffer(3,i,fg,bgcolor);
               break;
     case '5': plot_char_speedbuffer(4,i,fg,bgcolor);
               break;
     case '6': plot_char_speedbuffer(5,i,fg,bgcolor);
               break;
     case '7': plot_char_speedbuffer(6,i,fg,bgcolor);
               break;
     case '8': plot_char_speedbuffer(7,i,fg,bgcolor);
               break;
     case '9': plot_char_speedbuffer(8,i,fg,bgcolor);
               break;
     case '%': plot_char_speedbuffer(10,i,fg,bgcolor);
               break;
     case ' ': plot_char_speedbuffer(11,i,fg,bgcolor);
               break;
     }
   }
}



ULO newbytes,newpixels,newmaxscans;
int dispx,dispy;

void clear_framebuffer(void) {
  ULO *pt;
  int n;

  pt = (ULO *) framebuffer;
  if (config_graphics_mode == 6) for (n = 0; n < 16384; n++) *pt++ = 0;
  else {
    if (config_graphics_mode == 0) n = (configdoublebuffer+1)*(newpixels*300)*2;
    else if (config_graphics_mode == 1) n = (configdoublebuffer+1)*(newpixels*200)*2;
    else n = (configdoublebuffer+1)*(newpixels*240)*2;

    n = n/4;

    while (n-- > 0) *pt++ = 0;
    }
}


void set_mode800600() {
  VBE_modeInfo mymodeinfo;
  int mode;

  if (config_graphics_modebits[0] == 15) mode = 0x113;
  else mode = 0x114;

  VBE_getModeInfo(mode,&mymodeinfo);

  if (mymodeinfo.ModeAttributes & vbeMdAvailable) {
      if ((mymodeinfo.ModeAttributes & vbeMdLinear)) {
          VBE_setVideoMode(mode | 0x4000);
          if (!framebuffermapped) {
              framebufferunmodified = (UWO *) VBE_getLinearPointer(&mymodeinfo);
              framebuffermapped = 1;
              }
          VBE_getDisplayStart(&dispx,&dispy);
          framebuffer = framebufferunmodified;
          /*if (dispx > 0) framebuffer += dispx;
          if (dispy > 0) framebuffer += (dispy*800);*/
          scanlineadd = 0;
          VBE_getScanLineLength(&newbytes,&newpixels,&newmaxscans);
          scanlinelength = newbytes;
          if (!config_graphics_flickerfree) {
            if (newmaxscans >= 900) configdoublebuffer = 2;
            else if (newmaxscans >= 600) configdoublebuffer = 1;
            else configdoublebuffer = 0;
          }
          else configdoublebuffer = 0;
            
          if (newpixels > 800) scanlineadd = (newpixels-800)*2;

          if (config_graphics_flickerfree) scanlineadd = scanlineadd*2 + 1600;

          startoffset = 8*1600 + 8*scanlineadd + 32;
          bufferoffsets[0] = 0;
          bufferoffsets[1] = (300*1600) + (300*scanlineadd);
          bufferoffsets[2] = (600*1600) + (600*scanlineadd);

          VBE_setDisplayStart(0,0,0);
          }
      }
}

void set_mode640350() {
  VBE_modeInfo mymodeinfo;
  int mode;

  if (config_graphics_modebits[0] == 15) mode = 0x11d;
  else mode = 0x11f;

  VBE_getModeInfo(mode,&mymodeinfo);

  if (mymodeinfo.ModeAttributes & vbeMdAvailable) {
      if ((mymodeinfo.ModeAttributes & vbeMdLinear)) {
          VBE_setVideoMode(mode | 0x4000);
          if (!framebuffermapped) {
              framebufferunmodified = (UWO *) VBE_getLinearPointer(&mymodeinfo);
              framebuffermapped = 1;
              }
          VBE_getDisplayStart(&dispx,&dispy);
          framebuffer = framebufferunmodified;
          /*if (dispx > 0) framebuffer += dispx;
          if (dispy > 0) framebuffer += (dispy*800);*/
          scanlineadd = 0;
          VBE_getScanLineLength(&newbytes,&newpixels,&newmaxscans);
          if (newmaxscans >= 1050) configdoublebuffer = 2;
          else if (newmaxscans >= 700) configdoublebuffer = 1;
          else configdoublebuffer = 0;
          if (newpixels > 640) scanlineadd = (newpixels-640)*2;
          startoffset = 31*1280 + 31*scanlineadd;
          bufferoffsets[0] = 0;
          bufferoffsets[1] = (350*1280) + (350*scanlineadd);
          bufferoffsets[2] = (700*1280) + (700*scanlineadd);

          VBE_setDisplayStart(0,0,0);
          }
      }
}

void set_mode640400() {
  VBE_modeInfo mymodeinfo;
  int mode;

  if (config_graphics_modebits[0] == 15) mode = 0x11e;
  else mode = 0x120;

  VBE_getModeInfo(mode,&mymodeinfo);

  if (mymodeinfo.ModeAttributes & vbeMdAvailable) {
      if ((mymodeinfo.ModeAttributes & vbeMdLinear)) {
          VBE_setVideoMode(mode | 0x4000);
          if (!framebuffermapped) {
              framebufferunmodified = (UWO *) VBE_getLinearPointer(&mymodeinfo);
              framebuffermapped = 1;
              }
          VBE_getDisplayStart(&dispx,&dispy);
          framebuffer = framebufferunmodified;
          /*if (dispx > 0) framebuffer += dispx;
          if (dispy > 0) framebuffer += (dispy*800);*/
          scanlineadd = 0;
          VBE_getScanLineLength(&newbytes,&newpixels,&newmaxscans);
          if (newmaxscans >= 1200) configdoublebuffer = 2;
          else if (newmaxscans >= 800) configdoublebuffer = 1;
          else configdoublebuffer = 0;
          if (newpixels > 640) scanlineadd = (newpixels-640)*2;
          startoffset = 56*1280 + 56*scanlineadd;
          bufferoffsets[0] = 0;
          bufferoffsets[1] = (400*1280) + (400*scanlineadd);
          bufferoffsets[2] = (800*1280) + (800*scanlineadd);

          VBE_setDisplayStart(0,0,0);
          }
      }
}

void set_mode640480() {
  VBE_modeInfo mymodeinfo;
  int mode;

  if (config_graphics_modebits[0] == 15) mode = 0x110;
  else mode = 0x111;

  VBE_getModeInfo(mode,&mymodeinfo);

  if (mymodeinfo.ModeAttributes & vbeMdAvailable) {
      if ((mymodeinfo.ModeAttributes & vbeMdLinear)) {
          VBE_setVideoMode(mode | 0x4000);
          if (!framebuffermapped) {
              framebufferunmodified = (UWO *) VBE_getLinearPointer(&mymodeinfo);
              framebuffermapped = 1;
              }
          VBE_getDisplayStart(&dispx,&dispy);
          framebuffer = framebufferunmodified;
          /*if (dispx > 0) framebuffer += dispx;
          if (dispy > 0) framebuffer += (dispy*800);*/
          scanlineadd = 0;
          VBE_getScanLineLength(&newbytes,&newpixels,&newmaxscans);
          if (newmaxscans >= 1440) configdoublebuffer = 2;
          else if (newmaxscans >= 960) configdoublebuffer = 1;
          else configdoublebuffer = 0;
          if (newpixels > 640) scanlineadd = (newpixels-640)*2;
          startoffset = 96*1280 + 96*scanlineadd;
          bufferoffsets[0] = 0;
          bufferoffsets[1] = (480*1280) + (480*scanlineadd);
          bufferoffsets[2] = (960*1280) + (960*scanlineadd);

          VBE_setDisplayStart(0,0,0);
          }
      }
}

void set_mode320200(void) {
  VBE_modeInfo mymodeinfo;
  int mode;

  if (config_graphics_modebits[1] == 15) mode = 0x10d;
  else mode = 0x10e;

  VBE_getModeInfo(mode,&mymodeinfo);

  if (mymodeinfo.ModeAttributes & vbeMdAvailable) {
      /* Here mode is available */

      if ((mymodeinfo.ModeAttributes & vbeMdLinear)) {
          /* Linear mode available */  
          if (!(VBE_setVideoMode(mode | 0x4000))) {
              /* Set mode failed */
              return;
              }
          else {
              if (!framebuffermapped) {
                  framebufferunmodified = (UWO *) VBE_getLinearPointer(&mymodeinfo);
                  framebuffermapped = 1;
                  }
              VBE_getDisplayStart(&dispx,&dispy);
              framebuffer = framebufferunmodified;
              /*if (dispx > 0) {
                   framebuffer += dispx;
                   }
              if (dispy > 0) {
                   framebuffer += (dispy*320);
                   }  */
              scanlineadd = 0;
              if (VBE_getScanLineLength(&newbytes,&newpixels,&newmaxscans)) {
                   if (newpixels > 320) {
                        scanlineadd = (newpixels-320)*2;
                        }
                    }
               if (newmaxscans >= 600) configdoublebuffer = 2;
               else if (newmaxscans >= 400) configdoublebuffer = 1;
               else configdoublebuffer = 0;

               startoffset = 0;
               bufferoffsets[0] = 0;
               bufferoffsets[1] = (200*640) + (200*scanlineadd);
               bufferoffsets[2] = (400*640) + (400*scanlineadd);
               VBE_setDisplayStart(0,0,0);
               }
          }
      }
  return;
}


void set_mode320200oldvga(void) {
  int mode;

  mode = 0x13;

  if (!(VBE_setVideoMode(mode))) {
    /* Set mode failed */
    addlog("Failed to set mode 0x13\n");
    printf("Failed to set mode 0x13\n");
    exit(1);
    }
  framebuffer = (UWO *) 0xa0000;
  scanlineadd = 0;
  configdoublebuffer = 0;
  startoffset = 0;
  bufferoffsets[0] = 0;
  return;
}


void set_mode320240(void) {
  VBE_modeInfo mymodeinfo;
  int mode;

  if (config_graphics_modebits[2] == 15) mode = 0x12e;
  else mode = 0x136;

  VBE_getModeInfo(mode,&mymodeinfo);

  if (mymodeinfo.ModeAttributes & vbeMdAvailable) {
      /* Here mode is available */

      if ((mymodeinfo.ModeAttributes & vbeMdLinear)) {
          /* Linear mode available */  
          if (!(VBE_setVideoMode(mode | 0x4000))) {
              /* Set mode failed */
              return;
              }
          else {
              if (!framebuffermapped) {
                  framebufferunmodified = (UWO *) VBE_getLinearPointer(&mymodeinfo);
                  framebuffermapped = 1;
                  }
              VBE_getDisplayStart(&dispx,&dispy);
              framebuffer = framebufferunmodified;
/*              if (dispx > 0) {
                   framebuffer += dispx;
                   }               
                if (dispy > 0) {
                   framebuffer += (dispy*320);
                   } */
              scanlineadd = 0;
              if (VBE_getScanLineLength(&newbytes,&newpixels,&newmaxscans)) {
                   if (newpixels > 320) {
                        scanlineadd = (newpixels-320)*2;
                        }
                    }
               if (newmaxscans >= 720) configdoublebuffer = 2;
               else if (newmaxscans >= 480) configdoublebuffer = 1;
               else configdoublebuffer = 0;
               startoffset = 0;
               bufferoffsets[0] = 0;
               bufferoffsets[1] = (240*640) + (240*scanlineadd);
               bufferoffsets[2] = (480*640) + (480*scanlineadd);
               VBE_setDisplayStart(0,0,0);
               }
          }
      }
  return;
}


ULO find_mode_nr(ULO mode, VBE_vgaInfo *vi) {
  VBE_modeInfo mymodeinfo;
  char o[80];
  UWO *i;
  int found;

  sprintf(o,"Searching for mode %X\n",mode);
  addlog(o);

  found = 0;
  i = vi->VideoModePtr;

  while (*i != 0xffff) {
    if (*i == mode) found = 1;
    i++;
    }

  if (found) {
        VBE_getModeInfo(mode,&mymodeinfo);

        if (mymodeinfo.ModeAttributes & vbeMdAvailable) {
                addlog("Mode available\n");
                /* Here mode is available */
                if ((mymodeinfo.ModeAttributes & vbeMdLinear)) {
                        /* Linear mode available */  
                        addlog("Mode is capable of linear framebuffer\n");
                        return 1;
                        }
                else addlog("Mode not useable, missing linear framebuffer\n");
                }
        }
  else addlog("The mode was not found\n");
  return 0;
}


void find_modes(VBE_vgaInfo *vi) {
  ULO i;

  for (i = 0; i < NROFMODES; i++) config_graphics_modeavailable[i] = config_graphics_modebits[i] = 0;

  addlog("Searching for VESA mode 0x113 or 0x114, 800x600 15/16 bit color\n");
  if (find_mode_nr(0x113,vi)) {
    config_graphics_modeavailable[0] = 1;
    config_graphics_modebits[0] = 15;
    addlog("800x600x15 found and enabled\n");
    }
  else if (find_mode_nr(0x114,vi)) {
    config_graphics_modeavailable[0] = 1;
    config_graphics_modebits[0] = 16;
    addlog("800x600x16 found and enabled\n");
    }

  addlog("Searching for VESA mode 0x10d or 0x10e, 320x200 15/16 bit color\n");
  if (find_mode_nr(0x10d,vi)) {
    config_graphics_modeavailable[1] = 1;
    config_graphics_modebits[1] = 15;
    addlog("320x240x15 found and enabled\n");
    }
  else if (find_mode_nr(0x10e,vi)) {
    config_graphics_modeavailable[1] = 1;
    config_graphics_modebits[1] = 16;
    addlog("320x200x16 found and enabled\n");
    }

  addlog("Searching for VESA mode 0x12e or 0x136, 320x240 15/16 bit color\n");
  if (find_mode_nr(0x12e,vi)) {
    config_graphics_modeavailable[2] = 1;
    config_graphics_modebits[2] = 15;
    addlog("320x240x15 found and enabled\n");
    }
  else if (find_mode_nr(0x136,vi)) {
    config_graphics_modeavailable[2] = 1;
    config_graphics_modebits[2] = 16;
    addlog("320x240x16 found and enabled\n");
    }

  addlog("Searching for VESA mode 0x110 or 0x111, 640x480 15/16 bit color\n");
  if (find_mode_nr(0x110,vi)) {
    config_graphics_modeavailable[3] = 1;
    config_graphics_modebits[3] = 15;
    addlog("640x480x15 found and enabled\n");
    }
  else if (find_mode_nr(0x111,vi)) {
    config_graphics_modeavailable[3] = 1;
    config_graphics_modebits[3] = 16;
    addlog("640x480x16 found and enabled\n");
    }

  addlog("Searching for VESA mode 0x11e or 0x120, 640x400 15/16 bit color\n");
  if (find_mode_nr(0x11e,vi)) {
    config_graphics_modeavailable[4] = 1;
    config_graphics_modebits[4] = 15;
    addlog("640x400x15 found and enabled\n");
    }
  else if (find_mode_nr(0x120,vi)) {
    config_graphics_modeavailable[4] = 1;
    config_graphics_modebits[4] = 16;
    addlog("640x400x16 found and enabled\n");
    }
  addlog("Searching for VESA mode 0x11d or 0x11f, 640x350 15/16 bit color\n");
  if (find_mode_nr(0x11d,vi)) {
    config_graphics_modeavailable[5] = 1;
    config_graphics_modebits[5] = 15;
    addlog("640x350x15 found and enabled\n");
    }
  else if (find_mode_nr(0x11f,vi)) {
    config_graphics_modeavailable[5] = 1;
    config_graphics_modebits[5] = 16;
    addlog("640x350x16 found and enabled\n");
    }

}


/*===============================================================*/
/* screeninit								     */
/* checks for VESA 2.0, records the current screenmode and sets  */
/* Returns TRUE if intialization was successful, FALSE otherwise */
/*===============================================================*/

ULO screeninit(void) {
	VBE_vgaInfo myinfo;
	ULO version;
        ULO i;
        char o[80];

	/* Find VESA 2.0 driver */

	version = VBE_detect(&myinfo);
        sprintf(o,"VESA version %d.%d found.\n",(version&0xff00)>>8,version&0xff);
        addlog(o);
        if( !( version & 0xff00 ) ) addlog("No VESA found.\n");

	/* Find and select usable video-modes */

        if( version & 0xff00 ) find_modes(&myinfo);

        config_graphics_modeavailable[6] = 1;
        config_graphics_modebits[6] = 8;
        addlog("320x200x8 (mode 0x13) enabled, always available\n");

        if( !config_graphics_modeavailable[config_graphics_mode] ) {
          i = 0;
          while( i < NROFMODES && !config_graphics_modeavailable[i] ) i++;
          config_graphics_mode = i - 1;
        };


	/* Record old mode */

	oldmode = VBE_getVideoMode();

	BMPdumpflag = 0;
	return 1;
}

// ULO screenclose(void)
// Restores old videomode and frees memory used by VBE library
// Returns TRUE when successful, FALSE otherwise
// ===========================================================

ULO screenclose(void)
{
  ULO returnvalue = 1;
  // Restore screen to old videomode

  if (!VBE_setVideoMode(oldmode)) {
    addlog("Failed to restore old video mode\n");
    returnvalue = 0;
    }
  
  // Free some memory

  VBE_freePMCode();
  return returnvalue;
}

