/* Chip.c       */
/* Fellow       */
/* Petter Schau */

#include "defs.h"
#include "fellow.h"
#include "inout.h"
#include "68000.h"
#include "memory.h"
#include "graphem.h"

extern void drawddfline(void);
extern void drawddfline320200w(void);
extern void drawbgline(void);
extern void drawbgline320200w(void);

extern void decodelo0(void);
extern void decodelo1(void);
extern void decodelo2(void);
extern void decodelo3(void);
extern void decodelo4(void);
extern void decodelo5(void);
extern void decodelo6(void);


extern ULO oddscroll,evenscroll;


extern void blittergeneral(void);
extern void blitter_00(void);
extern void blitter_01(void);
extern void blitter_02(void);
extern void blitter_03(void);
extern void blitter_04(void);
extern void blitter_05(void);
extern void blitter_06(void);
extern void blitter_07(void);
extern void blitter_08(void);
extern void blitter_09(void);
extern void blitter_0a(void);
extern void blitter_0b(void);
extern void blitter_0c(void);
extern void blitter_0d(void);
extern void blitter_0e(void);
extern void blitter_0f(void);
extern void blitter_2a(void);
extern void blitter_4a(void);
extern void blitter_ca(void);
extern void blitter_d8(void);
extern void blitter_ea(void);
extern void blitter_f0(void);
extern void blitter_fa(void);
extern void blitter_fc(void);
extern void blitter_ff(void);


/* Line drawn until this cycle */

ULO drawpartialcycle = 44;
ULO drawpartialpixels = 0;

/* Clip positions for lores host screens */

ULO clipleftx = 120;
ULO cliprightx = 440;
ULO cliptop = 0x45;
ULO clipbot = 0x10d;

draw_routine_ptr drawptr;
draw_routine_ptr drawbgroutine;
draw_routine_ptr drawddfroutine;
draw_routine_ptr drawloresroutine,drawhiresroutine,drawdualloresroutine,
                 drawdualhiresroutine,drawhamroutine;


ULO frames;

ULO nxtcopaccess;

extern ULO readroutine;
extern ULO drawprepareroutine;

/* bpdmatab1 er en jump tabell til dekodingsrutiner basert p� de 4 �verste
   bits av BPLCON0 */

UBY lineflagstimes[314];

/* shadcol er 32K utgaver av farge-registrene, ligger lagret dobbelt for
   at det enkelt skal g� � plotte lores i full bredde
   Oppdateres hver gang det skrives til et farge-register  */

extern ULO shadcol[64];

/*  Used in translation of sprites 
    syntax: spritetranslate[0 - behind, 1 - front][bitplanedata][spritedata]
*/

UBY spritetranslate[2][256][256];

/* Used in translation of dual playfield
   syntax: dualtranslate[0 - PF1 behind, 1 - PF2 behind][PF1data][PF2data]
*/

UBY dualtranslate[2][256][256];

/* Used to select the minterm routines */

ULO blittertable[256] = {
// 0
   (ULO) blitter_00,
   (ULO) blitter_01,
   (ULO) blitter_02,
   (ULO) blitter_03,
   (ULO) blitter_04,
   (ULO) blitter_05,
   (ULO) blitter_06,
   (ULO) blitter_07,
   (ULO) blitter_08,
   (ULO) blitter_09,
   (ULO) blitter_0a,
   (ULO) blitter_0b,
   (ULO) blitter_0c,
   (ULO) blitter_0d,
   (ULO) blitter_0e,
   (ULO) blitter_0f,
// 0x10
   (ULO) blittergeneral,
   (ULO) blittergeneral,
   (ULO) blittergeneral,
   (ULO) blittergeneral,
   (ULO) blittergeneral,
   (ULO) blittergeneral,
   (ULO) blittergeneral,
   (ULO) blittergeneral,
   (ULO) blittergeneral,
   (ULO) blittergeneral,
   (ULO) blittergeneral,
   (ULO) blittergeneral,
   (ULO) blittergeneral,
   (ULO) blittergeneral,
   (ULO) blittergeneral,
   (ULO) blittergeneral,
// 0x20
   (ULO) blittergeneral,
   (ULO) blittergeneral,
   (ULO) blittergeneral,
   (ULO) blittergeneral,
   (ULO) blittergeneral,
   (ULO) blittergeneral,
   (ULO) blittergeneral,
   (ULO) blittergeneral,
   (ULO) blittergeneral,
   (ULO) blittergeneral,

   (ULO) blitter_2a,

   (ULO) blittergeneral,
   (ULO) blittergeneral,
   (ULO) blittergeneral,
   (ULO) blittergeneral,
   (ULO) blittergeneral,
// 0x30
   (ULO) blittergeneral,
   (ULO) blittergeneral,
   (ULO) blittergeneral,
   (ULO) blittergeneral,
   (ULO) blittergeneral,
   (ULO) blittergeneral,
   (ULO) blittergeneral,
   (ULO) blittergeneral,
   (ULO) blittergeneral,
   (ULO) blittergeneral,
   (ULO) blittergeneral,
   (ULO) blittergeneral,
   (ULO) blittergeneral,
   (ULO) blittergeneral,
   (ULO) blittergeneral,
   (ULO) blittergeneral,
// 0x40
   (ULO) blittergeneral,
   (ULO) blittergeneral,
   (ULO) blittergeneral,
   (ULO) blittergeneral,
   (ULO) blittergeneral,
   (ULO) blittergeneral,
   (ULO) blittergeneral,
   (ULO) blittergeneral,
   (ULO) blittergeneral,
   (ULO) blittergeneral,
   (ULO) blitter_4a,
   (ULO) blittergeneral,
   (ULO) blittergeneral,
   (ULO) blittergeneral,
   (ULO) blittergeneral,
   (ULO) blittergeneral,
// 0x50
   (ULO) blittergeneral,
   (ULO) blittergeneral,
   (ULO) blittergeneral,
   (ULO) blittergeneral,
   (ULO) blittergeneral,
   (ULO) blittergeneral,
   (ULO) blittergeneral,
   (ULO) blittergeneral,
   (ULO) blittergeneral,
   (ULO) blittergeneral,
   (ULO) blittergeneral,
   (ULO) blittergeneral,
   (ULO) blittergeneral,
   (ULO) blittergeneral,
   (ULO) blittergeneral,
   (ULO) blittergeneral,
// 0x60
   (ULO) blittergeneral,
   (ULO) blittergeneral,
   (ULO) blittergeneral,
   (ULO) blittergeneral,
   (ULO) blittergeneral,
   (ULO) blittergeneral,
   (ULO) blittergeneral,
   (ULO) blittergeneral,
   (ULO) blittergeneral,
   (ULO) blittergeneral,
   (ULO) blittergeneral,
   (ULO) blittergeneral,
   (ULO) blittergeneral,
   (ULO) blittergeneral,
   (ULO) blittergeneral,
   (ULO) blittergeneral,
// 0x70
   (ULO) blittergeneral,
   (ULO) blittergeneral,
   (ULO) blittergeneral,
   (ULO) blittergeneral,
   (ULO) blittergeneral,
   (ULO) blittergeneral,
   (ULO) blittergeneral,
   (ULO) blittergeneral,
   (ULO) blittergeneral,
   (ULO) blittergeneral,
   (ULO) blittergeneral,
   (ULO) blittergeneral,
   (ULO) blittergeneral,
   (ULO) blittergeneral,
   (ULO) blittergeneral,
   (ULO) blittergeneral,
// 0x80
   (ULO) blittergeneral,
   (ULO) blittergeneral,
   (ULO) blittergeneral,
   (ULO) blittergeneral,
   (ULO) blittergeneral,
   (ULO) blittergeneral,
   (ULO) blittergeneral,
   (ULO) blittergeneral,
   (ULO) blittergeneral,
   (ULO) blittergeneral,
   (ULO) blittergeneral,
   (ULO) blittergeneral,
   (ULO) blittergeneral,
   (ULO) blittergeneral,
   (ULO) blittergeneral,
   (ULO) blittergeneral,
// 0x90
   (ULO) blittergeneral,
   (ULO) blittergeneral,
   (ULO) blittergeneral,
   (ULO) blittergeneral,
   (ULO) blittergeneral,
   (ULO) blittergeneral,
   (ULO) blittergeneral,
   (ULO) blittergeneral,
   (ULO) blittergeneral,
   (ULO) blittergeneral,
   (ULO) blittergeneral,
   (ULO) blittergeneral,
   (ULO) blittergeneral,
   (ULO) blittergeneral,
   (ULO) blittergeneral,
   (ULO) blittergeneral,
// 0xa0
   (ULO) blittergeneral,
   (ULO) blittergeneral,
   (ULO) blittergeneral,
   (ULO) blittergeneral,
   (ULO) blittergeneral,
   (ULO) blittergeneral,
   (ULO) blittergeneral,
   (ULO) blittergeneral,
   (ULO) blittergeneral,
   (ULO) blittergeneral,
   (ULO) blittergeneral,
   (ULO) blittergeneral,
   (ULO) blittergeneral,
   (ULO) blittergeneral,
   (ULO) blittergeneral,
   (ULO) blittergeneral,
// 0xb0
   (ULO) blittergeneral,
   (ULO) blittergeneral,
   (ULO) blittergeneral,
   (ULO) blittergeneral,
   (ULO) blittergeneral,
   (ULO) blittergeneral,
   (ULO) blittergeneral,
   (ULO) blittergeneral,
   (ULO) blittergeneral,
   (ULO) blittergeneral,
   (ULO) blittergeneral,
   (ULO) blittergeneral,
   (ULO) blittergeneral,
   (ULO) blittergeneral,
   (ULO) blittergeneral,
   (ULO) blittergeneral,
// 0xc0
   (ULO) blittergeneral,
   (ULO) blittergeneral,
   (ULO) blittergeneral,
   (ULO) blittergeneral,
   (ULO) blittergeneral,
   (ULO) blittergeneral,
   (ULO) blittergeneral,
   (ULO) blittergeneral,
   (ULO) blittergeneral,
   (ULO) blittergeneral,
   (ULO) blitter_ca,
   (ULO) blittergeneral,
   (ULO) blittergeneral,
   (ULO) blittergeneral,
   (ULO) blittergeneral,
   (ULO) blittergeneral,
// 0xd0
   (ULO) blittergeneral,
   (ULO) blittergeneral,
   (ULO) blittergeneral,
   (ULO) blittergeneral,
   (ULO) blittergeneral,
   (ULO) blittergeneral,
   (ULO) blittergeneral,
   (ULO) blittergeneral,
   (ULO) blitter_d8,
   (ULO) blittergeneral,
   (ULO) blittergeneral,
   (ULO) blittergeneral,
   (ULO) blittergeneral,
   (ULO) blittergeneral,
   (ULO) blittergeneral,
   (ULO) blittergeneral,
// 0xe0
   (ULO) blittergeneral,
   (ULO) blittergeneral,
   (ULO) blittergeneral,
   (ULO) blittergeneral,
   (ULO) blittergeneral,
   (ULO) blittergeneral,
   (ULO) blittergeneral,
   (ULO) blittergeneral,
   (ULO) blittergeneral,
   (ULO) blittergeneral,
   (ULO) blitter_ea,
   (ULO) blittergeneral,
   (ULO) blittergeneral,
   (ULO) blittergeneral,
   (ULO) blittergeneral,
   (ULO) blittergeneral,
// 0xf0
   (ULO) blitter_f0,
   (ULO) blittergeneral,
   (ULO) blittergeneral,
   (ULO) blittergeneral,
   (ULO) blittergeneral,
   (ULO) blittergeneral,
   (ULO) blittergeneral,
   (ULO) blittergeneral,
   (ULO) blittergeneral,
   (ULO) blittergeneral,
   (ULO) blitter_fa,
   (ULO) blittergeneral,
   (ULO) blitter_fc,
   (ULO) blittergeneral,
   (ULO) blittergeneral,
   (ULO) blitter_ff};

UWO fillincfc0[65536];
UWO fillincfc1[65536];

UBY fillincfc0after[65536];
UBY fillincfc1after[65536];

UWO fillexcfc0[65536];
UWO fillexcfc1[65536];

UBY fillexcfc0after[65536];
UBY fillexcfc1after[65536];




ULO teller;
ULO delay;

ULO curcopptr;

ULO showbuffer = 0,drawbuffer = 1;



UBY curcol[18];


ULO playfieldon;


UBY sprite[8][16];
ULO spritesonline;
ULO spriteonline[8];
ULO spriteddfkill;

void init_spritetranslation_table(void) {
    int i,j,k,l;

    for (k = 0; k < 2; k++) {
        for (i = 0; i < 256; i++) {
            for (j = 0; j < 256; j++) {
                if (k == 0)
                    l = (i == 0) ? j:i;
                else
                    l = (j == 0) ? i:j;
                spritetranslate[k][i][j] = l;
                }
            }
        }
}

void init_dualtranslation_table(void) {
    int i,j,k,l;

    for (k = 0; k < 2; k++) {
        for (i = 0; i < 256; i++) {
            for (j = 0; j < 256; j++) {
                if (k == 0) {
                    /* PF1 behind, PF2 in front */
                    if (j == 0) {
                        /* PF2 transparent, PF1 visible */
                        l = i;
                    }
                    else {
                        /* PF2 visible */
                        /* If color is higher than 0x3c it is a sprite */
                        if (j < 0x40) l = j+0x20;
                        else l = j;
                    }
                }
                else {
                    /* PF1 in front, PF2 behind */
                    if (i == 0) {
                        /* PF1 transparent, PF2 visible */
                        if (j == 0) l = 0;
                        else {
                            if (j < 0x40) l = j+0x20;
                            else l = j;
                        }
                    }
                    else {
                        /* PF1 visible amd not transparent */
                        l = i;
                    }
                }
                dualtranslate[k][i][j] = l;
                }
            }
        }
}

ULO lace[3][2] = {1,0, 0,1, 1,0};

void set_displaybuffer(void) {
 ULO tmp;
 if (config_graphics_mode == 6 || debugging) return;
 if (config_graphics_maxfps == 2) tmp = 1;
 else tmp = 0;
 switch (config_graphics_mode) {
   case 0:                                       
     switch (showbuffer) {
       case 0:  VBE_setDisplayStart(0,0,tmp);
                break;
       case 1:  VBE_setDisplayStart(0,300,tmp);
                break;
       case 2:  VBE_setDisplayStart(0,600,tmp);
                break;
       }
       break;
   case 1:
     switch (showbuffer) {
       case 0:  VBE_setDisplayStart(0,0,tmp);
                break;
       case 1:  VBE_setDisplayStart(0,200,tmp);
                break;
       case 2:  VBE_setDisplayStart(0,400,tmp);
                break;
       }
       break;
   case 2:
     switch (showbuffer) {
       case 0:  VBE_setDisplayStart(0,0,tmp);
                break;
       case 1:  VBE_setDisplayStart(0,240,tmp);
                break;
       case 2:  VBE_setDisplayStart(0,480,tmp);
                break;
       }
       break;
   }
}


ULO copperytable[512];

void init_copperytable(void) {
  int i, ex = 16;

#ifdef CYCLE_EXACT
  if (configcycleexact) ex = 0;
#endif
  for (i = 0; i < 512; i++) {
     copperytable[i] = i*228 + ex;
     }
}

/* Initialiserer variable */

void initfilltable(void)
{
  int i,j,k,l;

/* inclusive fill, fc = 0 at start of word */
  for (i = 0; i< 65536; i++) {
    l = 0;
    j = i;
    for (k = 0; k < 16; k++) {
      j |= l<<k;                 /* Set fill for this bit */
/* Check if fill status has changed */
      if ((i & (0x1<<k))) {
        if (l == 1) l = 0; else l = 1;
        }
      }
    fillincfc0[i] = j;
    fillincfc0after[i] = l;
    }

/* inclusive fill, fc = 1 at start of word */
  for (i = 0; i< 65536; i++) {
    l = 1;
    j = i;
    for (k = 0; k < 16; k++) {
      j |= l<<k;                 /* Set fill for this bit */
/* Check if fill status has changed */
      if ((i & (0x1<<k))) {
        if (l == 1) l = 0; else l = 1;
        }
      }
    fillincfc1[i] = j;
    fillincfc1after[i] = l;
    }

/* exclusive fill, fc = 0 at start of word */
  for (i = 0; i< 65536; i++) {
    l = 0;
    j = i;
    for (k = 0; k < 16; k++) {
      j ^= l<<k;                 /* Set fill for this bit */
/* Check if fill status has changed */
      if ((i & (0x1<<k))) {
        if (l == 1) l = 0; else l = 1;
        }
      }
    fillexcfc0[i] = j;
    fillexcfc0after[i] = l;
    }

/* exclusive fill, fc = 1 at start of word */
  for (i = 0; i< 65536; i++) {
    l = 1;
    j = i;
    for (k = 0; k < 16; k++) {
      j ^= l<<k;                 /* Set fill for this bit */
/* Check if fill status has changed */
      if ((i & (0x1<<k))) {
        if (l == 1) l = 0; else l = 1;
        }
      }
    fillexcfc1[i] = j;
    fillexcfc1after[i] = l;
    }
}


void init_lineflagstables(void) {
  ULO i;

  for (i = 0; i < 314; i++) {
    lineflags[i] = 0xffff;
    lineflagstimes[i] = 10;
    }
}



void chipinit(void) {
  initfilltable();
  init_copperytable();
  init_spritetranslation_table();
  init_dualtranslation_table();
  playfieldon = 0;
  spriteddfkill = 32;
}
