/*=======================================*/
/* This is the actual GUI used in Fellow */
/* Petter Schau                          */
/* Patches by Roman Dolejsi 1997         */
/*=======================================*/

#include <stdio.h>
#include "defs.h"
#include "fellow.h"
#include "gui.h"
#include "floppy.h"
#include "chip.h"
#include "memory.h"
#include "sound.h"
#include "graphem.h"
#include "inout.h"
#include "68000.h"
#include "joymouse.h"
#include "cia.h"
#include "fhfile.h"
#include "sblast.h"

#ifdef DEBUGBUILD

#include "eventid.h"

#endif

extern void checkadr(void);

/*=============*/
/* The windows */
/*=============*/

struct gui_window fgui_wrequester, fgui_wfullscreen, fgui_wheader, fgui_wconsole, fgui_wmenu;

/*====================*/
/* The top level menu */
/*====================*/

struct gui_menu fgui_topmenu;

char *fgui_topmenu_entries[7] = {"Run","Debugger",
                                 "Configuration","Soft Reset","Hard Reset",
                                 "Quit",NULL};
                               
UBY fgui_topmenu_shortcuts[6] = {0,0,0,0,0,0};

/*========================*/
/* Configuration sub-menu */
/*========================*/

struct gui_menu fgui_configmenu;

char *fgui_configmenu_entries[] = {"Disk","Screen",
                                   "Memory","Sound",
                                   "Cpu","Hardfile",
                                   "Various",NULL};

UBY fgui_configmenu_shortcuts[7] = {0,0,0,1,0,0,0};

/*===================*/
/* Debugger sub-menu */
/*===================*/

struct gui_numberfield fgui_debugbreak_numberfield;
struct gui_menu fgui_debugmenu;

char *fgui_debugmenu_entries[] = {"Step","Step Over",
                                  "Breakpoint","Memory",
                                  "Cia","IO",
#ifdef DEBUGBUILD
                                  "Trace on","Trace off","Show Trace",
                                  "Evlog Config",
                                  "Show Evlog",
#endif
                                  NULL};

UBY fgui_debugmenu_shortcuts[] = {0,1,0,0,0,0
#ifdef DEBUGBUILD
                                  ,1,2,1,1,2
#endif                                  
};

/*===================*/
/* IO registers menu */
/*===================*/

struct gui_menu fgui_debugiomenu;

char *fgui_debugiomenu_entries[] = {"Floppy","Sound",
                                NULL};

UBY fgui_debugiomenu_shortcuts[] = {0,0};

/*====================*/
/* Breakpoint submenu */
/*====================*/

struct gui_menu fgui_debugbreakmenu;

char *fgui_debugbreakmenu_entries[] = {"Set Breakpnt","To Line 312",
#ifdef DEBUGBUILD
                                  "Until Event",
#endif
                                  NULL};

UBY fgui_debugbreakmenu_shortcuts[] = {0,0
#ifdef DEBUGBUILD
                                  ,0
#endif                                  
};


/*====================*/
/* Floppy option-menu */
/*====================*/

struct gui_optionmenu fgui_floppy_optionmenu;

char *fgui_floppy_topheader = {"Floppy-disk emulation options:"};

char *fgui_floppy_headers[11] = {"Disk-image in DF0 (1):","Disk-image in DF1 (2):",
                               "Disk-image in DF2 (3):","Disk-image in DF3 (4):",
                               "Drive 0 status:",   "Drive 1 status:",
                               "Drive 2 status:",   "Drive 3 status:",
                               "Disk-DMA speed:",   "Alt-N cycling:", NULL};

UBY fgui_floppy_shortcuts[10] = {19,19,19,19,0,1,2,3,9,0};

UBY fgui_floppy_actions[10] = {GUI_FILEREQ_ADF,GUI_FILEREQ_ADF,GUI_FILEREQ_ADF,GUI_FILEREQ_ADF,
                               GUI_VALUELIST,GUI_VALUELIST,GUI_VALUELIST,
                               GUI_VALUELIST,GUI_VALUELIST,GUI_VALUELIST};

const void *fgui_floppy_vars[10] = {config_floppy_name[0],config_floppy_name[1],
                                    config_floppy_name[2],config_floppy_name[3],
                                    &config_floppy_enabled[0],
                                    &config_floppy_enabled[1],
                                    &config_floppy_enabled[2],
                                    &config_floppy_enabled[3],
                                    &config_floppy_fast, &config_altn_loop};

/* Option texts for disk menu */

char *fgui_floppy_enabled_text[3] = {"Enabled ","Disabled",NULL};
char *fgui_floppy_fast_text[3] = {"Original","Fast    ",NULL};
char *fgui_floppy_altn_text[5] = {"1 drive ","2 drives",
                                  "3 drives","4 drives",NULL};

/* Option values for disk menu */

ULO fgui_floppy_enabled_vals[2] = {1,0};
ULO fgui_floppy_fast_vals[2] = {0,1};
ULO fgui_floppy_altn_vals[4] = {0,1,2,3};

char **fgui_floppy_texts[10] = {NULL,NULL,NULL,NULL,fgui_floppy_enabled_text,
                                fgui_floppy_enabled_text,
                                fgui_floppy_enabled_text,
                                fgui_floppy_enabled_text,
                                fgui_floppy_fast_text,fgui_floppy_altn_text};

void *fgui_floppy_vals[10] = {NULL,NULL,NULL,NULL,fgui_floppy_enabled_vals,
                              fgui_floppy_enabled_vals,
                              fgui_floppy_enabled_vals,
                              fgui_floppy_enabled_vals,
                              fgui_floppy_fast_vals,fgui_floppy_altn_vals};


void fgui_floppy_init_optionmenu(void) {
        gui_initoptionmenu(&fgui_floppy_optionmenu,fgui_floppy_topheader,
                           fgui_floppy_headers,fgui_floppy_actions,
                           fgui_floppy_vars,fgui_floppy_texts,
                           fgui_floppy_vals,&fgui_wconsole,fgui_floppy_shortcuts);
}

/*====================*/
/* Screen option-menu */
/*====================*/

struct gui_optionmenu fgui_screen_optionmenu;

char *fgui_screen_topheader = {"Screen-emulation configuration:"};

char *fgui_screen_headers[5] = {"Resolution:","Frame-skip ratio:",
                                "Maximum frame-rate:",
                                "Flicker-free interlace:",NULL};

UBY fgui_screen_shortcuts[4] = {0,0,0,2};

UBY fgui_screen_actions[4] = {GUI_VALUELIST,GUI_VALUELIST,GUI_VALUELIST,
                              GUI_VALUELIST};

const void *fgui_screen_vars[4] = {&config_graphics_mode,
                                   &config_graphics_skiprate,
                                   &config_graphics_maxfps,
                                   &config_graphics_flickerfree};

/* Option texts for screen menu */

char *fgui_screen_resolution_text[8];

char *fgui_screen_resolution_text_template[8] = {"800x300 hi-color   ",
                                                 "320x200 hi-color   ",
                                                 "320x240 hi-color   ",
                                                 "640x480 hi-color   ",
                                                 "640x400 hi-color   ",
                                                 "640x350 hi-color   ",
                                                 "320x200 8-bit color",NULL};

char *fgui_screen_frameskip_text[26] = {"1/1 ","1/2 ","1/3 ","1/4 ",
                                        "1/5 ","1/6 ","1/7 ","1/8 ",
                                        "1/9 ","1/10","1/11","1/12",
                                        "1/13","1/14","1/15","1/16",
                                        "1/17","1/18","1/19","1/20",
                                        "1/21","1/22","1/23","1/24",
                                        "1/25",NULL};

char *fgui_screen_maxframerate_text[4] = {"Unlimited             ",
                                          "50 hz                 ",
                                          "Use sync from VGA-card",
                                          NULL};

char *fgui_screen_interlace_text[3] = {"No ","Yes",NULL};

/* Option values for screen menu */

ULO fgui_screen_resolution_vals[7];
ULO fgui_screen_frameskip_vals[25] = {0,1,2,3,4,5,6,7,8,9,10,11,12,13,
                                      14,15,16,17,18,19,20,21,22,23,24};

ULO fgui_screen_maxframerate_vals[3] = {0,1,2};

ULO fgui_screen_interlace_vals[2] = {0,1};

char **fgui_screen_texts[4] = {fgui_screen_resolution_text,
                               fgui_screen_frameskip_text,
                               fgui_screen_maxframerate_text,
                               fgui_screen_interlace_text};

void *fgui_screen_vals[4] = {fgui_screen_resolution_vals,
                             fgui_screen_frameskip_vals,
                             fgui_screen_maxframerate_vals,
                             fgui_screen_interlace_vals};

void fgui_screen_init_optionmenu(void) {
        int i, j = 0;

        for (i = 0; i < 7; i++) {
                if (config_graphics_modeavailable[i]) {
                        fgui_screen_resolution_text[j] = fgui_screen_resolution_text_template[i];
                        fgui_screen_resolution_vals[j] = i;
                        j++;
                        }
                fgui_screen_resolution_text[j] = NULL;
                }
        gui_initoptionmenu(&fgui_screen_optionmenu,fgui_screen_topheader,fgui_screen_headers,fgui_screen_actions,fgui_screen_vars,fgui_screen_texts,fgui_screen_vals,&fgui_wconsole,fgui_screen_shortcuts);
}

/*====================*/
/* Memory option-menu */
/*====================*/

struct gui_optionmenu fgui_memory_optionmenu;

char *fgui_memory_topheader = {"Memory configuration (Changes force reset):"};

char *fgui_memory_headers[5] = {"Chip-memory:","Fast-memory:","Slow-memory:",
                                "Kickstart-image file:",NULL};

UBY fgui_memory_shortcuts[4] = {0,0,0,0};

UBY fgui_memory_actions[4] = {GUI_VALUELIST,GUI_VALUELIST,GUI_VALUELIST,
                              GUI_FILEREQ_ROM};

const void *fgui_memory_vars[4] = {&config_memory_chipsize,
                                   &config_memory_fastsize,
                                   &config_memory_bogosize,
                                   config_memory_kickname};

/* Option texts for memory menu */

char *fgui_memory_chip_text[9] = {"256 k ","512 k ","768 k ","1024 k",
                                  "1280 k","1536 k","1792 k","2048 k",
                                  NULL};

char *fgui_memory_fast_text[6] = {"0 MB","1 MB","2 MB","4 MB","8 MB",NULL};

char *fgui_memory_bogo_text[9] = {"0 k   ","256 k ","512 k ","768 k ",
                                  "1024 k","1280 k","1536 k","1792 k",
                                  NULL};

/* Option values for memory menu */

ULO fgui_memory_chip_vals[8] = {0x40000,0x80000,0xc0000,0x100000,
                                0x140000,0x180000,0x1c0000,0x200000};

ULO fgui_memory_fast_vals[5] = {0,0x100000,0x200000,0x400000,0x800000};

ULO fgui_memory_bogo_vals[8] = {0,0x40000,0x80000,0xc0000,0x100000,
                                0x140000,0x180000,0x1c0000};

char **fgui_memory_texts[4] = {fgui_memory_chip_text,fgui_memory_fast_text,
                               fgui_memory_bogo_text,NULL};

void *fgui_memory_vals[4] = {fgui_memory_chip_vals,fgui_memory_fast_vals,
                             fgui_memory_bogo_vals,NULL};

void fgui_memory_init_optionmenu(void) {
        gui_initoptionmenu(&fgui_memory_optionmenu,fgui_memory_topheader,fgui_memory_headers,fgui_memory_actions,fgui_memory_vars,fgui_memory_texts,fgui_memory_vals,&fgui_wconsole,fgui_memory_shortcuts);
}

/*===================*/
/* Sound option-menu */
/*===================*/

struct gui_optionmenu fgui_sound_optionmenu;

char *fgui_sound_topheader = {"Sound configuration:"};

char *fgui_sound_topheader_nosound = {"No supported sound card was found."};

char *fgui_sound_headers[3] = {"Sound-emulation:","Quality:",NULL};

UBY fgui_sound_shortcuts[2] = {0,0};

UBY fgui_sound_actions[2] = {GUI_VALUELIST,GUI_VALUELIST};
UBY fgui_sound_actionsnosound[1] = {GUI_VALUELIST};

const void *fgui_sound_vars[2] = {&config_sound,&config_sound_mode};

char *fgui_sound_headers_nosound[2] = {"Sound-emulation:",NULL};

const void *fgui_sound_vars_nosound[1] = {&config_sound};

UBY fgui_sound_actions_nosound[1] = {GUI_VALUELIST};

/* Option texts for sound menu */

char *fgui_sound_soundemu_text[5] = {"No sound                           ",
                                     "Normal, synchronized with emulation",
                                     "Normal, synchronized with real-time",
                                     "Emulated, no sound output          ",
                                     NULL};

ULO fgui_sound_soundemu_vals[4] = {0,1,2,3};

char *fgui_sound_soundemunosound_text[3] = {"No sound                 ",
                                            "Emulated, no sound output",
                                            NULL};

ULO fgui_sound_soundemunosound_vals[4] = {0,3};

char *fgui_sound_quality_text[17];

char *fgui_sound_quality_text_tmp[16] = {"44100 hz 16-bit Stereo",
                                         "31300 hz 16-bit Stereo",
                                         "22050 hz 16-bit Stereo",
                                         "15650 hz 16-bit Stereo",
                                         "44100 hz 16-bit Mono  ",
                                         "31300 hz 16-bit Mono  ",
                                         "22050 hz 16-bit Mono  ",
                                         "15650 hz 16-bit Mono  ",
                                         "44100 hz 8-bit Stereo ",
                                         "31300 hz 8-bit Stereo ",
                                         "22050 hz 8-bit Stereo ",
                                         "15650 hz 8-bit Stereo ",
                                         "44100 hz 8-bit Mono   ",
                                         "31300 hz 8-bit Mono   ",
                                         "22050 hz 8-bit Mono   ",
                                         "15650 hz 8-bit Mono   "};

ULO fgui_sound_quality_vals[16];

char **fgui_sound_texts[4] = {fgui_sound_soundemu_text,fgui_sound_quality_text,
                              NULL};

void *fgui_sound_vals[4] = {fgui_sound_soundemu_vals,fgui_sound_quality_vals,
                            NULL};

char **fgui_sound_texts_nosound[2] = {fgui_sound_soundemunosound_text,NULL};

void *fgui_sound_vals_nosound[2] = {fgui_sound_soundemunosound_vals,NULL};

void fgui_sound_init_optionmenu(void) {
        int i,j = 0;

        if (config_soundcard_found) {
                for (i = 0; i < 16; i++) {
                        fgui_sound_quality_text[j] = fgui_sound_quality_text_tmp[i];
                        fgui_sound_quality_vals[j] = i;
                        j++;
                        }
                fgui_sound_quality_text[j] = NULL;
                gui_initoptionmenu(&fgui_sound_optionmenu,fgui_sound_topheader,fgui_sound_headers,fgui_sound_actions,fgui_sound_vars,fgui_sound_texts,fgui_sound_vals,&fgui_wconsole,fgui_sound_shortcuts);
                }
        else {
                gui_initoptionmenu(&fgui_sound_optionmenu,fgui_sound_topheader_nosound,fgui_sound_headers_nosound,fgui_sound_actions_nosound,fgui_sound_vars_nosound,fgui_sound_texts_nosound,fgui_sound_vals_nosound,&fgui_wconsole,fgui_sound_shortcuts);
                }
}

/*=====================*/
/* Cpu option-menu     */
/*=====================*/

struct gui_optionmenu fgui_cpu_optionmenu;

char *fgui_cpu_topheader = {"Cpu configuration:"};

char *fgui_cpu_headers[3] = {"CPU Type:","Cpu speed:",NULL};

UBY fgui_cpu_shortcuts[2] = {0,4};

UBY fgui_cpu_actions[2] = {GUI_VALUELIST,GUI_VALUELIST};

const void *fgui_cpu_vars[4] = {&config_cpu_type,
                                   &config_cpu_speed};

/* Option texts for cpu menu */

char *fgui_cpu_type_text[3] = {"M68000                ",
                               "M68030 (Does not work)",NULL};

char *fgui_cpu_speed_text[3] = {"Normal","Fast  ",NULL};

/* Option values for cpu menu */

ULO fgui_cpu_type_vals[2] = {0,3};

ULO fgui_cpu_speed_vals[2] = {0,1};

char **fgui_cpu_texts[3] = {fgui_cpu_type_text,fgui_cpu_speed_text,NULL};

void *fgui_cpu_vals[3] = {fgui_cpu_type_vals, fgui_cpu_speed_vals,NULL};

void fgui_cpu_init_optionmenu(void) {
        gui_initoptionmenu(&fgui_cpu_optionmenu,fgui_cpu_topheader,fgui_cpu_headers,fgui_cpu_actions,fgui_cpu_vars,fgui_cpu_texts,fgui_cpu_vals,&fgui_wconsole,fgui_cpu_shortcuts);
}

/*=========================*/
/* Various option-menu     */
/*=========================*/

struct gui_optionmenu fgui_various_optionmenu;

char *fgui_various_topheader = {"Various configuration:"};


char *fgui_various_headers[8] = {"Joystick Port 1:","Joystick Port 2:",
                                 "Power,Floppy LEDs:","Keyboard LED order:",
                                 "Performance displayed on-screen:",
                                 "Menu position saving on exit:",
                                 "Automatic Run after commands:",NULL};

UBY fgui_various_shortcuts[7] = {14,14,0,0,1,0,0};

UBY fgui_various_actions[7] = {GUI_VALUELIST,GUI_VALUELIST,GUI_VALUELIST,
                               GUI_VALUELIST,GUI_VALUELIST,GUI_VALUELIST,
                               GUI_VALUELIST};
 
const void *fgui_various_vars[7] = {&config_joyA,
                                    &config_joyB,
                                    &config_enableleds,
                                    &kbdleds,
                                    &config_printspeed,
                                    &config_store_mpos,
                                    &config_autorun};

/* Option texts for various menu */

char *fgui_various_joya_text[6];
char *fgui_various_joyb_text[6];
char *fgui_various_joy_text_tmp[6] = {"Disabled                             ",
                                      "Joystick replacement, arrowkeys/RCTRL",
                                      "Joystick replacement, rdfg/LCTRL     ",
                                      "Analog Joystick                      ",
                                      NULL,
                                      "Mouse                                "};

/* Led meter values must be filled in runtime */

char *fgui_various_led_text[12] = {"Disabled                          ",
                                   "On screen                         ",
                                   "Keyboard (DF0, DF1, DF2)          ",
                                   "Keyboard (Power, DF0, DF1)        ",
                                   "Keyboard (Power, DF0+DF1, DF2+DF3)",
                                   "Led Meter on LPT1                 ",
                                   "Led Meter on LPT1 (mirrored)      ",
                                   "Led Meter on LPT2                 ",
                                   "Led Meter on LPT2 (mirrored)      ",
                                   "Led Meter on LPT3                 ",
                                   "Led Meter on LPT3 (mirrored)      ",NULL};
 

char *fgui_various_order_text[7] = {"Num / Caps / Scroll",
                                    "Num / Scroll / Caps",
                                    "Caps / Num / Scroll",
                                    "Caps / Scroll / Num",
                                    "Scroll / Caps / Num",
                                    "Scroll / Num / Caps",NULL};

char *fgui_various_speed_text[3] = {"No ","Yes",NULL};
char *fgui_various_mpos_text[3] = {"No ","Yes",NULL};

char *fgui_various_arun_text[5] = {"None         ","Alt-N        ",
                                   "Reset        ","Alt-N & Reset",NULL};

/* Option values for various menu */

ULO fgui_various_joya_vals[5];
ULO fgui_various_joyb_vals[5];
ULO fgui_various_led_vals[11] = {0,1,0x81,0x82,0x83,0x41,0x51,0x42,0x52,0x43,0x53};
ULO fgui_various_order_vals[6] = {0,1,2,3,4,5};
ULO fgui_various_speed_vals[2] = {0,1};
ULO fgui_various_mpos_vals[2] = {0,1};
ULO fgui_various_arun_vals[4] = {0,1,2,3};

char **fgui_various_texts[8] = {fgui_various_joya_text,fgui_various_joyb_text,
                                fgui_various_led_text,fgui_various_order_text,
                                fgui_various_speed_text,fgui_various_mpos_text,
                                fgui_various_arun_text,NULL};
void *fgui_various_vals[8] = {fgui_various_joya_vals,fgui_various_joyb_vals,
                              fgui_various_led_vals,fgui_various_order_vals,
                              fgui_various_speed_vals,fgui_various_mpos_vals,
                              fgui_various_arun_vals,NULL};

void fgui_various_init_optionmenu(void) {
        int i,j = 0;

        for (i = 0; i < 6; i++) {
                if ((i < 3) || (i == 3 && config_joyAfound) || (i != 4)) {
                        fgui_various_joya_text[j] = fgui_various_joy_text_tmp[i];
                        fgui_various_joya_vals[j] = i;
                        fgui_various_joyb_text[j] = fgui_various_joy_text_tmp[i];
                        fgui_various_joyb_vals[j] = i;
                        j++;
                        }
                }
        fgui_various_joya_text[j] = NULL;
        fgui_various_joyb_text[j] = NULL;
        gui_initoptionmenu(&fgui_various_optionmenu,fgui_various_topheader,fgui_various_headers,fgui_various_actions,fgui_various_vars,fgui_various_texts,fgui_various_vals,&fgui_wconsole,fgui_various_shortcuts);
}

/*=====================*/
/* hfile option-menu     */
/*=====================*/

struct gui_optionmenu fgui_hfile_optionmenu;

char *fgui_hfile_topheader = {"Hardfile configuration (Use Kickstart V2 or higher):"};

char *fgui_hfile_headers[3] = {"hardfile.device state:","Hardfile filename:",NULL};

UBY fgui_hfile_shortcuts[2] = {0,1};

UBY fgui_hfile_actions[2] = {GUI_VALUELIST,GUI_FILEREQ_HDF};

const void *fgui_hfile_vars[2] = {&config_fhfile_enabled,
                                  config_fhfile_name};

/* Option texts for hfile menu */

char *fgui_hfile_enabled_text[3] = {"Disabled","Enabled ",NULL};

/* Option values for hfile menu */

ULO fgui_hfile_enabled_vals[2] = {0,1};

char **fgui_hfile_texts[3] = {fgui_hfile_enabled_text,NULL,NULL};

void *fgui_hfile_vals[3] = {fgui_hfile_enabled_vals, NULL,NULL};

void fgui_hfile_init_optionmenu(void) {
        gui_initoptionmenu(&fgui_hfile_optionmenu,fgui_hfile_topheader,fgui_hfile_headers,fgui_hfile_actions,fgui_hfile_vars,fgui_hfile_texts,fgui_hfile_vals,&fgui_wconsole,fgui_hfile_shortcuts);
}


/*==================================*/
/* Event logging configuration menu */
/*==================================*/

#ifdef DEBUGBUILD

struct gui_optionmenu fgui_evlog_optionmenu;

char *fgui_evlog_topheader = NULL;

char *fgui_evlog_headers[] = {"Serial TBE irq (Level 1):",
                              "Disk DMA done irq (Level 1):",
                              "Software irq (Level 1):",
                              "Cia A irq (Level 2):",
                              "Copper irq (Level 3):",
                              "Vertical Blank irq (Level 3):",
                              "Blitter irq (Level 3):",
                              "Audio irq (Level 4):",
                              "Serial RBF irq (Level 5):",
                              "Disk Sync found irq (Level 5):",
                              "Cia B irq (Level 6):",
                              "Bus error exception:",
                              "Odd address exception:",
                              "Illegal instruction exception:",
                              "Division by zero exception:",
                              "Privilegie violation exception:",
                              "Trap exception:",
                              "STOP instruction:",
                              NULL};

UBY fgui_evlog_shortcuts[] = {0,0,1,8,2,0,0,0,1,1,7,1,13,1,7,23,0,16};

UBY fgui_evlog_actions[] = {GUI_VALUELIST,GUI_VALUELIST,GUI_VALUELIST,
                            GUI_VALUELIST,GUI_VALUELIST,GUI_VALUELIST,
                            GUI_VALUELIST,GUI_VALUELIST,GUI_VALUELIST,
                            GUI_VALUELIST,GUI_VALUELIST,GUI_VALUELIST,
                            GUI_VALUELIST,GUI_VALUELIST,GUI_VALUELIST,
                            GUI_VALUELIST,GUI_VALUELIST,GUI_VALUELIST};
                            
const void *fgui_evlog_vars[] = {&logserialtransmitbufferemptyirq,
                                 &logdiskdmatransferdoneirq,
                                 &logsoftwareirq,
                                 &logciaairq,
                                 &logcopperirq,
                                 &logverticalblankirq,
                                 &logblitterreadyirq,
                                 &logaudioirq,
                                 &logserialreceivebufferfullirq,
                                 &logdisksyncvaluerecognizedirq,
                                 &logciabirq,
                                 &logbuserrorex,
                                 &logoddaddressex,
                                 &logillegalinstructionex,
                                 &logdivisionby0ex,
                                 &logprivilegieviolationex,
                                 &logtrapex,
                                 &logstop};

/* Option texts for evlog menu */

char *fgui_evlog_all_text[3] = {"Logged    ","Not Logged",NULL};

/* Option values for evlog menu */

ULO fgui_evlog_all_vals[2] = {TRUE,FALSE};

char **fgui_evlog_texts[] = {fgui_evlog_all_text,
                             fgui_evlog_all_text,
                             fgui_evlog_all_text,
                             fgui_evlog_all_text,
                             fgui_evlog_all_text,
                             fgui_evlog_all_text,
                             fgui_evlog_all_text,
                             fgui_evlog_all_text,
                             fgui_evlog_all_text,
                             fgui_evlog_all_text,
                             fgui_evlog_all_text,
                             fgui_evlog_all_text,
                             fgui_evlog_all_text,
                             fgui_evlog_all_text,
                             fgui_evlog_all_text,
                             fgui_evlog_all_text,
                             fgui_evlog_all_text,
                             fgui_evlog_all_text,
                             NULL};

void *fgui_evlog_vals[] = {fgui_evlog_all_vals,
                           fgui_evlog_all_vals,
                           fgui_evlog_all_vals,
                           fgui_evlog_all_vals,
                           fgui_evlog_all_vals,
                           fgui_evlog_all_vals,
                           fgui_evlog_all_vals,
                           fgui_evlog_all_vals,
                           fgui_evlog_all_vals,
                           fgui_evlog_all_vals,
                           fgui_evlog_all_vals,
                           fgui_evlog_all_vals,
                           fgui_evlog_all_vals,
                           fgui_evlog_all_vals,
                           fgui_evlog_all_vals,
                           fgui_evlog_all_vals,
                           fgui_evlog_all_vals,
                           fgui_evlog_all_vals,
                           NULL};

void fgui_evlog_init_optionmenu(void) {
        gui_initoptionmenu(&fgui_evlog_optionmenu,fgui_evlog_topheader,fgui_evlog_headers,fgui_evlog_actions,fgui_evlog_vars,fgui_evlog_texts,fgui_evlog_vals,&fgui_wconsole,fgui_evlog_shortcuts);
}

#endif

/*===================*/
/* The entire screen */
/*===================*/

void fgui_initwindow_fullscreen(void) {
        gui_initwindow(&fgui_wfullscreen,1,80,1,25,BGCOL,TXTCOL,SHORTCUTCOL,REVERSECOL,0);
}

/*===================*/
/* Requester window  */                   
/*===================*/

void fgui_initwindow_requester(void) {
        gui_initwindow(&fgui_wrequester,5,76,10,16,BGCOL,TXTCOL,SHORTCUTCOL,REVERSECOL,0);
}

void fgui_fastmemAllocFail(ULO wantedMB, ULO gotMB) {
        char s[60];
        gui_clearwindow(&fgui_wrequester, TRUE);
        gui_printwindowborders(&fgui_wrequester);
        sprintf(s,"Not enough memory for %d MB of FAST memory",wantedMB);
        gui_plot_text_window(&fgui_wrequester,s,15,2);
        sprintf(s,"The setting was adjusted to %d MB",gotMB);
        gui_plot_text_window(&fgui_wrequester,s,18,4);
        getch();
}

/*============================================================*/
/* The header                                                 */
/* Used for version string normally, or registers in debugger */
/*============================================================*/

void fgui_initwindow_header(void) {
        gui_initwindow(&fgui_wheader,1,80,1,5,BGCOL,TXTCOL,SHORTCUTCOL,REVERSECOL,0);
}

/* The version and copyright notice */

void fgui_print_versiontext(void) {
        gui_plot_text_window(&fgui_wheader,"Fellow Amiga Emulator V0.3",2,1);
        gui_plot_text_window(&fgui_wheader,"(C) Petter Schau, Contributions by Roman Dolejsi & David Voracek",2,3);
}

void fgui_print_registers(void) {
        char st[80];
        gui_clearwindow(&fgui_wheader,FALSE);
        sprintf(st,"D0:%.8X %.8X %.8X %.8X %.8X %.8X %.8X %.8X:D7",d[0],d[1],d[2],d[3],d[4],d[5],d[6],d[7]);
        gui_plot_text_window(&fgui_wheader,st,1,1);
        sprintf(st,"A0:%.8X %.8X %.8X %.8X %.8X %.8X %.8X %.8X:A7",a[0],a[1],a[2],a[3],a[4],a[5],a[6],a[7]);
        gui_plot_text_window(&fgui_wheader,st,1,2);
        if ((sr & 0x2000) == 0x2000)
                sprintf(st,"PC:%.8X USP:%.8X SSP:%.8X SR:%.4X IRQ-LEVEL %1d SUPERVISOR MODE",pc,usp,a[7],sr,(sr & 0x700)>>8);
        else
                sprintf(st,"PC:%.8X USP:%.8X SSP:%.8X SR:%.4X IRQ-LEVEL %1d USER MODE",pc,a[7],ssp,sr,(sr & 0x700)>>8);
        gui_plot_text_window(&fgui_wheader,st,1,3);
}

/*=============*/
/* The console */
/*=============*/

void fgui_initwindow_console(void) {
        gui_initwindow(&fgui_wconsole,1,80,5,25,BGCOL,TXTCOL,SHORTCUTCOL,REVERSECOL,TOPLEFT|TOPRIGHT);
}

void fgui_print_info(void) {
        int i;
        char st[80];
        gui_plot_text_window(&fgui_wconsole,"Disk-images:",2,1);
        gui_plot_text_window(&fgui_wconsole,"------------",2,2);
        for (i = 0; i < 4; i++) {
                sprintf(st,"DF%d:",i);
                gui_plot_text_window(&fgui_wconsole,st,2,3 + i);
                gui_plot_text_window(&fgui_wconsole,config_floppy_name[i],7,3 + i);
                if (config_floppy_enabled[i]) {
                        switch (diskimagestatus[i]) {
                                case 0: gui_plot_text_window(&fgui_wconsole,"ADF Inserted ",50,3 + i);
                                        break;
                                case 1: gui_plot_text_window(&fgui_wconsole,"Not found    ",50,3 + i);
                                        break;
                                case 2: gui_plot_text_window(&fgui_wconsole,"Wrong size   ",50,3 + i);
                                        break;
                                case 3: gui_plot_text_window(&fgui_wconsole,"None inserted",50,3 + i);
                                        break;
                                }
                        }
                else gui_plot_text_window(&fgui_wconsole,"Disabled",50,3 + i);
                }
        gui_plot_text_window(&fgui_wconsole,"FELLOW: ",2,8);
        gui_plot_text_window(&fgui_wconsole,config_fhfile_name,11,8);
        if (config_fhfile_enabled) {
                if (config_memory_romversion < 0x200) 
                        gui_plot_text_window(&fgui_wconsole,"Disabled, use Kickstart >= 2",50,8);
                else {
                        sprintf( st, "%iMB Hardfile", fhfile_size / 1024 / 1024 );
                        gui_plot_text_window(&fgui_wconsole,st,50,8);
                        }
                }
        else gui_plot_text_window(&fgui_wconsole,"Disabled",50,8);

        if (!config_memory_nokick)
                gui_plot_text_window(&fgui_wconsole,kickstart_idstring,2,10);
        else {
                gui_plot_text_window(&fgui_wconsole,"No Kickstart loaded, Reset after inserting a disk-image enables",2,10);
                gui_plot_text_window(&fgui_wconsole,"a simple replacement loader.",2,11);
                }

        sprintf(st,"Memory Available: %d",getLargestMemBlock());
        gui_plot_text_window(&fgui_wconsole,st,2,18);


        if (mmx_detected) 
                gui_plot_text_window(&fgui_wconsole,"Found MMX",2,19);
}

void fgui_print_instructions(void) {
        ULO y,mpc,opco;
        union { ULO lo; ULO (*fun)(); } yeah;
        char s[80];

        mpc = pc;
        for (y = 1; y <= (fgui_wconsole.y2 - fgui_wconsole.y1 - 1); y++) {
                opco = fetw(mpc);
                yeah.lo = t[opco][1];
                mpc = yeah.fun(mpc,opco,s);
                gui_plot_text_window(&fgui_wconsole,s,1,y);
                }
}

void fgui_print_framexy(void) {
        char s[30];
        sprintf(s,"Frame: %d",frames);
        gui_plot_text_window(&fgui_wconsole,s,65,1);
        sprintf(s,"Xpos:  %d",xpos);
        gui_plot_text_window(&fgui_wconsole,s,65,2);
        sprintf(s,"Ypos:  %d",ypos);
        gui_plot_text_window(&fgui_wconsole,s,65,3);
#ifdef PREFETCH
        sprintf(s,"PFW:   %.4X",prefetch_word);
        gui_plot_text_window(&fgui_wconsole,s,65,4);
#endif
}

void fgui_debug_memory(void) {
        char st[80];
        int i,s,ended = FALSE,keyz,j,ascii = FALSE, padd = 608,k;

        s = 0;
        gui_clearwindow(&fgui_wconsole, TRUE);
        gui_printwindowborders(&fgui_wconsole);

        while (!ended & !exitflag) {

                for (i = 0; i < 19; i++) 
                        if (ascii) {
                                sprintf(st, "%.6X %.8X%.8X %.8X%.8X ",(s+i*16)&0xffffff,fetl(s+i*16+0),fetl(s+i*16+4),fetl(s+i*16+8),fetl(s+i*16+12));
                                gui_plot_text_window(&fgui_wconsole, st, 2, i + 1);
                                for (j = 0; j < 16; j++) {
                                        k = fetb(s+i*16+j)&0xff;
                                        if (k < 32) st[j] = '.';
                                        else st[j] = k;
                                        }
                                st[16] = '\0';
                                gui_plot_text_window(&fgui_wconsole, st, 44, i + 1);
                                }
                        else {
                                sprintf(st, "%.6X %.8X%.8X %.8X%.8X %.8X%.8X %.8X%.8X",(s+i*32)&0xffffff,fetl(s+i*32+0),fetl(s+i*32+4),fetl(s+i*32+8),fetl(s+i*32+12),fetl(s+i*32+16),fetl(s+i*32+20),fetl(s+i*32+24),fetl(s+i*32+28));
                                gui_plot_text_window(&fgui_wconsole, st, 2, i + 1);
                                }

                keyz = getch();
                if (keyz == 27) ended = 1;
                else if (keyz == 'a') {
                        padd = 304;
                        ascii = TRUE;
                        gui_clearwindow(&fgui_wconsole, FALSE);
                        }
                else if (keyz == 'h') {
                        padd = 608;
                        ascii = FALSE;
                        gui_clearwindow(&fgui_wconsole, FALSE);
                        }
                else if (keyz == 0) {
                        keyz = getch();
                        if (keyz == 71) {
                                s = (s-0x10000)&0xffffff;
                                }
                        else if (keyz == 79) {
                                s = (s+0x10000)&0xffffff;
                                }
                        else if (keyz == 72) {
                                s = (s-32)&0xffffff;
                                }
                        else if (keyz == 80) {
                                s = (s+32)&0xffffff;
                                }
                        else if (keyz == 73) {  // PGUP
                                s = (s-padd)&0xffffff;
                                }
                        else if (keyz == 81) { // PGDOWN
                                s = (s+padd)&0xffffff;
                                }
                        }
                }
}

void fgui_debug_print_cia(void) {
        char s[80];
        int y = 3;

        gui_clearwindow(&fgui_wconsole,TRUE);
        gui_printwindowborders(&fgui_wconsole);
        gui_plot_text_window(&fgui_wconsole,"Cia registers:",1,1);

        sprintf(s,"ACRA-%.2X ACRB-%.2X BCRA-%.2X BCRB-%.2X AIREQ-%.2X AIMSK-%.2X BIREQ-%.2X BIMSK-%.2X",ciaacra,ciaacrb,ciabcra,ciabcrb,ciaaicrreq,ciaaicrmsk,ciabicrreq,ciabicrmsk);
        gui_plot_text_window(&fgui_wconsole,s,1,y++);
        sprintf(s,"AEV-%.8X BEV-%.8X",ciaaev,ciabev);
        gui_plot_text_window(&fgui_wconsole,s,1,y++);
        sprintf(s,"ATA-%.8X ATAHELP-%.8X ATB-%.8X ATBHELP-%.8X",ciaata,ciaataleft,ciaatb,ciaatbleft);
        gui_plot_text_window(&fgui_wconsole,s,1,y++);
        if (ciaacra & 1)
                gui_plot_text_window(&fgui_wconsole,"Cia A Timer A started",1,y);
        else 
                gui_plot_text_window(&fgui_wconsole,"Cia A Timer A stopped",1,y);
        if (ciaacra & 8)
                gui_plot_text_window(&fgui_wconsole,"One-shot mode",25,y++);
        else 
                gui_plot_text_window(&fgui_wconsole,"Continous",25,y++);
        if (ciaacrb & 1)
                gui_plot_text_window(&fgui_wconsole,"Cia A Timer B started",1,y);
        else 
                gui_plot_text_window(&fgui_wconsole,"Cia A Timer B stopped",1,y);
        if (ciaacrb & 8)
                gui_plot_text_window(&fgui_wconsole,"One-shot mode",25,y++);
        else 
                gui_plot_text_window(&fgui_wconsole,"Continous",25,y++);
        sprintf(s,"BTA-%.8X BTAHELP-%.8X BTB-%.8X BTBHELP-%.8X",ciabta,ciabtaleft,ciabtb,ciabtbleft);
        gui_plot_text_window(&fgui_wconsole,s,1,y++);
        if (ciabcra & 1)
                gui_plot_text_window(&fgui_wconsole,"Cia B Timer A started",1,y);
        else 
                gui_plot_text_window(&fgui_wconsole,"Cia B Timer A stopped",1,y);
        if (ciabcra & 8)
                gui_plot_text_window(&fgui_wconsole,"One-shot mode",25,y++);
        else 
                gui_plot_text_window(&fgui_wconsole,"Continous",25,y++);
        if (ciabcrb & 1)
                gui_plot_text_window(&fgui_wconsole,"Cia B Timer B started",1,y);
        else 
                gui_plot_text_window(&fgui_wconsole,"Cia B Timer B stopped",1,y);
        if (ciabcrb & 8)
                gui_plot_text_window(&fgui_wconsole,"One-shot mode",25,y++);
        else 
                gui_plot_text_window(&fgui_wconsole,"Continous",25,y++);
        getch();
}

void fgui_print_diskname( char *str, int drv ) {
  char s[80];
  char s2[80];
  int i;
  char strw[80];

  if( strcmpi( config_floppy_name[drv], "__None__" ) ) {
    strw[0] = 0; s[0] = 0;
    if( strlen( str ) > ( 78 - 25 ) ) {
      strcat( strw, "..." );
      strcat( strw, &str[ strlen( str ) - ( 78 - 25 - 3 ) ] );
    } else strcpy( strw, str );
    sprintf( s2, "Inserting %s into drive Df%i", strw, drv );
    i = ( 78 - strlen( s2 ) ) / 2;
    while( i-- > 0 ) strcat( s, " " );
    strcat( s2, s );
    strcat( s, s2 );
    gui_plot_text_window( &fgui_wconsole, s, 1, 10 );
  };
}


/*=================*/
/* The menu window */
/*=================*/

void fgui_initwindow_menu(void) {
        gui_initwindow(&fgui_wmenu,66,80,18,25,BGCOL,TXTCOL,SHORTCUTCOL,REVERSECOL,TOPRIGHT|BOTLEFT);
}

/*==================*/
/* Init all windows */
/*==================*/

void fgui_init_windows(void) {
        fgui_initwindow_fullscreen();
        fgui_initwindow_header();
        fgui_initwindow_console();
        fgui_initwindow_menu();
        fgui_initwindow_requester();
}

/*======================*/
/* Init all optionmenus */
/*======================*/

void fgui_init_optionmenus(void) {
        fgui_floppy_init_optionmenu();
        fgui_screen_init_optionmenu();
        fgui_memory_init_optionmenu();
        fgui_sound_init_optionmenu();
        fgui_cpu_init_optionmenu();
        fgui_hfile_init_optionmenu();
        fgui_various_init_optionmenu();
#ifdef DEBUGBUILD
        fgui_evlog_init_optionmenu();
#endif
}

/*========================================================*/
/* Draw the screen                                        */
/*========================================================*/

void fgui_drawscreen_normal(ULO clearflag) {
        if (clearflag) gui_clearwindow(&fgui_wfullscreen, TRUE);
        gui_printwindowborders(&fgui_wfullscreen);
        gui_printwindowborders(&fgui_wheader);
        gui_printwindowborders(&fgui_wconsole);
        gui_printwindowborders(&fgui_wmenu);
        fgui_print_versiontext();
        fgui_print_info();
}

void fgui_drawscreen_nomenu(ULO clearflag) {
        if (clearflag) gui_clearwindow(&fgui_wfullscreen, TRUE);
        gui_printwindowborders(&fgui_wfullscreen);
        gui_printwindowborders(&fgui_wheader);
        gui_printwindowborders(&fgui_wconsole);
        fgui_print_versiontext();
}

void fgui_drawscreen_debug(ULO clearflag) {
        if (clearflag) gui_clearwindow(&fgui_wfullscreen, TRUE);
        gui_printwindowborders(&fgui_wfullscreen);
        gui_printwindowborders(&fgui_wheader);
        gui_printwindowborders(&fgui_wconsole);
        gui_printwindowborders(&fgui_wmenu);
        fgui_print_registers();
        fgui_print_instructions();
        fgui_print_framexy();
}

/*=======*/
/* Menus */
/*=======*/

/*===========================*/
/* The config menu functions */
/*===========================*/

void fgui_init_configmenu(void) {
        gui_initmenu(&fgui_configmenu,fgui_configmenu_entries,0,&fgui_wmenu,fgui_configmenu_shortcuts);
}

char s[128];
int exitflag = 0;

void fgui_run_configmenu(void) {
        int i,ended = FALSE;
        int wtop = 24- gui_menu_numberofentries(&fgui_configmenu);
        char disknames[4][256];  /* Save disk-image names */
        char romname[256];       /* Save Kickstart file name */
        ULO chips,bogos,fasts;   /* Save memory sizes */
        ULO vmode;               /* Save videomode    */
        char hardfilename[256];
        ULO hardfileenabled;
        ULO doreset = FALSE;
        UWO *lptcfg = (UWO *)0x410; // paralel port config address

        strcpy(disknames[0],config_floppy_name[0]);
        strcpy(disknames[1],config_floppy_name[1]);
        strcpy(disknames[2],config_floppy_name[2]);
        strcpy(disknames[3],config_floppy_name[3]);
        strcpy(romname,config_memory_kickname);
        strcpy(hardfilename,config_fhfile_name);

        hardfileenabled = config_fhfile_enabled;

        chips = config_memory_chipsize;
        bogos = config_memory_bogosize;
        fasts = config_memory_fastsize;
        vmode = config_graphics_mode;
        fgui_various_led_text[ 5 + ( (lptcfg[0] >> 14) * 2 ) ] = NULL;


        fgui_wmenu.y1 = wtop;
        gui_clearwindow(fgui_configmenu.w, FALSE);
        while (!ended && !exitflag) {
                fgui_wmenu.y1 = wtop;
                fgui_drawscreen_normal(FALSE);
                i = gui_menu_select(&fgui_configmenu);
                switch (i) {
                        case 0: /* Floppy */
                                gui_optionmenu_run(&fgui_floppy_optionmenu);
                                break;
                        case 1: /* Screen */
                                gui_optionmenu_run(&fgui_screen_optionmenu);
                                break;
                        case 2: /* Memory */
                                gui_optionmenu_run(&fgui_memory_optionmenu);
                                break;
                        case 3: /* Sound  */
                                gui_optionmenu_run(&fgui_sound_optionmenu);
                                break;
                        case 4: /* Cpu  */
                                gui_optionmenu_run(&fgui_cpu_optionmenu);
                                break;
                        case 5: /* Hardfile */
                                gui_optionmenu_run(&fgui_hfile_optionmenu);
                                break;
                        case 6: /* Various */
                                gui_optionmenu_run(&fgui_various_optionmenu);
                                break;
                        case 99999: /* ESC */
                                ended = TRUE;
                                break;
                        }
                }

        save_fellow_cfg();

        if( config_enableleds & 0x40 ) {
                lptcfg = (UWO *)0x406;
                ledlpt = lptcfg[ config_enableleds & 3 ]; // get LPT port from BIOS area
                };

        ended = FALSE;
        for (i = 0; i < 4; i++) {
                if (strcmp(disknames[i],config_floppy_name[i]) != 0) {
                        if( !ended ) {
                          gui_clearwindow( &fgui_wconsole, TRUE );
                          gui_printwindowborders( &fgui_wconsole );
                          ended = TRUE;
                        }
                        fgui_print_diskname( config_floppy_name[ i ], i );
                        insert_diskimage( config_floppy_name[ i ], i );
                        }
                }

        if (strcmp(hardfilename,config_fhfile_name) != 0)
                doreset = TRUE;
        if (hardfileenabled != config_fhfile_enabled)
                doreset = TRUE;
        if (vmode != config_graphics_mode)
                gmodefirsttime[config_graphics_mode] = TRUE;
        if (strcmp(romname,config_memory_kickname) != 0 ||
            config_memory_chipsize != chips ||
            config_memory_bogosize != bogos ||
            config_memory_fastsize != fasts) {
                doreset = TRUE;
                }
        if (config_sound > 0) sound_initmode();
        if (doreset) fellow_hardreset();
        gui_clearwindow(&fgui_wconsole,FALSE);
}

/*===========================*/
/* The debug breakpoint menu */
/*===========================*/

static gui_debugbreak_breakpoint = 0;

void fgui_init_debugbreakmenu(void) {
        gui_initmenu(&fgui_debugbreakmenu,fgui_debugbreakmenu_entries,0,&fgui_wmenu,fgui_debugbreakmenu_shortcuts);
        gui_initnumberfield(&fgui_debugbreak_numberfield,&fgui_wrequester,gui_debugbreak_breakpoint, 30,3);
}

ULO fgui_debugbreak_getbreakpoint(void) {
        gui_clearwindow(&fgui_wrequester,FALSE);
        gui_printwindowborders(&fgui_wrequester);
        gui_plot_text_window(&fgui_wrequester, "Breakpoint Address:",2,3);
        gui_numberfield_enter(&fgui_debugbreak_numberfield);
        gui_debugbreak_breakpoint = fgui_debugbreak_numberfield.value;
        return gui_debugbreak_breakpoint;
}

void fgui_run_debugbreakmenu(void) {
        int ended = FALSE;
        int wtop = 24- gui_menu_numberofentries(&fgui_debugbreakmenu);

        while (!ended) {
                fgui_wmenu.y1 = wtop;
                fgui_drawscreen_debug(TRUE);
                switch (gui_menu_select(&fgui_debugbreakmenu)) {
                        case 0: /* Enter breakpoint */
                                fellow_run_until_breakpoint(fgui_debugbreak_getbreakpoint());
                                gui_setupscreen();
                                ended = TRUE;
                                break;
                        case 1: /* Until Line 312 */
                                fellow_run_until_line_312();
                                ended = TRUE;
                                break;
#ifdef DEBUGBUILD
                        case 2: /* Until Event */
                                fellow_run_until_event();
                                ended = TRUE;
                                break;
#endif
                        case 99999:
                                ended = TRUE;
                                break;
                        }
                }
}

/*===========================*/
/* The debug ioregister menu */
/*===========================*/

void fgui_init_debugiomenu(void) {
        gui_initmenu(&fgui_debugiomenu,fgui_debugiomenu_entries,0,&fgui_wmenu,fgui_debugiomenu_shortcuts);
}

void fgui_debug_print_sound(void) {
        char s[80];
        int y = 1,i;

        gui_clearwindow(&fgui_wconsole,TRUE);
        gui_printwindowborders(&fgui_wconsole);

        sprintf(s,"SB dmaptr-%.8X dmabufstart-%.8X",auddmaptr,dmaflataddr);
        gui_plot_text_window(&fgui_wconsole,s,1,y++);
        getch();
}
void fgui_debug_print_floppy(void) {
        char s[80];
        int y = 1,i;

        gui_clearwindow(&fgui_wconsole,TRUE);
        gui_printwindowborders(&fgui_wconsole);

        for (i = 0; i < 4; i++) {
                sprintf(s,"DF%d:",i);
                gui_plot_text_window(&fgui_wconsole,s,1,y++);
                sprintf(s,"Track-%d Sel-%d Motor-%d Side-%d Lasttr-%d Used-%d Cached-%s",track[i],sel[i],motor[i],side[i],inmemlasttrack[i],inmemtimesused[i], (diskinmem[i] == NULL) ? "No ":"Yes");
                gui_plot_text_window(&fgui_wconsole,s,1,y++);
                y++;
                }

        sprintf(s,"Dskpt-%.6X dsklen-%.4X dsksync-%.4X",dskpt,dsklen,dsksync);
        gui_plot_text_window(&fgui_wconsole,s,1,y++);
        if (diskdmainprogress)
                gui_plot_text_window(&fgui_wconsole,"Disk DMA running",1,y++);
        else
                gui_plot_text_window(&fgui_wconsole,"Disk DMA stopped",1,y++);
        sprintf(s,"Busloop at: %X",checkadr);
        gui_plot_text_window(&fgui_wconsole,s,1,1+y++);
        getch();
}
void fgui_run_debugiomenu(void) {
        int ended = FALSE;
        int wtop = 24- gui_menu_numberofentries(&fgui_debugiomenu);

        while (!ended) {
                fgui_wmenu.y1 = wtop;
                fgui_drawscreen_debug(TRUE);
                switch (gui_menu_select(&fgui_debugiomenu)) {
                        case 0: /* Floppy */
                                fgui_debug_print_floppy();
                                break;
                        case 1: /* Sound */
                                fgui_debug_print_sound();
                                break;
                        case 99999:
                                ended = TRUE;
                                break;
                        }
                }
}

/*==========================*/
/* The debug menu functions */
/*==========================*/

void fgui_init_debugmenu(void) {
        gui_initmenu(&fgui_debugmenu,fgui_debugmenu_entries,0,&fgui_wmenu,fgui_debugmenu_shortcuts);
}

#ifdef DEBUGBUILD

/* Print event log from item start to stop */

/* Irq data-layout:
        
        0: eventid
        1: frame
        2: ypos
        3: xpos
        4: pc when irq happened
*/

void fgui_debug_print_evlog(ULO start, ULO stop) {
        ULO current,i,j;
        char s[80];

        for (current = start; current < stop; current++) {
                switch(logbuffer[current%EVENTCOUNT][0]) {
                        case IRQ1_0_TBE:
                                sprintf(s,"F-%.8X Y-%.3X X-%.3X - Serial Transmit Buffer Empty Interrupt (PC=%.6X)",logbuffer[current%EVENTCOUNT][1],logbuffer[current%EVENTCOUNT][2],logbuffer[current%EVENTCOUNT][3],logbuffer[current%EVENTCOUNT][4]);
                                break;
                        case IRQ1_1_DSKBLK:
                                sprintf(s,"F-%.8X Y-%.3X X-%.3X - Disk DMA Transfer Done Interrupt (PC=%.6X)",logbuffer[current%EVENTCOUNT][1],logbuffer[current%EVENTCOUNT][2],logbuffer[current%EVENTCOUNT][3],logbuffer[current%EVENTCOUNT][4]);
                                break;
                        case IRQ1_2_SOFT:
                                sprintf(s,"F-%.8X Y-%.3X X-%.3X - Software Interrupt (PC=%.6X)",logbuffer[current%EVENTCOUNT][1],logbuffer[current%EVENTCOUNT][2],logbuffer[current%EVENTCOUNT][3],logbuffer[current%EVENTCOUNT][4]);
                                break;
                        case IRQ2_CIAA:
                                sprintf(s,"F-%.8X Y-%.3X X-%.3X - Cia A Interrupt (PC=%.6X)",logbuffer[current%EVENTCOUNT][1],logbuffer[current%EVENTCOUNT][2],logbuffer[current%EVENTCOUNT][3],logbuffer[current%EVENTCOUNT][4]);
                                break;
                        case IRQ3_0_COPPER:
                                sprintf(s,"F-%.8X Y-%.3X X-%.3X - Copper Interrupt (PC=%.6X)",logbuffer[current%EVENTCOUNT][1],logbuffer[current%EVENTCOUNT][2],logbuffer[current%EVENTCOUNT][3],logbuffer[current%EVENTCOUNT][4]);
                                break;
                        case IRQ3_1_VBL:
                                sprintf(s,"F-%.8X Y-%.3X X-%.3X - Vertical Blank Interrupt (PC=%.6X)",logbuffer[current%EVENTCOUNT][1],logbuffer[current%EVENTCOUNT][2],logbuffer[current%EVENTCOUNT][3],logbuffer[current%EVENTCOUNT][4]);
                                break;
                        case IRQ3_2_BLIT:
                                sprintf(s,"F-%.8X Y-%.3X X-%.3X - Blitter Ready Interrupt (PC=%.6X)",logbuffer[current%EVENTCOUNT][1],logbuffer[current%EVENTCOUNT][2],logbuffer[current%EVENTCOUNT][3],logbuffer[current%EVENTCOUNT][4]);
                                break;
                        case IRQ4_AUD:
                                sprintf(s,"F-%.8X Y-%.3X X-%.3X - Audio Channel 0 Interrupt (PC=%.6X)",logbuffer[current%EVENTCOUNT][1],logbuffer[current%EVENTCOUNT][2],logbuffer[current%EVENTCOUNT][3],logbuffer[current%EVENTCOUNT][4]);
                                break;
                        case IRQ5_0_RBF:
                                sprintf(s,"F-%.8X Y-%.3X X-%.3X - Serial Receive Buffer Full Interrupt (PC=%.6X)",logbuffer[current%EVENTCOUNT][1],logbuffer[current%EVENTCOUNT][2],logbuffer[current%EVENTCOUNT][3],logbuffer[current%EVENTCOUNT][4]);
                                break;
                        case IRQ5_1_DSKSYN:
                                sprintf(s,"F-%.8X Y-%.3X X-%.3X - Disk Sync Value Recognized Interrupt (PC=%.6X)",logbuffer[current%EVENTCOUNT][1],logbuffer[current%EVENTCOUNT][2],logbuffer[current%EVENTCOUNT][3],logbuffer[current%EVENTCOUNT][4]);
                                break;
                        case IRQ6_0_CIAB:
                                sprintf(s,"F-%.8X Y-%.3X X-%.3X - Cia B Interrupt (PC=%.6X)",logbuffer[current%EVENTCOUNT][1],logbuffer[current%EVENTCOUNT][2],logbuffer[current%EVENTCOUNT][3],logbuffer[current%EVENTCOUNT][4]);
                                break;
                        case EXBUSERROR:
                                sprintf(s,"F-%.8X Y-%.3X X-%.3X - Bus Error Exception (PC=%.6X)",logbuffer[current%EVENTCOUNT][1],logbuffer[current%EVENTCOUNT][2],logbuffer[current%EVENTCOUNT][3],logbuffer[current%EVENTCOUNT][4]);
                                break;
                        case EXODDADDRESS:
                                sprintf(s,"F-%.8X Y-%.3X X-%.3X - Odd Address Exception (PC=%.6X)",logbuffer[current%EVENTCOUNT][1],logbuffer[current%EVENTCOUNT][2],logbuffer[current%EVENTCOUNT][3],logbuffer[current%EVENTCOUNT][4]);
                                break;
                        case EXILLEGAL:
                                sprintf(s,"F-%.8X Y-%.3X X-%.3X - Illegal Instruction Exception (PC=%.6X)",logbuffer[current%EVENTCOUNT][1],logbuffer[current%EVENTCOUNT][2],logbuffer[current%EVENTCOUNT][3],logbuffer[current%EVENTCOUNT][4]);
                                break;
                        case EXDIVBYZERO:
                                sprintf(s,"F-%.8X Y-%.3X X-%.3X - Division by Zero Exception (PC=%.6X)",logbuffer[current%EVENTCOUNT][1],logbuffer[current%EVENTCOUNT][2],logbuffer[current%EVENTCOUNT][3],logbuffer[current%EVENTCOUNT][4]);
                                break;
                        case EXPRIV:
                                sprintf(s,"F-%.8X Y-%.3X X-%.3X - Privilegie Violation Exception (PC=%.6X)",logbuffer[current%EVENTCOUNT][1],logbuffer[current%EVENTCOUNT][2],logbuffer[current%EVENTCOUNT][3],logbuffer[current%EVENTCOUNT][4]);
                                break;
                        case EXTRAP:
                                sprintf(s,"F-%.8X Y-%.3X X-%.3X - TRAP Exception %d (PC=%.6X)",logbuffer[current%EVENTCOUNT][1],logbuffer[current%EVENTCOUNT][2],logbuffer[current%EVENTCOUNT][3],(logbuffer[current%EVENTCOUNT][5]-0x80)/4,logbuffer[current%EVENTCOUNT][4]);
                                break;
                        case EVSTOP:
                                sprintf(s,"F-%.8X Y-%.3X X-%.3X - STOP instruction executed (PC=%.6X)",logbuffer[current%EVENTCOUNT][1],logbuffer[current%EVENTCOUNT][2],logbuffer[current%EVENTCOUNT][3],logbuffer[current%EVENTCOUNT][4]);
                                break;
                        default:
                                sprintf(s,"Unknown Log Event (bug!) found: %d",logbuffer[current%EVENTCOUNT][0]);
                                break;
                                }
                gui_plot_text_window(&fgui_wconsole,s,1,1 + current - start);
                gui_spaces_to_eol(&fgui_wconsole,s,1 + current - start);
                }
}

void fgui_debug_show_evlog(void) {
        int c,current,finished=0,wheight = fgui_wconsole.y2 - fgui_wconsole.y1 - 1;
        gui_clearwindow(&fgui_wconsole,TRUE);
        gui_printwindowborders(&fgui_wconsole);
        if (logfirst != loglast) {
                current = logfirst;
                while (!finished) {
                        fgui_debug_print_evlog(current, ((loglast-current) > wheight) ? (current+wheight):loglast);
                        c = getch();
                        if (c == 27) finished = 1;
                        else if (c == 0) {
                                c = getch();
                                if (c == 72) {
                                        if (current != logfirst) current--;
                                        }
                                else if (c == 80) {
                                        if (current != (loglast-1)) current++;
                                        }
                                else if (c == 73) {  // PGUP
                                        if ((current-wheight) < logfirst) current = logfirst;
                                        else current -= wheight;
                                        }
                                else if (c == 81) { // PGDOWN
                                        if ((current+wheight) > (loglast-1)) current = loglast-1;
                                        else current += wheight;
                                        }
                                }
                        }
                }
        else {
                gui_plot_text_window(&fgui_wconsole,"No events logged",1,1);
                getch();
                }
}

void fgui_debug_cputraceoff(void) {
        cputraceflag = FALSE;
}

void fgui_debug_cputraceon(void) {
        cputraceflag = TRUE;
        cputraceptr = 0;
        cputracecount = 0;
}

void fgui_debug_showcputrace(void) {
        char s[20],strr[80];
        ULO y,mpc,opco;
        int tracepostop;
        union { ULO lo; ULO (*fun)(); } yeah;
        ULO keyz;
        int cputend = 0,traceend;

        gui_clearwindow(&fgui_wconsole,FALSE);
        gui_printwindowborders(&fgui_wconsole);
  
        if (cputraceptr == 0) {
                gui_plot_text_window(&fgui_wconsole,"No cpu trace available",1,1);
                getch();
                return;
                }

        tracepostop = 0;
        if (cputracecount >= 524288) cputracecount = 524288;

        while (!cputend) {
                for (y = 0; y < (fgui_wconsole.y2 - fgui_wconsole.y1 - 1); y++) {
                        if ((tracepostop+y) < cputracecount) {
                                if (cputracecount == 524288) mpc = cputracebuffer[(cputraceptr + tracepostop + y) & 0x7ffff];
                                else mpc = cputracebuffer[(tracepostop + y) & 0x7ffff];
                                opco = fetw(mpc);
                                yeah.lo = t[opco][1];
                                yeah.fun(mpc, opco, strr);
                                gui_plot_text_window(&fgui_wconsole, strr, 1, y + 1);
                                gui_spaces_to_eol(&fgui_wconsole,strr,y+1);
                                }
                        else {
                                strr[0] = 0;
                                gui_spaces_to_eol(&fgui_wconsole,strr,y+1);
                                }
                        if (y == 2) {
                                gui_plot_text_window(&fgui_wconsole,"Trace position:",58,1);
                                sprintf(s, "%d", tracepostop);
                                gui_plot_text_window(&fgui_wconsole, s, 73, 1);
                                gui_plot_text_window(&fgui_wconsole, "Trace length:", 58, 2);
                                sprintf(s, "%d", cputracecount);
                                gui_plot_text_window(&fgui_wconsole, s, 73, 2);
                                }
                        }
                while (!kbhit()) {};
                keyz = getch();
                if (keyz == 27) cputend = 1;
                else if (keyz == 0) {
                        keyz = getch();
                        if (keyz == 71) {
                                tracepostop = 0;
                                }
                        else if (keyz == 79) {
                                tracepostop = cputracecount;
                                }
                        else if (keyz == 72) {
                                if (tracepostop > 0) tracepostop--; 
                                }
                        else if (keyz == 80) {
                                if (tracepostop < cputracecount)
                                        tracepostop++;
                                }
                        else if (keyz == 73) {  // PGUP
                                if ((tracepostop-19) < 0) tracepostop = 0;
                                else tracepostop -= 19;
                                }
                        else if (keyz == 81) { // PGDOWN
                                if ((tracepostop+19) > cputracecount)
                                        tracepostop = cputracecount;
                                else tracepostop += 19;
                                }
                        else if (keyz == 82) {  
                                if ((tracepostop-1000) < 0) tracepostop = 0;
                                else tracepostop -= 1000;
                                }
                        else if (keyz == 83) { 
                                if ((tracepostop+1000) > cputracecount)
                                        tracepostop = cputracecount;
                                else tracepostop += 1000;
                                }
                        }
                }
        
}
#endif

void fgui_run_debugmenu(void) {
        int ended = FALSE;
        int wtop = 24- gui_menu_numberofentries(&fgui_debugmenu);

        if (debug_screentables_not_set) {
                setup_emu_videomode(); /* Debug will crash if not run once */
                gui_setupscreen();
                }

        while (!ended && !exitflag) {
                fgui_wmenu.y1 = wtop;
                fgui_drawscreen_debug(TRUE);
                switch (gui_menu_select(&fgui_debugmenu)) {
                        case 0: /* Step */
                                fellow_step();
                                break;
                        case 1: /* Step over */
                                fellow_step_over();
                                break;
                        case 2: /* Breakpoint */
                                fgui_run_debugbreakmenu();
                                break;
                        case 3: /* Memory  */
                                fgui_debug_memory();
                                break;
                        case 4: /* Cia*/
                                fgui_debug_print_cia();
                                break;
                        case 5: /* IO */
                                fgui_run_debugiomenu();
                                break;
#ifdef DEBUGBUILD
                        case 6: /* Cputrace on */
                                fgui_debug_cputraceon();
                                break;
                        case 7: /* Cputrace off */
                                fgui_debug_cputraceoff();
                                break;
                        case 8: /* Show cputrace */
                                fgui_debug_showcputrace();
                                break;
                        case 9: /* Event log config */
                                gui_optionmenu_run(&fgui_evlog_optionmenu);
                                break;
                        case 10: /* Show Event log */
                                fgui_debug_show_evlog();
                                break;
#endif
                        case 99999:
                                ended = TRUE;
                                break;
                        }
                }
        gui_clearwindow(&fgui_wfullscreen,FALSE);
}

/*===================*/
/* The toplevel menu */
/*===================*/

void fgui_init_topmenu(void) {
        gui_initmenu(&fgui_topmenu,fgui_topmenu_entries,0,&fgui_wmenu,fgui_topmenu_shortcuts);
}

void fgui_run_topmenu(void) {
        int ended = FALSE;
        int wtop = 24- gui_menu_numberofentries(&fgui_topmenu);

        while (!ended && !exitflag) {
                fgui_wmenu.y1 = wtop;
                fgui_drawscreen_normal(FALSE);
                switch (gui_menu_select(&fgui_topmenu)) {
                        case 0: /* Run */
                                fellow_run();
                                gui_setupscreen();
                                gui_clearwindow(&fgui_wfullscreen,TRUE);
                                break;
                        case 1: /* Debugger */
                                fgui_run_debugmenu();
                                break;
                        case 2: /* Configuration */
                                fgui_run_configmenu();
                                break;
                        case 3: /* Soft Reset  */
                                fellow_softreset();
                                if( config_autorun & 2 ) {
                                  fellow_run();
                                  gui_setupscreen();
                                  gui_clearwindow(&fgui_wfullscreen,TRUE);
                                }
                                break;
                        case 4: /* Hard Reset  */
                                fellow_hardreset();
                                if( config_autorun & 2 ) {
                                  fellow_run();
                                  gui_setupscreen();
                                  gui_clearwindow(&fgui_wfullscreen,TRUE);
                                }
                                break;
                        case 5: /* Quit */
                        case 99999:
                                ended = TRUE;
                                break;
                        }
                }
        gui_clearwindow(fgui_topmenu.w,FALSE);
}

void fgui_init_menus(void) {
        menupos_act[0] = 0;
        fgui_init_topmenu();
        fgui_init_configmenu();
        fgui_init_debugmenu();
        fgui_init_debugbreakmenu();
        fgui_init_debugiomenu();
}

void fgui_preenter(void) {
        gui_setupscreen();
        fgui_init_windows();
        fgui_drawscreen_nomenu( TRUE );
}

/* Start GUI, when exited, the emulator ends */

void fgui_enter(void) {
        fgui_init_menus();
        fgui_init_optionmenus();
        gui_clearwindow(&fgui_wconsole, FALSE);

        fellow_hardreset();

        fgui_run_topmenu();
        gui_closescreen();
}
