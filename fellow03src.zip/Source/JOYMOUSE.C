/* Fellow 1997 Petter Schau */
/* Joystick first try       */

/* Slightly inspired by the DOS UAE joystick code */
/* The auto-calibration is not very good, fix me sometime */

#include "defs.h"
#include "fellow.h"
#include "inout.h"
#include "sddsdk\\pmpro.h"


/* Registers */

ULO potgor,pot0dat,pot1dat,joy0dat,joy1dat;

/* Joystickdata */
/* Flags, TRUE or FALSE */

ULO fire1A,fire2A;
ULO joyAleft;
ULO joyAright;
ULO joyAup;
ULO joyAdown;

ULO fire1B,fire2B;
ULO joyBleft;
ULO joyBright;
ULO joyBup;
ULO joyBdown;

/* Config                 */
/*------------------------*/
/* 0 - not emulated */
/* 1 - emulate from keyboard arrows/right CTRL */
/* 2 - emulate from keyboard DFG R left CTRL */
/* 3 - emulate from JOYA */
/* 5 - Mouse             */

ULO config_joyA,config_joyB;
ULO config_joyAfound;
ULO config_mousefound;

/* Other stuff */

int joyAmaxx,joyAmaxy;
int joyAminx,joyAminy;

/* Mouse data                         */
/* Mouse shares fireXX with joystick  */

ULO mouseAx,mouseBx;
ULO mouseAy,mouseBy;

/* Read joystick state and set variables, is only called when */
/* analog joystick is selected */

void read_joysticks(void) {
   int i = 0,j,Ax=0,Ay=0;
   if (config_joyA == 3 || config_joyB == 3) {
        j = inp(0x201);
        if (config_joyA == 3) {          /* Buttons */
                fire1A = !((j>>4)&0x1);
                fire2A = !((j>>5)&0x1);
                }
        if (config_joyB == 3) {
                fire1B = !((j>>4)&0x1);
                fire2B = !((j>>5)&0x1);
                }
        irq_off();
        outp(0x201,0xff);
        do {
               j = inp(0x201);
               Ax += (j & 0x1);
               Ay += ((j & 0x2)>>1);
               } while ( ((j & 0x3) != 0)  && (++i != 65536));
       irq_on();
       if (joyAmaxx < Ax) joyAmaxx = Ax;
       if (joyAmaxy < Ay) joyAmaxy = Ay;
       if (joyAminx > Ax) joyAminx = Ax;
       if (joyAminy > Ay) joyAminy = Ay;
       Ax -= joyAminx;
       Ay -= joyAminy;
       if (config_joyA == 3) { 
                if (Ax < ((joyAmaxx-joyAminx)/3)) joyAleft = 1;
                else joyAleft = 0;
                if (Ax > (((joyAmaxx-joyAminx)/3)*2)) joyAright = 1;
                else joyAright = 0;
                if (Ay < ((joyAmaxy-joyAminy)/3)) joyAup = 1;
                else joyAup = 0;
                if (Ay > (((joyAmaxy-joyAminy)/3)*2)) joyAdown = 1;
                else joyAdown = 0;
                }                
       if (config_joyB == 3) {
                if (Ax < ((joyAmaxx-joyAminx)/3)) joyBleft = 1;
                else joyBleft = 0;
                if (Ax > (((joyAmaxx-joyAminx)/3)*2)) joyBright = 1;
                else joyBright = 0;
                if (Ay < ((joyAmaxy-joyAminy)/3)) joyBup = 1;
                else joyBup = 0;
                if (Ay > (((joyAmaxy-joyAminy)/3)*2)) joyBdown = 1;
                else joyBdown = 0;
                }
    }
}
       

/* Handle joystick keyboard replacements */

/* Arrowkeys, return TRUE if scancode is used */

int joy_keyreplacement1(int scancode) {
       if ((scancode & 0x7f) == 72) {
                if (config_joyA == 1) joyAup = !(scancode & 0x80);
                if (config_joyB == 1) joyBup = !(scancode & 0x80);
                return TRUE;
                }
       else if ((scancode & 0x7f) == 80) {
                if (config_joyA == 1) joyAdown = !(scancode & 0x80);
                if (config_joyB == 1) joyBdown = !(scancode & 0x80);
                return TRUE;
                }
       else if ((scancode & 0x7f) == 77) {
                if (config_joyA == 1) joyAright = !(scancode & 0x80);
                if (config_joyB == 1) joyBright = !(scancode & 0x80);
                return TRUE;
                }
       else if ((scancode & 0x7f) == 75) {
                if (config_joyA == 1) joyAleft = !(scancode & 0x80);
                if (config_joyB == 1) joyBleft = !(scancode & 0x80);
                return TRUE;
                }
       else if ((scancode & 0x7f) == 0x1d) {  /* Right CTRL */
                if (config_joyA == 1) fire1A = !(scancode & 0x80);
                if (config_joyB == 1) fire1B = !(scancode & 0x80);
                return TRUE;
                }
       else if ((scancode & 0x7f) == 0x38) {  /* Right ALT */
                if (config_joyA == 1) fire2A = !(scancode & 0x80);
                if (config_joyB == 1) fire2B = !(scancode & 0x80);
                return TRUE;
                }
       return FALSE;
}


/* DFGR RCTRL */

int joy_keyreplacement2(int scancode) {
       if ((scancode & 0x7f) == 0x13) {
                if (config_joyA == 2) joyAup = !(scancode & 0x80);
                if (config_joyB == 2) joyBup = !(scancode & 0x80);
                return TRUE;
                }
       else if ((scancode & 0x7f) == 0x21) {
                if (config_joyA == 2) joyAdown = !(scancode & 0x80);
                if (config_joyB == 2) joyBdown = !(scancode & 0x80);
                return TRUE;
         }
       else if ((scancode & 0x7f) == 0x22) {
                if (config_joyA == 2) joyAright = !(scancode & 0x80);
                if (config_joyB == 2) joyBright = !(scancode & 0x80);
                return TRUE;
                }
       else if ((scancode & 0x7f) == 0x20) {
                if (config_joyA == 2) joyAleft = !(scancode & 0x80);
                if (config_joyB == 2) joyBleft = !(scancode & 0x80);
                return TRUE;
                }
       else if ((scancode & 0x7f) == 29) {  /* Left CTRL */
                if (config_joyA == 2) fire1A = !(scancode & 0x80);
                if (config_joyB == 2) fire1B = !(scancode & 0x80);
                return TRUE;
                }
       else if ((scancode & 0x7f) == 0x38) {  /* Left ALT */
                if (config_joyA == 2) fire2A = !(scancode & 0x80);
                if (config_joyB == 2) fire2B = !(scancode & 0x80);
                return TRUE;
                }
       return FALSE;
}


/* Find physical joysticks */

void detect_joysticks(void) {
        int i,j;
        char s[80];
        config_joyAfound = 0;
        i = 0;
        irq_off();
        outp(0x201,0xff);
        do {
               j = inp(0x201);
               config_joyAfound += (j & 0x1);
               } while (++i != 65535);
        irq_on();
        config_joyAfound = (config_joyAfound != 65535) ? 1:0;
        joyAmaxx = joyAmaxy = 0;
        joyAminx = joyAminy = 65536;
}

/* Clear variables and detect physical joysticks */
/* Called once during emulator startup */

void init_joysticks(void) {
        fire1A = 0;
        fire2A = 0;
        joyAleft = 0;
        joyAright = 0;
        joyAup = 0;
        joyAdown = 0;
        fire1B = 0;
        fire2B = 0;
        joyBleft = 0;
        joyBright = 0;
        joyBup = 0;
        joyBdown = 0;
        detect_joysticks();
}




/* Mouse handler */

void PMAPI mymousehandler(uint event, uint butstate, uint x, uint y, uint mickeyX, uint mickeyY) {
        if (config_joyA == 5) {
                fire1A = butstate & 0x1;
                fire2A = (butstate & 0x2)>>1;
                joy0dat = (((mickeyX)>>2)&0xff) | ((((mickeyY)>>1)&0xff)<<8);
                if ((fire2A == 0) && ((butstate & 0x2) == 0x2))
                        pot0dat = (pot0dat + 0x100) & 0xffff; 
                }
        if (config_joyB == 5) {
                fire1B = butstate & 0x1;
                fire2B = (butstate & 0x2)>>1;
                joy1dat = (((mickeyX)>>2)&0xff) | ((((mickeyY)>>1)&0xff)<<8);
                if ((fire2B == 0) && ((butstate & 0x2) == 0x2))
                        pot1dat = (pot1dat + 0x100) & 0xffff; 
                }
}

/* Sets our mouse irq handler, and clears variables */
/* Called before any emulation is started           */

void init_mouseirq(void) {
        fire1A = fire1B = 0;
        fire2A = fire2B = 0;
        joyAup = joyAdown = joyAright = joyAleft = 0;
        joyBup = joyBdown = joyBright = joyBleft = 0;
        PM_setMouseHandler(0xff,mymousehandler);
}

void restore_mouseirq(void) {
        restore_kbdirq();
        PM_restoreMouseHandler();
}

void reset_mouse(void) {
        potgor = 0xffff;
        pot0dat = pot1dat = 0;
        fire1A = fire1B = 0;
        fire2A = fire2B = 0;
        joyAup = joyAdown = joyAright = joyAleft = 0;
        joyBup = joyBdown = joyBright = joyBleft = 0;
}



