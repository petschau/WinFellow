/* Fellow */
/* Petter Schau 1997 */

#include "defs.h"
#include "68000.h"

ULO debugging;
ULO curcycle;

