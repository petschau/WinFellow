#include "defs.h"
#include "memory.h"
#include "sounda.h"           /* Symbols from sounda.asm */

ULO left[4],right[4];         /* Temorary buffer for samples */

ULO audioodd = 0;    /* Used for skipping bytes in 22050 */

ULO config_sound_mode;  /* 0 - 16, as described below */
ULO config_sound;       /* 0 - none, 1 - normal, 2 - conti, 3 - only emulate */
ULO config_soundcard_found;  /* Set TRUE by sound-driver */

/* Callback routines for adding samples to souncard specific buffers */
/* Set by soundcard driver, called during emulation */

add_sample_to_buffer_routine config_sound_bufferroutines[16];

/* Callback to play buffer */

playbuffer_routine sound_playbuffer;

/* Callback routines for setup of a specific sound-mode */
/* Called when the emulator (user) changes the sound-mode */
/* The soundcard driver can then do any adjustments */

setup_soundmode_routine config_sound_setuproutines[16];

/* Callbacks called before and after emulation is started/stopped */

sound_before_emu_routine sound_before_emu;
sound_after_emu_routine  sound_after_emu;

ULO configaudiomodesetbylog;
ULO audio_hblanks;
ULO audio_hblanks_thisbuffer;
ULO sound_framecounter;                 /* Count 5 frames, and then play */

ULO audiocounter;                       /* Used in 44100 to decide samples */

/*
 Sound-modes available, flagged with true or false

 0  - 44100 stereo 16 bit
 1  - 31300 stereo 16 bit
 2  - 22050 stereo 16 bit
 3  - 15650 stereo 16 bit
 4  - 44100 mono 16 bit
 5  - 31300 mono 16 bit
 6  - 22050 mono 16 bit
 7  - 15650 mono 16 bit
 8  - 44100 stereo 8 bit
 9  - 31300 stereo 8 bit
 10 - 22050 stereo 8 bit
 11 - 15650 stereo 8 bit
 12 - 44100 mono 8 bit
 13 - 31300 mono 8 bit
 14 - 22050 mono 8 bit
 15 - 15650 mono 8 bit

*/

ULO config_soundmodes[16];


/* Callback pointers used by emulation to produce sound */

ULO audio_handler;          /* Frequency handler called from end_of_line */

/* Called by frequency handler (card specific) */

add_sample_to_buffer_routine audio_putinbuffer;

/* These are external registers */

ULO audpt[4];
ULO audlen[4];
ULO audper[4];
ULO audvol[4];
ULO auddat[4];

/* These are internal registers */

ULO audlenw[4];                 // Length counted down
ULO audperconstant[4];          // Period constant used for counting down percounter
ULO audpercounter[4];  
ULO auddatw[4];                 // When this reg is loaded from auddat, ADL is set 
ULO audstate[4];
ULO auddma[4];
ULO audadl[4];                  // Audio data load signal (to dma controller)
ULO audvolw[4];                 // Internal volume control
ULO audptw[4];

ULO periodtable[65536];
WOR volumes[256][64];
ULO audioirqmask[4] = {0x0080,0x0100,0x0200,0x0400};
ULO audiodmaconmask[4] = {0x1,0x2,0x4,0x8};

ULO audstatejmptable[6] = {(ULO) audiostate0,(ULO) audiostate1,(ULO) audiostate2,(ULO)audiostate3,(ULO) audiostate4,(ULO)audiostate5};

void sound_callback_dummy(void) {};

/* Must be called every time sound quality is changed */

void initvolumetable(void) {
        int i,j,s;

        if (config_sound_mode & 0x4) s = 1;    /* Mono */
        else s = 2;                            /* Stereo */

        for (i= -128; i< 128; i++) 
                for (j=0; j< 64; j++) {
                        if (j == 0)
                                volumes[(i&0xff)][j] = 0;
                        else
                                volumes[(i&0xff)][j] = i*j*s;
                        }
}

/* Must be called every time sound_quality is changed */
/* baseperiod is the output frequency */

void initperiodtable(ULO baseperiod) {
        double j;
        int i;

        periodtable[0] = 0x10000;
        for (i = 1; i < 65536; i++) {
                j = 3568200/i;                  /* Sample rate */
                periodtable[i] = (ULO) ((j*65536)/baseperiod);
                if (periodtable[i] > 0x10000) periodtable[i] = 0x10000;
                }
}

/* Called whenever a new sound quality is selected */
/* Call the sound card init routine for this quality */

void sound_initmode(void) {
        audiocounter = 0;
        if (config_sound == 3) {
                initperiodtable(31300);
                audio_handler = (ULO) audio_frequency_handler_15650;
                audio_putinbuffer = (add_sample_to_buffer_routine)sound_callback_dummy;
                sound_playbuffer = sound_callback_dummy;
                sound_before_emu = sound_callback_dummy;
                sound_after_emu = sound_callback_dummy;
                }
        else {
                initperiodtable((*config_sound_setuproutines[config_sound_mode])());
                initvolumetable();
                switch ((config_sound_mode & 0x3)) {
                        case 0: audio_handler = (ULO) audio_frequency_handler_44100;
                                break;
                        case 1: audio_handler = (ULO) audio_frequency_handler_31300;
                                break;
                        case 2: audio_handler = (ULO) audio_frequency_handler_22050;
                                break;
                        case 3: audio_handler = (ULO) audio_frequency_handler_15650;
                                break;
                        }
                audio_putinbuffer = config_sound_bufferroutines[config_sound_mode];
                }
}

void sound_clear_callbacks(void) {
        int i;

        for (i = 0; i < 16; i++) {
                config_sound_bufferroutines[i] = (add_sample_to_buffer_routine)sound_callback_dummy;
                config_sound_setuproutines[i] = (setup_soundmode_routine)sound_callback_dummy;
                config_soundmodes[i] = FALSE;
                }
        sound_playbuffer = sound_callback_dummy;
        sound_before_emu = sound_callback_dummy;
        sound_after_emu = sound_callback_dummy;
}

/* Called every time we do a hard-reset */

void sound_reset(void) {
        int i;

        for (i = 0; i < 4; i++) {
                audpt[i] = 0;
                audptw[i] = 0;
                audlen[i] = 2;
                audper[i] = 0;
                audvol[i] = 0;
                audpercounter[i] = 0;
                audperconstant[i] = 0;
                auddat[i] = 0;
                auddatw[i] = 0;
                audlenw[i] = 2;
                audstate[i] = 0;
                auddma[i] = 0;
                audadl[i] = 0;
                audvolw[4] = 0;
                iowrite[(0xa0>>1) + (0x8*i)] = waudXpth;
                iowrite[(0xa2>>1) + (0x8*i)] = waudXptl;
                iowrite[(0xa4>>1) + (0x8*i)] = waudXlen;
                iowrite[(0xa6>>1) + (0x8*i)] = waudXper;
                iowrite[(0xa8>>1) + (0x8*i)] = waudXvol;
                }
        audio_hblanks = 0;
        audio_hblanks_thisbuffer = 0;
}

/* Called once, and before any soundcard setup */

void soundinit(void) {
        sound_reset();
        sound_clear_callbacks();
        config_soundcard_found = FALSE;
}

