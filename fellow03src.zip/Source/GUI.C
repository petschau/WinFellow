/*==================================================*/
/* The gui core is here                             */
/* For the Amiga emulator Fellow,                   */
/* Petter Schau, Roman Dolejsi 1997                 */
/*==================================================*/

#include <stdio.h>
#include <conio.h>
#include <graph.h>
#include <direct.h>
#include <dos.h>

#include "defs.h"
#include "gui.h"

/* text buffer for various operations */

static char gtxt[256];

char memnames[10][256];    // Disk memories
char config_diskpath[256]; // Saved disk path
char act_item[128];        // Actual item
char menupos_act[128];     // Actual Menu position
char menupos_want0[128];   // First wanted menu (often the desired function)
char menupos_want1[128];   // Second wanted menu (when defined, want0 also executed)
ULO config_altn_loop;      // Alt-N drive cycling
ULO config_store_mpos;     // Menu position storing on exit
ULO config_autorun;        // Automatic Run after command

/* Window specific routines */

/* Generic text-plot, used by print_text_window */

void gui_plot_text(char *text,ULO x, ULO y, UBY fgcolor, UBY bgcolor) {
        _settextposition(y,x);
        _settextcolor(fgcolor);
        _setbkcolor(bgcolor);
        _outtext(text);
}

/* Clear window */

void gui_clearwindow(struct gui_window *w, int borderclear) {
        ULO i,bc;

        bc = !borderclear;
        for (i = 0; i < (w->x2 - w->x1 + 1 - 2*bc); i++) gtxt[i] = ' ';
        gtxt[w->x2 - w->x1 + 1] = '\0';
        _setbkcolor(w->bgcolor);
        for (i = w->y1 + 1; i <= w->y2 - 1; i++) {
                _settextposition(i,w->x1 + bc);
                _outtext(gtxt);
                }
}

void gui_printwindowborders(struct gui_window *w) {
        int i;

        _settextcolor(BORDERCOL);
        _setbkcolor(w->bgcolor);
        _settextposition(w->y1,w->x1);
        if (w->cornerflags & TOPLEFT) _outtext("�");
        else _outtext("�");
        _settextposition(w->y2,w->x1);
        if (w->cornerflags & BOTLEFT) _outtext("�");
        else _outtext("�");
        _settextposition(w->y1,w->x2);
        if (w->cornerflags & TOPRIGHT) _outtext("�");
        else _outtext("�");
        _settextposition(w->y2,w->x2);
        _outtext("�");
        for (i = w->y1 + 1; i < w->y2; i++) {
                _settextposition(i, w->x1);
                _outtext("�");
                _settextposition(i, w->x2);
                _outtext("�");
                }
        for (i = 0; i < (w->x2 - w->x1 - 1); i++) gtxt[i] = '�';
        gtxt[w->x2 - w->x1 - 1] = '\0';
        _settextposition(w->y1, w->x1 + 1);
        _outtext(gtxt);
        _settextposition(w->y2, w->x1 + 1);
        _outtext(gtxt);
}

/* Plot text in window, normal or reverse */

void gui_plot_text_window(struct gui_window *w,char *s,ULO x,ULO y) {
        gui_plot_text(s,x+w->x1,y+w->y1,w->fgcolor,w->bgcolor);
}

void gui_plot_text_window_shortcut(struct gui_window *w,char *s,ULO x,ULO y,ULO shortcutpos) {
        int i;
        i = s[shortcutpos];
        s[shortcutpos] = 0;
        gui_plot_text(s,x+w->x1,y+w->y1,w->fgcolor,w->bgcolor);
        gui_plot_text(&s[shortcutpos + 1],x+w->x1+shortcutpos+1,y+w->y1,w->fgcolor,w->bgcolor);
        s[shortcutpos] = i;
        i = s[shortcutpos+1];
        s[shortcutpos+1] = 0;
        gui_plot_text(&s[shortcutpos],x+w->x1+shortcutpos,y+w->y1,w->shortcutcolor,w->bgcolor);
        s[shortcutpos+1] = i;
}

void gui_plot_text_window_reverse(struct gui_window *w,char *s,ULO x,ULO y) {
        gui_plot_text(s,x+w->x1,y+w->y1,w->fgcolor,7);
}

void gui_plot_text_window_reverse_shortcut(struct gui_window *w,char *s,ULO x,ULO y,ULO shortcutpos) {
        int i;
        i = s[shortcutpos];
        s[shortcutpos] = 0;
        gui_plot_text(s,x+w->x1,y+w->y1,w->fgcolor,w->reversecolor);
        gui_plot_text(&s[shortcutpos + 1],x+w->x1+shortcutpos+1,y+w->y1,w->fgcolor,w->reversecolor);
        s[shortcutpos] = i;
        i = s[shortcutpos+1];
        s[shortcutpos+1] = 0;
        gui_plot_text(&s[shortcutpos],x+w->x1+shortcutpos,y+w->y1,w->shortcutcolor,w->reversecolor);
        s[shortcutpos+1] = i;
}

void gui_spaces_to_eol(struct gui_window *w, char *s, ULO y) {
        int i,j = strlen(s);

        for (i = 0; i < (78 - j); i++) s[i] = ' ';
        s[i] = 0;
        gui_plot_text_window(w,s,j + 1, y);
}

/*==============*/
/* Number field */
/*==============*/

void gui_initnumberfield(struct gui_numberfield *n,struct gui_window *w,ULO v,ULO x,ULO y) {
        n->hostwindow = w;
        n->x = x;
        n->y = y;
        n->value = v;
}

void gui_numberfield_enter(struct gui_numberfield *n) {
        char tall[10];
        ULO unchanged = 1, finished = 0,cursor = 0,c;
        sprintf(tall,"%X",n->value);
        gui_plot_text_window(n->hostwindow,tall,n->x,n->y); 
        while (!finished) {
                c = getch();
                if (c == 13) { // RET
                        finished = TRUE;
                        }
                else if ((c >= '0' && c <= '9') || (c >= 'a' && c <= 'f')) { // NUMBER
                        if (unchanged) {
                                unchanged = 0;
                                tall[0] = 0;
                                gui_plot_text_window(n->hostwindow,"        ",n->x,n->y);
                                }
                        if (cursor < 8) {
                                tall[cursor++] = c;
                                tall[cursor] = 0;
                                }      
                        gui_plot_text_window(n->hostwindow,tall,n->x,n->y);
                        }
                else if (c == 8) {  // DEL
                        if (!unchanged) {
                                if (cursor > 0) {
                                        tall[--cursor] = ' ';
                                        gui_plot_text_window(n->hostwindow,tall,n->x,n->y);
                                        tall[cursor] = 0;
                                        }
                                }
                        }
                }
        sscanf(tall,"%X",&(n->value));
}



/* Filerequester */
/* One directory entry in a list */

typedef struct dt_entstruct {
  struct dt_entstruct *next;
  struct dt_entstruct *prev;
  char name[13];
  UBY dir;
} dt_filelist;

char dt_path[256];          /* Current path */
char dt_origpath[256];          /* Original path */
int dt_firsttime = TRUE;         /* Flag to indicate the first time we enter */
unsigned dt_origdrv;
unsigned dt_curdrv;
UBY drivesavailable[27];
int drivesmap[51] = { 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
                      0, 0, 0, 0, 0, 0, 17, 23, 5, 18,
                      20, 25, 21, 9, 15, 16, 0, 0, 0, 0,
                      1, 19, 4, 6, 7, 8, 10, 11, 12, 0,
                      0, 0, 0, 0, 26, 24, 3, 22, 2, 14, 13 };

void dt_freefilelist(dt_filelist *fl) {
  dt_filelist *fl1,*fl2;

  fl1 = fl;
  while (fl1 != NULL) {
    fl2 = fl1->next;
    free(fl1);
    fl1 = fl2;
    }
}

dt_filelist *dt_allocitem(void) {
        dt_filelist *ftmp;
        ftmp = (dt_filelist*) malloc(sizeof(dt_filelist));
        if (ftmp == NULL) {
          printf("Malloc error\n");
          exit(1);
          }
        ftmp->prev = ftmp->next = NULL;
        return ftmp;
}

dt_filelist *dt_sortedinsert(dt_filelist *head,dt_filelist *fl) {
  dt_filelist *t;
  int done = 0;

  if (head == NULL) {                /* Empty list */
        head = fl;
        head->prev = head->next = NULL;
        }
  else {                                /* Not empty  */
        t = head;
        while (!done) {
          if (strcmp(fl->name,t->name) > 0) {   /* Check next */
            if (t->next != NULL) t = t->next;
            else {  /* End of list, insert item at tail */
                fl->next = NULL;
                fl->prev = t;
                t->next = fl;
                done = TRUE;
                }
            }
          else {        /* Insert before t */
            fl->next = t;
            fl->prev = t->prev;
            if (t->prev != NULL) t->prev->next = fl;
            else head = fl;
            t->prev = fl;
            done = TRUE;
            }
        }
    }
 return head;
}

dt_filelist *dt_joinlists(dt_filelist *first,dt_filelist *second) {
        dt_filelist *tmp;

        if (first == NULL) return second;
        else if (second == NULL) return first;
        else {
                tmp = first;
                while (tmp->next != NULL) tmp = tmp->next;
                tmp->next = second;
                second->prev = first;
                }
        return first;
}

/* Will return a directory listing of the directories in the path specified */

dt_filelist *dt_getdirs(char *path) {
  DIR *mydir;
  struct dirent *myent;
  dt_filelist *fl,*fltmp,*flist;

  flist = fl = fltmp = NULL;
  mydir = opendir(path);
  if (mydir != NULL) {
    while ((myent = readdir(mydir)) != NULL) {
      if (myent->d_attr & _A_SUBDIR) {
        fl = dt_allocitem();
        fl->dir = 1;
        strcpy(fl->name,myent->d_name);
        strlwr(fl->name);
        flist = dt_sortedinsert(flist,fl);
        }
      }
    closedir(mydir);
    }
  return flist;
}

dt_filelist *dt_getfiles(char *path,char *suffix) {
  DIR *mydir;
  struct dirent *myent;
  dt_filelist *fl,*fltmp,*tmplist,*newfl;
  char ourpath[256];
  int i,j;

  if( !strcmpi( suffix, "adf" ) ) j = 6;
  else j = 1;

  for (i = 0; i < j; i++) {
    strcpy(&ourpath,path);

    if (ourpath[strlen(&ourpath)-1] != '\\') strcat(&ourpath,"\\*.");
    else strcat(&ourpath,"*.");
    if (i == 5) strcat(&ourpath,"bz2");
    else if (i == 4) strcat(&ourpath,"bz");
    else if (i == 3) strcat(&ourpath,"gz");
    else if (i == 2) strcat(&ourpath,"z");
    else if (i == 1) strcat(&ourpath,"adz");
    else strcat(&ourpath,suffix);
    if (i == 0) tmplist = NULL;

    mydir = opendir(&ourpath);
    if (mydir != NULL) {
      while ((myent = readdir(mydir)) != NULL) {
        if (!(myent->d_attr & _A_SUBDIR) && !(myent->d_attr & _A_HIDDEN) &&
            !(myent->d_attr & _A_SYSTEM) && !(myent->d_attr & _A_VOLID)) {
          fl = dt_allocitem();
          fl->dir = 0;
          strcpy(fl->name,myent->d_name);
          strlwr(fl->name);

          tmplist = dt_sortedinsert(tmplist,fl);
          }
        }
      }
    closedir(mydir);
    }
  return tmplist;
}

dt_filelist *dt_drives(void) {
  dt_filelist *ftmp,*dl;
  int i;

  dl = NULL;
  for (i = 1; i < 27; i++) {
        if (drivesavailable[i]) {
           ftmp = dt_allocitem();
           ftmp->name[0] = i + 0x40;
           ftmp->name[1] = ':';
           ftmp->name[2] = 0;
           ftmp->dir = 2;
           dl = dt_sortedinsert(dl,ftmp);
           }
        }
  return dl;
}


int dt_countfilelist(dt_filelist *fl) {
  int i = 0;
  dt_filelist *t = fl;
  while (t != NULL) {
    i++;
    t = t->next;
    }
  return i;
}

void dt_print_entries( struct gui_window *w, dt_filelist *fl, char *fstr,
                       int max, int may, int x, int y, int numcols ) {
    dt_filelist *t;
    int i,j,firstvisible,lastvisible;
    char s[127];
    char fstr2[30];

    if (x < max) firstvisible = 0;
    else firstvisible = x - (x % max);
    if (x < max) lastvisible = max;
    else lastvisible = firstvisible + max;
    t = fl;
    for (i = 0; i < firstvisible + max; i++) {
      for (j = 0; j < may; j++) {
        if (t != NULL) {
	  if (i >= firstvisible && i < lastvisible) {
            if (t->dir == 1) {
              strupr( t->name );
              sprintf(&s,"%-12s DIR",t->name);
              strlwr( t->name );
            } else sprintf(&s,"%-12s    ",t->name);
            if (x == i && y == j)
              gui_plot_text_window_reverse(w,&s,(i-firstvisible)*17 + 6,j + 1);
            else gui_plot_text_window(w,&s,(i-firstvisible)*17 + 6,j + 1);
	    }
	  t = t->next;
          }
        else if (i >= firstvisible && i < lastvisible)
          gui_plot_text_window(w,"                 ",(i-firstvisible)*17 + 6,j + 1);
        }
      }
    strcpy( &fstr2, fstr );
    while( strlen( &fstr2 ) < 8 ) strcat( &fstr2, "." );
    sprintf( &s, "Quickfind [%s] Path %s", &fstr2, dt_path );
    gui_plot_text_window(w,&s,5,w->y2-w->y1);
    if (firstvisible != 0) gui_plot_text_window(w,"<---",1,may);
    else gui_plot_text_window(w,"    ",1,may);
    if ((firstvisible+max) < numcols) gui_plot_text_window(w,"--->",w->x2-5,may);
    else gui_plot_text_window(w,"    ",w->x2-5,may);
}

dt_filelist *dt_find_entry(dt_filelist *t,int x,int y,int may) {
  dt_filelist *i;
  int j;

  i = t;
  j = x*may+y;
  if (t == NULL) return NULL;
  else {
    while (j-- != 0) {
      i = i->next;
      if (i == NULL) return NULL;
      }
    }
  return i;
}

int dt_search_dups( dt_filelist *fl, char *fstr ) {
  int num = 0;

  while( fl != NULL ) {
    if( !strncmp( fl->name, fstr, strlen( fstr ) ) ) num++;
    fl = fl->next;
  };
  return num;
}

char *dt_search_first( dt_filelist *fl, char *fstr ) {
  int found = 0;

  while( fl != NULL && !found ) {
    if( !strncmp( fl->name, fstr, strlen( fstr ) ) ) found++;
    else fl = fl->next;
  };
  return fl->name;
}

void dt_print_msg( struct gui_window *w, char *str ) {
  char tmpstr[80];
  int i;

  tmpstr[0] = 0;
  gui_clearwindow( w , FALSE);
  gui_plot_text_window( w, str, ( 76 - strlen( str ) ) / 2, 10 );
  delay( 350 );
  for( i = 0; i < strlen( str ); i ++ ) strcat( &tmpstr, " " );
  gui_plot_text_window( w, &tmpstr, ( 76 - strlen( str ) ) / 2, 10 );
}

int dt_search_entry( dt_filelist *fl, char *fstr ) {
  dt_filelist *flp = fl;
  int found, num;

  found = num = 0;
  while( flp != NULL && !found ) {
    if( !strncmp( flp->name, fstr, strlen( fstr ) ) ) {
      found++;
    } else {
      num++; flp = flp->next;
    };
  };
  if( !found ) num = -1;
  else {
    found = dt_search_dups( fl, fstr );
/*    while( dt_search_dups( fl, fstr ) == found ) {
      if( strlen( dt_search_first( fl, fstr ) ) > strlen( fstr ) )
        strncat( fstr, &(dt_search_first( fl, fstr )[ strlen( fstr ) ]), 1 );
      else strcat( fstr, " " ); */
    while( dt_search_dups( fl, fstr ) == found &&
           strcmp( dt_search_first( fl, fstr ), fstr ) ) {
      strncat( fstr, &(dt_search_first( fl, fstr )[ strlen( fstr ) ]), 1 );
      if( fstr[ strlen( fstr ) - 1 ] == '.' || strlen( fstr ) > 8 ) found = 0;
    };
    fstr[ strlen( fstr ) - 1 ] = 0;
  };
  return num;
}

dt_filelist *dt_print_and_select(struct gui_window *w,dt_filelist *fl,int presel) {
  int lasty,numcol,selection,key,x,y,maxcol,may,nument,esc;
  char fstr[30];
  char s[128];
  dt_filelist *fl2;

  /* Init */
  gui_clearwindow(w,FALSE);
  x = y = fstr[0] = fstr[19] = selection = esc = 0;
  fstr[18] = ':';

  /* Find how many entries fit on one line */
  /* And how many lines of entries there are */

  maxcol = (w->x2 - w->x1) / 17;
  nument = dt_countfilelist(fl);
  if (nument < (w->y2 - w->y1 - 1)) may = nument;
  else may = (w->y2 - w->y1 - 1);
  if (nument != may) numcol = (nument / may)+1;
  else numcol = 1;
  lasty = nument - ((numcol-1)*may);
  if( presel == -1 ) presel++;
  x = presel / may;
  y = presel - x * may;

  /* Will loop until a file is selected or Esc is pressed */
    /* Select loop */

    while( !selection && !esc ) {
      dt_print_entries( w, fl, fstr, maxcol, may, x, y, numcol );
      key = getch();
      if (key == 0) {
        key = getch();
        if (key == 80) {                // Down
          if( x == numcol-1 ) {
            if( y < lasty-1 ) y++;
          } else {
            if( y < may-1 ) y++;
            else { x++; y = 0; };
          };
        } else if (key == 81) {         // PageDown
          if( x < numcol - 1 ) {
            if( y + 10 < may ) y += 10;
            else {
              x++;
              y = 10 - may + y;
              if( x == numcol - 1 && y > lasty - 1 ) y = lasty - 1;
            };
          } else {
            if( y + 10 < lasty ) y += 10;
            else y = lasty - 1;
          };
        } else if( key == 72 ) {        // Up
          if( y > 0 ) y--;
          else if( x > 0 ) {
            y = may - 1;
            x--;
          };
        } else if( key == 73 ) {        // PageUp
          if( y - 10 >= 0 ) y -= 10;
          else if( x > 0 ) {
            x--;
            y = may - 10 + y;
          } else y = 0;
        } else if( key == 75 ) {        // Left
          if( x > 0 ) x--;
          else y = 0;
        } else if( key == 77 ) {        // Right
          if( x == numcol - 1 ) y = lasty - 1;
          if( x < numcol - 1 ) x++;
          if( x == numcol - 1 && y > lasty - 1 ) y = lasty - 1;
        } else if( key == 71 ) {        // Home
          x = 0; y = 0;
        } else if( key == 79 ) {
          x = numcol - 1;
          y = lasty - 1;
        } else if( ( key > 15 && key < 26 ) ||  // Alt + drive letter
                   ( key > 29 && key < 39 ) ||
                   ( key > 43 && key < 51 ) ) {
          if( drivesavailable[ drivesmap[ key ] ] ) {
            fstr[ 18 ] = ':';
            fstr[ 17 ] = 'A' + drivesmap[ key ] - 1;
            selection = dt_search_entry( fl, &fstr[17] );
            if( selection == -1 ) selection++;
            x = selection / may;
            y = selection - x * may;
            selection = 1;
          }
        } else if( key > 119 && key < 130 ) {   // disk name memory
          strcpy( memnames[key - 120], dt_path );
          strcat( memnames[key - 120], "\\" );
          strcat( memnames[key - 120], dt_find_entry( fl, x, y, may )->name );
          sprintf( &s, "Disk memory %i updated to %s", ( key == 129 ) ? 0 : key - 119, memnames[key - 120] );
          dt_print_msg( w, &s );
          if( x == numcol-1 ) {                 // advance one item
            if( y < lasty-1 ) y++;
          } else {
            if( y < may-1 ) y++;
            else { x++; y = 0; };
          };
        } else if( key == 41 ) {                // disk name memory clear
          for( esc = 0; esc < 10; esc++ ) strcpy( memnames[esc], "__None__" );
          dt_print_msg( w, "All disk memory cleared" );
          esc = 0;
        }
      } else if( ( ( key > 0x30 && key < 0x3a ) ||    // quick find
                   ( key > 0x40 && key < 0x7b ) ) &&
                   strlen( &fstr ) < 8 ) {
        esc = strlen( &fstr );
        fstr[ esc ] = key;
        fstr[ esc + 1 ] = 0;
        strlwr( fstr );
        if( ( esc = dt_search_entry( fl, &fstr ) ) != -1 ) {
          x = esc / may;
          y = esc - x * may;
        } else fstr[ strlen( &fstr ) - 1 ] = 0;
        esc = 0;
      } else if( key == 8 && strlen( &fstr ) > 0 ) {   // BackSpace
        esc = dt_search_dups( fl, &fstr );
        fstr[ strlen( &fstr ) - 1 ] = 0;
        if( esc == dt_search_dups( fl, &fstr ) ) {
          if( strlen( &fstr ) > 0 ) {
            esc = dt_search_dups( fl, &fstr );
            while( dt_search_dups( fl, &fstr ) == esc && strlen( &fstr ) > 0 )
              fstr[ strlen( &fstr ) - 1 ] = 0;
          };
        }; esc = 0;
      } else if( key == 13 ) {
        selection++;                    // Enter => selection made
      } else if( key == 27 ) esc = 1;   // Esc => quit
    }

  fl2 = dt_find_entry( fl, x, y, may );
  strcpy( act_item, fl2->name );
  if( selection ) return fl2;
  return NULL;
}

void dt_selectfile(struct gui_window *w, char *suffix, char *s) {
        int imageselected = FALSE;
        unsigned drv, tot, i, j, sel = 0;
        char *tmps;
        /* The directory list */

        dt_filelist *sent, *fl = NULL;

        /* Save our original path */

        if (dt_firsttime) {
                dt_firsttime = FALSE;
                strcpy( act_item, "." );
                getcwd( dt_origpath, 256 );
                _dos_getdrive(&dt_origdrv);
                if( config_diskpath[0] ) {
                  if( ( tmps = (char *)strrchr( config_diskpath, '/' ) ) ) {
                    strcpy( act_item, &tmps[1] );
                    tmps[0] = 0;
                  };
                  if( !chdir(config_diskpath) )
                    strcpy( dt_path, config_diskpath );
                  else {
                    strcpy( dt_path, dt_origpath );
                    strcpy( act_item, "." );
                  };
                } else strcpy( dt_path, dt_origpath );
                dt_curdrv = toupper( dt_path[0] ) - 'A' + 1;
                for (i = 1; i < 27; i++) {
                        _dos_setdrive(i, &tot);
                        _dos_getdrive(&j);
                        if (j == i) drivesavailable[i] = TRUE;
                        else drivesavailable[i] = FALSE;
                        }
                }
        _dos_setdrive(dt_curdrv, &tot);

        while (!imageselected) {
                chdir(dt_path);

                /* Build list of directories in current dir */

                fl = NULL;
                fl = dt_joinlists(fl, dt_getdirs(dt_path));
                fl = dt_joinlists(fl, dt_getfiles(dt_path, suffix));
                fl = dt_joinlists(fl, dt_drives());

                sent = dt_print_and_select(w, fl, dt_search_entry( fl, act_item ) );
                if (sent == NULL) {
                        imageselected = TRUE;
                        }
                else if (sent->dir == 1) {
                        /* directory selected */

                        if (dt_path[strlen(dt_path) - 1] != '\\')
                                strcat(dt_path, "\\");
                        strcat(dt_path, sent->name);
                        chdir(dt_path);
                        getcwd(dt_path, 256);
                        strcpy( act_item, "." );
                        dt_freefilelist(fl);
                        gui_printwindowborders(w);
                        }
                else if (sent->dir == 2) {
                        /* new drive selected */
                        drv = (ULO) sent->name[0] & 0x1f;
                        _dos_setdrive(drv, &tot);
                        getcwd(dt_path, 256);
                        _dos_getdrive(&dt_curdrv);
                        strcpy( act_item, "." );
                        dt_freefilelist(fl);
                        gui_printwindowborders(w);
                        }
                else {
                        /* Image selected */
                        /* Copy name to string */
                        if (strcmp(sent->name, "__None__")) {
                                if (dt_path[strlen(dt_path) - 1] != '\\')
                                        sprintf(s, "%s\\%s", dt_path, sent->name);
                                else sprintf(s, "%s%s", dt_path, sent->name);
                                }
                        else strcpy(s, "__None__");
                        imageselected = 1;
                        }
                }
        strcpy( config_diskpath, dt_path );
        strcat( config_diskpath, "/" );
        strcat( config_diskpath, act_item );
        _dos_setdrive(dt_origdrv, &tot);
        chdir(dt_origpath);
        dt_freefilelist(fl);
        gui_clearwindow(w,FALSE);
        gui_printwindowborders(w);
}

/* End of file-requester */

/*=============*/
/* Optionmenus */
/*=============*/

/* Initialize an optionmenu structure */

void gui_initoptionmenu(struct gui_optionmenu *om,char *topheader,char **headers,UBY *actions,void *vars,char ***texts,void **vals,struct gui_window *w,UBY *shortcuts) {
        om->topheader = topheader;
        om->headers = headers;
        om->actions = actions;
        om->vars = vars;
        om->texts = texts;
        om->vals = vals;
        om->w = w;
        om->shortcuts = shortcuts;
}

ULO gui_optionmenu_textcount(char **headers) {
        ULO i = 0;

        while (headers[i] != NULL) i++;
        return i;
}

ULO gui_optionmenu_maxheadlen(struct gui_optionmenu *om, ULO n) {
        ULO i,j = 0,k;

        for (i = 0; i < n; i++) {
                k = strlen(om->headers[i]);
                if (k > j) j = k;
                }
        return j + 2;
}

ULO gui_optionmenu_getactivevalue(ULO *var, ULO *vals, ULO numberofvals) {
        ULO i = 0;

        while (i < numberofvals) {
                if (*var == vals[i]) return i;
                else i++;
                }
        return 0;
}

char *gui_optionmenu_getactivetext(ULO *var, ULO *vals,char **texts) {
        return texts[gui_optionmenu_getactivevalue(var, vals, gui_optionmenu_textcount(texts))];
}

void gui_optionmenu_printitem(struct gui_optionmenu *om, ULO n, ULO optpos, ULO activeflag, ULO yadjust) {
        gui_plot_text_window_shortcut(om->w,om->headers[n],1,n+3+yadjust,om->shortcuts[n]);
        switch (om->actions[n]) {
                case GUI_FILEREQ_ROM:
                case GUI_FILEREQ_ADF:
                case GUI_FILEREQ_HDF:
                        if (!activeflag) gui_plot_text_window(om->w,((char **)om->vars)[n],optpos,n+3+yadjust);
                        else gui_plot_text_window_reverse(om->w,((char **)om->vars)[n],optpos,n+3+yadjust);
                        break;
                case GUI_VALUELIST:
                        if (!activeflag) gui_plot_text_window(om->w,gui_optionmenu_getactivetext(((ULO **)om->vars)[n],((ULO **)om->vals)[n],om->texts[n]),optpos,n+3+yadjust);
                        else gui_plot_text_window_reverse(om->w,gui_optionmenu_getactivetext(((ULO **)om->vars)[n],((ULO **)om->vals)[n],om->texts[n]),optpos,n+3+yadjust);
                        break;
                }
}

void gui_optionmenu_print(struct gui_optionmenu *om, ULO activeitem) {
        ULO itemcount = gui_optionmenu_textcount(om->headers);
        ULO itemmaxlen = gui_optionmenu_maxheadlen(om,itemcount);
        int yadjust = 0,j;

        if (om->topheader != NULL) gui_plot_text_window(om->w,om->topheader,1,1);
        else yadjust = -2;
        for (j = 0; j < itemcount; j++)
                gui_optionmenu_printitem(om, j, itemmaxlen, (j == activeitem) ? TRUE:FALSE, yadjust);
}

void gui_optionmenu_selection(struct gui_optionmenu *om, ULO activeitem, ULO dirflag) {
        if (om->actions[activeitem] == GUI_VALUELIST) {
                ULO numberofvals = gui_optionmenu_textcount(om->texts[activeitem]);
                int activeval = gui_optionmenu_getactivevalue(((ULO **)om->vars)[activeitem],((ULO **)om->vals)[activeitem],numberofvals);

                switch (dirflag) {
                        case GUI_OPTIONMENU_DEC:
                                activeval--;
                                if (activeval == -1)
                                        activeval = numberofvals - 1;
                                break;
                        case GUI_OPTIONMENU_INC:
                                activeval++;
                                if (activeval >= numberofvals)
                                        activeval = 0;
                                break;
                        }
                *(((ULO **)om->vars)[activeitem]) = (((ULO **)om->vals)[activeitem])[activeval];
                }
        else if (om->actions[activeitem] == GUI_FILEREQ_ADF){
                dt_selectfile(om->w, "ADF", ((char **)om->vars)[activeitem]);
                }
        else if (om->actions[activeitem] == GUI_FILEREQ_ROM){
                dt_selectfile(om->w, "ROM", ((char **)om->vars)[activeitem]);
                }
        else if (om->actions[activeitem] == GUI_FILEREQ_HDF){
                dt_selectfile(om->w, "*"  /*"HDF"*/, ((char **)om->vars)[activeitem]);
                }
}

int gui_optionmenu_test_shortcuts(struct gui_optionmenu *om, int c, int numberofentries) {
  int i;

  for (i = 0; i < numberofentries; i++) 
    if (toupper(c) == toupper(om->headers[i][om->shortcuts[i]])) return i;
  return -1;
}

int gui_menu_testfastkeys( int c ) {

  if (c == 63) {      /* F5: Soft Reset */
    strcpy( &menupos_want1, &menupos_act );
    strcpy( &menupos_want0, "/Soft Reset/" );
    menupos_act[0] = 0;
    return 1;
  }
  if (c == 65) {      /* F7: Hard Reset */
    strcpy( &menupos_want1, &menupos_act );
    strcpy( &menupos_want0, "/Hard Reset/" );
    menupos_act[0] = 0;
    return 1;
  }
  if (c == 67) {      /* F9: Run */
    strcpy( &menupos_want1, &menupos_act );
    strcpy( &menupos_want0, "/Run/" );
    menupos_act[0] = 0;
    return 1;
  }
  if (c == 133) {      /* F11: Debugger */
    strcpy( &menupos_want0, "/Debugger/" );
    menupos_act[0] = 0;
    return 1;
  }
  if (c == 32) {      /* Alt-D: Floppy disk settings */
    strcpy( &menupos_want0, "/Configuration/Disk/" );
    menupos_act[0] = 0;
    return 1;
  }
  if (c == 33) {      /* Alt-F: Frame rate settings */
    strcpy( &menupos_want0, "/Configuration/Screen/Frame-skip ratio:" );
    menupos_act[0] = 0;
    return 1;
  }
  if (c == 35) {      /* Alt-H: Hardfile settings */
    strcpy( &menupos_want0, "/Configuration/Hardfile/" );
    menupos_act[0] = 0;
    return 1;
  }
  if (c == 36) {      /* Alt-J: Joystick settings */
    strcpy( &menupos_want0, "/Configuration/Various/Joystick Port 1:" );
    menupos_act[0] = 0;
    return 1;
  }
  if (c == 38) {      /* Alt-L: LED emulation settings */
    strcpy( &menupos_want0, "/Configuration/Various/Power,Floppy LEDs:" );
    menupos_act[0] = 0;
    return 1;
  }
  if (c == 50) {      /* Alt-M: Memory settings */
    strcpy( &menupos_want0, "/Configuration/Memory/" );
    menupos_act[0] = 0;
    return 1;
  }
  if (c == 31) {      /* Alt-S: Sound settings */
    strcpy( &menupos_want0, "/Configuration/Sound/" );
    menupos_act[0] = 0;
    return 1;
  }
  if (c == 19) {      /* Alt-R: Resolution settings */
    strcpy( &menupos_want0, "/Configuration/Screen/Resolution:" );
    menupos_act[0] = 0;
    return 1;
  }
  return 0;
}


void gui_optionmenu_run(struct gui_optionmenu *om) {
  ULO activeitem = 0, c, ended = FALSE,
      numberofitems = gui_optionmenu_textcount(om->headers);
  int scut, tmp1 = 0;
  char *tmps;
  char tmps2[20];

  if( strlen( &menupos_want0 ) ) {
    while( strcmpi( om->headers[tmp1], &menupos_want0 ) && tmp1 < numberofitems )
      tmp1++;
      if( tmp1 < numberofitems )
         activeitem = tmp1;
      menupos_want0[0] = 0;
      menupos_want1[0] = 0; // stops also any other wanted path
      }

  strcat( &menupos_act, "/" );
  strcat( &menupos_act, om->headers[activeitem] );
  gui_clearwindow(om->w,TRUE);
  gui_printwindowborders(om->w);
  while (!ended) {
    tmps = (char *)strrchr( &menupos_act, '/' );
    tmps[0] = 0;
    strcat( &menupos_act, "/" );
    strcat( &menupos_act, om->headers[activeitem] );
    gui_optionmenu_print(om,activeitem);
    c = getch();
    if ((scut = gui_optionmenu_test_shortcuts(om, c, numberofitems)) != -1) {
      activeitem = scut;
      }
    if (c == 27) {
      tmps = (char *)strrchr( &menupos_act, '/' );
      tmps[0] = 0;
      tmps = (char *)strrchr( &menupos_act, '/' );
      tmps[0] = 0;
      ended = TRUE;
      }
    if (c == 17) {              /* Ctrl-Q */
      exitflag = TRUE;
      ended = TRUE;
      }
    else if (c == 13)
      gui_optionmenu_selection(om, activeitem, GUI_OPTIONMENU_INC);
    else if (c == 0) {
      c = getch();
      if (c == 45) {      /* Alt-X */
        exitflag = TRUE;
        ended = TRUE;
        }
      if ( gui_menu_testfastkeys( c ) ) ended = TRUE;
        if (c == 72) {      /* Up */
          if (activeitem > 0) activeitem--;
          else activeitem = numberofitems - 1;
          }
        else if (c == 80) { /* Down */
          if (activeitem < (numberofitems-1)) activeitem++;
          else activeitem = 0;
          }
        else if (c == 75)   /* Left */
          gui_optionmenu_selection(om, activeitem, GUI_OPTIONMENU_DEC);
        else if (c == 77)   /* Right */
          gui_optionmenu_selection(om, activeitem, GUI_OPTIONMENU_INC);
        else if (c == 71 || c == 73) { /* Home & PageUp */
          activeitem = 0;
          }
        else if (c == 79 || c == 81) { /* End & PageDown */
          activeitem = numberofitems - 1;
          }
        else if( c > 119 && c < 130 ) { // Alt-n (disk memory records)
          if (om->actions[activeitem] == GUI_FILEREQ_ADF || om->actions[activeitem] == GUI_FILEREQ_HDF || om->actions[activeitem] == GUI_FILEREQ_ROM) {
            if( strcmpi( memnames[c-120], "__None__" ) ) {
              strcpy(((char **)om->vars)[activeitem], memnames[c-120] );
              if( activeitem < config_altn_loop ) activeitem++;
              else activeitem = 0;
              gui_clearwindow(om->w,FALSE);
              if( config_autorun & 1 ) {
                tmps = (char *)strrchr( &menupos_act, '/' );
                tmps[0] = 0;
                strcat( &menupos_act, "/" );
                strcat( &menupos_act, om->headers[activeitem] );
                strcpy( &menupos_want1, &menupos_act );
                strcpy( &menupos_want0, "/Run/" );
                menupos_act[0] = 0;
                ended = TRUE;
                }
              }
            }
          }
        else if (c == 82) { /* Ins */
          if (om->actions[activeitem] == GUI_FILEREQ_ADF || om->actions[activeitem] == GUI_FILEREQ_HDF || om->actions[activeitem] == GUI_FILEREQ_ROM)
            gui_optionmenu_selection(om, activeitem, GUI_OPTIONMENU_INC);
          }
        else if (c == 83) { /* Del */
          if (om->actions[activeitem] == GUI_FILEREQ_ADF || om->actions[activeitem] == GUI_FILEREQ_HDF || om->actions[activeitem] == GUI_FILEREQ_ROM) {
            int stopit = FALSE, actitem2 = activeitem;
            strcpy(((char **)om->vars)[activeitem], "__None__");
            while((actitem2 + 1) < numberofitems && om->actions[actitem2 + 1] == GUI_FILEREQ_ADF && !stopit)
              if (strcmp(((char **)om->vars)[++actitem2], "__None__" )) {
                activeitem++;
                stopit = TRUE;
                }
             gui_clearwindow(om->w,FALSE);
             }
           }
         }
       }
   gui_clearwindow(om->w,FALSE);
}

/* Menus */

/* Prints the menu in the associated window */
void gui_menu_print(struct gui_menu *m) {
        int y = 0, x, width;

        width = m->w->x2 - m->w->x1;
        while (m->entrytext[y] != NULL) {
                x = ((width - strlen(m->entrytext[y]))/2) + 1;
                if (m->activeentry == y)
                        gui_plot_text_window_reverse_shortcut(m->w,m->entrytext[y],x,y+1,m->shortcuts[y]);
                else
                        gui_plot_text_window_shortcut(m->w,m->entrytext[y],x,y+1,m->shortcuts[y]);
                y++;
                }
}

/* Count number of entries in a menu */

ULO gui_menu_numberofentries(struct gui_menu *m) {
        ULO i = 0;

        while (m->entrytext[i] != NULL) i++;
        return i;
}

int gui_menu_test_shortcuts(struct gui_menu *m, int c, int numberofentries) {
        int i;

        for (i = 0; i < numberofentries; i++) {
                if (toupper(c) == toupper(m->entrytext[i][m->shortcuts[i]]))
                        return i;
                }
        return -1;
}

/* Waits for a selection and returns the entry position */

ULO gui_menu_select(struct gui_menu *m) {
        int c,selection = -1,numberofentries = gui_menu_numberofentries(m);
        int scut,tmp1,arun = 0;
        char *tmps;
        char tmps2[128];

        if( strlen( menupos_want0 ) ) {
          if( menupos_want0[0] == '/' ) {
            if( strcmpi( m->entrytext[0], "Run" ) ) {
              arun = 27;
              menupos_act[0] = 0;
            } else {
              strcpy( &tmps2, &menupos_want0[1] );
              strcpy( &menupos_want0, &tmps2 );
            };
          }
          if( menupos_want0[0] != '/' ) {
            strcpy( tmps2, menupos_want0 );
            if( ( tmps = (char *)strchr( tmps2, '/' ) ) ) {
              if( strlen( tmps ) > 1 ) strcpy( menupos_want0, &tmps[1] );
              else menupos_want0[0] = 0;
              tmps[0] = 0; arun = 13;
            } else menupos_want0[0] = 0;
            tmp1 = 0;
            while( strcmpi( m->entrytext[tmp1], tmps2 ) && tmp1 < numberofentries )
              tmp1++;
            if( tmp1 < numberofentries )
              m->activeentry = tmp1;
          }
        }
        if( !arun )
          if( !strlen( &menupos_want0 ) && strlen( &menupos_want1 ) ) {
            strcpy( &menupos_want0, &menupos_want1 );
            menupos_want1[0] = 0;
            arun = 26;
          }
        strcat( menupos_act, "/" );
        strcat( menupos_act, m->entrytext[m->activeentry] );
        gui_menu_print(m);
        while (selection == -1) {
                if( ( tmps = (char *)strrchr( menupos_act, '/' ) ) != NULL ) {
                  tmps[0] = 0;
                } else {
                  menupos_act[0] = 0;
                }
                strcat( menupos_act, "/" );
                strcat( menupos_act, m->entrytext[m->activeentry] );
                if( !arun ) c = getch();
                else {
                  c = arun;
                  arun = 0;
                };
                if ((scut = gui_menu_test_shortcuts(m, c, numberofentries)) != -1) {
                        m->activeentry = scut;
                        c = 13;
                        if( ( tmps = (char *)strrchr( menupos_act, '/' ) ) != NULL ) {
                          tmps[0] = 0;
                        } else {
                          menupos_act[0] = 0;
                        }
                        strcat( menupos_act, "/" );
                        strcat( menupos_act, m->entrytext[m->activeentry] );
                        }
                if (c == 27 || c == 26) {   /* Esc & Sub-Esc */
                  if( ( tmps = (char *)strrchr( menupos_act, '/' ) ) != NULL ) {
                    tmps[0] = 0;
                  } else {
                    menupos_act[0] = 0;
                  }
                  if( ( tmps = (char *)strrchr( menupos_act, '/' ) ) != NULL ) {
                    tmps[0] = 0;
                  } else {
                    menupos_act[0] = 0;
                  }
                  if( c == 27 ) return 99999; else return 99998;
                  }
                if (c == 17) {              /* Ctrl-Q */
                  exitflag = TRUE;
                  return 99999;
                } else if (c == 0) {
                        c = getch();
                        if (c == 45) {      /* Alt-X */
                          exitflag = TRUE;
                          return 99999;
                        }
                        if( gui_menu_testfastkeys( c ) ) return 99998;
                        if (c == 72) {      /* Up */
                                if (m->activeentry > 0) {
                                        m->activeentry--;
                                        }
                                else m->activeentry = numberofentries - 1;
                                gui_menu_print(m);
                                }
                        else if (c == 80) { /* Down */
                                if (m->activeentry < (numberofentries-1)) {
                                        m->activeentry++;
                                        }
                                else m->activeentry = 0;
                                gui_menu_print(m);
                                }
                        else if (c == 71 || c == 73) { /* Home & PageUp */
                                m->activeentry = 0;
                                gui_menu_print(m);
                                }
                        else if (c == 79 || c == 81) { /* End & PageDown */
                                m->activeentry = numberofentries - 1;
                                gui_menu_print(m);
                                }
                        }
                if (c == 13) selection = m->activeentry;
                }
        return selection;
}

/* Init a menu stucture */

void gui_initmenu(struct gui_menu *m,char *entries[],ULO activeentry,struct gui_window *w,UBY *shortcuts) {
        m->entrytext = entries;
        m->activeentry = activeentry;
        m->w = w;
        m->shortcuts = shortcuts;
}

/* Initialize a window structure */

void gui_initwindow(struct gui_window *w,UBY x1, UBY x2, UBY y1, UBY y2, UBY bgcolor, UBY fgcolor, UBY shortcutcolor, UBY reversecolor, UBY cornerflags) {
        w->x1 = x1;
        w->x2 = x2;
        w->y1 = y1;
        w->y2 = y2;
        w->bgcolor = bgcolor;
        w->fgcolor = fgcolor;
        w->shortcutcolor = shortcutcolor;
        w->reversecolor = reversecolor;
        w->cornerflags = cornerflags;
}

/* Fill disk memories with dummy defs */

void gui_clear_memnames(void) {
        int i;

        for( i = 0; i < 10; i++ )
          strcpy( memnames[i], "__None__" );
}

/* Will set a textscreen, hide the cursor and no wrap */

void gui_setupscreen(void) {
        _setvideomode(_TEXTC80);
        _displaycursor(_GCURSOROFF);
        _wrapon(_GWRAPOFF);
}

/* Will set a textscreen */

void gui_closescreen(void) {
        _setvideomode(_TEXTC80);
        _displaycursor(_GCURSORON);
        _wrapon(_GWRAPON);
}

